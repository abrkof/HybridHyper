<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Paises;
use App\Models\Departamentos;
use App\Models\Municipios;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class UserController extends Controller{

    public function index(){
        $query = DB::select( DB::raw("SELECT municipios.*, departamentos.depto as 'depto_name', paises.pais as 'pais_name'
										FROM municipios
										LEFT JOIN departamentos ON (municipios.depto_id = departamentos.id)
										LEFT JOIN paises ON (departamentos.pais_id = paises.id)
										WHERE departamentos.id = '1'"));
        //return response()->json($users);
        //return json_encode($users);
        //dd($users);
        //return view('users.index', ['users'=>$users]);
		
		$users = array();
		foreach($query as $registro){
			/*$users[] = array(
				'id'=> '1',
				'name'=> 'name'
			);*/
			$users["users"][] = $registro;
		}		
		echo json_encode($users);
    }

    public function create(){
        return view('users.create');
    }

    public function store(Request $request){
        $user = new User();

        $user->id = $request->input('id');
        $user->name = $request->input('name');

        $user->save();
        
        return response()->json(['user'=>$user], 201);

        
        //$input = $request->all();
        //$user = user::create($input);
        

        redirect()->route('users');
    }

    public function show($id){
        //
    }

    public function edit($id){
        //
    }

    public function update(Request $request, $id){
        //
    }

    public function destroy($id){
        //
    }/**/

    public function postUser(Request $request){
        $user = new User();

        //for($i=0;$i<10; $i++){}

        //$user->id = $request->input('id');
        $user->name = $request->input('name');

        $user->save(); 
        
        return response()->json(['users'=>$user], 201);

    }/**/

    public function getUsers(){
        $users = User::all();
        $response = [
            'users'=>$users
        ];

        return response()->json($response, 200);
    }
	
    public function getLugar(Request $request, $id){
        //$user = User::find($id);
		$lugar = DB::select( DB::raw("SELECT municipios.*, departamentos.depto as 'depto_name', paises.pais as 'pais_name'
										FROM municipios
										LEFT JOIN departamentos ON (municipios.depto_id = departamentos.id)
										LEFT JOIN paises ON (departamentos.pais_id = paises.id)
										WHERE departamentos.id = '$id'"));
        $response = [
            'lugar'=>$lugar
        ];
		
		return response()->json($response, 200);
    }

    public function putUser(Request $request, $id){
        $user = User::find($id);
        if (!$user){
            return response()->json(['message'=>'Document not found'], 404);
        }

        $user->name = $request->input('name');

        $user->save();

        return response()->json(['user'=>$user], 200);
    }

    public function deleteUser($id){
        $user = User::find($id);
        $user->delete();
        
        return response()->json(['message'=>'User Delete'], 200);
    }

}
