<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Paises extends Model{
    public $table = 'paises';
}
