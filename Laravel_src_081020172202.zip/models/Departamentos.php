<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Departamentos extends Model{
    public $table = 'departamentos';
}
