<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/insert', [
'uses' => 'UsuarioController@insert',
'as' => 'insert'
]);

Route::get('/user', function (Request $request){
    return $request->user();
})->middleware('auth:api');*/

/*Route::prefix('api')
    ->middleware('api')
    ->as('api.')
    ->namespace($this->namespace."\\API")
    ->group(base_path('routes/api.php'));*/

Route::post('/user', 'UserController@postUser');
Route::get('/users', 'UserController@getUsers');
Route::get('/lugar/{id}', 'UserController@getLugar');
Route::put('/user/{id}', 'UserController@putUser');
Route::delete('/user/{id}', 'UserController@deleteUser');/**/
