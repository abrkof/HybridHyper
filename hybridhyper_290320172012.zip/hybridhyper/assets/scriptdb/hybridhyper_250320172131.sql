﻿create database hybridhyper;
use hybridhyper;

--
-- Base de datos: `hybridhyper`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_estudiante`
--

CREATE TABLE IF NOT EXISTS `datos_estudiante` (
  `id_dat_est` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `apellidos` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `genero` varchar(15) COLLATE utf8_spanish2_ci NOT NULL,
  `fecha_nacimiento` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `created` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id_dat_est`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `datos_estudiante`
--

INSERT INTO `datos_estudiante` (`id_dat_est`, `nombres`, `apellidos`, `genero`, `fecha_nacimiento`, `created`, `updated`) VALUES
(1, 'Carlos Abraham', 'Ayala Herrera', '1', '2015-10-11', '2015/10/14 22:54:31', '2015/12/24 05:12:00'),
(2, 'Einspringt Hellsengberm', 'Root Fraunlensky', '1', '2015-10-11', '2015/10/12 00:43:00', '2015/10/12 00:43:00'),
(3, 'Glenda Yamileth', 'Garcia Linares', '2', '2015-10-11', '2015/10/12 00:43:00', '2015/10/12 00:43:00'),
(4, 'Raúl Alejandro', 'Yipi Care Vega', '2', '2015-10-11', '2015/10/12 00:43:00', '2017/03/26 03:17:00'),
(5, 'Reyna Morena', 'Noze', '2', '2015-10-11', '2015/10/12 00:44:00', '2015/11/15 12:24:48'),
(6, 'Stephanie Yamileth', 'Alvarado Gonzales', '2', '2015-10-12', '2015/10/12 20:33:47', '2015/10/12 20:33:47');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupo`
--

CREATE TABLE IF NOT EXISTS `grupo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` varchar(25) COLLATE utf8_spanish2_ci NOT NULL,
  `created` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `grupo`
--

INSERT INTO `grupo` (`id`, `name`, `descripcion`, `created`, `updated`) VALUES
(1, 'Sonsonate', 'Gerencia', '2015/10/29 21:47:15', '2016/05/22 09:06:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupo_usuario`
--

CREATE TABLE IF NOT EXISTS `grupo_usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `grupo_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `descripcion` varchar(25) COLLATE utf8_spanish2_ci NOT NULL,
  `created` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `grupo_id` (`grupo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `grupo_usuario`
--

INSERT INTO `grupo_usuario` (`id`, `name`, `grupo_id`, `usuario_id`, `descripcion`, `created`, `updated`) VALUES
(1, 'Gerencia', 1, 1, 'CRUD del Sistema', '2015/10/29 21:47', '2015/11/25 14:30:21'),
(2, 'Gerencia', 1, 12, 'Gerencia', '2016/04/24 21:55', '2016/04/24 21:55');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `controlador` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `accion` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `url` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `orden` char(5) COLLATE utf8_spanish2_ci NOT NULL,
  `icon` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish2_ci NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `menu`
--

INSERT INTO `menu` (`id`, `menu`, `controlador`, `accion`, `url`, `orden`, `icon`, `descripcion`, `created`, `updated`) VALUES
(1, 'Inicio', 'admin', 'index/', '#', '1', '', 'Principal', '2015/11/23 22:12:31', '2015/12/20 18:57:40'),
(2, 'Datos Estudiantes', 'datos_estudiante', '', '#', '1', '', 'Registro de Estudiantes', '2015/11/23 22:13:24', '2015/12/21 22:09:37'),
(3, 'Menús', 'menu', '', '#', '2', '', 'Registro de Menús', '2015/11/23 22:15:06', '2015/11/23 22:15:06'),
(5, 'Perfiles', 'perfil', '', '#', '4', '', 'Registro de Perfiles', '2015/11/23 22:17:27', '2015/11/23 22:17:27'),
(6, 'Sub Menús', 'submenu', '', '#', '5', '', 'Registro de Sub Menús', '2015/11/23 22:18:44', '2015/11/23 22:18:44'),
(7, 'Usuarios', 'usuario', '', '#', '6', '', 'Registro de Usuarios', '2015/11/23 22:19:31', '2015/11/23 22:19:31'),
(8, 'Acerca De', 'admin', 'acerca_de/', '#', '7', '', 'Acerca De', '2015/11/23 22:20:30', '2015/12/20 19:06:25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu_perfil`
--

CREATE TABLE IF NOT EXISTS `menu_perfil` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `perfil_id` (`perfil_id`),
  KEY `menu_id` (`menu_id`),
  KEY `menu_id_2` (`menu_id`),
  KEY `perfil_id_2` (`perfil_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `menu_perfil`
--

INSERT INTO `menu_perfil` (`id`, `menu_id`, `perfil_id`, `created`, `updated`) VALUES
(2, 3, 1, '2015/11/24 12:29:25', '2015/11/24 12:29:25'),
(4, 5, 1, '2015/11/24 12:29:47', '2015/11/24 12:29:47'),
(5, 6, 1, '2015/11/24 12:29:59', '2015/11/24 12:29:59'),
(6, 7, 1, '2015/11/24 12:30:18', '2015/11/24 12:30:18'),
(8, 8, 2, '2015/11/24 12:30:35', '2015/12/02 05:37:08'),
(27, 8, 1, '2016/03/13 19:51:22', '2016/03/13 19:51:22'),
(31, 1, 1, '2016/03/27 07:01:54', '2016/03/27 07:01:54');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu_perfil_vistas`
--

CREATE TABLE IF NOT EXISTS `menu_perfil_vistas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `created` char(19) NOT NULL,
  `updated` char(19) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  KEY `perfil_id` (`perfil_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `menu_perfil_vistas`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil`
--

CREATE TABLE IF NOT EXISTS `perfil` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perfil` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish2_ci NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `perfil`
--

INSERT INTO `perfil` (`id`, `perfil`, `descripcion`, `created`, `updated`) VALUES
(1, 'Administrador', 'Perfil Principal', '2015/10/13 19:26:22', '2015/10/16 14:01:56'),
(2, 'Reportes', 'Generación de Reportes', '2015/10/13 19:26:22', '2015/11/22 21:42:35'),
(3, 'Restricción', 'Perfil Restringido', '2015/10/13 19:26:22', '2015/11/22 21:42:48');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones`
--

CREATE TABLE IF NOT EXISTS `sesiones` (
  `id` float NOT NULL AUTO_INCREMENT,
  `usuario_id` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `ip` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `Date` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `Latitude` float NOT NULL DEFAULT '0',
  `Longitude` float NOT NULL DEFAULT '0',
  `ZoneTime` varchar(100) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '',
  `entrada` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `salida` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `sesiones`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones_temp`
--

CREATE TABLE IF NOT EXISTS `sesiones_temp` (
  `id` float NOT NULL AUTO_INCREMENT,
  `usuario_id` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `estado` char(1) COLLATE utf8_spanish2_ci NOT NULL,
  `ip` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `Date` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `Latitude` float NOT NULL DEFAULT '0',
  `Longitude` float NOT NULL DEFAULT '0',
  `ZoneTime` varchar(100) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '',
  `entrada` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `salida` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `sesiones_temp`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `submenu`
--

CREATE TABLE IF NOT EXISTS `submenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submenu` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `menu_id` int(11) NOT NULL,
  `controlador` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `accion` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `url` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `orden` char(5) COLLATE utf8_spanish2_ci NOT NULL,
  `icon` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish2_ci NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `submenu`
--

INSERT INTO `submenu` (`id`, `submenu`, `menu_id`, `controlador`, `accion`, `url`, `orden`, `icon`, `descripcion`, `created`, `updated`) VALUES
(1, 'Consultar Menús', 3, 'menu', '', '#', '1', '', 'Consultar Menús', '2015/11/26 00:07:08', '2015/12/20 19:00:34'),
(2, 'Seguridad (Menús)', 3, 'menu_perfil', '', '#', '2', '', 'Seguridad (Menús)', '2015/11/26 00:09:46', '2015/12/12 00:07:39'),
(3, 'Ordenar Menús', 3, 'menu', 'menu_ordenar/', '#', '3', '', 'Ordenar Menús', '2015/11/26 00:11:24', '2015/12/20 18:59:33'),
(6, 'Consultar Sub Menús', 6, 'submenu', '', '#', '6', '', 'Consultar Sub Menús', '2015/11/26 19:23:08', '2015/11/26 19:23:08'),
(7, 'Ordenar Sub Menús', 6, 'submenu', 'submenu_ordenar/', '#', '7', '', 'Ordenar Sub Menús', '2015/11/26 19:24:06', '2015/12/20 18:59:58');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `submenu_perfil`
--

CREATE TABLE IF NOT EXISTS `submenu_perfil` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submenu_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `perfil_id` (`perfil_id`),
  KEY `submenu_id_2` (`submenu_id`),
  KEY `perfil_id_2` (`perfil_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `submenu_perfil`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `submenu_perfil_vistas`
--

CREATE TABLE IF NOT EXISTS `submenu_perfil_vistas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submenu_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `created` char(19) NOT NULL,
  `updated` char(19) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `submenu_id` (`submenu_id`),
  KEY `perfil_id` (`perfil_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `submenu_perfil_vistas`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `apellidos` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `login` varchar(11) COLLATE utf8_spanish2_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `image` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `created` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `perfil_id` (`perfil_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=0 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombres`, `apellidos`, `login`, `password`, `email`, `perfil_id`, `image`, `created`, `updated`) VALUES
(1, 'Charles Ansengbernhem', 'Ayla Hero', 'abrkof', '0cc175b9c0f1b6a831c399e269772661', 'abraham_kof@hotmail.com', 1, '', '2015/10/16 00:44', '2017/03/21 00:54:43'),
(12, 'Einspringt Hellsengberm', 'Root Fraunlensky', 'fantomghost', '0cc175b9c0f1b6a831c399e269772661', 'abrkof@gmail.com', 2, '', '2015/11/23 23:28:43', '2015/11/24 11:30:29');

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `grupo_usuario`
--
ALTER TABLE `grupo_usuario`
  ADD CONSTRAINT `grupo_usuario_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  ADD CONSTRAINT `grupo_usuario_ibfk_3` FOREIGN KEY (`grupo_id`) REFERENCES `grupo` (`id`);

--
-- Filtros para la tabla `menu_perfil`
--
ALTER TABLE `menu_perfil`
  ADD CONSTRAINT `menu_perfil_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`),
  ADD CONSTRAINT `menu_perfil_ibfk_2` FOREIGN KEY (`perfil_id`) REFERENCES `perfil` (`id`);

--
-- Filtros para la tabla `menu_perfil_vistas`
--
ALTER TABLE `menu_perfil_vistas`
  ADD CONSTRAINT `menu_perfil_vistas_ibfk_1` FOREIGN KEY (`perfil_id`) REFERENCES `perfil` (`id`),
  ADD CONSTRAINT `menu_perfil_vistas_ibfk_2` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`);
