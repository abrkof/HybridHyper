﻿<?php
//date_default_timezone_set('UTC');
#Fecha de creación: 11/10/2015.
#Desarrolador : Carlos Abraham Ayala Herrera
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2003 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2003 - 2015, ABRKOF. (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */
/*
 *---------------------------------------------------------------
 * Aplicación de entorno (ENVIRONMENT)
 *---------------------------------------------------------------
 *
 * Puede cargar diferentes configuraciones en función de su
 * entorno actual. Los ajustes del entorno también influye
 * en cosas como el logeo y el informe de errores.
 *
 * Se puede ajustar a cualquier necesidad, pero el uso por defecto es:
 *
 *     development
 *     testing
 *     production
 *
 * NOTA: Si cambias esto, también debes cambiar el código de error_reporting() de debajo.
 
 *
 */
	define('ENVIRONMENT', isset($_SERVER['CI_ENV']) ? $_SERVER['CI_ENV'] : 'production');

/*
 *---------------------------------------------------------------
 * REPORSTES DE ERROR
 *---------------------------------------------------------------
 *
 * Diferentes entornos requieren diferentes niveles de informe de errores.
 * Por defecto development mostrará los errores, pero las testing y live los ocultaran.
 */
switch (ENVIRONMENT){
	case 'development':
		error_reporting(-1);
		ini_set('display_errors', 1);
	break;

	case 'testing':
	case 'production':
		ini_set('display_errors', 0);
		if (version_compare(PHP_VERSION, '5.3', '>=')){
			error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT & ~E_USER_NOTICE & ~E_USER_DEPRECATED);
		} else {
			error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_USER_NOTICE);
		}
	break;

	default:
		header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
		echo 'The application environment is not set correctly.';
		exit(1); // EXIT_ERROR
}

/*
 *---------------------------------------------------------------
 * NOMBRE DE LA CARPETA DEl  NÚCLEO Ó SISTEMA
 *---------------------------------------------------------------
 *
 * Esta variable debe contener el nombre de la carpeta "system".
 * Incluya la vía de acceso (path) si la carpeta no está en el mismo directorio
 * como en la linea de código siguiente.
 *
 */
	$system_path = 'system';

/*
 *---------------------------------------------------------------
 * NOMBRE DE LA CARPETA DE LA APLICACIÓN
 *---------------------------------------------------------------
 *
 * Si desea que este controlador principal utilice un nombre diferente de "application",
 * entonces el valor predeterminado lo puede configurar con otro nombre aqui. La carpeta
 * también se puede renombrar o reubicado en cualquier lugar de su servidor.  Si lo hace,
 * utilice la ruta completa del servidor. Para mas información vaya al manual de usuario en:
 * http://www.abrkof.org/manual/general/gestion_app.php
 *
 * NO UTLIZAR BARRA INVERTIDA AL FINAL ("/")
 *
 */
	$application_folder = 'application';

  /*Tambien puede utilizar las siguientes variables.
  */
	$views_folder = 'application/views';
	$helpers_folder = 'application/helpers';
	$models_folder = 'application/models';
	
	$css_folder = 'assets';
	$js_folder = 'assets';

	/*Customs: define('var', var);
	define — Define una constante con nombre.
	Define una constante con nombre en tiempo de ejecución.
	*/
	define('DS', DIRECTORY_SEPARATOR);
	define('PATH', realpath(dirname(__FILE__)).DS);
	define('APP_PATH', PATH.'application'.DS);
	define('BASE_PATH', PATH.'system'.DS.'core'.DS);
	
	$view_folder = '';


/*
 * --------------------------------------------------------------------
 * DEFAULT CONTROLLER
 * --------------------------------------------------------------------
 *
 * Normally you will set your default controller in the routes.php file.
 * You can, however, force a custom routing by hard-coding a
 * specific controller class/function here. For most applications, you
 * WILL NOT set your routing here, but it's an option for those
 * special instances where you might want to override the standard
 * routing in a specific front controller that shares a common CI installation.
 *
 * IMPORTANT: If you set the routing here, NO OTHER controller will be
 * callable. In essence, this preference limits your application to ONE
 * specific controller. Leave the function name blank if you need
 * to call functions dynamically via the URI.
 *
 * Un-comment the $routing array below to use this feature
 */
	// The directory name, relative to the "controllers" folder.  Leave blank
	// if your controller is not in a sub-folder within the "controllers" folder
	// $routing['directory'] = '';

	// The controller class file name.  Example:  mycontroller
	// $routing['controller'] = '';

	// The controller function you wish to be called.
	// $routing['function']	= '';


/*
 * --------------------------------------------------------------------
 * CONTROLADOR POR DEFECTO
 * --------------------------------------------------------------------
 *
 * Normalmente puede setear el nombre del controlador en el archivo routes.php,
 * ubicado en 'application/config/routes.php'
 *
 * IMPORTANT:  Si configura el enrutamiento aquí, ningún otro controlador sera
 * exigible. En esencia, esta preferencia limita su aplicación a UN
 * controlador específico. Deje el nombre de la función en blanco si usted necesita
 * llamar a funciones de forma dinámica a través de la URL.
 *
 */

// --------------------------------------------------------------------
// FIN DE LAS OPCIONES CONFIGURABLES POR EL USUARIO. NO EDITAR BAJO DE ESTA LINEA
// --------------------------------------------------------------------

/*
 * ---------------------------------------------------------------
 *  Resolver la ruta del sistema para una mayor fiabilidad
 * ---------------------------------------------------------------
 */


	// Set the current directory correctly for CLI requests
	// Establezca el directorio actual correctamente para las solicitudes de carga de directorios
	if (defined('STDIN')){
		chdir(dirname(__FILE__));
	}

	if (($_temp = realpath($system_path)) !== FALSE){
		$system_path = $_temp.'/';
	} else {
		// Ensure there's a trailing slash
		$system_path = rtrim($system_path, '/').'/';
	}

	// Is the system path correct?
	if ( ! is_dir($system_path)){
		header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
		echo 'Su ruta de la carpeta del sistema no parece estar configurada correctamente. Por favor, abra el siguiente archivo y corregir este: '.pathinfo(__FILE__, PATHINFO_BASENAME);
		exit(3); // EXIT_CONFIG
	}

/*
 * -------------------------------------------------------------------
 *  Ahora que conocemos la ruta, establecemos las constantes de la ruta principal
 * -------------------------------------------------------------------
 */
	// El nombre de este archivo
	define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME));

	// Ruta hacia la carpeta del sistema
	define('BASEPATH', str_replace('\\', '/', $system_path));

	// Ruta al controlador principal (this file)
	define('FCPATH', dirname(__FILE__).'/');

	// Nombre de la carpeta "system"
	define('SYSDIR', trim(strrchr(trim(BASEPATH, '/'), '/'), '/'));

	// La ruta a la carpeta "application"
	if (is_dir($application_folder)){
		if (($_temp = realpath($application_folder)) !== FALSE){
			$application_folder = $_temp;
		}

		define('APPPATH', $application_folder.DIRECTORY_SEPARATOR);
	}
	else
	{
		if ( ! is_dir(BASEPATH.$application_folder.DIRECTORY_SEPARATOR))
		{
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo 'La ruta de la carpeta application no parece estar configurada correctamente. Por favor, abra el siguiente archivo y corregir este: '.SELF;
			exit(3); // EXIT_CONFIG
		}

		define('APPPATH', BASEPATH.$application_folder.DIRECTORY_SEPARATOR);
	}

	// Ruta de la carpeta "views"
	if (! is_dir($view_folder)){
		if (! empty($view_folder) && is_dir(APPPATH.$view_folder.DIRECTORY_SEPARATOR)){
			$view_folder = APPPATH.$view_folder;
		}
		elseif (! is_dir(APPPATH.'views'.DIRECTORY_SEPARATOR)){
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo 'La ruta de la carpeta views no parece estar configurada correctamente. Por favor, abra el siguiente archivo y corregir este: '.SELF;
			exit(3); // EXIT_CONFIG
		} else {
			$view_folder = APPPATH.'views';
		}
	}

	if (($_temp = realpath($view_folder)) !== FALSE){
		$view_folder = $_temp.DIRECTORY_SEPARATOR;
	} else {
		$view_folder = rtrim($view_folder, '/\\').DIRECTORY_SEPARATOR;
	}

	define('VIEWPATH', $view_folder);

	// Ruta de la carpeta "model"
	if (is_dir($models_folder)){
		define('MODELSPATH', $models_folder.'/');
	} else {
		if ( ! is_dir(BASEPATH.$models_folder.'/')){
			exit("La ruta de la carpeta models no parece estar configurada correctamente. Por favor, abra el siguiente archivo y corregir este: ".SELF);
		}

		define('MODELSPATH', BASEPATH.$models_folder.'/');
	}

	// Ruta de la carpeta "helpers"
	if (is_dir($helpers_folder)){
		define('MY_HELPERPATH', $helpers_folder.'/');
	} else {
		if ( ! is_dir(BASEPATH.$helpers_folder.'/')){
			exit("La ruta de la carpeta helpers no parece estar configurada correctamente. Por favor, abra el siguiente archivo y corregir este: ".SELF);
		}

		define('MY_HELPERPATH', BASEPATH.$helpers_folder.'/');
	}




/*
 * --------------------------------------------------------------------
 * CARGAR EL ARCHIVO DE ARRANQUE
 * --------------------------------------------------------------------
 *
 * Y allá vamos ...
 *
 */

require_once BASEPATH . 'core/Start.php';//Cargamos todas las librerias necesarias

/* End of file index.php */
/* Location: ./index.php */