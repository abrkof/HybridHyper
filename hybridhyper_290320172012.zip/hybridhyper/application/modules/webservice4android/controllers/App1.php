<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class App1 extends Controller{
    public function __construct(){
		parent::__construct();
		$this->model_app1 = $this->load->model('model_app1');
    }
    //Creamos una accion principal y cargamos las vistas
    public function home(){
        $data['titulo'] = 'Bienvenido';
		$data['contenido'] = 'view/index';
		$this->load->view('template/template',$data);
    }

	public function index(){
		if ($_SERVER['REQUEST_METHOD'] == 'GET') {
			//Manejar petici�n por GET
			$app1 = $this->model_app1->all();
			if ($app1) {
				$datos["estado"] = 1;
				$datos["metas"] = $app1;
				echo json_encode($datos);
			} else {
				echo json_encode(array(
					"estado" => 2,
					"mensaje" => "Ha ocurrido un error"
				));
			}
		}
	}

	public function insert(){
		if ($_SERVER['REQUEST_METHOD'] == 'POST'){
			//Decodificando el formato Json
			$body = json_decode(file_get_contents("php://input"), true);
			//Insertar meta
			$app1 = $this->model_app1->insert(
				$body['titulo'],
				$body['descripcion'],
				$body['fechaLim'],
				$body['categoria'],
				$body['prioridad']);
			if ($app1){
				//Mensaje de validaci�n
				echo json_encode(
					array(
						'estado' => '1',
						'mensaje' => 'Creaci�n �xitosa')
				);
			} else {
				//C�digo de falla
				echo json_encode(
					array(
						'estado' => '2',
						'mensaje' => 'Creaci�n fallida')
				);
			}
		}
	}

	public function prepare(){
		if ($_SERVER['REQUEST_METHOD'] == 'GET'){
			if (isset($_GET['idMeta'])){
				//Obtener par�metro idMeta
				$parametro = $_GET['idMeta'];
				//Obteniendo valores de retorno
				$app1 = $this->model_app1->allFiltered($parametro);
				if ($retorno){
					$meta["estado"] = "1";
					$meta["meta"] = $app1;
					//enviando el objeto json de la meta
					echo json_encode($meta);
				} else {
					//enviando el mensaje de error general
					echo json_encode(
						array(
							'estado' => '2',
							'mensaje' => 'No se obtuvo el registro'
						)
					);
				}
		
			} else {
				//enviando el mensaje de error
				echo json_encode(
					array(
						'estado' => '3',
						'mensaje' => 'Se necesita un identificador'
					)
				);
			}
		}
	}

	public function update(/*$id*/){
		if ($_SERVER['REQUEST_METHOD'] == 'POST'){
			//Decodificando el formato Json
			$body = json_decode(file_get_contents("php://input"), true);
			//Actualizar meta
			$app1 = $this->model_app1->update(
				$body['idMeta'],
				$body['titulo'],
				$body['descripcion'],
				$body['fechaLim'],
				$body['categoria'],
				$body['prioridad']);
			if ($app1){
				//C�digo de �xito
				echo json_encode(
					array(
						'estado' => '1',
						'mensaje' => 'Actualizaci�n �xitosa')
				);
			} else {
				//C�digo de falla
				echo json_encode(
					array(
						'estado' => '2',
						'mensaje' => 'Actualizaci�n fallida')
				);
			}
		}
	}

	public function delete(){
		if ($_SERVER['REQUEST_METHOD'] == 'POST'){
			//Decodificando formato Json
			$body = json_decode(file_get_contents("php://input"), true);
			$app1 = $this->model_app1->delete($body['idMeta']);
			if ($app1){
				echo json_encode(
					array(
						'estado' => '1',
						'mensaje' => 'Eliminaci�n exitosa')
				);
			} else {
				echo json_encode(
					array(
						'estado' => '2',
						'mensaje' => 'Eliminaci�n fallida')
				);
			}
		}
	}

}