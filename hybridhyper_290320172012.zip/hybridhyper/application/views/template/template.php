﻿<?php //error_reporting(0);?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<!--<meta charset="utf-8">-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('');?>assets/images/favicon.ico"/>
		<?php echo css('bootstrap.min');?>
		<?php echo css('bootstrap-responsive');?>
		<?php echo css('micss');?>
		<link href="<?php //echo base_url('css/amelia.css') ?>" rel="stylesheet" media="screen">
		<?php echo packstylecss('alertifyjs/css/alertify.min');?>
		<?php echo packstylecss('alertifyjs/css/themes/default.min');?>
		<?php echo packstylejs('alertifyjs/alertify.min');?>

		<?php echo packstylejs('jquery-ui/jquery-ui.min') ;?>
		<?php echo js('jquery-1.11.2.min') ;?>
		<?php echo css('modal') ;?>
		
		<?php echo css('saved_resource') ;?> <!-- id="all-css-0" -->
		<?php echo css('saved_resource(1)') ;?> <!-- id="all-css-2" -->
		
		<?php echo js('jquery.abrkof-validator') ;?>
		<title> <?php echo TITLE ;?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	</head>
<style type="text/css">
<!--
p{
border-top: 1px solid #EEEEEE;
margin-top: 0px; margin-bottom: 5px; padding-top: 5px;
}
.Estilo1x {
	color: #21759B;
	font-weight: bold;
}
.Titulox {
	color: #FFF;
	font-weight: bold;
}
.bs-docs-header{
background-color: #21759B;
}
body {
	background-image: url(grid-18px-masked.png);
}
-->
</style>
	<body data-twttr-rendered="true">
		<!-- Barra superior fija con opciones principales de menú -->
        <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="#"> <?php echo $titulo;?> </a>
					<div class="navbar-text pull-right">
                        <ul class="nav">
                            <?php //echo my_menu_ppalx(); ?>
                        </ul>
					</div>
                    <div class="nav-collapse collapse">
                        <ul class="nav">
							<?php echo my_menu_ppal();?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
<!--<div><h2><br></h2></div>
        <!-- Contenido dividos en 2, una parte izquierda para el menú, una parte central para las vistas -->
		<div class="container-fluid">
            <div class="row-fluid">
            	<!-- Menú del sistema -->
                <div class="span3">
                    <div class="well sidebar-nav">
                        <ul class="nav nav-list">
                            <!--<li class="nav-header"><i class="icon-globe"></i> Menú Público </li>
							<?php //echo my_menu_appx(); ?>-->
							<hr>
							<li class="nav-header">Menú Administrador</li>
							<?php //if ($this->session->get_userdata('perfil_id')<=6){ ?>
							<?php echo my_menu_ppal();?>
							<?php //echo my_menu_site(); ?>
							<hr>
							<?php //}else{?>
							<?php //if ($this->session->get_userdata('perfil_id')!==3){ ?>
							<!--<li class="nav-header"><i class="icon-globe"></i> Menú Restringido </li>
							<hr>-->
							<?php //} //} ?>
                        </ul>
                    </div>
                </div>
                <!-- Contenido de la aplicación -->
                <div class="span9">
					<?php $data = array('query'=>$query, 'registro'=>$registro, 'query_izq'=>$query_izq, 'query_der'=>$query_der,
							'menus'=>$menus, 'perfiles'=>$perfiles, 'submenus'=>$submenus, 'usuarios'=>$usuarios);?>
					
					<?php $this->load->view($contenido, $data);?>
					<?php $this->load->template('menu_usr');?>
                </div>
            </div>

			<!--<hr>-->

            <footer>
            	<p> &copy; By ABRKOF Copyright  2003 - <?php echo date ('Y') ;?> <br></p>
            </footer>
        </div>
		<p><?php echo DESCRIPTION; ?></p>
		<div align="center"><p><span class="Estilo1x">Versión del Núcleo </span><b><?php echo VERSION; ?></b></p></div>
		<div align="center"><p><span class="Estilo1x">FORK </span><b style="color:#CC0033;"><?php echo FORK; ?></b></p></div>
		<!--<script>alertify.success('Bienvendio <?php //echo '<br>'.$this->session->get_userdata('usuario'); ?>');</script>-->
		<?php //echo js('jquery');?>
		<?php echo js('bootstrap.min');?><br><br>
		<?php echo js('angular.min') ;?>
		<?php echo js('angular-animate.min') ;?>
		<?php echo js('v-modal') ;?>
		<?php echo js('v-modal-v') ;?>
	</body>
</html>