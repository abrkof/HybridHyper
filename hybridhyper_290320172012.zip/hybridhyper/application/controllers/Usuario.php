﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Usuario extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Usuario = $this->load->model('Model_Usuario');
		$this->usuariolib = $this->load->library('UsuarioLib');
    }

    public function index(){
		$data['titulo'] = 'Usuarios';
		$data['query'] = $this->Model_Usuario->all();
		$data['contenido'] = 'usuario/index';
		$this->load->view('template/template',$data);
    }

    public function create(){
		$data['titulo'] = 'Usuarios';
		$data['perfiles'] = $this->Model_Usuario->get_perfiles(); /* Lista de los Perfiles */
		$data['contenido'] = 'usuario/create';
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$count = $this->db->get('usuario');
		$n_e = $count + 1;
		$registro['id'] = $n_e;
		$registro['nombres'] = $_REQUEST['nombres'];
		$registro['apellidos'] = $_REQUEST['apellidos'];
		$registro['login'] = $_REQUEST['login'];
		$registro['password'] = $_REQUEST['password'];
		$registro['email'] = $_REQUEST['email'];
		$registro['perfil_id'] = $_REQUEST['perfil_id'];
		$registro['image'] = $_REQUEST['image'];
		$registro['created'] = date('Y/m/d H:i:s');
		$registro['updated'] = date('Y/m/d H:i:s');

		//Llamada al método de un objeto
		//if (call_user_func(array($this->usuariolib, 'my_validation')));

		$this->Model_Usuario->insert($registro);
		$this->Model_Usuario->passrecovery($registro);
			
		redirect('usuario');
    }

    public function edit($id){
		$data['titulo'] = 'Usuarios';
		$data['perfiles'] = $this->Model_Usuario->get_perfiles(); /* Lista de los Perfiles */
		$data['registro'] = $this->Model_Usuario->allFiltered($id);
		$data['contenido'] = 'usuario/edit';
		$this->load->view('template/template',$data);
    }
    
    public function update(){
		$registro['id'] = $_REQUEST['id'];
		$registro['nombres'] = $_REQUEST['nombres'];
		$registro['apellidos'] = $_REQUEST['apellidos'];
		$registro['login'] = $_REQUEST['login'];
		$registro['password'] = $_REQUEST['password'];
		$registro['email'] = $_REQUEST['email'];
		$registro['perfil_id'] = $_REQUEST['perfil_id'];
		$registro['image'] = $_REQUEST['image'];
		$registro['updated'] = date('Y/m/d H:i:s');

		//Llamada al método de un objeto
		//if (call_user_func(array($this->usuariolib, 'my_validation')));

		$this->Model_Usuario->update($registro);
			
		redirect('usuario');
    }
    
    public function delete($id){
		$this->Model_Usuario->delete($id);
		redirect('usuario');
    }

	public function comprobar(){
		//Llamada al método de un objeto
		call_user_func(array($this->usuariolib, 'my_validation'));
	}

}