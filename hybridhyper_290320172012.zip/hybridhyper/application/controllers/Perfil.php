﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Perfil extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Perfil = $this->load->model('Model_Perfil');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
		$data['titulo'] = 'Perfiles';
		$data['query'] = $this->Model_Perfil->all();
		$data['contenido'] = 'perfil/index';
		$this->load->view('template/template',$data);
    }

    public function create(){
		$data['titulo'] = 'Perfiles';
		$data['contenido'] = 'perfil/create';
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$registro['perfil'] = $_REQUEST['perfil'];
		$registro['descripcion'] = $_REQUEST['descripcion'];
		$registro['created'] = date('Y/m/d H:i:s');
		$registro['updated'] = date('Y/m/d H:i:s');

		$$this->Model_Perfil->insert($registro);
		
		redirect('perfil');
    }

    public function edit($id){
		$data['titulo'] = 'Perfiles';
		$data['registro'] = $this->Model_Perfil->allFiltered($id);
		$data['contenido'] = 'perfil/edit';
		$this->load->view('template/template',$data);
    }
    
    public function update(){
		$registro['id'] = $_REQUEST['id'];
		$registro['perfil'] = $_REQUEST['perfil'];
		$registro['descripcion'] = $_REQUEST['descripcion'];
		$registro['updated'] = date('Y/m/d H:i:s');

		$this->Model_Perfil->update($registro);
		
		redirect('perfil');
    }
    
    public function delete($id){
		$this->Model_Perfil->delete($id);
		redirect('perfil');
    }

}