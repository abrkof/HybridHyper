﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
#This is CORE of HybridHyper - ABRKOF, ABRKOF - HybridHyper, HybridHyper, HybridHyper ABRKOF, ABRKOF HybridHyper, ABRKOF.©
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Start File^
 *
 * Inicializa todos los componentes requeridos para el funcionamiento total del framework.
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Loader
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

define('VERSION', 'HybridHyper - v1.0.0');
define('TITLE', 'ABRKOF® - HYBRIDHYPER®');
define('DESCRIPTION', 'EXPERIMENTAL WEB FRAMEWORK (MVC) - PHP');
define('COMPANY_NAME', 'ABRKOF®');
define('FORK', '“CodeIgniter 2.2.4”');

require_once BASEPATH.('autoloader/AutoLoaderCoreClass.php');
AutoLoaderCoreClass::init();

require_once BASEPATH.('autoloader/AutoLoaderFolder.php');
//require_once BASEPATH.('autoloader/AutoLoaderFiles.php');

/*include_folder(BASEPATH.'helpers/');
include_folder(BASEPATH.'libraries/');*/

include_once APPPATH.('config/autoload.php');
define('APP_HELPERS_FOLDER', $config['app_helpers_folder']);
if (APP_HELPERS_FOLDER == TRUE){
	include_folder(APPPATH.'helpers/');
}

require_once BASEPATH.('helpers/base_helper.php');

include_once APPPATH.('config/hooks.php');
define('APP_HOOK_FILES', $config['app_hook_files']);
if (APP_HOOK_FILES == TRUE){
	include_folder(APPPATH.'hooks/');
}

/*
**
//Ejemplos:
//Incluimos el directorio "foo"
//Incluimos todos los ficheros que contenga "foo", esten en ese directorio o dentro de otros.
include_folder('foo.*');
//Incluimos el directorio "foo" con ruta absoluta
include_folder('root.foo');
//Incluimos todos los ficheros que contenga "foo", esten en ese directorio o dentro de otros.
include_folder('root.foo.*');
**
*/

require_once BASEPATH.('core/Configs.php');
require_once BASEPATH.('errors/Errors.php');
require_once BASEPATH.('database/ActiveRecord.php');
//include_folder(APPPATH.'config/');
require_once APPPATH.('config/database.php');
define('DB_HOST', $db['db_host']);//Creamos indices, ejemplo de indice: $db['db_host'].
define('DB_PORT', $db['db_port']);
define('DB_USER', $db['db_user']);
define('DB_PASS', $db['db_pass']);
define('DB_NAME', $db['db_name']);
define('DB_CHAR', $db['db_char']);
define('DB_DRIVER', $db['db_driver']);
define('DB_ENGINE', $db['db_engine']);

//************************************************************
//Cargamos las librerias correspondientes
require_once APPPATH.('config/config.php');
require_once APPPATH.('config/routes.php');
define('SITE_FOLDER', $config['site_folder']);
//define('DEFAULT_MODULE_NAME', $route['default_module_name']);
define('DEFAULT_MODULE_CONTROLLER', $route['default_module_controller']);
define('DEFAULT_CONTROLLER', $route['default_controller']); //Carga la ruta del controlador inicial, por defecto carga "home" (Controlador/Accion) - "Clase/Función"
//************************************************************

define('TIME_ZONE', $config['time_zone']);
date_default_timezone_set(TIME_ZONE);

//************************************************************
//Asigna todos los objetos de una clase que fueron instanciadas por el
//Archivo de arranque (start.php) para las variables de clases locales
//Por lo que ABRKOF puede funcionar como un gran super objeto.
function &get_instance(){
	return Controller::get_instance();
}

$ABRKOF = Singleton::getInstance();
$ABRKOF->ActiveRecord = new ActiveRecord();
$ABRKOF->load = new Common (new Loader);
$ABRKOF->loader = new Loader;
$ABRKOF->session = new Session(); //Inicializamos la clase Session para el manejo de variables de sesión.
if (DB_DRIVER == 'pdoDB'){
	$ABRKOF->dbx = Database::pdoDB();
} else if (DB_DRIVER == 'mysqlDB'){
	$ABRKOF->dbx = Database::mysqlDB();
} else if (DB_DRIVER == 'mysqliDB'){
	$ABRKOF->dbx = Database::mysqliDB();
} else if (DB_DRIVER == 'odbcDB'){
	$ABRKOF->dbx = Database::odbcDB();
}
$ABRKOF->errors = new Errors();

$ABRKOF->uri = new Uri();

/*require_once BASEPATH.('libraries/Form_Validation.php');
require_once BASEPATH.('libraries/Extra_Validation.php');
$ABRKOF->Form_Validation = new Form_Validation();*/
//************************************************************

define('SESSION_START', $config['sess_start']);
define('SESSION_TIME_ON', $config['sess_time_on']);
define('SESSION_TIME', $config['sess_time']);
define('SESSION_REDIRECT', $config['sess_redirect']);
//define('HASH_KEY', '4f6a6d832be79');

$session = $ABRKOF->session; 
if (SESSION_TIME_ON == TRUE){
	$session->sess_start();
	$session->sess_time();
} else {
	$session->sess_start();
}

//************************************************************
//Cargamos las librerias correspondientes
require_once APPPATH.('config/tablesfields.php');
require_once APPPATH.('config/tablesnames.php');
//************************************************************

//************************************************************
//Cargamos los helpers correspondientes
require_once APPPATH.('config/loadhelpers.php');
LoadHelpers::helpers();
//************************************************************

//************************************************************
//Cargamos las librerias correspondientes
require_once APPPATH.('config/loadlibraries.php');
LoadLibraries::libraries();
//************************************************************

try{
    HybridHyper::core($ABRKOF->loader);
}
catch(Exception $e){
	$controller = $ABRKOF->errors;
	$controller->error($e->getMessage());
}

CorrectAccess::pathAccess();

/* End of file start.php */
/* Location: ./system/core/start.php */