﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Loader Class
 *
 * Carga los componentes framework.
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Loader
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

//Creamos la clase Loader, hace los requerimietos.
class Loader{
    private $module; //Modulo.
	private $modules; //Modulos.
    private $controller;//Controlador o clase principal.
    private $method;//Metodos o funciones.
    private $arguments;//Funsiones defininas por el usuario.
    
    public function __construct(){ //Inicializamos en constructor.
        if(isset($_GET['url'])){ //Obtenemos los valores por URL.
            $url = filter_input(INPUT_GET, 'url', FILTER_SANITIZE_URL); //Elimina todos los caracteres excepto letras, dígitos y $-_.+!*'(),{}|\\^~[]`<>#%";/?:@&=.
			$url = explode('/', $url); //Creamos el separador de url, Clase/Metodo.
			$url = array_filter($url); //array_filter — Filtra elementos de un array usando una función de devolución de llamada para la URL.

			//------------ Inicio Modulos ------------
            $route['default_module_name'] = array('testmodule','webservice4android');
			$this->modules = $route['default_module_name'];
			//var_dump($this->modules);
            $this->module = strtolower(array_shift($url));
            
            if(!$this->module){
                $this->module = FALSE;
            }
            else{
                if(count($this->modules)){
                    if(!in_array($this->module, $this->modules)){
                        $this->controller = $this->module;
                        $this->module = FALSE;
                    } else {
                        $this->controller = strtolower(array_shift($url)); //strtolower - Devuelve una string con todos los caracteres alfabéticos convertidos a minúsculas.
                        
                        if(!$this->controller){ //Si no existe el controlador, carga el controlador por defecto.
                            $this->controller = DEFAULT_MODULE_CONTROLLER;
                        }
                    }
                }
                else{
                     $this->controller = $this->module;
                     $this->module = FALSE;
                }
            }
			//------------ Fin Modulos ------------

            $this->method = strtolower(array_shift($url)); //array_shift - Quita un elemento del principio del array.
            $this->arguments = $url; //Seteamos sus argumentos.
        }
        
        if(!$this->controller){ //Si no existe el controlador, carga el controlador por defecto.
            $this->controller = DEFAULT_CONTROLLER;
			//throw new Exception('Error al cargar el controlador - '.$this->controller); //Cargamos error si no existe el controlador.
        }
        
        if(!$this->method){ //Si no existe el controlador, carga el metodo por defecto.
            $this->method = 'index';
			//throw new Exception('Error al cargar el método - '.$this->method); //Cargamos error si no existe el método.
        }
        
        if(!isset($this->arguments)){ //Si no existe el controlador, carga los parametros por defecto.
            $this->arguments = array();//Devuelve un array.
        }
    }
	//En orden jerárquico
	public function getModule(){
		return $this->module;
	}

    public function getController(){ //Obtenemos el controlador.
        return $this->controller;
    }
    
    public function getMethod(){ //Obtenemos el método.
        return $this->method;
    }
    
    public function getArgs(){ //Obtenemos los argumentos o parametros.
        return $this->arguments;
    }

	public function &_get_component($component){ //Experiemntación de carga de objetos de forma global.
		$ABRKOF =& get_instance();
		return $ABRKOF->$component;
	}

}

/* End of file Loader.php */
/* Location: ./system/core/Loader.php */