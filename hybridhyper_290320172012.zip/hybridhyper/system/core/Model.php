﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Model Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

//Creamos la clase Model para el manejo de datos.
require_once BASEPATH.('database/ActiveRecord.php');
class Model{
    protected $load;//Creamos un variable u objeto de tipo protegido.
	protected $session;//Creamos un variable u objeto de tipo publico.
	protected $db;//Creamos una variable u objeto de tipo protegido.
	protected $dbx;//Creamos una variable u objeto de tipo protegido.
	protected $update;//Creamos una variable u objeto de tipo protegido.
	private $ABRKOF;
    
    public function __construct(){ //Inicializamos el constructor.
        //$this->db = new Database(); //Instanciamos de la clase que administra la conexión del motor de la base de datos.
		try{
			$this->ABRKOF = Singleton::getInstance();
			$this->dbx = $this->ABRKOF->dbx;
		}
		catch(Exception $e){
			die($e->getMessage());
		}
		$this->db = $this->ABRKOF->ActiveRecord;/**/
		$this->load = $this->ABRKOF->load; //Instanciamos.
		$this->session = $this->ABRKOF->session; //Instanciamos.
    }

	public function question_mark($longitud){
		$key = '';
		$pattern = '?';
		$max = strlen($pattern)-1;
		for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)}.',';
		//return $key;
		return substr($key,0,strripos($key,','));
	}

}

/* End of file Model.php */
/* Location: ./system/core/Model.php */