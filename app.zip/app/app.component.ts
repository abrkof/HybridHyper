import { Component} from '@angular/core';
//import { NgForm } from '@angular/forms';
import {PostService} from './post.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [PostService]
})
export class AppComponent{
  name : string;
  lastName: string;
  languages: string[];
  showLanguages: boolean;
  posts: IPost[];

  constructor(private postService: PostService){
    this.name = 'Charles';
    this.lastName = 'Hero';
    this.languages = ['PHP', 'JAVA', 'TypeScript'];
    this.showLanguages = false;
    this.postService.getPosts().subscribe(posts=>{this.posts = posts;});//console.log(posts);
    /*getPosts(): void {
      this.postService.getPosts().then(posts => this.posts = posts);
    }*/
  }

  toggleLanguages(){
    this.showLanguages = !this.showLanguages;
  }

  newLanguage(language){
    this.languages.push(language.value);
    language.value = '';
    return false;
  }

  interface IPost{
    id: string;
    title: string;
    body: string;
  }

}
