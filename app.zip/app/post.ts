export class Post {
    id: string;
    title: string;
    body: string;
  }
  