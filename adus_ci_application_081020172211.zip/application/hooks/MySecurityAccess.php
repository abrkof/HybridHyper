﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Security Access Library Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
//Acceso por autentificación de usuarios.
//echo txt_freeCtrlAcc();
class CorrectAccess{

	function __construct(){
		$this->CI = & get_instance(); //Instanciamos al super objeto.

		$this->CI->load->model('Model_Menu');
        $this->CI->load->model('Model_SubMenu');
		$this->CI->load->model('Model_Menu_Public');

		$this->CI->load->library('menuLib');
		$this->CI->load->library('subMenuLib');
		
		$this->CI->load->library('menu_PerfilLib');
		$this->CI->load->library('subMenu_PerfilLib');
    }
	
	public function pathAccess(){
		$query1 = $this->CI->Model_Menu->get_menu_lv1();
		$menu = $query1->row();
		
		$query2 = $this->CI->Model_Menu->get_menu_lv2();
		$menu_module = $query2->row();
		
		$query7 = $this->CI->Model_SubMenu->get_submenu_lv1();
		$submenu = $query7->row();
		
		$query8 = $this->CI->Model_SubMenu->get_submenu_lv2();
		$submenu_module = $query8->row();
		
		//Si el controlador pertenece a un modulo y este no es cargado en el sistema, no se permitira el acceso.
		switch ($this->CI->uri->segment(1)){
			case strtolower($menu_module->module_name):
				$controlador = $this->CI->uri->segment(2);
				$accion = $this->CI->uri->segment(3);
				$url = $controlador.'/'.$accion;
			break;
			
			case strtolower($menu->controlador):
				$controlador = $this->CI->uri->segment(1);
				$accion = $this->CI->uri->segment(2);
				$url = $controlador.'/'.$accion;
			break;
			
			case strtolower($submenu_module->module_name):
				$controlador = $this->CI->uri->segment(2);
				$accion = $this->CI->uri->segment(3);
				$url = $controlador.'/'.$accion;
			break;
		
			default:
				$controlador = $this->CI->uri->segment(1);
				$accion = $this->CI->uri->segment(2);
				$url = $controlador.'/'.$accion;
		}
		
		/*$text1 = "";
		$lista1 = array();
		
		$registros1 = $this->CI->menu_perfillib->free_ctrl_acc();

		foreach ($registros1 as $registro){
			$lista1[$registro->id] = $registro->controlador.'/'.$registro->accion;
			foreach (explode(',', $lista1[$registro->id]) as $option_data){
				$text1 .= "'".$option_data."',";
			}
		}
		
		$text2 = "";
		$lista2 = array();
		
		$registros2 = $this->CI->submenu_perfillib->free_ctrl_acc();

		foreach ($registros2 as $registro){
			$lista2[$registro->id] = $registro->controlador.'/'.$registro->accion;
			foreach (explode(',', $lista2[$registro->id]) as $option_data){
				$text2 .= "'".$option_data."',";
			}
		}*/
		
		/*$rt1 = 'asd, asd, 123, 456';
		$rt2 = 'asd, asd, 123, 789';
		$slice = implode("," , array_unique(array_merge(explode(",",$rt1),explode(",", $rt2))));*/
		
		//echo $slice;
		
		$menu = $text1;
		$submenu = substr($text2,0,strripos($text2,','));
		$publicCtrlAcc = $menu.$submenu;
		//echo $publicCtrlAcc;
		
		$freeCtrlAcc = array(
			'/',
			'welcome/',
			'welcome/index',
			'admin/',
			'admin/index',
			'admin/inicio_sesion',
			'admin/auth',
			'admin/accessCorrect',
			'admin/ingresar',
			'admin/cambio_clave',
			'admin/cambiar_clave',
			'admin/salir',
			'admin/export_to_excel',
			'admin/acceso_denegado',
			'admin/acerca_de',
			'usuario/usr_common_config',
			'usuario/usr_common_edit',
			'usuario/usr_common_update',
			'usuario/usr_common_edit_img',
			'usuario/usr_common_update_img',
			'usuario/usr_common_baja',
			'My404/',
			'My404/index',
			'admin/export_to_excel',
			'usuario/usr_common_config',
			'usuario/usr_common_edit',
			'usuario/usr_common_update',
			'usuario/usr_common_edit_img',
			'usuario/usr_common_update_img',
			'usuario/usr_common_baja',
			'anuncio/veranuncio',
			'anuncio/',
			'home/',
			'home/index',
			'home/cv',
			'portafolio/',
			'portafolio/index',
			'servicios/index',
			'servicios/',
			'articulo/index',
			'articulo/ajax',
			'articulo/',
			'contacto/index',
			'contacto/send_mail',
			'contacto/index',
			'lugar/',
			'lugar/index',
			'editeur/',
			'editeur/index',
			'inventaire/',
			'inventaire/index',
			'profil/',
			'profil/index',
			'personas/',
			'personas/index'
			/*print_r($i),*/
		);
		
		//echo var_dump($freeCtrlAcc);

		if(in_array($url, $freeCtrlAcc)){
			echo $this->CI->output->get_output();
		} else {
			if($this->CI->session->userdata('usuario_id')){
				if($this->authorize_menu_submenu()){
					echo $this->CI->output->get_output();
				} else {
					redirect('admin/acceso_denegado');
				}
			} else {
				redirect('admin/acceso_denegado');
			}
		}

	}

	public function authorize_menu_submenu(){
		$query3 = $this->CI->Model_Menu->get_menu_lv1();
		$menu = $query3->row();
		
		$query4 = $this->CI->Model_Menu->get_menu_lv2();
		$menu_module = $query4->row();
		
		$query5 = $this->CI->Model_SubMenu->get_submenu_lv1();
		$submenu = $query5->row();
		
		$query6 = $this->CI->Model_SubMenu->get_submenu_lv2();
		$submenu_module = $query6->row();
	
		//El perfil del usuario logueado.
		$perfil_id = $this->CI->session->userdata('perfil_id');
		
		//$controlador = '';
		
		//Si el controlador pertenece a un modulo y este no es cargado en el sistema, no se permitira el acceso.
		switch ($this->CI->uri->segment(1)){
			case strtolower($menu_module->module_name):
				$controlador = $this->CI->uri->segment(2);
			break;
			
			case strtolower($menu->controlador):
				$controlador = $this->CI->uri->segment(1);
			break;
			
			case strtolower($submenu_module->module_name):
				$controlador = $this->CI->uri->segment(2);
			break;
			
			case strtolower($submenu->controlador):
				$controlador = $this->CI->uri->segment(1);
			break;
		
			default:
				$controlador = $this->CI->uri->segment(1);
		}
		
		$menu_id = $this->CI->menulib->findByControlador($controlador)->id;
		$submenu_id = $this->CI->submenulib->findByControlador($controlador)->id;
	
		if(!$menu_id AND !$submenu_id){
			return FALSE;
		}
	
		//Recupera de la tabla permisos, la combinación Menú, Sub Menú - Perfil.
		$acceso1 = $this->CI->menu_perfillib->findByMenuAndPerfil($menu_id, $perfil_id);
		$acceso2 = $this->CI->submenu_perfillib->findBySubMenuAndPerfil($submenu_id, $perfil_id);
		if(!$acceso1 AND !$acceso2){
			return FALSE;
		}
		return TRUE;
	}

	public function freeCtrlAcc(){
		$filename = "./assets/freeCtrlAcc.txt";
		$text = "";
		
		$lista = array();
		$registros = $this->CI->Model_Menu->all();
		foreach ($registros as $registro){
			$lista[$registro->id] = $registro->controlador.'/'.$registro->accion;
			foreach (explode(',', $lista[$registro->id]) as $option_data){
				$text .= "'".$option_data."',";
			}
		}
		
		$fh = fopen($filename, "w") or die("Imposible abir el archivo.");
		fwrite($fh, $text."'/'") or die("Imposible escribir el archivo!");
		fclose($fh);
		
		$file = fopen("./assets/freeCtrlAcc.txt", "r");
		$rt = fgets($file);
		$rt = file('./assets/freeCtrlAcc.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
		
		echo $rt = file_get_contents("./assets/freeCtrlAcc.txt");
	}

}


/*
Vamos a ver de forma rápida como utilizar hooks con codeigniter, imaginemos que tenemos un gran portal y no queremos 
dejar pasar a ningún usuario a según que zonas del mismo, podríamos poner en cada página una comprobación de si existe 
la sesión o no, pero eso en codeigniter es ‘pecado’.

Gracias a los hooks podemos hacer eso en una sola función y diciéndole cuando queremos que haga las comprobaciones, 
por ejemplo, nosotros lo haremos en el post_controller_constructor que es cuando el constructor se instancia pero cuando 
todavía ningún método haya sido llamado, veamos las opciones que nos dá codeigniter.

pre_system
Llamado muy pronto durante la ejecución del sistema. En este punto, solamente se cargaron las clases de
hooks y benchmark. No ocurrió ningún ruteo u otro proceso.

pre_controller
Llamado inmediatamente antes de que cualquiera de sus controladores haya sido llamado. Se hicieron
todas las clases base, ruteo y verificaciones de seguridad.

post_controller_constructor
Llamado inmediatamente después que su controlador se instanció, pero antes que haya ocurrido cualquier
llamada a un método.

post_controller
Llamado inmediatamente después que su controlador se ejecutó completamente.

display_override
Anula la función _display(), usada para enviar la página finalizada al navegador web al final de la
ejecución del sistema. Esto le permite usar su propia metodología de impresión. Advierta que necesitará
referenciar al superobjeto CI con $this->CI =& get_instance() y luego los datos finalizados estarán
disponibles llamando a $this->CI->output->get_output()

cache_override
Le permite llamar a su propia función en lugar de la función _display_cache() en la clase Output. Esto le
permite usar su propio mecanismo de visualización del caché.

post_system
Llamado después que la página final renderizada se envíe al navegador, en el final de la ejecución del
sistema y después que los datos finalizados se envían al navegador.
*/