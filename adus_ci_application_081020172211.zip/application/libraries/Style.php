<?php if (!defined('BASEPATH')) exit('No permitir el acceso directo al script');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Style Library
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
header("Content-type: text/css"); 
echo librarypath('libraries/style_ini');
?>

.body{
background-image:url(back_ground.png);
background-attachment:fixed;right:0px;left:auto;
background-color:<?php echo $Body_Hex;?>; 
}

div.menu{
padding:5px;
text-align:center;
color:#ffffff; 
font:bold 13px Arial;
width:115px;
background-color:<?php echo $Menu_Hex;?>; 
border-width: 1px;
border-style:solid;
border-color:#606060;
z-index:1;
}

ul.main_menu{
margin:0px;
padding:0px;	
list-style:none;
width:140px;
font:11px Arial;
z-index:1;
}

li.main_menu{
width:140px;
float:right;
padding:5px;
margin:0px;
background-color:<?php echo $Menu_Slide_Hex;?>; 
border-width: 1px;
border-style:solid;
border-color:#606060;
z-index:1;
}

li.main_menu:hover{
background-color:<?php echo $Menu_Slide_Hover_Hex;?>; 
border-width:1px;
border-style:solid;
border-color:#000000;
z-index:1;
}

.box_fill{
background-color:<?php echo $Box_Hex;?>; 
}

.div_fill{
background-color:<?php echo $Div_Hex;?>; 
}

.title_fill{
background-color:<?php echo $Title_Hex;?>; 
}

.arial_small{
font-size:8pt;
font-family:Arial;
font-weight:400;
}

.arial{
font-size:9pt;
font-family:Arial;
font-weight:500;
}

.arial_big{
font-size:12pt;
font-family:Arial;
font-weight:500;
}

table.first{
background-color:#ffffff;
color:#000000;
font-size:8pt;
font-family:'Verdana';
border-style:solid;
border-width:1px;
border-color:#000000;
} 

table.index{
color:#000000;
font-size:7pt;
font-family:'Verdana';
text-align:center;
width:250px;
border-width:1px;
border-style:solid;
border-color:#b0afb0;
}

table.comment{
color:#000000;
font-size:7pt;
font-family:'Verdana';
text-align:center;
width:300px;
border-width:1px;
border-style:solid;
border-color:#023f6a;
padding:5px; 
}

table.photo
{
text-align:center;
width:130px;
height:130px;
border-width:1px;
border-style:solid;
border-color:#b0afb0;
padding:5px;
}

a.link{ 
color:#ffffff;
text-decoration: none;
}
a.link:hover{
text-decoration:underline;
}

a.group{
color:#000000;
text-decoration: none;
}
a.group:hover{
color:#000000;
text-transform:uppercase;
text-decoration:underline;
}

a.page{ 
color:#023f6a;
text-decoration: none;
}
a.page:hover{
text-decoration:underline;
}

table.blog{
border-width:1px;
border-top-style:solid;
border-bottom-style:dotted;
border-color:#023f6a;
}

input.tick{
background-image:url(pixel_2.png);
text-align:left;
}

td.index{
background:#c0dcf1; 
color:#023f6a;
font-size:10pt; 
font-weight:bold;
text-align:left;  
border-style:dotted;
border-width:1px;
border-color:#49A3FF;
}


table.poll{
color:#000000;
font-size:8pt;
font-family:'Verdana';
border-width:1px;
border-top-style:dotted;
border-bottom-style:solid;
border-color:#023f6a;
}



a.menu{
color:#000000;
text-decoration:none;
}

a.menu:hover
{
color:#ffffff;
font:bold 12px Arial;
text-decoration:underline;
}


div.box
{
text-align:left;
color:#000000;
font-size:10pt;
font-family:'Arial';
border-width:1px;
border-style:solid;
border-color:#b0afb0;
padding:10px 10px 10px 10px; 
}

div.index{
text-align:left;
color:#000000;
font-size:8pt;
font-family:'Arial';
border-width:1px;
border-style:solid;
border-color:#b0afb0;
padding:10px; 
}

input.smalltag{
font:10px Arial;
padding:2px;
margin-top:2px;
margin-bottom:2px;
border-width:1px;
border-top-style:dotted;
border-left-style:solid;
border-bottom-style:dotted;
border-right-style:solid;
border-color:#3399FF;
}

input.tag{
font:12px Arial;
padding:5px;
margin:0px;
border-width:1px;
border-top-style:dotted;
border-left-style:dotted;
border-bottom-style:solid;
border-right-style:solid;
border-color:#3399FF;
}

input.button{
background-image:url(siteicons/button.png);
color:#555152;
font-size:12pt;
font-family:Arial;
width:150px;
height:30px;
text-align:center;
border-width:1px;
border-style:solid;
border-color:#023f6a;
}

table.blog{
border-width:1px;
border-top-style:dotted;
border-left-style:dotted;
border-right-style:dotted;
border-bottom-style:solid;
border-color:#023f6a;
}


table.event{
color:#000000;
font-size:8pt;
font-family:'Verdana';
text-align:left;
border-width:1px;
border-style:dotted;
border-color:#49A3FF;
}