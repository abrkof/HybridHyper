﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Coordenadas Library Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

class CoordenadasLib{

	function __construct(){
		$this->CI = & get_instance(); //Instanciamos al super objeto.
    }

	public function getCoordenadas($lat, $lng, $distancia = 5, $earthRadius = 6371){//Obtener Coordenadas.
		$return = array();
		 
		//Ingresamos valores dentro de un array de los ángulos por dirección.
		$cardinalCoords = array('north' => '0',
								'south' => '180',
								'east' => '90',
								'west' => '270');
	
		$rLat = deg2rad($lat);//Convertimos grados a su equivalente en radianes.
		$rLng = deg2rad($lng);
		$rAngDist = $distancia/$earthRadius;
	
		foreach ($cardinalCoords as $name => $angle){
			$rAngle = deg2rad($angle);
			$rLatB = asin(sin($rLat) * cos($rAngDist) + cos($rLat) * sin($rAngDist) * cos($rAngle));//(asin) Devuelve el arco seno hiperbólico de arg, es decir, el valor cuyo seno hiperbólico es arg.
			$rLonB = $rLng + atan2(sin($rAngle) * sin($rAngDist) * cos($rLat), cos($rAngDist) - sin($rLat) * sin($rLatB));//(atan2) La función devuelve el resultado en radianes, que se encuentra entre -PI y PI (inclusive).
	
			$return[$name] = array('lat' => (float) rad2deg($rLatB),//rad2deg — Convierte el número en radianes a su equivalente en grados.
									'lng' => (float) rad2deg($rLonB));
		}
	
		return array('min_lat'  => $return['south']['lat'],
					 'max_lat' => $return['north']['lat'],
					 'min_lng' => $return['west']['lng'],
					 'max_lng' => $return['east']['lng']);
	}

    public function gotItCoordenadas(){//Coordenadas Obtenidas, Implementación de la fórmula de Haversine.
		//$this->load->model('Model_Sesiones_Temp');
		//$drivers_online = $this->Model_Sesiones_Temp->get_drivers_x();
		//$driver = $drivers_online->row();
		
		$lat = $this->CI->session->userdata('update_latitude');
		$lng = $this->CI->session->userdata('update_longitude');
		$distancia = 5;//Lugares que se encuentran en un radio de 5KM.
		$box = $this->getCoordenadas($lat, $lng, $distancia);

		//Implementación del teorema de la fórmula del Coseno.
		$query = $this->CI->db->query('SELECT *, (6371 * ACOS(
															COS(RADIANS('.$lat.'))
															* COS(RADIANS(sesiones_temp.Latitude))
															* COS(RADIANS(sesiones_temp.Longitude)
															- RADIANS('.$lng.'))
															+ SIN(RADIANS('.$lat.'))
															* SIN(RADIANS(sesiones_temp.Latitude))
														)
												)AS distancia,
								 sesiones_temp.usuario_id, 
								 perfil.perfil as perfil_name,
								 usuario.nombres as usuario_name, usuario.apellidos as usuario_ape
								 FROM sesiones_temp 
								 left join usuario ON (sesiones_temp.usuario_id = usuario.id)
								 left join perfil ON (usuario.perfil_id = perfil.id)
								 WHERE (sesiones_temp.Latitude BETWEEN '.$box['min_lat'].' AND '.$box['max_lat'].')
								 AND (sesiones_temp.Longitude BETWEEN '.$box['min_lng'].' AND ' .$box['max_lng'].')
								 AND perfil_id = "4"
								 HAVING distancia < '.$distancia.'
								 ORDER BY distancia ASC');
		$registros = $query->result();
		var_dump($registros);//Cargamos un arreglo de objetos.
		//var_dump(json_encode($rows));//Cargamos consulta en formato universal, Codificación JSON
		echo '<script>
		function getDistanceToCoords(lat1,lon1,lat2,lon2) {
		  function _deg2rad(deg) {
			return deg * (Math.PI/180)
		  }
		  var R = 6371; //Radio de la tierra en km
		  var dLat = _deg2rad(lat2-lat1);  //deg2rad below
		  var dLon = _deg2rad(lon2-lon1); 
		  var a = 
			Math.sin(dLat/2) * Math.sin(dLat/2) +
			Math.cos(_deg2rad(lat1)) * Math.cos(_deg2rad(lat2)) * 
			Math.sin(dLon/2) * Math.sin(dLon/2); 
		  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
		  var d = R * c; // Distance in km
		  return d.toFixed(3);
		}
		
		lat1 = 13.7106;
		lon1 = -89.7169;
		lat2 = 34.2010887;
		lon2 = -117.2064181;
		
		document.write("Distance between Sonsonate (El Salvador) and Los Ángeles (E.U.A)");
		document.write(getDistanceToCoords(lat1,lon1,lat2,lon2) + " Km");
		</script>';
    }
}
