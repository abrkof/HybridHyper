<?php if (!defined('BASEPATH')) exit('No permitir el acceso directo al script');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Menu Perfil Vistas Library Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Menu_Perfil_VistasLib {

	function __construct() {
		$this->CI = & get_instance(); //Instanciamos al super objeto

		$this->CI->load->model('Model_Menu_Perfil_Vistas');
    }

    public function my_validation($registro) {
        $this->CI->db->where('menu_id', $registro['menu_id']);
        $this->CI->db->where('perfil_id', $registro['perfil_id']);
        $query = $this->CI->db->get('menu_perfil_vistas');
        if ($query->num_rows() > 0 AND (!isset($registro['id']) OR ($registro['id'] != $query->row('id')))) {
            return FALSE;
        }
        else {
            return TRUE;
        }
    }

    public function dar_acceso_vistas($perfil_id, $menu_id) {
        $registro = array();
        $registro['menu_id'] = $menu_id;
        $registro['perfil_id'] = $perfil_id;
        $registro['created'] = date('Y-m-d H:i:s');
        $registro['updated'] = date('Y-m-d H:i:s');
        $this->CI->Model_Menu_Perfil_Vistas->insert($registro);
    }

    public function quitar_acceso_vistas($perfil_id, $menu_id) {
        $this->CI->db->where('perfil_id', $perfil_id);
        $this->CI->db->where('menu_id', $menu_id);
        $this->CI->db->delete('menu_perfil_vistas');
    }

    public function findByMenuAndPerfil($menu_id, $perfil_id) {
        $this->CI->db->where('menu_id', $menu_id);
        $this->CI->db->where('perfil_id', $perfil_id);
        return $this->CI->db->get('menu_perfil_vistas')->row();
    }

}
