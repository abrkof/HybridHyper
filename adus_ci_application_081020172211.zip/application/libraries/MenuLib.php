﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Menu Library Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class MenuLib{

	function __construct(){
		$this->CI = & get_instance(); //Instanciamos al super objeto
    }

    public function my_validation($registro){
        $ctr = ($registro['controlador'] != '');
        $acc = ($registro['accion'] != '');
        $url = ($registro['url'] != '');

        //No puede no ingresar Controlador, Acción, URL
        if(!$ctr AND !$acc AND !$url){
            $this->CI->form_validation->set_message('my_validation', 'Debe ingresar Controlador y Acción o una URL');
            return FALSE;
        }

        //Si ingresó controlador, debe ingresar acción
        if($ctr AND !$acc){
            $this->CI->form_validation->set_message('my_validation', 'Ingresó Controlador, falta la Acción');
            return FALSE;
        }

        //Si ingresó accion, debe ingresar controlador
        if(!$ctr AND $acc){
            $this->CI->form_validation->set_message('my_validation', 'Ingresó Acción, falta el Controlador');
            return FALSE;
        }

        //Si ingresó URL, no puede haber ni Controlador ni Acción
        if($url AND ($ctr OR $acc)){
            $this->CI->form_validation->set_message('my_validation', 'Si ingresa URL, no ingresar ni Controlador ni Acción');
            return FALSE;
        }

        return TRUE;
    }

    public function get_perfiles_asig_noasig($menu_id){
        $lista_asig = array();
        $lista_noasig = array();

        $this->CI->load->model('Model_Perfil');
        $perfiles = $this->CI->Model_Perfil->all();

        foreach($perfiles as $perfil){
            $this->CI->db->where('menu_id', $menu_id);
            $this->CI->db->where('perfil_id', $perfil->id);
            $query = $this->CI->db->get('menu_perfil');
            $existe = ($query->num_rows() > 0);

            if($existe) {
                $lista_asig[] = array($perfil->id, $perfil->perfil, $menu_id);
            }
            else {
                $lista_noasig[] = array($perfil->id, $perfil->perfil, $menu_id);
            }
        }

        return array($lista_noasig, $lista_asig);
    }

    public function findByControlador($controlador){
        $this->CI->db->where('controlador', $controlador);
        return $this->CI->db->get('menu')->row();
    }

//------------------------Vistas------------------------------------------------
    public function get_perfilesx_asig_noasig($menu_id) {
        $lista_asig = array();
        $lista_noasig = array();

        $this->CI->load->model('Model_Perfil');
        $perfiles = $this->CI->Model_Perfil->all();

        foreach($perfiles as $perfil) {
            $this->CI->db->where('menu_id', $menu_id);
            $this->CI->db->where('perfil_id', $perfil->id);
            $query = $this->CI->db->get('menu_perfil_vistas');
            $existe = ($query->num_rows() > 0);

            if($existe) {
                $lista_asig[] = array($perfil->id, $perfil->perfil, $menu_id);
            }
            else {
                $lista_noasig[] = array($perfil->id, $perfil->perfil, $menu_id);
            }
        }

        return array($lista_noasig, $lista_asig);
    }
//------------------------Vistas------------------------------------------------

}
