<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * UsuarioLib Library Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
// Validaciones para el modelo de usuarios (login, cambio clave, CRUD Usuario)
class UsuarioLib{

	function __construct(){
		$this->CI = & get_instance(); //Instanciamos al super objeto

		$this->CI->load->model('Model_Usuario');
        $this->CI->load->model('Model_Perfil');
		$this->CI->load->model('Model_Sesiones');
    }

    public function login($user, $password){
		$query = $this->CI->Model_Usuario->get_login($user);
		$estado = $this->CI->input->post('estado');
        
        $plain_password = '';

        if ($query->num_rows() == 1) {
            $qp = $query->row();
            $plain_password = $this->CI->encryption->decrypt($qp->password);
        }
        
        //Verificamos si el usuario existe
        if (($query->num_rows() == 1) && ($plain_password == $password)){
    		$usuario = $query->row();
            $perfil = $this->CI->Model_Perfil->find($usuario->perfil_id);

    		$datosSession = array('usuario_name' => $usuario->nombres,
    			                  'usuario_ape' => $usuario->apellidos,
								  'usuario_image' => $usuario->image,
								  'usuario_id' => $usuario->id,
								  'usuario_state' => $estado,
								  'usuario_login' => $usuario->login,
								  'usuario_email' => $usuario->email,
								  'usuario_latitude' => $_COOKIE['locx'],
								  'usuario_longitude' => $_COOKIE['locy'],
								  'usuario_zonetime' => $_COOKIE['onlinedate'],
    			                  'perfil_id' => $usuario->perfil_id,
                                  'perfil_name' => $perfil->perfil,
								  'usuario_state' => 1);
    		$this->CI->session->set_userdata($datosSession);
    		return TRUE;
    	} else {
    		$this->CI->session->sess_destroy();
    		return FALSE;
    	}
    }
	
	//Método con ajax
	public function validarUsuarioAjax($user, $password){
		$user = htmlspecialchars(trim($_POST['login']));
		$password = htmlspecialchars(trim($_POST['password']));
		
		$query = $this->CI->Model_Usuario->get_login($user);
        
        $plain_password = '';

        if ($query->num_rows() == 1) {
            $qp = $query->row();
            $plain_password = $this->CI->encryption->decrypt($qp->password);
        }
        
        //Verificamos si el usuario existe
        if (($query->num_rows() == 1) && ($plain_password == $password)){
    		$usuario = $query->row();
            $perfil = $this->CI->Model_Perfil->find($usuario->perfil_id);

    		$datosSession = array('usuario_name' => $usuario->nombres,
    			                  'usuario_ape' => $usuario->apellidos,
								  'usuario_image' => $usuario->image,
								  'usuario_id' => $usuario->id,
								  'usuario_login' => $usuario->login,
								  'usuario_email' => $usuario->email,
								  'usuario_latitude' => $_COOKIE['locx'],
								  'usuario_longitude' => $_COOKIE['locy'],
								  'usuario_zonetime' => $_COOKIE['onlinedate'],
    			                  'perfil_id' => $usuario->perfil_id,
                                  'perfil_name' => $perfil->perfil,
								  'usuario_state' => 1);
    		$this->CI->session->set_userdata($datosSession);

			$arr_rpta = array("estado"=>"1","url"=>"Correct Access");
			
			//session_start();
			//
			//$_SESSION['usuario_login'] = $usuario;
				
			$this->CI->db->query('INSERT INTO sesiones_temp (usuario_id) VALUES ("'.$user.'")');
		} else {
		   $arr_rpta = array("estado"=>"0","url"=>"
			<div class='alert alert-error'>
			<a class='close' data-dismiss='alert-close' href='".base_url('')."jcride/app/login'> × </a>
			<h4><i class='icon fa fa-ban'></i> Mensajes de Validación </h4>
			<small>'Datos de usuario incorrectos!!!'</small>
			</div>");
		}
		echo json_encode($arr_rpta);
	}

	//Método con Tarjeta y Pin de seguridad.
    public function loginAuth($user){
		$query = $this->CI->Model_Usuario->get_login($user);
        
        //Verificamos si el usuario existe
        if ($query->num_rows() == 1){
    		$usuario = $query->row();
            $perfil = $this->CI->Model_Perfil->find($usuario->perfil_id);

    		$datosSession = array('usuario_name' => $usuario->nombres,
    			                  'usuario_ape' => $usuario->apellidos,
								  'usuario_image' => $usuario->image,
								  'usuario_id' => $usuario->id,
								  'usuario_login' => $usuario->login,
								  'usuario_email' => $usuario->email,
								  'usuario_latitude' => $_COOKIE['locx'],
								  'usuario_longitude' => $_COOKIE['locy'],
								  'usuario_zonetime' => $_COOKIE['onlinedate'],
    			                  'perfil_id' => $usuario->perfil_id,
                                  'perfil_name' => $perfil->perfil,
								  'usuario_state' => 1);
    		$this->CI->session->set_userdata($datosSession);
    		return TRUE;
    	} else {
    		$this->CI->session->sess_destroy();
    		return FALSE;
    	}
    }

	public function update_latlon(){
		$update_latlon = array('update_latitude' => $_COOKIE['locx'],
							  'update_longitude' => $_COOKIE['locy'],
							  'usuario_zonetime' => $_COOKIE['onlinedate']);
		$this->CI->session->set_userdata($update_latlon);
		
		$this->CI->db->set('Latitude', $this->CI->session->userdata('update_latitude'));
		$this->CI->db->set('Longitude', $this->CI->session->userdata('update_longitude'));
		$this->CI->db->where('usuario_id', $this->CI->session->userdata('usuario_id'));
		$this->CI->db->update('sesiones_temp');
		//echo '</body>';
	}
	
	public function update_state1(){
		$update_state = array('usuario_state' => 1);
		$this->CI->session->set_userdata($update_state);
		
		$this->CI->db->set('estado', $this->CI->session->userdata('usuario_state'));
		$this->CI->db->where('usuario_id', $this->CI->session->userdata('usuario_id'));
		$this->CI->db->update('sesiones_temp');
	}

	public function update_state0(){
		$update_state = array('usuario_state' => 0);
		$this->CI->session->set_userdata($update_state);
		
		$this->CI->db->set('estado', $this->CI->session->userdata('usuario_state'));
		$this->CI->db->where('usuario_id', $this->CI->session->userdata('usuario_id'));
		$this->CI->db->update('sesiones_temp');
	}

    public function cambiarPWD($act, $new){
		if($this->CI->session->userdata('usuario_id') == null){
    		return FALSE;
    	}

    	$id = $this->CI->session->userdata('usuario_id');
    	$usuario = $this->CI->Model_Usuario->find($id);
		
		$decrypting_password = $this->CI->encryption->decrypt($usuario->password);//$this->CI->encrypt->decode($usuario->password, $key);
		$new_encrypt = $this->CI->encryption->encrypt($new);//$this->CI->encrypt->encode($new, $key);
    	
		if($decrypting_password == $act){
    		$data = array('id' => $id,
               			  'password' => $new_encrypt);
    		$this->CI->Model_Usuario->update($data);
    	} else {
    		return FALSE;
    	}
    }

    public function resetPWD($id){
		$usuario = $this->CI->Model_Usuario->find($id);
		
		$new_encrypt = $this->CI->encryption->encrypt($usuario->login);
    	
		if($new_encrypt){
    		$date = date('Y-m-d H:i:s');
			$data = array('id' => $id,
               			  'password'=>$new_encrypt,
						  'updated'=>$date);
    		$this->CI->Model_Usuario->update($data);
			
		$usr = '"'.$usuario->login.'"';
		$pwd = '"'.$this->CI->encryption->decrypt($new_encrypt).'"';
		
		echo packstylecss('alertifyjs/css/themes/default.min');
		echo packstylecss('alertifyjs/css/alertify.min');
		echo packstylejs('alertifyjs/alertify.min');

		echo "<script>
			function error_pwdusr(){
				var alert = alertify.alert('La nueva contraseña se ha generado con exito!','Los nuevos Datos de Usuario Son:<br><br> Usuario: ".$usr."<br>Password: ".$pwd."', function (e){     	 
				alert.set({transition:'flipx'}); //slide, zoom, flipx, flipy, fade, pulse (default)
				alert.set('modal', false);  //al pulsar fuera del dialog se cierra o no
					if (e){
						window.location='".base_url('')."usuario/index';
					} else {
						return false;
					}
				}).set('label', 'Aceptar');
				return true;
			}
		
			error_pwdusr();
			</script>";
		
    	} else {
    		return FALSE;
    	}
    }

    public function my_validation($registro){
        $this->CI->db->where('login', $registro['login']);
        $query = $this->CI->db->get('usuario');

        if ($query->num_rows() > 0 AND (!isset($registro['id']) OR ($registro['id'] != $query->row('id')))){
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function my_validation_mail($registro){
        $this->CI->db->where('email', $registro['email']);
        $query = $this->CI->db->get('usuario');

        if ($query->num_rows() > 0 AND (!isset($registro['id']) OR ($registro['id'] != $query->row('id')))){
            return FALSE;
        } else {
            return TRUE;
        }
    }

}
