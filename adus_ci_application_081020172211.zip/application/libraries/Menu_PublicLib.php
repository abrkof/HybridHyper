<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Menu Public Library Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Menu_PublicLib {

	function __construct() {
		$this->CI = & get_instance(); //Instanciamos al super objeto
    }

    public function my_validation($registro) {
        $ctr = ($registro['controlador'] != '');
        $acc = ($registro['accion'] != '');
        $url = ($registro['url'] != '');

        //No puede no ingresar Controlador, Accion, URL
        if(!$ctr AND !$acc AND !$url) {
            $this->CI->form_validation->set_message('my_validation', 'Debe ingresar Controlador y Acción o una URL');
            return FALSE;
        }

        //Si ingresó controlador, debe ingresar accion
        if($ctr AND !$acc) {
            $this->CI->form_validation->set_message('my_validation', 'Ingresó Controlador, falta la Acción');
            return FALSE;
        }

        //Si ingresó accion, debe ingresar controlador
        if(!$ctr AND $acc) {
            $this->CI->form_validation->set_message('my_validation', 'Ingresó Acción, falta en Controlador');
            return FALSE;
        }

        //Si ingresó URL, no puede haber ni Controlador ni Accion
        if($url AND ($ctr OR $acc)) {
            $this->CI->form_validation->set_message('my_validation', 'Si ingresa URL, no ingresar ni Controlador ni Acción');
            return FALSE;
        }

        return TRUE;
    }

    public function findByControlador($controlador) {
        $this->CI->db->where('controlador', $controlador);
        return $this->CI->db->get('menu_public')->row();
    }

}
