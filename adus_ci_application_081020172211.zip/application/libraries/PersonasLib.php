<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * AccessRegistryLib Library Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
// Validaciones para el modelo de usuarios (login, cambio clave, CRUD Usuario)
class PersonasLib{

	function __construct(){
		$this->CI = & get_instance(); //Instanciamos al super objeto
    }


    public function getPersonas($id){
		$query = $this->CI->db->query('SELECT sesiones_temp.*, usuario.nombres as nombres, usuario.apellidos as apellidos,
										usuario.image as foto, perfil.perfil as perfil
										FROM sesiones_temp
										LEFT JOIN usuario ON (sesiones_temp.usuario_id = usuario.id)
										LEFT JOIN perfil ON (sesiones_temp.perfil_id = perfil.id)')->result();
		
		$users = array();
		foreach($query as $registro){
			$now=time() - $registro->Date;
			if ($now<60) $now=$now." segundos.";
			
			else if ($now>60 AND $now<3600){
				$now_minute= intval($now/60);
				$now_second=$now%60;
				$now=$now_minute." minutos, ".$now_second. " segundos.";
			}
			else if ($now>3600 AND $now<86400){
				$now_hour=intval($now/3600);
				$now_minute=intval(($now%3600)/60);
				$now_second=$now%60;
				$now=$now_hour." horas, ".$now_minute. " minutos, ".$now_second." segundos.";
			}
			else if ($now>86400 AND $now<604800)
				$now='Hace '.intval($now/86400)." dia(s).";
			else if ($now>604800 AND $now<2592000)
				$now="Hace mas de ".intval($now/604800)." semana(s).";
			else if ($now>2592000 AND $now<31104000)
				$now="Hace mas de ".intval($now/2592000)." mes(es).";
			else if ($now>31104000)
				$now="Hace mas de 1 a�o.";
		
			$users[] = array(
				'id'=> $registro->id,
				'nombres'=> $registro->nombres,
				'apellidos'=> $registro->apellidos,
				'perfil'=> $registro->perfil,
				'foto'=> $registro->foto,
				'ip'=> $registro->ip,
				'date'=> $now,
				'lat'=> $registro->Latitude,
				'lng'=> $registro->Longitude,
				'zonetime'=> $registro->ZoneTime,
				'entrada'=> $registro->entrada
			);
			//$users["data"]["users"][] = $registro;
		}		
		echo json_encode($users);
    }

}
