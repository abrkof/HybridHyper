<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * AccessRegistryLib Library Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
// Validaciones para el modelo de usuarios (login, cambio clave, CRUD Usuario)
class AccessRegistryLib{

	function __construct(){
		$this->CI = & get_instance(); //Instanciamos al super objeto

		$this->CI->load->model('Model_Access_Registry');
		$this->CI->load->model('Model_Menu');
        $this->CI->load->model('Model_SubMenu');
    }


    public function my_access_registry(){
		$query1 = $this->CI->Model_Menu->get_menu_lv1();
		$menu = $query1->row();
		
		$query2 = $this->CI->Model_Menu->get_menu_lv2();
		$menu_module = $query2->row();
		
		$query3 = $this->CI->Model_SubMenu->get_submenu_lv1();
		$submenu = $query3->row();
		
		$query4 = $this->CI->Model_SubMenu->get_submenu_lv2();
		$submenu_module = $query4->row();
		
		switch ($this->CI->uri->segment(1)){
			case strtolower($menu_module->module_name):
				$registro['module'] = $menu_module->module_name;
				$registro['controlador'] = $this->CI->uri->segment('2');
				$registro['accion'] = $this->CI->uri->segment('3');
				$registro['variable'] = $this->CI->uri->segment('4');
			break;
			
			case strtolower($menu->controlador):
				$registro['module'] = 'System';
				$registro['controlador'] = $this->CI->uri->segment('1');
				$registro['accion'] = $this->CI->uri->segment('2');
				$registro['variable'] = $this->CI->uri->segment('3');
			break;
			
			case strtolower($submenu_module->module_name):
				$registro['module'] = $submenu_module->module_name;
				$registro['controlador'] = $this->CI->uri->segment('2');
				$registro['accion'] = $this->CI->uri->segment('3');
				$registro['variable'] = $this->CI->uri->segment('4');
			break;
		
			default:
			$registro['module'] = 'System';
			$registro['controlador'] = $this->CI->uri->segment('1');
			$registro['accion'] = $this->CI->uri->segment('2');
			$registro['variable'] = $this->CI->uri->segment('3');
		}
		
		$registro['usuario_id'] = $this->CI->session->userdata('usuario_id');
		$registro['ip'] = $_SERVER['REMOTE_ADDR'];
		$registro['Latitude'] = $this->CI->session->userdata('usuario_latitude');
		$registro['Longitude'] = $this->CI->session->userdata('usuario_longitude');
		$registro['ZoneTime'] = $this->CI->session->userdata('usuario_zonetime');

		$this->CI->Model_Access_Registry->insert($registro);
		return TRUE;
    }

}
