<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Categoria Model Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Model_Sub_Categoria extends CI_Model {

	function __construct() {
		parent::__construct();
    }

    function all($pagination, $segment) {
        $this->db->select('subcategoria.*, categoria.categoria as categoria_name, usuario.nombres as usuario_name, usuario.apellidos as usuario_ape, perfil.perfil as perfil_name');
        $this->db->from('subcategoria');
        $this->db->join('categoria', 'subcategoria.categoria_id = categoria.id', 'left');
		$this->db->join('usuario', 'subcategoria.usuario_id = usuario.id', 'left');
        $this->db->join('perfil', 'subcategoria.perfil_id = perfil.id', 'left');
		$this->db->limit($pagination, $segment);
        $query = $this->db->get();
        return $query->result();
    }

    function all_subcategorias() {
        $this->db->order_by('subcategoria','ASC');
		$query = $this->db->get('subcategoria');
        return $query->result();
    }
	
	function subcategoria(){
		$this->db->select('subcategoria.*');
		$this->db->where('categoria_id', $_REQUEST['i']);
		$this->db->from('subcategoria');
		
        $query = $this->db->get();
        return $query->result();
	}

	function get_subcategoria($pagination, $segment) {
		$query = $this->db->get('subcategoria');
		$this->db->limit($pagination, $segment);
		return $this->db->get('subcategoria')->result();
	}

    function allFiltered($field, $value, $pagination, $segment) {
        $this->db->like($field, $value);
		$this->db->limit($pagination, $segment);
        $query = $this->db->get('subcategoria');
        return $query->result();
    }

    function find($id) {
    	$this->db->where('id', $id);
		return $this->db->get('subcategoria')->row();
    }

    function insert($registro) {
    	$this->db->set($registro);
		$this->db->insert('subcategoria');
    }

    function update($registro) {
    	$this->db->set($registro);
		$this->db->where('id', $registro['id']);
		$this->db->update('subcategoria');
    }

    function delete($id) {
    	$this->db->where('id', $id);
		$this->db->delete('subcategoria');
    }

    //obtenemos el total de filas para hacer la paginaci�n del buscador
    function got_subcategoria($buscador){
        $this->db->select('subcategoria.*, categoria.categoria as categoria_name, usuario.nombres as usuario_name, usuario.apellidos as usuario_ape, perfil.perfil as perfil_name');
        $this->db->join('categoria', 'subcategoria.categoria_id = categoria.id', 'left');
		$this->db->join('usuario', 'subcategoria.usuario_id = usuario.id', 'left');
        $this->db->join('perfil', 'subcategoria.perfil_id = perfil.id', 'left');
        $this->db->like('subcategoria', $buscador);
		//$this->db->where('categoria', $buscador);
        $query = $this->db->get('subcategoria');
        return $query->num_rows();
    }
    //obtenemos todos los posts a paginar con la funci�n
    //total_posts_paginados pasando lo que buscamos, la cantidad por p�gina y el segmento
    //como par�metros de la misma
    function total_posts_paginados($buscador, $por_pagina, $segmento) {
        $this->db->select('subcategoria.*, categoria.categoria as categoria_name, usuario.nombres as usuario_name, usuario.apellidos as usuario_ape, perfil.perfil as perfil_name');
        //$this->db->from('subcategoria');
        $this->db->join('categoria', 'subcategoria.categoria_id = categoria.id', 'left');
		$this->db->join('usuario', 'subcategoria.usuario_id = usuario.id', 'left');
        $this->db->join('perfil', 'subcategoria.perfil_id = perfil.id', 'left');
        $this->db->like('subcategoria', $buscador);
        $query = $this->db->get('subcategoria', $por_pagina, $segmento);
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $registro) {
            $data[] = $registro;
        }
            return $data;
        }
    }

    function get_categorias() {
        $lista = array();
        $this->load->model('site/Model_Categoria');
        $registros = $this->Model_Categoria->all();
        foreach ($registros as $registro) {
            $lista[$registro->id] = $registro->categoria;
        }
        return $lista;
    }

}