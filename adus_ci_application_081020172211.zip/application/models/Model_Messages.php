<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Model_Messages extends CI_Model {

	function __construct() {
		parent::__construct();
    }

    public function get_all($pagination, $segment) {
		$usern = $this->session->userdata('usuario_login');

        $this->db->select('messages.*, perfil.perfil as perfil_name, usuario.nombres as usuario_name, usuario.apellidos as usuario_ape, 
							usuario.image as usuario_image, usuario.login as usuario_login');
		$this->db->from('messages', 'usuario', 'perfil');
		$this->db->where('messages.remitente',$usern);
		$this->db->where('messages.state_a',1);
        $this->db->join('usuario', 'messages.emisor = usuario.login', 'left');
		$this->db->join('perfil', 'usuario.perfil_id = perfil.id', 'left');
		$this->db->order_by('id', 'desc');
		
		$this->db->limit($pagination, $segment);		
        $query = $this->db->get();
        return $query->result();
    }
	
    public function get_all_x() {
		$usern = $this->session->userdata('usuario_login');

        $this->db->select('messages.*');
		$this->db->from('messages');
		$this->db->where('remitente',$usern);
		$this->db->where('state_a',1);
		$this->db->where('state_b',1);
		$this->db->where('state_c',0);
		$this->db->limit(5);
		$this->db->order_by('id', 'desc');
		
        $query = $this->db->get();
        return $query->result();
    }

    public function get_sent($pagination, $segment) {
		$usern = $this->session->userdata('usuario_login');
		
        $this->db->select('messages.*, perfil.perfil as perfil_name, usuario.nombres as usuario_name, usuario.apellidos as usuario_ape, 
							usuario.image as usuario_image, usuario.login as usuario_login');
		$this->db->from('messages', 'usuario', 'perfil');
		$this->db->where('messages.emisor', $usern);
		//$this->db->where('login', 'remitente');
		$this->db->where('messages.state_b',1);
        $this->db->join('usuario', 'messages.emisor = usuario.login', 'left');
		$this->db->join('perfil', 'usuario.perfil_id = perfil.id', 'left');
		$this->db->order_by('id', 'desc');
		
		$this->db->limit($pagination, $segment);
        $query = $this->db->get();
		/*$query = $this->db->query('select messages.*,
						perfil.perfil as perfil_name, usuario.nombres as usuario_name, 
						usuario.apellidos as usuario_ape, usuario.image as usuario_image, 
						usuario.login as usuario_login
						from messages
						left join usuario ON (messages.emisor = usuario.login)
						left join perfil ON (usuario.perfil_id = perfil.id)
						where messages.emisor = "'.$usern.'" and messages.state_b = 1 
						order by id desc');*/
        return $query->result();
    }

    function find_remitente($id) {
    	$usern = $this->session->userdata('usuario_login');
        $this->db->select('messages.*, perfil.perfil as perfil_name, usuario.nombres as usuario_name, usuario.apellidos as usuario_ape, 
							usuario.image as usuario_image, usuario.login as usuario_login');
        $this->db->join('usuario', 'messages.remitente = usuario.login', 'left');
		$this->db->join('perfil', 'usuario.perfil_id = perfil.id', 'left');
		$this->db->where('messages.id', $id);
		$this->db->where('remitente', $usern);
		return $this->db->get('messages')->row();
    }

    function find_emisor($id) {
    	$usern = $this->session->userdata('usuario_login');
		$this->db->where('id', $id);
		$this->db->where('emisor', $usern);
		return $this->db->get('messages')->row();
    }

    function insert($registro) {
    	$this->db->set($registro);
		$this->db->insert('messages');
    }

    function insert_rd($registro) {
		$this->db->set($registro);
		//$this->db->where('Latitude BETWEEN "'.$this->session->userdata('update_latitude'). '" and "'.$this->session->userdata('update_longitude').'"');
		$this->db->insert('requires_on_way');
    }

    function delete_received_messages($id) {
    	$this->db->where('id', $id);
		$this->db->delete('messages');
    }

    function delete_sent_messages($id) {
    	$this->db->where('id', $id);
		$this->db->delete('messages');
    }

	function countRegs(){
        $query = $this->db->query('SELECT COUNT(id) AS total FROM messages');
        return $query->result();
	}

	function count_recived_messages(){
        $usern = $this->session->userdata('usuario_login');
		$query = $this->db->query('SELECT COUNT(id) AS total, id as id FROM messages where remitente="'.$usern.'" AND state_c="0" AND state_b="1" AND state_a="1"');
		//$this->db->query("DELETE FROM messages WHERE created < SUBTIME(NOW(),'00:00:15')");
        return $query->result();
	}

	function count_recived_notify(){
        $usern = $this->session->userdata('usuario_login');
		$query = $this->db->query('SELECT COUNT(id) AS total, id as id, emisor as emisor, remitente as remitente, Latitude as Latitude, Longitude as Longitude
								 FROM messages WHERE remitente="'.$usern.'" AND state_c="0" AND state_b="1" AND state_a="1" AND type="notify"');
		//$this->db->query("DELETE FROM messages WHERE created < SUBTIME(NOW(),'00:00:15') AND remitente='".$usern."' AND type='notify'");
		//$this->delete_recived_notify();
        return $query->result();
	}
	
	function delete_recived_notify(){
		$usern = $this->session->userdata('usuario_login');
		$query = $this->db->query("SELECT * FROM messages WHERE remitente='".$usern."' AND state_a='1' AND state_b='1' AND state_c='0' AND type='notify'")->row();
		$segundos = time() - $query->Date;
		if ($segundos<60) $segundos = $segundos;
		//echo $segundos;
		if($segundos >15){$this->db->query("DELETE FROM messages WHERE remitente='".$usern."' AND state_a='1' AND state_b='1' AND state_c='0' AND type='notify'");}
	}

	function state_c(){
        $usern = $this->session->userdata('usuario_login');
		$query = $this->db->query('SELECT messages FROM messages WHERE remitente="'.$usern.'" AND state_c="0" limit 1');
        return $query->result();
	}

	function state_b(){
        $usern = $this->session->userdata('usuario_login');
		$query = $this->db->query('SELECT * FROM messages WHERE emisor="'.$usern.'" AND state_b="1"');
        return $query->result();
	}

	function state_a(){
        $usern = $this->session->userdata('usuario_login');
		$query = $this->db->query('SELECT * FROM messages WHERE remitente="'.$usern.'" AND state_a="1"');
        return $query->result();
	}

	function update_a($id){
        $usern = $this->session->userdata('usuario_login');
		//$query = $this->db->query('UPDATE messages SET state_a="0" WHERE remitente="'.$usern.'" AND id="'.$id.'"');
    	$this->db->set(array('state_a'=>'0', 'remitente'=>$usern));
		$this->db->where('id', $id);
		$this->db->update('messages');
	}

	function update_b($id){
        $usern = $this->session->userdata('usuario_login');
		//$query = $this->db->query('UPDATE messages SET state_b="0" WHERE emisor="'.$usern.'" AND id="'.$id.'"');
    	$this->db->set(array('state_b'=>'0', 'emisor'=>$usern));
		$this->db->where('id', $id);
		$this->db->update('messages');
	}

	function update_c($id){
        $usern = $this->session->userdata('usuario_login');
		//$query = $this->db->query('UPDATE messages SET state_c="1" WHERE remitente="'.$usern.'" AND id="'.$id.'"');
    	$this->db->set(array('state_c'=>'1', 'remitente'=>$usern));
		$this->db->where('id', $id);
		$this->db->update('messages');
	}

}
