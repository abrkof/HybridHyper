<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Sesiones Model Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Model_Sesiones extends CI_Model {

	function __construct() {
		parent::__construct();
    }

	function all($pagination, $segment) {
		$this->db->select('sesiones.* , perfil.perfil as perfil_name, usuario.nombres as usuario_name, usuario.apellidos as usuario_ape, usuario.image as usuario_image');
		$this->db->order_by('id', 'desc'); // Opcionalmente usar 'asc'
		$this->db->from('sesiones','usuario');
		$this->db->join('usuario', 'sesiones.usuario_id = usuario.id', 'left');
		$this->db->join('perfil', 'usuario.perfil_id = perfil.id', 'left');
		$this->db->limit($pagination, $segment);
	
		$query = $this->db->get();
		return $query->result();
			  
	}

    function allFiltered($field, $value, $pagination, $segment) {
	   	$value = $this->input->post('buscar');

		$this->db->select('sesiones.* , perfil.perfil as perfil_name, usuario.nombres as usuario_name, usuario.apellidos as usuario_ape, usuario.image as usuario_image');
		$this->db->order_by('id', 'desc'); // Opcionalmente usar 'asc'
		$this->db->from('sesiones', 'usuario');
		$this->db->join('usuario', 'sesiones.usuario_id = usuario.id', 'left');
		$this->db->join('perfil', 'sesiones.perfil_id = perfil.id', 'left');
		$this->db->where('usuario.name',$value);
		$this->db->limit($pagination, $segment);

        $query = $this->db->get();
        return $query->result();
    }
	
	/*function load_system(){
		$ip = $_SERVER['REMOTE_ADDR'];
		$query = $this->db->query('INSERT INTO load_system (ip,Latitude,Longitude,ZoneTime) VALUES ("'.$_SERVER['REMOTE_ADDR'].'","'.$_COOKIE[locx].'","'.$_COOKIE[locy].'","'.$_COOKIE[xdate].'")');
	}*/

    function findx1($id) {
    	$this->db->where('id', $id);
		return $this->db->get('sesiones')->row();
    }

	function insert(){
		$dateonlinex = date(DATE_ATOM);
		$dateonline = strtotime($dateonlinex);
		$usuario_id = $this->session->userdata('usuario_id');
		$usuario_state = $this->session->userdata('usuario_state');
		$check_time = $this->db->query('SELECT * FROM sesiones_temp WHERE usuario_id='.$usuario_id.'');
		$online = $check_time->num_rows();
		$ip = $_SERVER['REMOTE_ADDR'];
		$latitude = $_COOKIE['locx'];
		$longitude = $_COOKIE['locy'];
		$xdate = $_COOKIE['onlinedate'];
		$entrada = date('Y-m-d H:i:s');
		if($online==0){
			$this->db->query('INSERT INTO sesiones (usuario_id,ip,Date,Latitude,Longitude,ZoneTime,entrada,salida) VALUES ("'.$usuario_id.'","'.$ip.'","Procesando Algoritmo ...","'.$latitude.'","'.$longitude.'","'.$xdate.'","'.$entrada.'","En Espera ...")');
			$this->db->query('INSERT INTO sesiones_temp (usuario_id,estado,ip,Date,Latitude,Longitude,ZoneTime,entrada,salida) VALUES ("'.$usuario_id.'","'.$usuario_state.'","'.$ip.'","'.$dateonline.'","'.$latitude.'","'.$longitude.'","'.$xdate.'","'.$entrada.'","En Espera ...")');
		} else {
			//$this->db->query('UPDATE sesiones_temp SET Date="'.$dateonline.'" WHERE usuario_id="'.$usuario_id.'"');
			$this->db->query('UPDATE sesiones_temp SET WHERE usuario_id="'.$usuario_id.'"');
		}
	}

    function delete(){
		$usuario_id = $this->session->userdata('usuario_id');
		$onlineusr = $this->db->query('SELECT id FROM sesiones WHERE usuario_id="'.$usuario_id.'"')->result();
		foreach ($onlineusr as $row){
			$t= $row->id;
		}
		//Calculando tiempo lapsado *******************
		$result = $this->db->query('SELECT * FROM sesiones_temp WHERE usuario_id="'.$usuario_id.'" ORDER BY Date DESC')->result();
		foreach($result as $row){
			$now=time() - $row->Date;
			if ($now<60) $now=$now." segundos.";

			else if ($now>60 AND $now<3600){
				$now_minute= intval($now/60);
				$now_second=$now%60;
				$now=$now_minute." minutos, ".$now_second. " segundos.";
        	} else if ($now>3600 AND $now<86400){
				$now_hour=intval($now/3600);
				$now_minute=intval(($now%3600)/60);
				$now_second=$now%60;
				$now=$now_hour." horas, ".$now_minute. " minutos, ".$now_second." segundos.";
        	}
			else if ($now>86400 AND $now<604800)
			$now=''.intval($now/86400)." dia(s).";
			else if ($now>604800 AND $now<2592000)
			$now="M�s de ".intval($now/604800)." semana(s).";
			else if ($now>2592000 AND $now<31104000)
			$now="M�s de ".intval($now/2592000)." mes(es).";
			else if ($now>31104000)
			$now="M�s de 1 a�o.";
			$tr = $now;
			}
		$salida = date('Y-m-d H:i:s');
		$this->db->query('UPDATE sesiones SET salida="'.$salida.'", Date="'.$tr.'" WHERE id="'.$t.'" AND usuario_id="'.$usuario_id.'"');
		$this->db->query('DELETE FROM sesiones_temp WHERE usuario_id="'.$usuario_id.'"');
    }

    //obtenemos el total de filas para hacer la paginaci�n del buscador
    function got_usuario($buscador){
        $this->db->select('sesiones.* , perfil.perfil as perfil_name, usuario.nombres as usuario_name, usuario.apellidos as usuario_ape, usuario.image as usuario_image');
		$this->db->order_by('id', 'desc'); // Opcionalmente usar 'asc'
        $this->db->join('usuario', 'sesiones.usuario_id = usuario.id', 'left');
		$this->db->join('perfil', 'sesiones.perfil_id = perfil.id', 'left');
        $this->db->like('usuario.nombres', $buscador);
		$this->db->or_like('usuario.apellidos', $buscador);
		$this->db->or_like('perfil.name', $buscador);
		//$this->db->where('tbl', $buscador);
        $query = $this->db->get('sesiones');
        return $query->num_rows();
    }
    //obtenemos todos los posts a paginar con la funci�n
    //total_posts_paginados pasando lo que buscamos, la cantidad por p�gina y el segmento
    //como par�metros de la misma
    function total_posts_paginados($buscador, $por_pagina, $segmento) {
        $this->db->select('sesiones.*, perfil.perfil as perfil_name, usuario.nombres as usuario_name, usuario.apellidos as usuario_ape, usuario.image as usuario_image');
		$this->db->order_by('id', 'desc'); // Opcionalmente usar 'asc'
        $this->db->join('usuario', 'sesiones.usuario_id = usuario.id', 'left');
		$this->db->join('perfil', 'sesiones.perfil_id = perfil.id', 'left');
        $this->db->like('usuario.nombres', $buscador);
		$this->db->or_like('usuario.apellidos', $buscador);
		$this->db->or_like('perfil.perfil', $buscador);
        $query = $this->db->get('sesiones', $por_pagina, $segmento);
        if ($query->num_rows() > 0){
            foreach ($query->result() as $registro) {
            	$data[] = $registro;
        	}
            return $data;
        }
    }

	function countRegs(){
        $query = $this->db->query('SELECT COUNT(usuario_id) as total, sesiones.usuario_id, 
									perfil.perfil as perfil_name,
									usuario.nombres as usuario_name, usuario.apellidos as usuario_ape
									FROM sesiones 
									left join usuario ON (sesiones.usuario_id = usuario.id)
									left join perfil ON (usuario.perfil_id = perfil.id)
									GROUP BY usuario_id');
        return $query->result();
	}

	function countTotalRegs(){
        $query = $this->db->query('SELECT COUNT(id) as total FROM sesiones');
        return $query->result();
	}

}
