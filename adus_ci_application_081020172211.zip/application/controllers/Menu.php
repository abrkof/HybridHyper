<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Menu Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Menu extends CI_Controller {

	//Constructor de Clase
	function __construct() {
		parent::__construct();

		$this->load->model('Model_Menu');
		$this->load->library('menuLib');

		$this->form_validation->set_message('required', 'Debe ingresar un valor para %s');
		$this->form_validation->set_message('numeric', '%s debe ser un número');
		$this->form_validation->set_message('is_natural', '%s debe ser un número mayor a cero');
	}

	public function index() {
	    $this->accessregistrylib->my_access_registry();
		
		$pagination = 20;
		$config['base_url'] = base_url().'menu/index';
        $config['total_rows'] = $this->db->get('menu')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 1; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

		$data['contenido'] = 'menu/index';
		$data['titulo'] = 'Menús';
		$data['query'] = $this->Model_Menu->all($pagination, $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}

    //con esta función validamos y protegemos el buscador
    public function validar(){
        $this->accessregistrylib->my_access_registry();
		
		$this->form_validation->set_rules('buscar', 'Menú', 'required|min_length[2]|max_length[20]|trim|xss_clean');
        if ($this->form_validation->run() == TRUE) {
            $buscador = $this->input->post('buscar');
            $this->session->set_userdata('buscar', $buscador);
            redirect('menu/consultar');
        } else {
			$data['titulo'] = 'Menús';
			$data['contenido'] = 'menu/result';
			$this->load->view('template/template', $data);
        }
    }

	public function consultar(){
        $this->accessregistrylib->my_access_registry();
		
		$buscador = $this->session->userdata('buscar');
        $pagination = 20; //Número de registros mostrados por páginas
        $config['base_url'] = base_url().'menu/consultar'; // parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php
        $config['total_rows'] = $this->Model_Menu->got_menu($buscador); //calcula el número de filas
        $config['per_page'] = $pagination; //Número de registros mostrados por páginas
        $config['num_links'] = 10; //Número de links mostrados en la paginación
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //inicializamos la paginación
        //el array con los datos a paginar ya preparados
        $data['query'] = $this->Model_Menu->total_posts_paginados($buscador, $config['per_page'], $this->uri->segment(3));

		$data['titulo'] = 'Menús';
		$data['contenido'] = 'menu/result';
		$this->load->view('template/template', $data);
	}

	public function my_validation() {
		return $this->menulib->my_validation($this->input->post());
	}

	public function create() {
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Crear Menú';
		$data['contenido'] = 'menu/create';
		$data['modules'] = $this->Model_Menu->get_modules(); /* Lista de los Módulos */
		$data['count'] = $this->db->get('menu')->num_rows();
		$this->load->view('template/template', $data);
	}

	public function insert() {
		$this->accessregistrylib->my_access_registry();
		
		$registro = $this->input->post();

		$this->form_validation->set_rules('menu', 'Nombre', 'required|callback_my_validation');
		$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		if($this->form_validation->run() == FALSE) {
			$this->create();
		} else {
			$registro['created'] = date('Y-m-d H:i:s');
			$registro['updated'] = date('Y-m-d H:i:s');
			
			$this->Model_Menu->insert($registro);
			redirect('menu/index');
		}
	}

	public function edit($id) {
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Actualizar Menú';
		$data['contenido'] = 'menu/edit';
		$data['modules'] = $this->Model_Menu->get_modules(); /* Lista de los Módulos */
		$data['registro'] = $this->Model_Menu->find($id);
		$this->load->view('template/template', $data);
	}

	public function update() {
		$this->accessregistrylib->my_access_registry();
		
		$registro = $this->input->post();

		$this->form_validation->set_rules('menu', 'Nombre', 'required|callback_my_validation');
		$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		} else {
			$registro['updated'] = date('Y-m-d H:i:s');
			$this->Model_Menu->update($registro);
			redirect('menu/index');
		}
	}

	public function delete($id) {
		$this->accessregistrylib->my_access_registry();
		
		$this->Model_Menu->delete($id);
		redirect('menu/index');
	}

	public function menu_perfiles($menu_id) {
		$this->accessregistrylib->my_access_registry();
		
		$data['contenido'] = 'menu/menu_perfiles';
		$data['titulo'] = 'Accesos de '.$this->Model_Menu->find($menu_id)->menu;

		// Cargar arreglos Izquierda y Derecha
		$perfiles = $this->menulib->get_perfiles_asig_noasig($menu_id);
		$data['query_izq'] = $perfiles[0];
		$data['query_der'] = $perfiles[1];

		$this->load->view('template/template', $data);
	}

	public function mp_noasig() {
		$this->accessregistrylib->my_access_registry();
		
		$perfil_id = $this->uri->segment(3);
		$menu_id = $this->uri->segment(4);

		$this->load->library('menu_PerfilLib');
		$this->menu_perfillib->quitar_acceso($perfil_id, $menu_id);
		redirect('menu/menu_perfiles/'.$menu_id);
	}

	public function mp_asig() {
		$this->accessregistrylib->my_access_registry();
		
		$perfil_id = $this->uri->segment(3);
		$menu_id = $this->uri->segment(4);

		$this->load->library('menu_PerfilLib');
		$this->menu_perfillib->dar_acceso($perfil_id, $menu_id);
		redirect('menu/menu_perfiles/'.$menu_id);
	}

//--------------------------Vistas para accesos de partes del sistema--------------------------
	public function menu_vistas($id) {
		$this->accessregistrylib->my_access_registry();
		
		$data['contenido'] = 'menu/menu_vistas';
		$data['titulo'] = 'Mostrando Links';
		$data['registro'] = $this->Model_Menu->find($id); /*Lista de los Menús*/
		$data['perfiles'] = $this->Model_Menu_Perfil->get_perfiles(); /*Lista de los Perfiles */
		$this->load->view('template/template', $data);
	}

	public function update_menu_vistas() {
		$this->accessregistrylib->my_access_registry();
		
		$registro = $this->input->post();
		$registro['updated'] = date('Y-m-d H:i:s');
		$this->Model_Menu_Vistas->update($registro);
		redirect('menu/index');
	}

	public function menu_perfiles_vistas($menu_id) {
		$this->accessregistrylib->my_access_registry();
		
		$data['contenido'] = 'menu/menu_perfiles_vistas';
		$data['titulo'] = 'Accesos de '.$this->Model_Menu->find($menu_id)->menu;

		// Cargar arreglos Izquierda y Derecha
		$perfiles = $this->menulib->get_perfilesx_asig_noasig($menu_id);
		$data['query_izq'] = $perfiles[0];
		$data['query_der'] = $perfiles[1];

		$this->load->view('template/template', $data);
	}

	public function mpv_noasig() {
		$this->accessregistrylib->my_access_registry();
		
		$perfil_id = $this->uri->segment(3);
		$menu_id = $this->uri->segment(4);

		$this->load->library('menu_Perfil_VistasLib');
		$this->menu_perfil_vistaslib->quitar_acceso_vistas($perfil_id, $menu_id);
		redirect('menu/menu_perfiles_vistas/'.$menu_id);
	}

	public function mpv_asig() {
		$this->accessregistrylib->my_access_registry();
		
		$perfil_id = $this->uri->segment(3);
		$menu_id = $this->uri->segment(4);

		$this->load->library('menu_Perfil_VistasLib');
		$this->menu_perfil_vistaslib->dar_acceso_vistas($perfil_id, $menu_id);
		redirect('menu/menu_perfiles_vistas/'.$menu_id);
	}
//--------------------------Vistas para accesos de partes del sistema--------------------------

    //Creamos una acción para cargar el ordenar los menús.
    public function menu_orden(){
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Odenando Menús';
		$data['contenido'] = 'menu/menu_system_ordenar';
		$data['query'] = $this->Model_Menu->all_system();
		$this->load->view('template/template',$data);
    }
    //Creamos una acción para actualizar el orden de los menús.
    public function update_orden(){
		$this->accessregistrylib->my_access_registry();
		
		//aquí ordenaremos los articulos con ajax.
		//array con el nuevo orden de nuestros registros.
		$menus_ordenados = $_POST['menu'];
		$pos = 1;
		foreach ($menus_ordenados as $key){
			//actualizamos el campo orden.
			$this->db->set('orden', $pos);
			$this->db->where('id', $key);
			$this->db->update('menu');
			$pos++;
		}
		echo "El Menú se ha Actualizado con Exito!!!";
	}

}
