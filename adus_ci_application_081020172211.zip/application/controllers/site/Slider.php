<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Slider Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Slider extends CI_Controller {

    function __construct() {
        parent::__construct();
		$this->load->model('site/Model_Slider');

		$this->form_validation->set_message('required', 'Debe ingresar campo %s');
        $this->form_validation->set_message('required', 'Campo %s no es un imagen valida');
        $this->form_validation->set_message('my_validation', 'Existe otro registro con el mismo nombre');/**/
    }

	public function index() {
	    $this->accessregistrylib->my_access_registry();
		
		$pagination = 10;
		$config['base_url'] = base_url().'site/slider/index';
        $config['total_rows'] = $this->db->get('slider')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

		$data['titulo'] = 'Sliders';
		$data['contenido'] = 'modules/abrkof/site/slider/index';
		$data['query'] = $this->Model_Slider->get_slider($pagination, $this->uri->segment(4));
		$this->load->view('template/template', $data);
	}

    //con esta función validamos y protegemos el buscador
    public function validar(){
        $this->accessregistrylib->my_access_registry();
		
		$this->form_validation->set_rules('buscar', 'Título', 'required|min_length[2]|max_length[20]|trim|xss_clean');

        if ($this->form_validation->run() == TRUE) {
            $buscador = $this->input->post('buscar');
            $this->session->set_userdata('buscar', $buscador);
            redirect('site/slider/consultar');
        } else {
			$data['titulo'] = 'Sliders';
			$data['contenido'] = 'modules/abrkof/site/slider/result';
			$this->load->view('template/template', $data);
        }
    }

	public function consultar() {
        $this->accessregistrylib->my_access_registry();
		
		$buscador = $this->session->userdata('buscar');
        $pages = 10; //Número de registros mostrados por páginas
        $config['base_url'] = base_url() . 'site/slider/consultar'; // parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php
        $config['total_rows'] = $this->Model_Slider->got_slider($buscador); //calcula el número de filas
        $config['per_page'] = $pages; //Número de registros mostrados por páginas
        $config['num_links'] = 10; //Número de links mostrados en la paginación
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //inicializamos la paginación
	
		$data['titulo'] = 'Sliders';
		$data['contenido'] = 'modules/abrkof/site/slider/result';
		$data['query'] = $this->Model_Slider->total_posts_paginados($buscador, $config['per_page'], $this->uri->segment(4));
		$this->load->view('template/template', $data);
	}

	public function norep() {
		//eturn $this->sliderlib->norep($this->input->post());
	}

	public function create() {
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Crear Slider';
		$data['contenido'] = 'modules/abrkof/site/slider/create';
		$this->load->view('template/template', $data);
	}

    //FUNCIÓN PARA SUBIR LA IMAGEN Y VALIDAR EL TÍTULO
    function do_upload() {
        $this->accessregistrylib->my_access_registry();
		
		$registro = $this->input->post();
		$this->form_validation->set_rules('titulo', 'Título', 'required|min_length[5]|max_length[10]|trim|xss_clean|callback_norep');
		//$this->form_validation->set_rules('descripcion', 'Descripción', 'required|xss_clean');
		//$this->form_validation->set_rules('userfile', 'Imagen', 'required');
        $this->form_validation->set_message('required', 'El %s no puede ir vacío!');
        $this->form_validation->set_message('min_length', 'El %s debe tener al menos %s carácteres');
        $this->form_validation->set_message('max_length', 'El %s no puede tener más de %s carácteres');
        //SI EL FORMULARIO PASA LA VALIDACIÓN HACEMOS TODO LO QUE SIGUE
        if ($this->form_validation->run() == FALSE){
			$this->create();
		}else{
			$config['upload_path'] = './assets/images/';
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size'] = '2000';
			$config['max_width'] = '2024';
			$config['max_height'] = '2008';
			//Hacemos el requeriento de la libreria "upload"
			$this->load->library('upload', $config);
			//SI LA IMAGEN FALLA AL SUBIR MOSTRAMOS EL ERROR EN LA VISTA ACTUAL
			if (!$this->upload->do_upload()) {
			$data = array('error' => $this->upload->display_errors());
			$data['titulo'] = 'Creando Slider';
			$data['contenido'] = 'modules/abrkof/site/slider/create';
			$this->load->view('template/template', $data);
            //redirect('upload/do_upload', $error);
			} else {
				//EN OTRO CASO SUBIMOS LA IMAGEN, CREAMOS LA MINIATURA Y HACEMOS 
				//ENVÍAMOS LOS DATOS AL MODELO PARA HACER LA INSERCIÓN
				$file_info = $this->upload->data();
				//USAMOS LA FUNCIÓN create_thumbnail Y LE PASAMOS EL NOMBRE DE LA IMAGEN,
				//ASÍ YA TENEMOS LA IMAGEN REDIMENSIONADA
				$this->_create_thumbnail($file_info['file_name']);
				$data = array('upload_data' => $this->upload->data());
				$registro['ip'] = $_SERVER['REMOTE_ADDR'];
				$registro['created'] = date('Y/m/d H:i:s');
				$registro['updated'] = date('Y/m/d H:i:s');
				$registro['usuario_id'] = $this->session->userdata('usuario_id');
				$registro['perfil_id'] = $this->session->userdata('perfil_id');
				$registro['userfile'] = $file_info['file_name'];
				$this->Model_Slider->insert($registro);
	
				redirect('site/slider/index');
			}
		}

	 }

	public function edit($id) {
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Actualizar Slider';
		$data['contenido'] = 'modules/abrkof/site/slider/edit';
		$data['registro'] = $this->Model_Slider->find($id);
		$this->load->view('template/template', $data);
	}

	public function update() {
		$this->accessregistrylib->my_access_registry();
		
		$registro = $this->input->post();

		$this->form_validation->set_rules('titulo', 'Título', 'required|callback_norep');
		
		if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		} else {
			$registro['ip'] = $_SERVER['REMOTE_ADDR'];
			$registro['updated'] = date('Y/m/d H:i');
			$this->Model_Slider->update($registro);
			redirect('site/slider/index');
		}
	}

	public function edit_img($id) {
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Actualizar Slider';
		$data['contenido'] = 'modules/abrkof/site/slider/edit_img';
		$data['registro'] = $this->Model_Slider->find($id);
		$this->load->view('template/template', $data);
	}

	public function update_img() {
		$this->accessregistrylib->my_access_registry();
		
		$registro = $this->input->post();

		$this->form_validation->set_rules('id', 'id', 'required|callback_norep');
		
		if($this->form_validation->run() == FALSE) {
			$this->edit_img($registro['id']);
			}else{
				$config['upload_path'] = './assets/images/';
				$config['allowed_types'] = 'gif|jpg|jpe|jpeg|png';
				$config['max_size'] = '2000';
				$config['max_width'] = '2024';
				$config['max_height'] = '2008';
				//Hacemos el requeriento de la libreria "upload"
				$this->load->library('upload', $config);
				//SI LA IMAGEN FALLA AL SUBIR MOSTRAMOS EL ERROR EN LA VISTA ACTUAL
				if (!$this->upload->do_upload()) {
				$data = array('error' => $this->upload->display_errors());
				$this->edit_img($registro['id']);
				//redirect('upload/do_upload', $error);
			} else {
				//EN OTRO CASO SUBIMOS LA IMAGEN, CREAMOS LA MINIATURA Y HACEMOS 
				//ENVÍAMOS LOS DATOS AL MODELO PARA HACER LA INSERCIÓN
				$file_info = $this->upload->data();
				//USAMOS LA FUNCIÓN create_thumbnail Y LE PASAMOS EL NOMBRE DE LA IMAGEN,
				//ASÍ YA TENEMOS LA IMAGEN REDIMENSIONADA
				$this->_create_thumbnail($file_info['file_name']);
				$data = array('upload_data' => $this->upload->data());
				$ip = $_SERVER['REMOTE_ADDR'];
				$updated = date('Y/m/d H:i');
				$usrx = $this->session->userdata('usuario_id');
				$pflx = $this->session->userdata('perfil_id');
				$imagen = $file_info['file_name'];
				$registro['userfile'] = $imagen;
				$registro['ip'] = $_SERVER['REMOTE_ADDR'];
				$registro['updated'] = date('Y/m/d H:i');
				$this->Model_Slider->update($registro);
				
				redirect('site/slider/index');
			}
		}
	}

    //FUNCIÓN PARA CREAR LA MINIATURA A LA MEDIDA QUE LE DIGAMOS
    function _create_thumbnail($filename){
       $this->accessregistrylib->my_access_registry();
	   
	    $config['image_library'] = 'gd2';
        //CARPETA EN LA QUE ESTÁ LA IMAGEN A REDIMENSIONAR
        $config['source_image'] = 'assets/images/'.$filename;
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = TRUE;
        //CARPETA EN LA QUE GUARDAMOS LA MINIATURA.
        $config['new_image']='assets/images/thumbs/';
        $config['width'] = 150;
        $config['height'] = 150;
        $this->load->library('image_lib', $config); 
        $this->image_lib->resize();
    }

	public function delete($id) {
		$this->accessregistrylib->my_access_registry();
		
		$this->Model_Slider->delete($id);
		redirect('site/slider/index');
	}

	public function ver_slider() {
		$this->accessregistrylib->my_access_registry();
		
		$data['contenido'] = 'modules/abrkof/site/slider/slider';
		$data['slider'] = $this->Model_Slider->slider();
		$this->load->view('template/template', $data);
	}

    //Creamos una acción para cargar el ordenar los sliders.
    public function orden_slider(){
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Odenando Sliders';
		$data['contenido'] = 'modules/abrkof/site/slider/slider_ordenar';
		$data['query'] = $this->Model_Slider->slider();
		$this->load->view('template/template',$data);
    }

    //Creamos una acción para actualizar el orden de los menús.
    public function update_orden(){
		$this->accessregistrylib->my_access_registry();
		
		//aquí ordenaremos los articulos con ajax.
		//array con el nuevo orden de nuestros registros.
		$sliders_ordenados = $_POST['slider'];
		$pos = 1;
		foreach ($sliders_ordenados as $key){
			//actualizamos el campo orden.
			$this->db->set('orden', $pos);
			$this->db->where('id', $key);
			$this->db->update('slider');
			$pos++;
		}
		echo "El Slider se ha Actualizado con Exito!!!";
	}

}