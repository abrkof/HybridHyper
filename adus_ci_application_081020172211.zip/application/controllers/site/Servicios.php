﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Servicios Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Servicios extends CI_Controller{

	//Constructor de Clase
	function __construct(){
		parent::__construct();

		$this->load->model('site/Model_Servicios');
		$this->load->library('site/ServiciosLib');
        $this->form_validation->set_message('required', 'El %s no puede ir vacío!');
        $this->form_validation->set_message('min_length', 'La %s debe tener al menos %s carácteres');
        $this->form_validation->set_message('max_length', 'La %s no puede tener más de %s carácteres');/**/
	}

	public function index(){
	    $this->accessregistrylib->my_access_registry();
		
		$pagination = 20;
		$config['base_url'] = base_url().'site/servicios/consultar';
        $config['total_rows'] = $this->db->get('servicios')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);
		
		$data['titulo'] = 'Servicios';
		$data['contenido'] = 'modules/abrkof/site/servicios/index';
		$data['query'] = $this->Model_Servicios->all($pagination, $this->uri->segment(4));
		$this->load->view('template/modules/abrkof/site/template', $data);
	}

	public function consultar(){
	    $this->accessregistrylib->my_access_registry();
		
		$pagination = 10;
		$config['base_url'] = base_url().'site/servicios/consultar';
        $config['total_rows'] = $this->db->get('servicios')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);
		
		$data['titulo'] = 'Servicios';
		$data['contenido'] = 'modules/abrkof/site/servicios/procesos/index';
		$data['query'] = $this->Model_Servicios->get_servicios($pagination, $this->uri->segment(4));
		$this->load->view('template/template', $data);
	}

    //con esta función validamos y protegemos el buscador
    public function validar(){
        $this->accessregistrylib->my_access_registry();
		
		$this->form_validation->set_rules('buscar', 'Servicio', 'required|min_length[2]|max_length[20]|trim|xss_clean');

        if ($this->form_validation->run() == TRUE) {
            $buscador = $this->input->post('buscar');
            $this->session->set_userdata('buscar', $buscador);
            redirect('site/servicios/search');
        } else {
			$data['titulo'] = 'Servicios';
			$data['contenido'] = 'modules/abrkof/site/servicios/procesos/result';
			$this->load->view('template/template', $data);
        }
    }

	public function search(){
        $this->accessregistrylib->my_access_registry();
		
		$buscador = $this->session->userdata('buscar');
        $pages = 10; //Número de registros mostrados por páginas
        $config['base_url'] = base_url() . 'site/servicios/search'; // parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php
        $config['total_rows'] = $this->Model_Servicios->got_servicios($buscador); //calcula el número de filas
        $config['per_page'] = $pages; //Número de registros mostrados por páginas
        $config['num_links'] = 10; //Número de links mostrados en la paginación
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //inicializamos la paginación
        //el array con los datos a paginar ya preparados
        $data['query'] = $this->Model_Servicios->total_posts_paginados($buscador, $config['per_page'], $this->uri->segment(4));

		$data['titulo'] = 'Servicios';
		$data['contenido'] = 'modules/abrkof/site/servicios/procesos/result';
		$this->load->view('template/template', $data);
	}

	public function my_validation() {
		return $this->servicioslib->my_validation($this->input->post());
	}

	public function create() {
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Registrando Servicios';
		$data['contenido'] = 'modules/abrkof/site/servicios/procesos/create';
		$this->load->view('template/template', $data);
	}

	public function insert() {
		$this->accessregistrylib->my_access_registry();
		
		$registro = $this->input->post();

		//$this->form_validation->set_rules('name', 'Titulo', 'required|callback_my_validation');
		//$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		/*if($this->form_validation->run() == FALSE) {
			$this->create();
		} else {*/
			$registro['image'] = 'afd-8475.jpg';
			$registro['usuario_id'] = $this->session->userdata('usuario_id');
			$registro['perfil_id'] = $this->session->userdata('perfil_id');
			$registro['created'] = date('Y/m/d H:i');
			$registro['updated'] = date('Y/m/d H:i');
			$this->Model_Servicios->insert($registro);
			redirect('site/servicios/consultar');
		//}
	}

	public function edit($id) {
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Actualizando Servicios';
		$data['contenido'] = 'modules/abrkof/site/servicios/procesos/edit';
		$data['registro'] = $this->Model_Servicios->find($id);
		$this->load->view('template/template', $data);
	}

	public function update() {
		$this->accessregistrylib->my_access_registry();
		
		$registro = $this->input->post();

		//$this->form_validation->set_rules('name', 'Titulo', 'required|callback_my_validation');
		//$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		/*if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		} else {*/
			$registro['usuario_id'] = $this->session->userdata('usuario_id');
			$registro['perfil_id'] = $this->session->userdata('perfil_id');
			$registro['updated'] = date('Y/m/d H:i');
			$this->Model_Servicios->update($registro);
			redirect('site/servicios/consultar');
		//}
	}

	public function delete($id) {
		$this->accessregistrylib->my_access_registry();
		
		$this->Model_Servicios->delete($id);
		redirect('site/servicios/consultar');
	}
    //Creamos una acción para cargar el ordenar los menús
    public function orden_servicio(){
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Odenando Servicios';
		$data['query'] = $this->Model_Servicios->all();
		$data['contenido'] = 'modules/abrkof/site/servicios/procesos/servicios_ordenar';
		$this->load->view('template/template',$data);
    }
    //Creamos una acción para actualizar el orden de los menús
    public function update_orden(){
		$this->accessregistrylib->my_access_registry();
		
		//aquí ordenaremos los articulos con ajax
		//array con el nuevo orden de nuestros registros
		$servicios_ordenados = $_POST['servicio'];
		$pos = 1;
		foreach ($servicios_ordenados as $key){
			//actualizamos el campo orden
			$this->db->set('orden', $pos);
			$this->db->where('id', $key);
			$this->db->update('servicios');
			$pos++;
		}
		echo "Los Servicios se han Actualizado con Exito!!!";
	}

}
