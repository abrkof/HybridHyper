<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * SubMenu Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class SubMenu_Site extends CI_Controller {

	//Constructor de Clase
	function __construct() {
		parent::__construct();

		$this->load->model('site/Model_SubMenu_Site');
	}

    //Creamos una acción para cargar el ordenar los sub menús.
    public function index(){
		$this->accessregistrylib->my_access_registry();
		
		$data['titulo'] = 'Odenando Sub Menús';
		$data['contenido'] = 'site/submenu_site/submenu_site_ordenar';
		$data['query'] = $this->Model_SubMenu_Site->all_site();
		$this->load->view('template/template',$data);
    }
    //Creamos una acción para actualizar el orden de los sub menús.
    public function update_orden(){
		$this->accessregistrylib->my_access_registry();
		
		//aquí ordenaremos los articulos con ajax.
		//array con el nuevo orden de nuestros registros.
		$submenus_ordenados = $_POST['submenu'];
		$pos = 1;
		foreach ($submenus_ordenados as $key){
			//actualizamos el campo orden.
			$this->db->set('orden', $pos);
			$this->db->where('id', $key);
			$this->db->update('submenu');
			$pos++;
		}
		echo "El Sub Menú se ha Actualizado con Exito!!!";
	}

}
