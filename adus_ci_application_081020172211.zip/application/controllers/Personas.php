<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Personas extends CI_Controller {

	//Constructor de Clase
	function __construct() {
		parent::__construct();
		$this->load->library('personasLib');
	}
	
	public function index(){
		$data['titulo'] = 'Personas';
		$data['contenido'] = '';//template/template
		//echo var_dump($this->db->query("SELECT * FROM cyb_users")->result());
		//$data['function'] = $this->get_personas();
		$this->load->view('json', $data);
	}
	
	public function start(){
		if(isset($_GET['id'])) {
			$this->get_personas($_GET['id']);
		} else {
			die("Solicitud no válida.");
		}
	}

	public function get_personas(){
		$this->personaslib->getpersonas();
	}

}                   