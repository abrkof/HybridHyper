﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Messages extends CI_Controller{
    
    public function __construct(){
        parent::__construct();
        $this->load->model('Model_Messages');
		$this->load->library('MessagesLib');
		$this->load->library('usuarioLib');
		$this->form_validation->set_message('required', 'Debe ingresar campo %s');
        $this->form_validation->set_message('required', 'Campo %s no debe ir vacio');
		$this->usern = $this->session->userdata('usuario_login');
    }
    
    public function index(){
        $this->accessregistrylib->my_access_registry();
		
		$data['title'] = 'Mensajes Directos';
		$data['contenido'] = 'directly_messages/index';
        $this->load->view('template/template',$data);
    }

    public function messages(){
	    $this->accessregistrylib->my_access_registry();
		
		$pagination = 10;
        $config['base_url'] = base_url().'messages/messages';
        $config['total_rows'] = $this->db->get_where('messages', array('remitente'=>$this->usern, 'state_a'=>1))->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

        $data['title'] = 'Mensajes Directos';
		
		$data['query'] = $this->Model_Messages->get_all($pagination, $this->uri->segment(3));
		$data['contenido'] = 'directly_messages/received_messages';
        $this->load->view('template/template',$data);
    }

    public function sent(){
	    $this->accessregistrylib->my_access_registry();
		
		$pagination = 10;
        $config['base_url'] = base_url().'messages/sent';
        $config['total_rows'] = $this->db->get_where('messages', array('emisor'=>$this->usern, 'state_a'=>1))->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = 'Última';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

        $data['title'] = 'Mensajes Directos';
		$data['query'] = $this->Model_Messages->get_sent($pagination, $this->uri->segment(3));
		$data['contenido'] = 'directly_messages/sent_messages';
        $this->load->view('template/template',$data);
    }

	public function my_validation(){
		return $this->messageslib->my_validation($this->input->post());
	}

    public function send(){
        $this->accessregistrylib->my_access_registry();
		
		$data['title'] = 'Mensajes Directos';
		$data['contenido'] = 'directly_messages/send_messages';
        $this->load->view('template/template',$data);
    }

	public function send_message(){
		$this->accessregistrylib->my_access_registry();
		
		$registro = $this->input->post();

		$this->form_validation->set_rules('remitente', 'Para', 'required|callback_my_validation');
		$this->form_validation->set_rules('asunto', 'Asunto', 'required');
		$this->form_validation->set_rules('mensaje', 'Mensaje', 'required');
		if($this->form_validation->run() == FALSE){
			$this->send();
		} else {
			$registro['image'] = $this->session->userdata('usuario_image');
			$registro['emisor'] = $this->session->userdata('usuario_login');
			$registro['Latitude'] = $this->session->userdata('update_latitude');
			$registro['Longitude'] = $this->session->userdata('update_longitude');
			$registro['ZoneTime'] = $this->session->userdata('usuario_zonetime');
			$registro['state_a'] = '1';
			$registro['state_b'] = '1';
			$registro['state_c'] = '0';
			$dateonlinex = date(DATE_ATOM);
			$dateonline = strtotime($dateonlinex);
			$registro['Date'] = $dateonline;
			$registro['ip'] = $_SERVER['REMOTE_ADDR'];
			$registro['created'] = date('Y-m-d H:i:s');
			$registro['updated'] = date('Y-m-d H:i:s');
				
			$this->Model_Messages->insert($registro);
			redirect('messages/sent');
		}
	}

	public function resend($id){
        $this->accessregistrylib->my_access_registry();
		
		$data['title'] = 'Mensajes Directos';
		$data['registro'] = $this->Model_Messages->find_emisor($id);
		$data['data'] = $this->Model_Messages->find_emisor($id);
		$data['contenido'] = 'directly_messages/re_send';
        $this->load->view('template/template',$data);
	}

	public function read($id){
        $this->accessregistrylib->my_access_registry();
		
		$data['title']   = 'Mensajes Directos';
		$this->Model_Messages->update_c($id);
		$data['registro'] = $this->Model_Messages->find_remitente($id);
		$data['contenido'] = 'directly_messages/read';
        $this->load->view('template/template',$data);
	}
	
	public function reply($id){
        $this->accessregistrylib->my_access_registry();
		
		$data['title']   = 'Mensajes Directos';
		$this->Model_Messages->update_c($id);
		$data['registro'] = $this->Model_Messages->find_remitente($id);
		$data['contenido'] = 'directly_messages/reply';
        $this->load->view('template/template',$data);
	}

    public function re_send(){
		$this->accessregistrylib->my_access_registry();
		
		$registro['image'] = $this->session->userdata('usuario_image');
		$registro['emisor'] = $this->session->userdata('usuario_login');
		$registro['remitente'] = $this->input->post('remitente');
		$registro['mensaje'] = $this->input->post('mensaje');
		$registro['asunto'] = $this->input->post('asunto');
		$registro['type'] = $this->input->post('type');
		$registro['Latitude'] = $this->session->userdata('update_latitude');
		$registro['Longitude'] = $this->session->userdata('update_longitude');
		$registro['ZoneTime'] = $this->session->userdata('usuario_zonetime');
		$registro['state_a'] = '1';
		$registro['state_b'] = '1';
		$registro['state_c'] = '0';
		$dateonlinex = date(DATE_ATOM);
		$dateonline = strtotime($dateonlinex);
		$registro['Date'] = $dateonline;
		$registro['ip'] = $_SERVER['REMOTE_ADDR'];
		$registro['created'] = date('Y/m/d H:i');
		$registro['updated'] = date('Y-m-d H:i:s');
		$this->Model_Messages->insert($registro);
		redirect('messages/index');
	}

	public function delete_received_message($id){
		$this->accessregistrylib->my_access_registry();
		
		$registro['updated'] = date('Y-m-d H:i:s');
		$this->Model_Messages->update_a($id);
		redirect('messages/read');
	}

	public function delete_sent_message($id){
		$this->accessregistrylib->my_access_registry();
		
		$registro['updated'] = date('Y-m-d H:i:s');
		$this->Model_Messages->update_b($id);
		redirect('messages/sent');
	}

	public function n_m(){
		$this->accessregistrylib->my_access_registry();
		
		$query = $this->Model_Messages->count_recived_messages();
		if($query){
			foreach($query as $registro){
				if($registro->total > 0){
					echo '<span class="badge bg-green">'.$registro->total.'</span>';
				} else {
					echo '<span class="badge bg-blue">'.$registro->total.'</span>';
				}
			}
		}
	}

	public function load_notify(){
		//$this->db->query("DELETE FROM messages WHERE created < SUBTIME(NOW(),'23:59:59')");
		
		$query = $this->Model_Messages->count_recived_notify();
		if($query){
			foreach($query as $registro){
				if($registro->total > 0){
					//<a href="'.base_url('').'messages/read/" style="background-color:transparent;">
					echo '
					<div class="avatarx noze" style="height:100px; width:100px">
						<a href="'.base_url('').'messages/read/'.$registro->id.'" style="background-color:transparent;">
							<img src="'.base_url('').'assets/img/scrib.png">
							<!--<img src="'.base_url('').'assets/siteicons/redactar.png" class="img-circle">-->
						</a>
					</div>';
				} else {
					echo '';
				}
			$this->Model_Messages->delete_recived_notify();
			}
		}
	}
	
}
