﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Version Helper
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
define('SYSNAME', 'ADUS CI®');
define('VERSION', 'v2.2.0');
define('ADUS_CI', 'ADUS CI® - v2.2.0 (<a href="http://www.abrkof.com/" target="_blank">ABRKOF©</a>)');
define('ADUS_CI_VERSION', 'ADUS CI® - v2.2.0 (<a href="http://www.abrkof.com/" target="_blank">ABRKOF©</a>)');
define('DEVELOPER', 'Carlos Abraham Ayala Herrera');
define('WEB', 'http://www.abrkof.com/');
/**
El control de versiones es la gestión de los diversos cambios que se realizan sobre los elementos de algún producto o una configuración del mismo. 
Se aplica en informática sobre el código fuente.

La numeración de las versiones de cada producto suele adquirir o sufrir ciertas variaciones, no obstante la convencción más habiltual es la utilización de 3 números, 
por ejemplo la versión v1.2.3. En ocaciones es mas entendible que el número sea precedido por una “v” minúscula para dejar claro que es un número de versión y no 
confundirlo por ejemplo con una fecha.

Su analogia puede ser:

El tercer dígito (build) representa correcciones de bugs o errores encontrados. También se suelen incluir cambios no funcionales (correciones ortográficas, cambios 
de color o tamaño de ventanas…) Es decir en el ejemplo se trata de la tercera entrega sobre la versión v1.2 en la que se reparan los bugs o errores detectados.
El segundo dígito (release) representa modificaciones funcionales, es decir se han añadido, eliminado o modificado funcionalidades al código. En el ejemplo se trata 
de la segunda entrega con modificaciones funcionales de la versión v01.
El primer dígito (versión propiamente dicho) representa cambios mayores en el diseño del código que impliquen cambios en el código de las aplicaciones que tengan 
dependencias con nuestro software (como pasar de Struts 1.3.8 a Struts 2.0, nuestro código debe cambiar).
La numeración suele comenzar en 0 para las versiones en producción, y el paso a la versión v1.0.0 suele indicar el arranque en producción. Así nuestro ejemplo se 
trata de una aplicación que está en producción y aún no ha sufrido cambios notables en su arquitectura.

En ocasiones se utiliza un cuarto dígito de versión (review) cuando el usuario/cliente/equipo de calidad debe validar una entrega devuelve la entrega. 
Así la versión v1.2.3.4 sería la cuarta entrega que hace el equipo de desarrollo al cliente para que se valide que se han solventado los bug, errores y modificaciones 
no funcionales objeto de la entrega v1.2.3.

También hay otras convenciones bastante utilizadas.

En algunos casos, las versiones cuyo segundo número sea par indica que son entregas al cliente e impar significa que son versiones de desarrollo.
En ocasiones en lugar de utilizar un cuarto dígito se utiliza una letra, por ejemplo v1.2.3c.
De cara a los usuarios, hay gente que incluye alguna codificación para que se pueda identificar en qué fecha se liberó la versión, pero no ha tenido mucho éxito; 
resulta un problema cuando realizas dos entregas el mismo día.
Desde Windows rompiera totalmente esta tendencia con Windows 95, hay más equipos que “ponen un nombre” a sus cambios mayores de versiones. Eclipse es un ejemplo (Europa, Galileo, Ganymede…)
**/