﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Hierarchal Menu Helper
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
if (!function_exists('my_hierarchal_menu_ppal_system')){
	function my_hierarchal_menu_ppal_system(){
		//Cargamos el super objeto.
		$CI = & get_instance();
		if ($CI->session->userdata('usuario_id')>=1){
			//Instanciamos a la clase de conexión de la base de datos personalizada.
			$pdo = DataBaseX::pdoDB();
			//Obtenemos el perfil_id del usuario logeado.
			$perfil_id = $CI->session->userdata('perfil_id');
			//Preparamos la primera consulta de acceso y cargamos los permisos de visualización para los Menús.
			$stmtp = $pdo->prepare('SELECT menu.*, module.module AS module_name FROM menu 
									LEFT JOIN module ON (menu.module_id = module.id)
									WHERE EXISTS (SELECT * FROM menu_perfil_vistas 
									WHERE menu_perfil_vistas.menu_id = menu.id AND perfil_id= :perfil_id) 
									ORDER BY orden ASC');
			$stmtp->execute(array(':perfil_id'=>$perfil_id));
			$stmtpx = $stmtp->fetchAll();

			foreach($stmtpx as $menux){
				//Preparamos la segunda consulta de acceso y sus permisos de visualización.
				$stmt1 = $pdo->prepare('SELECT menu_perfil_vistas.*, menu.menu AS menu_name 
										from menu_perfil_vistas 
										LEFT JOIN menu ON (menu_perfil_vistas.menu_id = menu.id)
										WHERE menu_id = :menu_id AND perfil_id = :perfil_id');
				$stmt1->execute(array(':menu_id'=>$menux['id'], ':perfil_id'=>$perfil_id));
				//Devolvemos un arreglo con la siguiente fila.
				$stmtx = $stmt1->fetchAll();
				if($menux['module_id'] != '1'){
					$menu_url = base_url('').strtolower($menux['module_name']).'/'.$menux['controlador'].'/'.$menux['accion'];
				} else {
					$menu_url = base_url('').$menux['controlador'].'/'.$menux['accion'];
				}
				$menu_external_url = $menux['url'];
				//Creamos un salto o nueva linea.
				$menu = '';
				//Evaluamos si el arreglo trae algo.
				if(count($stmtx) > 0);
				foreach($stmtx as $row1){
					//Preparamos la tercera consulta de accesoo y cargamos los permisos de visualización para los Sub Menús.
					$stmt2 = $pdo->prepare('SELECT submenu.*, module.module AS module_name FROM submenu 
											LEFT JOIN module ON (submenu.module_id = module.id)
											WHERE menu_id = :menu_id 
											AND EXISTS (SELECT * FROM submenu_perfil_vistas WHERE 
											submenu_perfil_vistas.submenu_id = submenu.id AND perfil_id = :perfil_id)
											ORDER BY orden ASC');
					$stmt2->execute(array(':menu_id'=>$row1['menu_id'], ':perfil_id'=>$perfil_id));
					//Contamos el número de filas que trae.
					$submenu_ppal = $stmt2->rowCount();
					//Llenamos variable con el controlador y su acción.
					if ($menu_external_url != '') {
						$menu_ppal = $menu_external_url;
					} else {
						$menu_ppal = $menu_url;
					}
					//Evaluamos si el arreglo viene vacío.
					if($submenu_ppal == 0){//Si no se relaciona con un sub menú, imprime un link normal.
						echo $menu .='<li><a href="'.$menu_ppal.'"><i class="'.$menux['icon'].'"></i> <span>'.$row1['menu_name'].'</span></a></li>';
					} else {//Si hay un sub menú relacionado, imprime un menú en cascada.
						$menu .= '<li><a><i class="'.$menux['icon'].'"></i> '.$menux['menu'].' <span class="fa fa-chevron-down"></span></a>
									<ul class="nav child_menu">';
						foreach($stmt2 as $row2){
							if($row2['module_id'] != '1'){
								$submenu_url = base_url('').strtolower($row2['module_name']).'/'.$row2['controlador'].'/'.$row2['accion'];
							} else {
								$submenu_url = base_url('').$row2['controlador'].'/'.$row2['accion'];
							}
							$submenu_external_url = $row2['url'];
							if ($submenu_external_url != '') {
								$menu .= '<li><a href="'.$submenu_external_url.'">'.$row2['submenu'].'</a></li>';
							} else {
								$menu .= '<li><a href="'.$submenu_url.'">'.$row2['submenu'].'</a></li>';
							}
						}
					$menu .= '</ul></li>';
					echo $menu;
					}
				}
			}
		} else {
			echo '<hr><li class="header"><i class="fa fa-dashboard"></i> Menú Restringido</li><hr>';
		}
	}
}
