<?php $this->load->view('admin/headers_check_login');?>

<style type="text/css">
<!--
.Estilo1 {color: #FF3333}
-->
</style>

<div class="x_panel">
  <div class="x_title">
	<h2> Sub Menú Perfil Vistas - (Visualización) <small>|| mantenimiento de registros</small></h2>
	<ul class="nav navbar-right panel_toolbox">
	  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
	  </li>
	  <li class="dropdown">
		<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
	  </li>
	  <li><a class="close-link"><i class="fa fa-close"></i></a>
	  </li>
	</ul>
	<div class="clearfix"></div>
  </div>
  <div class="x_content">

<div style="width:400px;">
<button type="button" class="btn btn-primary btn-lrg ajax" title="Ajax Request">
	<i class="fa fa-spin fa-refresh"></i>
	<?php echo anchor('SubMenu_Perfil_Vistas/index/', 'Refrescar', array('style'=>'color:#FFFFFF;')); ?>
</button>
<?php echo anchor('SubMenu_Perfil_Vistas/create', 'Agregar', array('class'=>'btn btn-success')); ?>
</div>

<?php echo form_open('SubMenu_Perfil_Vistas/validar', array('class'=>'sidebar-form')); ?>
<div class="title_right">
	<div class="col-md-3 col-sm-8 col-xs-12 form-group pull-left top_search">
		<div class="input-group">
			<?php echo form_input(array('type'=>'text', 'name'=>'buscar', 'id'=>'buscar', 'placeholder'=>'Buscar Sub Menú Perfil...', 'class'=>'form-control', 'required'=>'true')); ?>
			<span class="input-group-btn">
				<?php echo form_button(array('type'=>'submit', 'content'=>'Buscar', 'class'=>'btn btn-default', 'type'=>'submit')); ?>
			</span>
		</div>
	</div>
</div>
<?php echo form_close(); ?>

<?php if(!$query) { ?>
<div class="col-xs-3">
	<div class="alert alert-error">
	  <button type="button" class="close" data-dismiss="alert">&times;</button>
	  <strong>Alerta!</strong> No hay nada que mostrar.!!!
	</div>
</div>
<?php }else{ ?>

<script language="Javascript">
	function imprSelec(impresion) {
	  var ficha = document.getElementById(impresion);
	  var ventimp = window.open(' ', 'popimpr');
	  //$("#seleccion").append('<img src="../img/coed2.png">');
	  ventimp.document.write( ficha.innerHTML );
	  ventimp.document.close();
	  ventimp.print( );
	  ventimp.close();
	}
</script>
<?php echo packstylejs('admin/js/jquery-1.3.2.min');?>
<script language="javascript">
	$(document).ready(function() {
		$("#botonExcel").click(function(event) {
			$("#datos_a_enviar").val( $("<div>").append( $("#Exportar_a_Excel").eq(0).clone()).html());
			$("#FormularioExportacion").submit();
		});
	});
</script>
<div id="seleccion" align="center">
	<div class="table-responsive">
				<table class="table table-striped jambo_table bulk_action" border="1" bordercolor="#CCCCCC" id="Exportar_a_Excel">
					<thead>
						<tr class="headings">
							<th> Editar</th>
							<th> ID </th>
							<th> Sub Menú </th>
							<th> Perfil </th>
							<th> Creado </th>
							<th> Modificado </th>
						</tr>
					</thead>
				
					<tbody>
						<?php foreach ($query as $registro): ?>
						<tr>
							<td><div align="center" class="Estilo1"><?php echo anchor('SubMenu_Perfil_Vistas/edit/'.$registro->id, '<i class="icon-edit"></i>');?></div></td>
							<td> <?php echo anchor('SubMenu_Perfil_Vistas/edit/'.$registro->id, $registro->id); ?> </td>
							<td> <?php echo $registro->submenu_name ?> </td>
							<td> <?php echo $registro->perfil_name ?> </td>
							<td> <?php echo date("d/m/Y - H:i:s", strtotime($registro->created)); ?> </td>
							<td> <?php echo date("d/m/Y - H:i:s", strtotime($registro->updated)); ?> </td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php if ($this->session->userdata('perfil_id')<=2) {?>
<?php echo form_open('admin/export_to_excel', array('id'=>'FormularioExportacion', 'target'=>'_blank')); ?>
<p><span class="label label-info">Exportar a Excel!</span> <img src="<?php echo base_url('');?>assets/admin/img/xlsx.png" style="cursor:pointer" name="botonExcel" id="botonExcel"></p>
<input type="hidden" id="title" name="title" value="<?php echo $titulo ;?>">
<input type="hidden" id="datos_a_enviar" name="datos_a_enviar">
<?php echo form_close();?>
<a href="javascript:imprSelec('seleccion')" class="btn btn-primary"><img src="<?php echo base_url('');?>assets/admin/img/print.png"/> Imprimir Resultado</a>
<?php }else{  }?>
<?php } ?>
<div><ul class="pagination"><li><?php echo $this->pagination->create_links(); ?></li></ul></div>