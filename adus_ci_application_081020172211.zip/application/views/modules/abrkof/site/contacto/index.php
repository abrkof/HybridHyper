﻿<?php echo js('jquery.min');?>
<div class="row" id="property-list">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel">
			<div class="panel-body">
				<div class="row">
					<div class="col-sm-12">
					 <!--banner-->
						 <div class="banner5">	
							 <div class="banner5-info">
							 <h1>¡Contáctanos!</h1>
							 <h2>Permítenos demostrarte</h2><br>
							 <h2><r style="color:#FF0000">la calidad</r> de nuestros servicios…</h2><br>
							 <h2><r style="color:#FF0000">¡Conócenos!.</r><h2>
							 </div>
						 </div>
					 <!--banner-->
					 </div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
#C API FOR THE WEB
/*
void Cos(void){
	Stack *s;
	char temp[64];
	
	s = Pop();
	if(!s){
		Error("Stack error in cos");
		return;
	}
	sprintf(temp,"%f",cos(s->douval));
	Push(temp,DNUMBER);
}
echo Cos($input);
*/
?>

<section class="panel">
	<header class="panel-heading">
	</header>
	<div class="panel-body">
		<?php echo form_open('site/contacto/send_mail', array('class'=>'form-horizontal')); ?>
			<div class="form-group">
				<label for="exampleInputEmail1">Asunto</label>
				<?php echo form_input(array('type'=>'text', 'name'=>'asunto', 'id'=>'asunto', 'style'=>'border:active;HEIGHT:30px','class'=>'form-control', 
				'placeholder'=>'Digite el asunto', 'value'=>set_value('asunto'),'required'=>'asunto', 'autofocus'=>'asunto')); ?>  
			</div>
			<div class="form-group">
				<label for="exampleInputPassword1">Nombre Completo</label>
				<?php echo form_input(array('type'=>'text', 'name'=>'nombres', 'id'=>'nombres', 'style'=>'border:active;HEIGHT:30px','class'=>'form-control', 
				'placeholder'=>'Digite su nombre completo', 'value'=>set_value('nombres'),'required'=>'nombres')); ?>
			</div>
			<div class="form-group">
				<label for="exampleInputFile">E-Mail</label>
				<?php echo form_input(array('type'=>'text', 'name'=>'email', 'id'=>'email', 'style'=>'border:active;HEIGHT:30px','class'=>'form-control', 
				'placeholder'=>'Digite su correo electrónico', 'value'=>set_value('email'),'required'=>'email')); ?> 
			</div>
			<div class="form-group">
				<label for="exampleInputFile">Mensaje</label>
				<?php echo form_textarea(array('type'=>'text', 'name'=>'mensaje', 'id'=>'mensaje', 'value'=>set_value('mensaje'), 'class'=>'form-control', 'cols'=>'5', 'rows'=>'5')); ?>
			</div>
			<input type="submit" name="submit" id="submit" class="btn btn-drop btn-danger" value="Enviar Mensaje"><!--</button>-->
			<input type="reset" name="reset" id="reset" class="btn btn-drop btn-success" value="Limpiar" width="100px">
	  <?php echo form_close(); ?>
	</div>
</section>
