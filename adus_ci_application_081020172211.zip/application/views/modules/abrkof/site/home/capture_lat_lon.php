﻿<script type="text/javascript">

function toggle (id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }

</script>

<script type="text/javaScript">
<!--
function time()
{
var y= new Date();
document.cookie="xdate="+y; 
}
//-->
</script>

<script type="text/JavaScript">
<!--
var t= new Date();
document.cookie="onlinedate="+t; 
//-->
</script>

<script type="text/javascript" src="http://www.google.com/jsapi?key=<?php echo $google;?>"></script>
<script type="text/javascript">

google.load("maps", "2", {"other_params":"sensor=true"});

function find_location() 
 {
	
 if(navigator.geolocation) 
 {
 navigator.geolocation.getCurrentPosition(locator,error,{maximumAge:300000});
 } 
 else 
 {
 document.getElementById("location").innerHTML = "La localizacion no puede ser Detectada!";	
 }
 
 }

function locator (position) 
 {
 var latitude = position.coords.latitude;
 var longitude = position.coords.longitude;

 document.cookie="locx="+latitude;
 document.cookie="locy="+longitude;
  
 // Display the map
 var map = new GMap2(document.getElementById('map'));
	
 // Centre the map around the latitude and longitude
 var latlng = new google.maps.LatLng(latitude,longitude);
 var zoom = 16;
 map.setCenter(latlng, zoom);
	
 // Display the default controls
 map.setUIToDefault();


function createInfoMarker(point, address) 
 {
 var marker = new GMarker(point);
 GEvent.addListener(marker, "click",function() {marker.openInfoWindowHtml(address);});
 return marker;
 }

 // Add a marker

 var point = new GLatLng(latitude,longitude);
 var address = "<?php echo $g_time.'&ensp;'.$g_action; ?>";
 var marker = createInfoMarker(point, address); 

 map.addOverlay(marker);
 }

function error () 
 {
 document.getElementById("location").innerHTML = "La localizacion no puede ser Detectada!";
 }

</script>