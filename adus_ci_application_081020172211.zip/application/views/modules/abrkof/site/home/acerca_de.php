﻿	  <div class="span6">
						<div class='wrapper indent-bot2'>
							<figure class='img-indent' aling="left"><img src='<?php echo base_url('') ;?>assets/images/page1-img1.jpg' alt=''></figure>
							<div>
								<h2>City Guides</h2>
								<h2><strong class='color-3'>Darse a conocer <em> de la mejor manera!</em></strong></h2>
							</div>
						</div>
						<p class='p1' style='text-align: justify;'>City Guides, somos un grupo de personas creativas en el desarrollo de negocios, que prepara procesos de comercialización y publicidad moderna, funcional e innovadora. Estudiado y con resultados garantizados desde la Pequeña y Mediana Empresa hasta las Grandes Multinacionales.</br> Cumplimos con el Código de Ética Publicitaria de El Salvador.</p>
						<p class='img-indent-bot' style='text-align: justify;'>Nuestra oferta inicial es una revista mensual llamada “City Guides”, de la cual obtenemos nuestra primera edición en JULIO/2014. Esta contiene además de anuncios publicitarios, temas de interés como: Farándula, Salud y Belleza, Astrología, Ciencia y Tecnología, Humor y Entretenimiento, Familia y Hogar, Finanzas y muchos más. Como un regalo a nuestros lectores contiene una cuponera de descuentos de diferentes establecimientos. Trabajando de la mano con nuestro sitio web <a class='link' target='_blank' href='http://www.cityguidesv.com'>www.cityguidesv.com</a>, donde puede encontrar mucha información de interes, agregando que nuestros usuarios en general puede publicar anuncios de compra-venta de artículos, empleos y servicios de una manera gratuita y muy interactiva.</p>

	  </div>