<?php $this->load->view('site/home/headers_check_login');?>

<?php echo form_open('site/home/cambiar_clave', array('class'=>'form-horizontal')); ?>
	<legend> Cambiar la Clave de Usuario </legend>

	<?php echo my_validation_errors(validation_errors()); ?>

	<div class="control-group">
		<?php echo form_label('Clave Actual :', 'clave_act', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'password', 'name'=>'clave_act', 'id'=>'clave_act', 'style'=>'border:active;HEIGHT: 30px', 'value'=>set_value('clave_act'))); ?>
	</div>

	<div class="control-group">
		<?php echo form_label('Clave Nueva :', 'clave_new', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'password', 'name'=>'clave_new', 'id'=>'clave_new', 'style'=>'border:active;HEIGHT: 30px', 'value'=>set_value('clave_new'))); ?>
	</div>

	<div class="control-group">
		<?php echo form_label('Confirmar Clave Nueva :', 'clave_rep', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'password', 'name'=>'clave_rep', 'id'=>'clave_rep', 'style'=>'border:active;HEIGHT: 30px', 'value'=>set_value('clave_rep'))); ?>
	</div>

	<div class="form-actions">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Confirmar', 'class'=>'btn btn-primary')); ?>
		<?php echo anchor('site/home/acerca_de', 'Cancelar', array('class'=>'btn')); ?>
	</div>
<?php echo form_close(); ?>
