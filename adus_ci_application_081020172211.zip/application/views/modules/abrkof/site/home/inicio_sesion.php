<?php $this->load->view('sitio/home/capture_lat_lon');?>

<div onload="find_location();return false;">
<?php echo form_open('sitio/home/ingresar', array('class'=>'form-horizontal')); ?>
	<legend> Ingreso al Sistema </legend>

	<?php echo my_validation_errors(validation_errors()); $plain_password;?>

	<div class="control-group">
		<?php echo form_label('Usuario : ', 'login', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'login', 'id'=>'login', 'style'=>'border:active;HEIGHT: 30px', 'placeholder'=>'Usuario...', 
		'value'=>set_value('login'), 'autofocus'=>'login')); ?>
	</div>

	<div class="control-group">
		<?php echo form_label('Password : ', 'password', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'password', 'name'=>'password', 'id'=>'password', 'style'=>'border:active;HEIGHT: 30px', 'placeholder'=>'Password...', 
		'value'=>set_value('password'))); ?>
	</div>

	<div class="form-actions">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Ingresar', 'class'=>'btn btn-primary')); ?>
		<?php echo anchor('sitio/home/acerca_de', 'Cancelar', array('class'=>'btn')); ?>
	</div>
<?php echo form_close(); ?>
</div>