﻿<?php $this->load->view('modules/abrkof/site/home/capture_lat_lon');?>
<?php
/*$plain_text = '123';
$ciphertext = $this->encryption->encrypt($plain_text);
echo $this->encryption->decrypt($ciphertext);
echo '<br><br>'.$ciphertext;*/
?>
<div>
	<?php $this->load->view('modules/abrkof/site/slider/slider');?>
	<div class="row" id="home-content">
		<div class="col-lg-8">
			<!--custom chart start-->
			<div class="border-head">
				<!--<h3><strong>Graph</strong> Earning</h3>-->
			</div>
			<hr>
			<div class="panel panel-default">
				<section class="panel">
					<div class='wrapper indent-bot2'>
						<figure class='img-indent' aling="left"><img class="pin" src="<?php echo base_url('');?>assets/images/signo_filosofia.png" class="img-responsive" height="100px"/></figure>
						<div>
						<h3 style="font-size:20px;">Si he logrado ver más lejos, ha sido porque he subido a hombros de gigantes.<br></h3>
						<span style="font-size:30px;"><em>Sir Isaac Newton</em>.</span>
						</div>
					</div>
					<p><iframe src="//www.youtube.com/embed/S7xluRDRz5k" width="425" height="350" allowfullscreen="allowfullscreen"></iframe></p>
					<p class='p1' style='text-align: justify;'><strong style="color:#0099FF;">ABRKOF</strong>, nace para fortalecer el conocimiento humano de orden educacional, para aquellos jovenes y adultos estudiantes, que
					tras verse con dificultades en la vida diaria, necesitan un apoyo más para nutrir su conocimiento, el cual es esencial para la superación humana.</br></p>
					<p><img src="<?php echo base_url('');?>assets/images/abrkof_logo_x.png" style="height:300px;width:400px;" class="img-responsive"></p>
					<p class='img-indent-bot' style='text-align: justify;'><strong style="color:#0099FF;">ABRKOF</strong>, no es una empresa, organizacion estatal, organización sin fines de lucro,
					ni cualquiera de sus similares; no obstante, nuestro sitio ofrece servicios de paga, asi mismo, es un portal de ayuda para el conocimiento humano, porque sabemos fervientemente que antes de todo es bueno:
					Pensar, Analizar, Reflexionar, Recapacitar, Reaccionar y Actuar, siendo concientes de nuestros propios actos, los cuales nos convertiran en personas con un legado que dejar.
					Por ello el contenido expuesto en este sitio, sera de orden educativo y de ayuda para las personas que asi lo requieran.</p>
				</section>
			</div>
			<!--custom chart end-->
			<!-- Beneficios -->
				<!--<div class="panel-body">
					<div class="row">
						<div class="col-sm-5">
							
						</div>
						<div class="col-sm-7">
				
						</div>
					</div>
				</div>-->
				<div class="row" id="property-list">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <img src="<?php echo base_url('');?>assets/images/haa.jpg" class="img-responsive">
                                    </div>
                                    <div class="col-sm-7">
                                        <h4 class="title-real-estates">
                                            <strong><a href="#">BENEFICIOS</a></strong> <span class="pull-right">SISTEMA</span>
                                        </h4>
                                        <hr>
										<br><br>
										<ul class='list-2'>
											<li>Repositorio de hojas de vida</li>
											<li>Temas de insteres educacional</li>
											<li>Noticias</li>
											<li>Repositorio de datos</li>
											<li>Material de apoyo 24/7</li>
										</ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="panel">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h4 class="title-real-estates">
                                            <strong><a href="#">EDUCACIÓN</a></strong> <span class="pull-center">BÁSICA - MEDIA</span>
                                        </h4>
                                        <hr>
										<ul class="list-1">
											<li>Herramienta de apoyo académico</li>
											<li>Tutoria en línea</li>
											<li>Foro</li>
											<li>Desarrollo Cognitivo</li>
									  </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <img src="<?php echo base_url('');?>assets/images/edificios.png" class="img-responsive">
                                    </div>
                                    <div class="col-sm-7">
                                        <h4 class="title-real-estates">
                                            <strong><a href="#">PARA</a></strong> <span class="pull-center">UNIVERSITARIOS</span>
                                        </h4>
                                        <hr>
										<ul class="list-1">
											<li>Herramienta de apoyo académico</li>
											<li>Tutoria en línea</li>
											<li>Foro</li>
											<li>Apoyo en proyectos educaciónales</li>
									  </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="panel">
                            <div class="panel-body">
                                <div class="row" align="justify">
                                    <div class="col-sm-12">
                                        <h4 class="title-real-estates">
                                            <strong><a href="#">SERVICIOS A</a></strong> <span class="pull-center">PERSONAS Y EMPRESAS</span>
                                        </h4>
                                        <hr>
										<ul class='list-2'>
											<li><strong><em>Soporte técnico:</em></strong> Mantenimiento correctivo y preventivo a nivel físico y lógico.</li>
											<li><strong><em>Publicidad virtual:</em></strong> Espacio virtual publicitario en nuestro sitio web y radio en linea.</li>
											<li><strong><em>Desarrollo de sistemas:</em></strong> Nos acoplamos a sus necesidades.</li>
											<li><strong><em>Personal Capacitado:</em></strong> Personal en constante formación académica y especialistas</li>
										</ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
			<!-- Beneficios -->
		</div>
		<div class="col-lg-4">
			<!-- start:user info -->
			<div class="panel panel-default">
				<div class="panel-heading">
					<header class="panel-title">
						<div class="text-center">
							<!--<strong>Agent</strong> Author<strong>.</strong>-->
						</div>
					</header>
				</div>
				<div class="panel-body">
					<div class="text-center" id="author">
						<div class="banner">	
							<div class="banner-info">
							<h1>ABRKOF</h1>
							<p><h2>Dando<br>
							es como<r style="color:#FF0000"> recibimos</r><br>
							</div>
						 </div>
					</div>
				</div>
			</div>
			<!-- end:user info -->
			<!-- start:new earning -->
			<div class="panel green-chart">
				<div class="panel-body chart-texture">
					<div class="chart">
						<div class="heading">
							<strong><h2 class='color-3'>¿Que necesitas?</h2></strong>
						</div>
					</div>
				</div>
				<div class="chart-tittle">
					<span class="value">
					<p>Si quieres contratar nuestros servicios o algún espacio publicitario, envíanos un correo a abrkof@gmail.com o llama a nuestros números: 71037139 ó 76165028</p>
					</span>
					<img src="<?php echo base_url('');?>assets/images/marketing.jpg" class="img-responsive">
				</div>
			</div>
			<!-- end:new earning-->

			<!-- start:total earning-->
			<div class="panel terques-chart">
				<div class="banner">	
					<div class="banner-info">
					<h1>Explorando posiblidades</h1>
						<div class="panel-body">
						</div>
						<div class="chart-tittle">
						<h2><p>es como se logran los objetivos</p><br>
						<p>unamonos<r style="color:#FF0000"> y fomentemos el desarrollo</r></p><br>
						<p>para un futuro <r style="color:#FF0000">libre de</r> dificultades académicas.</p><h2><!---->
					</div>
				 </div>
				</div>
			</div>
			<!-- end:total earning -->
		</div>
	</div>

	<div class="row">
		<div class="col-lg-4">
		</div>
		<div class="col-lg-8">
		</div>
	</div>
</div>