﻿<?php $this->load->view('admin/headers_check_login');?>

<script type="text/javascript">
function control(f){
    var ext=['jpg','jpeg','png'];
    var v=f.value.split('.').pop().toLowerCase();
    for(var i=0,n;n=ext[i];i++){
        if(n.toLowerCase()==v)
            return
    }
    var t=f.cloneNode(true);
    t.value='';
    f.parentNode.replaceChild(t,f);
    alert('Extensión no válida');
}
</script>

<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Creando Registro</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
						<?php echo my_validation_errors(validation_errors()); ?>
						<?php echo form_open_multipart('site/slider/do_upload', array('class'=>'form-horizontal')); ?>
							<div class="box-body">
								<div class="form-group">
									<?php echo form_label('Título : ', 'titulo', array('class'=>'col-sm-2 control-label')); ?>
									<div class="col-sm-10">
										<?php echo form_input(array('type'=>'text', 'name'=>'titulo', 'id'=>'titulo', 'value'=>set_value('titulo'), 'class'=>'form-control', 'placeholder'=>'Título', 'required'=>'true')); ?>
									</div>
								</div>
							</div>
			
							<div class="box-body">
								<div class="form-group">
									<?php echo form_label('Descripción : ', 'descripcion', array('class'=>'col-sm-2 control-label')); ?>
									<div class="col-sm-10">
										<?php echo form_textarea(array('type'=>'text', 'name'=>'descripcion', 'id'=>'descripcion', 'value'=>set_value('descripcion'), 'class'=>'form-control')); ?>
									</div>
								</div>
							</div>
				
							<div class="box-body">
								<div class="form-group">
									<?php echo form_label('Controlador : ', 'controlador', array('class'=>'col-sm-2 control-label')); ?>
									<div class="col-sm-10">
										<?php echo form_input(array('type'=>'text', 'name'=>'controlador', 'id'=>'controlador', 'value'=>set_value('controlador'), 'class'=>'form-control', 'placeholder'=>'Controlador')); ?>
									</div>
								</div>
							</div>
				
							<div class="box-body">
								<div class="form-group">
									<?php echo form_label('Acción : ', 'accion', array('class'=>'col-sm-2 control-label')); ?>
									<div class="col-sm-10">
										<?php echo form_input(array('type'=>'text', 'name'=>'accion', 'id'=>'accion', 'value'=>set_value('accion'), 'class'=>'form-control', 'placeholder'=>'Acción')); ?>
									</div>
								</div>
							</div>
			
							<div class="box-body">
								<div class="form-group">
									<?php echo form_label('URL : ', 'url', array('class'=>'col-sm-2 control-label')); ?>
									<div class="col-sm-10">
										<?php echo form_input(array('type'=>'text', 'name'=>'url', 'id'=>'url', 'value'=>set_value('url'), 'class'=>'form-control', 'placeholder'=>'URL')); ?>
									</div>
								</div>
							</div>
			
							<div class="box-body">
								<div class="form-group">
									<?php echo form_label('Imagen : ', 'imagen', array('class'=>'col-sm-2 control-label')); ?>
									<div class="col-sm-10">
										<?php echo form_input(array('type'=>'file', 'name'=>'userfile', 'id'=>'userfile', 'value'=>set_value('userfile'), 'class'=>'form-control', 
										'required'=>'userfile', 'onchange'=>'javascritp:control(this)', 'title'=>'Debes de seleccionar una imagen de formato valido', 'required'=>'true')); ?>
									</div>
								</div>
							</div>
				
							<div class="box-body">
								<div class="form-group">
									<?php echo form_label('Orden : ', 'orden', array('class'=>'col-sm-2 control-label')); ?>
									<div class="col-sm-10">
										<?php echo form_input(array('type'=>'number', 'name'=>'orden', 'id'=>'orden', 'value'=>set_value('orden'), 'class'=>'form-control', 'placeholder'=>'Orden', 'required'=>'true')); ?>
									</div>
								</div>
							</div>
			
					<hr>
					<!-- /.box-body -->
					<div class="box-footer">
						<?php echo form_button(array('type'=>'submit', 'content'=>'Aceptar', 'class'=>'btn btn-info')); ?>
						<?php echo anchor('site/slider/index', 'Cancelar', array('class'=>'btn btn-default')); ?><!--pull-left-->
					</div>
					<!-- /.box-footer -->
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>