﻿<?php $this->load->view('admin/headers_check_login');?>

<?php echo packstylejs('admin/js/jquery_ordenar');?>
<div class="page-header">
	<h1> Ordenando Servicios <small> mantenimiento de registros </small> </h1>
</div>
<style type="text/css">
.contentx{
	padding-top:20px;
	width:320px;
	margin:0 auto;
}
.ui-state-highlight{ background:#FFF0A5; border:1px solid #FED22F}
.msg{
	color:#0C0;
	font:normal 11px Tahoma
}
</style>
<?php if(!$query) { ?>
<div class="col-xs-3">
	<div class="alert alert-error">
	  <button type="button" class="close" data-dismiss="alert">&times;</button>
	  <strong>Alerta!</strong> No hay nada que mostrar.!!!
	</div>
</div>
<?php }else{ ?>
<script type="text/javascript">
$(document).ready(function(){
	$("ul#categorias").sortable({ placeholder: "ui-state-highlight",opacity: 0.6, cursor: 'move', update: function() {
		var order = $(this).sortable("serialize");
		$.post("<?php echo base_url('');?>categoria/update_orden", order, function(respuesta){
			$(".msg").html(respuesta).fadeIn("fast").fadeOut(4500);
		});
	}
	});
});
</script>
<div class="x_panel">
  <div class="x_title">
	<h2> Lista de Menús </h2>
	<ul class="nav navbar-right panel_toolbox">
	  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
	  </li>
	  <li class="dropdown">
		<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
	  </li>
	  <li><a class="close-link"><i class="fa fa-close"></i></a>
	  </li>
	</ul>
	<div class="clearfix"></div>
  </div>
  <div class="x_content">
		<div class="contentx">
			<ul id="categorias" style="/*list-style:none;*/margin:0;padding:0;">
				<?php foreach($query as $registro): ?>
					<li id="categoria-<?php echo $registro->id; ?>"style="display:block;background:#F6F6F6;border:1px solid #CCC;color:#3594C4;margin-top:3px;height:30px;padding:3px;">
					<img src="<?php echo base_url('') ;?>assets/admin/img/arrastrar.png"><?php echo $registro->categoria; ?></li>
				<?php endforeach; ?>
			</ul>
			<div class="msg"></div>
		</div>
	</div>
  </div>
</div>
<?php } ?>