﻿<?php
if(isset($_REQUEST['c'])){
		switch($_REQUEST['c']){
			case 1:
				if(isset($_REQUEST['n']) and isset($_REQUEST['i'])){?>
						<section class="panel">
                            <div class="panel-body">
								<h3><?php echo $_REQUEST['n'];?></h3>
								<div class='wrapper indent-bot col-sm-12'>
								<?php foreach ($subcategoria as $registro):?>
										<div class="span3" style="border:none; overflow:hidden;">
											<article class='grid_3'>
												<!--<center><figure class='p2'><a href='#'><img id='imagen_articulo' src='<?php echo base_url('');?>assets/images/".utf8_decode($fila['url_imag'])."' alt=''></a></figure></center>-->
												<strong><?php echo $registro->subcategoria;?></strong>
												<p class='p0' align="justify"><?php echo $registro->descripcion;?>.</p>
												<a class='link' href='#' onclick="cargar_articulos('<?php echo $registro->subcategoria;?>', '<?php echo $registro->id;?>', '2');">Ver Art&iacuteculos</a>
											</article>
										</div>
								<?php endforeach;?>
							</div>
                        </section>
				<?php }
				else{
					echo"Recursos de articulo o parametro no valido";
				}
				break;
			case 2:
				if(isset($_REQUEST['n']) AND isset($_REQUEST['i'])){?>
					<article class='grid_9'>
						<h3><?php echo $_REQUEST['n'];?></h3>
						<div class='wrapper indent-bot'>
						<?php foreach ($get_subcategoria as $registro):?>
								<article class='grid_3'>
									<!--<center><figure class='p2'><a href='#'><img id='imagen_articulo' src='<?php echo base_url('');?>assets/images/".$fila['imagen']."' alt=''></a></figure></center>-->
									<strong><?php echo $registro->titulo;?></strong>
									<p class='p0'><?php echo substr($registro->contenido, 0, 100);?>...</p>
									<a class='link' href='#' onclick="cargar_articulos('<?php echo $registro->titulo;?>', '<?php echo $registro->id;?>', '3');">Leer m&aacute;s</a>
								</article>
						<?php endforeach;?>
						</div>
					</article>
					<?php }
				else{
					echo "Recursos de artículo o parametro no valido";
				}
				break;
			case 3:
				if(isset($_REQUEST['n']) and isset($_REQUEST['i'])){?>
					<script language="Javascript">
						function imprSelec(impresion) {
						  var ficha = document.getElementById(impresion);
						  var ventimp = window.open(' ', 'popimpr');
						  $("#seleccion").append('Visto desde "CITYGUIDES"<br> http://www.abrkof.com/site/articulo/<br>');
						  ventimp.document.write( ficha.innerHTML );
						  ventimp.document.close();
						  ventimp.print( );
						  ventimp.close();
						}
					</script>
					<div id="seleccion">
					<article class='grid_9'>
						<h3><?php echo $articulo->titulo;?></h3>
								<article class='grid_13'>
									<!--<figure class='p2'><center><img id='imagen_articulo' src='resources/images/".$fila['imagen']."' alt=''></center></figure>-->
									<p class='p0' align="justify"><?php echo $articulo->contenido;?></p>
								</article>
					</article>
					</div>
					<a href="javascript:imprSelec('seleccion')" class="btn btn-primary"><img src="<?php echo base_url('');?>assets/images/print.png"/> Imprimir Artículo</a>
					<?php }
				else{
					echo"Recursos de árticulo o parametro no valido";
				}
				break;
		}
}?>
