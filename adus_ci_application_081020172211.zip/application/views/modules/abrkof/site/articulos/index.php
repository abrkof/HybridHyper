﻿<div class="row" id="property-list">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel">
			<div class="panel-body">
				<div class="row">
					<div class="col-sm-12">
					<?php echo js('jquery.min');?>
					 <!--banner-->
						 <div class="banner4">	
							 <div class="banner4-info">
							 <h1>Ven y descubre ¡Novedades!</h1>
							 <h2>con cada artículo</h2><br>
							 <h2>siempre hay algo <r style="color:#FF0000">nuevo</r></h2><br>
							 <h2>que <r style="color:#FF0000">descubrir</r>.<h2>
							 </div>
						 </div>
					 <!--banner-->
					 </div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
function cargar_articulos(categoria, id, caso){
	var $contenidoAjax = $('div#articulo_refresh').html("<img src='<?php echo base_url('');?>assets/images/cargando.gif' style='margin-top:220px;'/>");
	var url='<?php echo base_url('');?>site/articulo/ajax'
	$.ajax({
		type:'POST',
		url:url,
		data:{
			n: categoria, i:id, c:caso
		},
		success: function(datos){
			$('#articulo_refresh').show();
			$('#articulo_refresh').html(datos);
			setTimeout(function del_sg(){
				$('#articulo_refresh').scrollTo( '#articulo_refresh', {duration:1000} );
				//$('html,body').scrollTop($('.articulo_refresh')[0].scrollHeight);
			}, 500);
		}
	});
}
</script>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel">
			<div class="panel-body">

				<div class="col-sm-4">
					<div class="col-sm-8">
				<?php if(!$categoria){ ?>
				<img src="<?php echo base_url('');?>assets/images/buscar.png" class="img-responsive">
				<?php }else{ ?>
					<article class='grid_3'>
						<h3 class='p0'>Categoría</h3>
						<ul class='list-2'>
						<?php foreach ($categoria as $registro):?>
							<li><a href="#" class="show_categoria_<?php echo $registro->id;?>" data-content_show_categoria="<?php echo $registro->id;?>">
							<div onclick="cargar_articulos('<?php echo $registro->categoria;?>', '<?php echo $registro->id;?>', '1')"><?php echo $registro->categoria;?></div></a></li>
							<script>
								$('a.show_categoria_<?php echo $registro->id;?>').click(function(e){
									e.preventDefault();
									$('html,body').scrollTo( '#articulo_refresh', {duration:1000} );
								});
							</script>
							<?php endforeach;?>
						</ul>
					</article>
				<?php } ?>
					</div>
				</div>

				<div class="col-sm-8">
					<div class="col-sm-12">
						<article class="grid_4 omega">
							<div id='articulo_refresh'>
							<!--NOTICIAS-->
							<h3>Noticias</h3>
							<?php
							function obtenerMes($mes){switch ($mes){case 1:$nombre_mes="Enero";break;case 2:$nombre_mes="Febrero";break;case 3:$nombre_mes="Marzo";break;case 4:$nombre_mes="Abril";
							break;case 5:$nombre_mes="Mayo";break;case 6:$nombre_mes="Junio";break;case 7:$nombre_mes="Julio";break;case 8:$nombre_mes="Agosto";break;case 9:$nombre_mes="Septiembre";
							break;case 10:$nombre_mes="Octubre";break;case 11:$nombre_mes="Noviembre";break;case 12:$nombre_mes="Diciembre";break;}return $nombre_mes;}?>
							<?php if(!$query) { ?>
							<div class="col-sm-6">
								<div class="alert alert-error">
								  <button type="button" class="close" data-dismiss="alert">&times;</button>
								  <strong>Alerta!</strong> No hay nada que mostrar.!!!
								</div>
							</div>
							<?php }else{ ?>
							<?php foreach ($query as $registro):?>
							<div class='indent-bot' style='text-align: justify;'>
							<time class='tdate-1' datetime='<?php echo $registro->updated;?>'><strong><?php echo date("d", strtotime($registro->updated)) ;?></strong>
							<?php echo strtoupper(substr(obtenerMes(date("m", strtotime($registro->updated))), 0, 3));?></time>
							<div class='extra-wrap'>
							<h6><a class='link' 
							onclick="alertify.alert('<b><?php echo $registro->titulo;?></b>','“Noticia” <br> <?php echo $registro->contenido;?>',
							  function(ok){
								alertify.message('Elija una opción');
							  }).set('label', 'Regresar'); return false"
							href='#'><?php echo $registro->titulo;?></a></h6><?php echo $registro->contenido;?></div>
							<div class='clear'></div>
							</div>
							<?php endforeach;?>
							<span class='button-2'>
								<a href='<?php echo base_url('') ;?>#'
								onclick="alertify.alert('<b>MÁS NOTICIAS</b>','“En Contrucción!”',
								  function(ok){
									alertify.message('Elija una opción');
								  }).set('label', 'Regresar'); return false">
								<strong>Más Noticias</strong></a>
							</span>
							<?php } ?>
							</div>
							<!--NOTICIAS-->
							</div>
						</article>
					</div>
				</div>

			</div>
		</div>
	</div>