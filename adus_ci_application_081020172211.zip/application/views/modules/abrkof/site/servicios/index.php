﻿<div class="row" id="property-list">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel">
			<div class="panel-body">
				<div class="row">
					<div class="col-sm-12">
					<?php echo js('jquery.min');?>
					 <!--banner-->
						 <div class="banner2">	
							 <div class="banner2-info">
							 <h1>¿Necesitas darte a conocer?</h1>
							 <h2>Ven y</h2><br>
							 <h2>Echa un vistazo a nuestros servicios</h2><br>
							 <h2>y explota al <r style="color:#FF0000">máximo</r> el potencial de tu <r style="color:#FF0000">negocio!</r></h2>
							 </div>
						 </div>
					 <!--banner-->
					 </div>
				</div>
			</div>
		</div>
	</div>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel">
			<div class="panel-body">
			<?php foreach ($query as $registro):?>
				<div class="col-sm-4">
					<h3>Servicios</h3>
					<div class="col-sm-12">
						<article class="grid_4 omega">
							<div class="indent-left">
								<strong class="circle"><?php echo $registro->orden;?></strong>
								<div class="extra-wrap">
									<div class="indent-top3">
										<strong class="title-1 color-2"><?php echo $registro->name;?></strong>
									</div>
								</div>
								<div class="clear"></div>
								<p style="text-align: justify;">
								<?php echo $registro->contenido;?>
								</p>
							</div>
						</article>
					</div>
				</div>
				<?php endforeach;?>
			</div>
		</div>
	</div>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel">
			<div class="panel-body">
				<h1>EN CONSTRUCCIÓN.</h1>
				<!--<div class="col-sm-4">
					<h3>Servicios</h3>
					<div class="col-sm-12">
						<article class="grid_4 omega">
							<div class="indent-left">
								<figure class="img-indent2"><img src="<?php echo base_url('') ?>assets/images/Imag_descuento.png" alt=""></figure>
								<div class="extra-wrap" align="justify">
									<strong class="title-1">Cuponera de descuento.</strong>
									Al estar suscrito a nuestra revista mensual, podrá disponer de cupones para fabulosos descuentos en diferentes establecimientos.
								</div>
							</div>
						</article>
					</div>
				</div>

				<div class="col-sm-4">
					<h3>Servicios</h3>
					<div class="col-sm-12">
						<article class="grid_4 omega">
							<div class="indent-left">
								<figure class="img-indent2"><img src="<?php echo base_url('') ?>assets/images/Imag_rel_estrechas.png" alt=""></figure>
								<div class="extra-wrap">
									<strong class="title-1">Relaciones estrechas con clientes.</strong>
									Nuestros esfuerzos están dirigidos a las necesidades de los clientes; compartimos conocimientos con el fin de potenciar sus ideas.
								</div>
							</div>
						</article>
					</div>
				</div>

				<div class="col-sm-4">
					<h3>Servicios</h3>
					<div class="col-sm-12">
						<article class="grid_4 omega">
							<div class="indent-left">
								<figure class="img-indent2"><img src="<?php echo base_url('') ?>assets/images/Imag_estrategia.png" alt=""></figure>
								<div class="extra-wrap">
									<strong class="title-1">Planificación Estratégica.</strong>
									Procesos de desarrollo e implementación de planes para alcanzar propósitos u objetivos propuestos en sus negocios. 
								</div>
							</div>
						</article>
					</div>
				</div>-->

			</div>
		</div>
	</div>
	
</div>
