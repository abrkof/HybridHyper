﻿<!-- Button trigger modal -->
<script>
function jcride(){
	if(document.frm_login.login.value == "jcride"){
		var alert = alertify.alert("Error de Validación","El usuario “jcride” es reservado por el sistema! <br> Escribe un usuario valido o verifica tus datos.", function(){     	 
			alert.set({transition:'flipx'}); //slide, zoom, flipx, flipy, fade, pulse (default)
			alert.set('modal', false);  //al pulsar fuera del dialog se cierra o no.
			alertify.error('Intenta de Nuevo');
		}).set('label', 'Aceptar');
		return false;
	}
}
</script>

<script>
function char_set(e) { // 1
    tecla = (document.all) ? e.keyCode : e.which; // 2
    if (tecla==8) return true; // 3
    patron =/[A-Za-z_0-9 _\s]/; // 4
    te = String.fromCharCode(tecla); // 5
    return patron.test(te); // 6
}
</script>

<script>
function val_match(f){
	if(f.password.value != "" && (f.password.value == f.confirm_pwd.value)){
		return true;
	} else {
		var alert = alertify.alert("Error de Validación","La contraseña y su confirmación no coinciden!", function(){     	 
		alert.set({transition:'flipx'}); //slide, zoom, flipx, flipy, fade, pulse (default)
		alert.set('modal', false);  //al pulsar fuera del dialog se cierra o no	
		alertify.warning('Intenta de Nuevo');
		}).set('label', 'Aceptar');
		return false;
	}
}
</script>
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
  Register Now!
</button>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Registration Process</h4>
      </div>
	  <?php echo my_validation_errors_info(validation_errors()); $plain_password;?>
      <div class="modal-body">
		<?php echo form_open('site/home/register', array('name'=>'frm_login', 'id'=>'frm_login', 'class'=>'form-horizontal', 'onSubmit'=>"return val_match(this) && jcride();")); ?>
		  <div class="form-group">
			<?php echo form_label('First Name ', 'nombres', array('class'=>'col-sm-2 control-label')); ?>
			<div class="col-sm-10">
			<div class="input-group">
			  <div class="input-group-addon">F</div>
			  <?php echo form_input(array('type'=>'text', 'name'=>'nombres', 'id'=>'nombres', 'value'=>set_value('nombres'), 'class'=>'form-control',
			  								'placeholder'=>'Example: Charles Xavier', 'autofocus'=>'nombres', 'required'=>'true')); ?>
			</div>
			</div>
		  </div>

		  <div class="form-group">
			<?php echo form_label('Last Name ', 'apellidos', array('class'=>'col-sm-2 control-label')); ?>
			<div class="col-sm-10">
			<div class="input-group">
			  <div class="input-group-addon">L</div>
			  <?php echo form_input(array('type'=>'text', 'name'=>'apellidos', 'id'=>'apellidos', 'value'=>set_value('apellidos'), 'class'=>'form-control', 
			  								'placeholder'=>'Example: Jones Smith', 'required'=>'true')); ?>
			</div>
			</div>
		  </div>

		  <div class="form-group">
			<?php echo form_label('Birth Date ', 'fecha_nac', array('class'=>'col-sm-2 control-label')); ?>
			<div class="col-sm-10">
			<div class="input-group">
			  <div class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></div>
			  <?php echo form_input(array('type'=>'date', 'name'=>'fecha_nac', 'id'=>'fecha_nac', 'value'=>set_value('fecha_nac'), 'class'=>'form-control', 
			  								'placeholder'=>'Example: mm/dd/yyyy', 'required'=>'true')); ?>
			</div>
			</div>
		  </div>
		
		  <div class="form-group">
			<?php echo form_label('Email ', 'email', array('class'=>'col-sm-2 control-label')); ?>
			<div class="col-sm-10">
			<div class="input-group">
			  <div class="input-group-addon">@</div>
			  <?php echo form_input(array('type'=>'email', 'name'=>'email', 'id'=>'email', 'value'=>set_value('email'), 'class'=>'form-control', 
			  								'placeholder'=>'example@domain.com', 'required'=>'true')); ?>
			</div>
			</div>
		  </div>

		  <div class="form-group">
			<?php echo form_label('Username ', 'login', array('class'=>'col-sm-2 control-label')); ?>
			<div class="col-sm-10">
			<div class="input-group">
			  <div class="input-group-addon">AB</div>
			  <?php echo form_input(array('type'=>'text', 'name'=>'login', 'id'=>'login', 'value'=>set_value('login'), 'class'=>'form-control', 'placeholder'=>'Example: BearPolar',
			  								'onkeypress'=>'return char_set(event);', 'pattern'=>'[a-z_A-Z0-9]*', 'required'=>'true', 'minlength'=>'5', 'maxlength'=>'15')); ?>
			</div>
			</div>
		  </div>

		  <div class="form-group">
			<?php echo form_label('User Type ', 'perfil_id', array('class'=>'col-sm-2 control-label')); ?>
			<div class="col-sm-10">
			<div class="input-group">
			  <div class="input-group-addon">AB</div>
				<?php $perfil = array('Driver'=>'Driver', 'Passenger'=>'Passenger');?>
				<?php $style = 'class="form-control"';?>
				<?php echo form_dropdown('perfil_id', $perfil, 1, $style);?>
			</div>
			</div>
		  </div>
		  
		  <div class="form-group">
			<?php echo form_label('Password ', 'password', array('class'=>'col-sm-2 control-label')); ?>
			<div class="col-sm-10">
			<div class="input-group">
			  <div class="input-group-addon">***</div>
			   <?php echo form_input(array('type'=>'password', 'name'=>'password', 'id'=>'password', 'value'=>set_value('password'), 'class'=>'form-control', 'placeholder'=>'**********',
			   								'onkeypress'=>'return char_set(event);', 'required'=>'true')); ?>
			</div>
			</div>
		  </div>

		  <div class="form-group">
			<?php echo form_label('Confirm Password ', 'password', array('class'=>'col-sm-2 control-label')); ?>
			<div class="col-sm-10">
			<div class="input-group">
			  <div class="input-group-addon">***</div>
			   <?php echo form_input(array('type'=>'password', 'name'=>'confirm_pwd', 'id'=>'confirm_pwd', 'value'=>set_value('confirm_pwd'), 'class'=>'form-control', 'placeholder'=>'**********',
			   								'onkeypress'=>'return char_set(event);', 'required'=>'true')); ?>
			</div>
			</div>
		  </div>
		  
		  <div class="form-group">
			<div class="col-sm-offset-2 col-sm-10">
			<?php echo form_hidden('Latitude', $_COOKIE['locx']); ?>
			  <?php echo form_hidden('Longitude', $_COOKIE['locy']); ?>
			  <?php echo form_hidden('ZoneTime', $_COOKIE[onlinedate]); ?>
			  <?php echo form_button(array('type'=>'submit', 'content'=>'Sing up', 'class'=>'btn btn-primary')); ?>
			</div>
		  </div>
		<?php echo form_close(); ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <!--<button type="button" class="btn btn-primary">Accept</button>-->
      </div>
    </div>
  </div>
</div>