﻿<?php echo packstylecss('themes/sliders/slick/css/normalize');?>
<link rel='stylesheet prefetch' href='https://googledrive.com/host/0B1RR6fhjI2QROGt0MTFoVkhMdUk/fonts.css'>
<?php echo packstylecss('themes/sliders/slick/css/animate.min');?>
<?php echo packstylecss('themes/sliders/slick/css/style');?>
  <div class="Modern-Slider">
  <!-- Item -->
  <?php foreach($query as $row){?>
  <div class="item">
    <div class="img-fill">
      <img src="<?php echo base_url('assets/images/'.$row->userfile.'');?>" alt="">
      <div class="info">
        <div>
          <h3><?php echo $row->titulo;?></h3>
          <h5><?php echo $row->descripcion;?></h5>
		  <p style="font-size:15px;"><span class="button"><a href="<?php echo $row->url;?>">Leer Más</a></span></p>
        </div>
      </div>
    </div>
  </div>
  <?php } ?>
  <!-- // Item -->
</div>
<?php echo packstylejs('themes/sliders/slick/js/jquery.min');?>
<?php echo packstylejs('themes/sliders/slick/js/slick');?>
<?php echo packstylejs('themes/sliders/slick/js/index');?>