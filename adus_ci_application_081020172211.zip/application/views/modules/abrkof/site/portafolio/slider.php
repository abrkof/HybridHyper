﻿<div class='slider-wrapper' style="background-color: ">

<?php
$count = $query;
$slides = '';
$indicadores =  '';
$counter = 0;

    foreach($query as $row){
        $titulo = $row->titulo;
        $descripcion = $row->descripcion;
        $img = $row->userfile;
		$link = $row->url;
        if($counter == 0){
            $indicadores .='<li data-target="#myCarousel" data-slide-to="'.$counter.'" class="active"></li>';
            $slides .= '<div class="item active">
            <img src="'.base_url().'assets/images/'.$img.'" alt="'.$titulo.'"/>
            <div class="carousel-caption">
              <div style="background-color:#2980B9;" class="img-rounded img-polaroid"><h4>'.$titulo.'</h4></div>
              <div style="background-color:#FFBB00;" class="img-rounded img-polaroid"><p><h5>'.$descripcion.'<h5></p></div>
			  <!--<span class="button"><a href="'.$link.'" style="text-decoration:none;">Leer Más</a></span>-->
            </div>
          </div>';
        } else {
            $indicadores .='<li data-target="#myCarousel" data-slide-to="'.$counter.'"></li>';
            $slides .= '<div class="item">
            <img src="'.base_url().'assets/images/'.$img.'" alt="'.$titulo.'"/>
            <div class="carousel-caption">
              <div style="background-color:#2980B9;" class="img-rounded img-polaroid"><h4>'.$titulo.'</h4></div>
              <div style="background-color:#FFBB00;" class="img-rounded img-polaroid"><p><h5>'.$descripcion.'<h5></p></div>
			  <span><a href="'.$link.'" style="text-decoration:none;"class="btn btn-success">Leer Más</a></span>
            </div>
          </div>';
        }
        $counter++;
    }
?>
<!--<div class="container" style="width: 730px;">-->
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
         <?php echo $indicadores; ?>
        </ol>
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
        <?php echo $slides; ?>  
        </div>
        <!-- Controls -->
        <a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a><!---->
        
		<a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a><!---->
      </div>
    <!--</div>-->
</div>