﻿<div class="panel-pane pane-views-panes pane-destcados-panel-pane-1">
	<div class="view view-destcados view-id-destcados view-display-id-panel_pane_1 destacado view-dom-id-b62aecf974285a8f459132f1d558ca67">
	<br><br>
		<div class="view-content">
			<ul class="sliderHome">
				<?php foreach($query as $row){?>
				<li class="slide">  
					<figure><img typeof="foaf:Image" src="<?php echo base_url('assets/images/'.$row->userfile.'');?>" width="1024" height="512" alt="" /></figure>
					<div class="titular wow fadeIn blanco">
					<h2 class="sliderHome-title linea2 blanco marron_degradado60" style="font-size:30px;"><?php echo $row->titulo;?></h2>
					<p class="linea1 blanco marron_degradado40" style="font-size:20px;"><span><?php echo $row->descripcion;?></span></p>
					<p></p>
					<p class="linea1 destacado2 marron blanco_degradado100" style="font-size:15px;"><a href="<?php echo $row->url;?>" class="area6">Leer Más...</a></p>
					</div>
				</li>
				<?php } ?>
			</ul>
		</div>
	</div>
</div>