﻿<?php //$this->load->view('admin/headers_check_login');?>

<div class="row" id="real-estates-detail">
	<div class="col-lg-4 col-md-4 col-xs-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<header class="panel-title">
					<div class="text-center">
						<strong>Agent</strong> Author<strong>.</strong>
					</div>
				</header>
			</div>
			<div class="panel-body">
				<div class="text-center" id="author">
					<img src="<?php echo base_url('');?>assets/images/abrkof_logo_x.png" style="height:300px;width:400px;" class="img-responsive">
					<h3>ABRKOF</h3>
					<small class="label label-warning">El Salvador</small>
				  <p>Estos sitios corren bajo nuestra plataforma<br>
				    <span style="color:#0099FF;">ADUS CI</span>®</p>
					<p class="sosmed-author">
						<a href="http://www.facebook.com/abrkof" target="_blank"><i class="fa fa-facebook" data-toggle="tooltip" data-placement="top" title="" data-original-title="Facebook"></i></a>
						<a href="http://www.twitter.com/abrkof" target="_blank"><i class="fa fa-twitter" data-toggle="tooltip" data-placement="top" title="" data-original-title="Twitter"></i></a>
						<a href="https://plus.google.com/107806265976973067351" target="_blank"><i class="fa fa-google-plus" data-toggle="tooltip" data-placement="top" title="" data-original-title="Google Plus"></i></a>
					</p>
				</div>
			</div>
		</div>
	</div>
	<div class="col-lg-8 col-md-8 col-xs-12">
		<div class="panel">
			<div class="panel">
				<div class="panel-body">

					<div class="row">
						<div class="col-sm-5">
							<a href="http://lpsenlinea.net/" target="_blank"><img src="<?php echo base_url('');?>assets/images/portafolio/lpsenlinea.jpg" class="img-responsive"></a>
						</div>
						<div class="col-sm-7">
							<h4 class="title-real-estates">
								<strong><a href="#">Telefonía VoIP</a></strong> <span class="pull-right">2013</span>
							</h4>
							<hr>
							<p>Empresa de telefonía ip movil.</p>
							<p>Comunicate entre los tuyos, desde cualquier parte del mundo, desde cualquier movil con un mismo número.<p>
							<!--<p><span class="label label-danger">1</span> | <span class="label label-danger">1</span> | <span class="label label-danger">1</span></p>--->
						</div>
					</div>

					<div class="row">
						<div class="col-sm-5">
							<a href="http://voiceline2phone.com/" target="_blank"><img src="<?php echo base_url('');?>assets/images/portafolio/voiceline.png" class="img-responsive"></a>
						</div>
						<div class="col-sm-7">
							<h4 class="title-real-estates">
								<strong><a href="#">Telefonía VoIP</a></strong> <span class="pull-right">2013</span>
							</h4>
							<hr>
							<p>Empresa de telefonía ip movil.</p>
							<p>Comunicate entre los tuyos, desde cualquier parte del mundo, desde cualquier movil con un mismo número.<p>
							<!--<p><span class="label label-danger">1</span> | <span class="label label-danger">1</span> | <span class="label label-danger">1</span></p>--->
						</div>
					</div>

					<div class="row">
						<div class="col-sm-5">
							<a href="http://www.cityguidesv.com" target="_blank"><img src="<?php echo base_url('');?>assets/images/portafolio/cityguides_logox.png" class="img-responsive"></a>
						</div>
						<div class="col-sm-7">
							<h4 class="title-real-estates">
								<strong><a href="#">Revista Digital</a></strong> <span class="pull-right">2016</span>
							</h4>
							<hr>
							<p>Empresa de publicidad estrategica.</p>
							<p>Vuélvete el favorito de los clientes entre toda la competencia y comienza a aumentar tus ingresos de manera fácil, confiable y segura.<p>
							<!--<p><span class="label label-danger">1</span> | <span class="label label-danger">1</span> | <span class="label label-danger">1</span></p>--->
						</div>
					</div>
					
					<div class="row">
						<div class="col-sm-5">
							<a href="http://www.cityguidesv.com/clasificados" target="_blank"><img src="<?php echo base_url('');?>assets/images/portafolio/clasificados.png" class="img-responsive"></a>
						</div>
						<div class="col-sm-7">
							<h4 class="title-real-estates">
								<strong><a href="#">Clasificados</a></strong> <span class="pull-right">2016</span>
							</h4>
							<hr>
							<p>Clasificados en Linea.</p>
							<p>Un excelente lugar para publicar todo lo que quieras vender en internet, completamente gratiuto.<p>
							<!--<p><span class="label label-danger">1</span> | <span class="label label-danger">1</span> | <span class="label label-danger">1</span></p>--->
						</div>
					</div>

					<div class="row">
						<div class="col-sm-5">
							<a href="http://www.cashnchecks.com/" target="_blank"><img src="<?php echo base_url('');?>assets/images/portafolio/cash__check.png" class="img-responsive"></a>
						</div>
						<div class="col-sm-7">
							<h4 class="title-real-estates">
								<strong><a href="#">Casa de Empeño</a></strong> <span class="pull-right">2016</span>
							</h4>
							<hr>
							<p>Inversión, Casa de Empeño, Prestamos Hipotecarios.</p>
							<p>Tu mejor opción en casa de empeño y prestamos hipotecarios.<p>
							<!--<p><span class="label label-danger">1</span> | <span class="label label-danger">1</span> | <span class="label label-danger">1</span></p>--->
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>