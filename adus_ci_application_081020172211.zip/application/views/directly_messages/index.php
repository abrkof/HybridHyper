﻿<?php $this->load->view('admin/headers_check_login');?>

<style type="text/css">
<!--
.Estilo1 {color: #FF3333}
-->
</style>

<div class="x_panel">
  <div class="x_title">
	<h2> Mensajes <small>|| Acceso a Mensajeria Interna</small></h2>
	<ul class="nav navbar-right panel_toolbox">
	  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
	  </li>
	  <li class="dropdown">
		<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
	  </li>
	  <li><a class="close-link"><i class="fa fa-close"></i></a>
	  </li>
	</ul>
	<div class="clearfix"></div>
  </div>
  <div class="x_content">
<div align="center"><a href="<?php echo base_url('messages/') ;?>"><img src="<?php echo base_url('')?>assets/siteicons/correo.png" width="150" height="150"></a><br>DESLIZA DE DERECHA A IZQUIERDA</div>
<hr>
<div class="table-responsive">
			<table class="table table-bordered table-hover" border="1" bordercolor="#CCCCCC">
				<thead>
					<tr>
						<th> <div align="center"><a href="<?php echo base_url('messages/messages/#messages') ;?>"><img src="<?php echo base_url('assets/siteicons/redactar.png')?>" width="90" height="90"></a></div> </th>
						<th> <div align="center"><a href="<?php echo base_url('messages/send/#messages') ;?>"><img src="<?php echo base_url('assets/siteicons/enviar.png')?>" width="100" height="100"></a></div> </th>
						<th> <div align="center"><a href="<?php echo base_url('messages/sent/#messages') ;?>"><img src="<?php echo base_url('assets/siteicons/recibir.png')?>" width="100" height="100"></a></div> </th>
					</tr>
				</thead>
			
				<tbody>
					<tr>
						<th> <h3 align="center">Iniciar bandeja de entrada!</h3> </th>
						<td> <h3 align="center">Redactar un mensaje directo!</h3> </td>
						<td> <h3 align="center">Listar mensajes enviados!</h3> </td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
<div><ul class="pagination"><li><?php echo $this->pagination->create_links(); ?></li></ul></div>