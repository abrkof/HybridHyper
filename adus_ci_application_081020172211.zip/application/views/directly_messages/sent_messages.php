﻿<?php $this->load->view('admin/headers_check_login');?>

<style type="text/css">
<!--
.Estilo1 {color: #FF3333}
.Estilo3 {font-size: 14px}
-->
</style>

<div class="x_panel">
  <div class="x_title">
	<h2> Mensajes <small>|| Acceso a Mensajeria Interna</small></h2>
	<ul class="nav navbar-right panel_toolbox">
	  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
	  </li>
	  <li class="dropdown">
		<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
	  </li>
	  <li><a class="close-link"><i class="fa fa-close"></i></a>
	  </li>
	</ul>
	<div class="clearfix"></div>
  </div>
  <div class="x_content">
<div class="table-responsivex">

<div class="page-header" align="center">
	<h1><a href="<?php echo base_url('messages/#messages') ;?>"><img src="<?php echo base_url('')?>assets/siteicons/correo.png" width="150" height="150"></a></h1>
	<h1> Mensajes Directos Enviados </h1>
	<h3> Lista de mensajes  </h3>
</div>

<?php if(!$query) { ?>
<div class="col-xs-12">
	<div class="alert alert-danger">
	  <button type="button" class="close" data-dismiss="alert">&times;</button>
	  <strong>Alerta!</strong> No hay nada que mostrar.!!!
	</div>
</div>
<?php }else{ ?>

<div class="row">
  <div class="col-sm-12 mail_list_column">
	<a href="<?php echo base_url('messages/send/#messages') ;?>" id="compose" class="btn btn-sm btn-success btn-block" type="button">REDACTAR</a>
	<?php foreach ($query as $registro): ?>
	<a href="#">
	  <div class="mail_list">
		<div class="left">
			<?php echo anchor('messages/resend/'.$registro->id,'<i class="fa fa-edit" style="font-size:17;"></i>'); ?> |
			<?php echo anchor('messages/delete_sent_message/'.$registro->id, '<i class="fa fa-trash-o" style="font-size:17;"></i>', array('onClick'=>"return confirm('Eliminando Mensaje, ¿Está Seguro?')")); ?>
			<?php if ($registro->state_c==0){?>
			<span class="label label-info">Sin Leer</span>
			<?php } ?>
			<?php if ($registro->state_c==1){?>
			<span class="label label-success">Leido</span>
			<?php } ?>
		</div>
		<div class="right">
		  <a href="<?php echo base_url('messages/resend/'.$registro->id);?>">
		  <h3><?php echo $registro->remitente ;?>
		  <small><?php echo date("d/m/Y - H:i", strtotime($registro->created)); ?> - (UTC) 
		  <!--img src="<?php //echo base_url('');?>assets/images/usuario_image/<?php //echo $registro->image;?>" class="img-rectangle" alt="User Image" height="30px"--></small></h3>
		  <h3><?php echo '[ '.$registro->asunto.' ]' ;?></h3>
		  
		  <p>
		  <?php 
		  if (strlen($registro->mensaje)>80){
		  	echo substr($registro->mensaje, 0, 80).'...';
		  } else {
		  	echo $registro->mensaje;
		  }?>
		  </p>
		  </a>
		</div>
	  </div>
	</a>
	<?php endforeach; ?>
  </div>
<div>
<div><ul class="pagination"><li><?php echo $this->pagination->create_links(); ?></li></ul></div>
</ul>
</div>
<?php } ?>
</div>
</div>