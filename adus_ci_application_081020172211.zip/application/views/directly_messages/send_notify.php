﻿<br>
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModalx">
  Contactar Mas Cercano
</button>

<!-- Modal -->
<div class="modal fade" id="myModalx" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	  <h4 class="modal-title" id="myModalLabel">Formulario de petición a chofer</h4>
	  </div>
	  <div class="modal-body">
		<?php echo form_open('messages/require_driver', array('name'=>'frm', 'id'=>'frm', 'class'=>'form-horizontal', 'onSubmit'=>'return index();')); ?>
		<div class="panel panel-default">
			<div class="panel-body">
			  <p><img src="<?php echo base_url('');?>assets/app/dashboard/img/photo.jpg" class="img-rounded pull-right"> <a href="#">Alerta de Notificación</a></p>
			  <div class="clearfix"></div>
			  <hr>
			  Se enviara una petición de viaje a los conductores mas cercanos.
			  <?php echo form_hidden('ZoneTime', $_COOKIE[zonetime]); ?>
			</div>
		 </div>
		  
		  <div class="form-group">
			<div class="col-sm-offset-2 col-sm-10">
			  <?php echo form_button(array('type'=>'submit', 'content'=>'Enviar', 'class'=>'btn btn-primary', 'onclick'=>'addStuff()')); ?>
			</div>
		  </div>
		<?php echo form_close(); ?>
	  </div>
	  <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		<!--<button type="button" class="btn btn-primary">Accept</button>-->
	  </div>
	</div>
  </div>
</div>
<!-- Modal -->