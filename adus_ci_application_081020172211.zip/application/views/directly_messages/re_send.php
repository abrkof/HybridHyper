<?php $this->load->view('admin/headers_check_login');?>

<?php echo packstylejs('tinymce/tinymce.min');?>
<script type="text/javascript">
	tinyMCE.init({
		mode : "textareasx",
		width: "70%",
		height: "240px",
		language: 'en',
		theme_advanced_toolbar_align : "left",
		theme_advanced_toolbar_location : "top",
		plugins : [
			"advlist autolink lists link image charmap preview anchor",
			"searchreplace visualblocks code fullscreen",
			"insertdatetime media table contextmenu paste"
		],
		entity_encoding : "raw",
		theme_advanced_buttons1_add : "forecolorpicker,fontsizeselect",
		theme_advanced_buttons2_add: "media",
		theme_advanced_buttons3: "",
		theme_advanced_disable : "styleselect,anchor",
		relative_urls : false,
		remove_script_host : false,
		convert_urls : false
	});

</script>
<script type="text/JavaScript">
<!--
function time()
{
var y= new Date();
document.cookie="xdate="+y; 
}
//-->
</script>

<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Reenviando Mensaje</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<div class="page-header" align="center">
					<h1><a href="<?php echo base_url('messages/sent/') ;?>#messages"><img src="<?php echo base_url('');?>assets/siteicons/recibir.png" width="150" height="150"></a></h1>
					<h1> Mensajes Directos Enviados </h1>
					<h3> Lista de mensajes  </h3>
				</div>
				<?php echo my_validation_errors(validation_errors()); ?>
				<?php echo form_open('module/insert', array('class'=>'form-horizontal form-label-left')); ?>
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Para : ', 'para', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<span class="uneditable-input form-control"><div align="left"> <?php echo $registro->remitente; ?> </div></span>
							<?php echo form_hidden('remitente', $registro->remitente); ?>
							<?php echo form_hidden('ZoneTime', $_COOKIE[zonetime]); ?>
							<?php //echo $registro->usuario_name.' '.$registro->usuario_ape.' / '.$registro->usuario_login.' - '.$registro->perfil_name;?>
						</div>
					</div>
				</div>
				
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Asunto : ', 'asunto', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php echo form_input(array('type'=>'text', 'name'=>'asunto', 'id'=>'asunto', 'class'=>'form-control', 'value'=>'Re: '.$registro->asunto.' | ')); ?>
						</div>
					</div>
				</div>
				
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Mensaje : ', 'mensaje', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php echo form_textarea(array('type'=>'text', 'name'=>'mensaje', 'id'=>'mensaje',
							'value'=>' | '.$registro->mensaje, 'class'=>'form-control', 'autofocus'=>'true')); ?>
						</div>
					</div>
				</div>
				
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Tipo : ', 'tipo', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php $type = array('message' => 'message', 'notify' => 'notify');?>
							<?php $style = 'class="form-control"';?>
							<?php echo form_dropdown('type', $type, $registro->type, $style);?>
						</div>
					</div>
				</div>
				
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Fecha de envio : ', 'fecha', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<span class="uneditable-input form-control"> <?php echo date("d/m/Y - H:i:s", strtotime($registro->created)); ?> </span>
							<?php echo form_hidden('created', $registro->created); ?>
						</div>
					</div>
				</div>
				
				<hr>
				<div class="input-group">
					<?php echo form_button(array('type'=>'submit', 'content'=>'Aceptar', 'class'=>'btn btn-info')); ?>
					<?php echo anchor('messages/sent', 'Cancelar', array('class'=>'btn btn-default')); ?><!--pull-left-->
				</div>
				
				<!-- /.box-footer -->
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>