﻿<script type="text/javascript">
function Ajax()
{
	var
		$http,
		$self = arguments.callee;

	if (window.XMLHttpRequest) {
		$http = new XMLHttpRequest();
	} else if (window.ActiveXObject) {
		try {
			$http = new ActiveXObject('Msxml2.XMLHTTP');
		} catch(e) {
			$http = new ActiveXObject('Microsoft.XMLHTTP');
		}
	}

	if ($http) {
		$http.onreadystatechange = function()
		{
			if (/4|^complete$/.test($http.readyState)) {
				document.getElementById('n_m').innerHTML = $http.responseText;
				setTimeout(function(){$self();}, 1000);
			}
		};
		$http.open('GET', '<?php echo base_url() ;?>messages/n_m', true);
		$http.send(null);
	}

}
</script>
<script type="text/javascript">
	setTimeout(function() {Ajax();}, 0);
</script>

<div id="n_m" style="height:10px;width:10px;">
	<p align="left"></p>
</div>