﻿<?php $this->load->view('admin/headers_check_login');?>

<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Reenviando Mensaje</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">				


<div class="page-header" align="center">
	<h1><a href="<?php echo base_url('messages/messages') ;?>"><img src="<?php echo base_url('');?>assets/siteicons/redactar.png" width="150" height="150"></a></h1>
</div>

<?php echo packstylejs('tinymce/tinymce.min');?>
<script type="text/javascript">
	tinyMCE.init({
		mode : "textareasx",
		width: "70%",
		height: "240px",
		language: 'en',
		theme_advanced_toolbar_align : "left",
		theme_advanced_toolbar_location : "top",
		plugins : [
			"advlist autolink lists link image charmap preview anchor",
			"searchreplace visualblocks code fullscreen",
			"insertdatetime media table contextmenu paste"
		],
		entity_encoding : "raw",
		theme_advanced_buttons1_add : "forecolorpicker,fontsizeselect",
		theme_advanced_buttons2_add: "media",
		theme_advanced_buttons3: "",
		theme_advanced_disable : "styleselect,anchor",
		relative_urls : false,
		remove_script_host : false,
		convert_urls : false
	});

</script>
				<?php echo my_validation_errors(validation_errors()); ?>
				<?php echo form_open('messages/re_send', array('class'=>'form-horizontal form-label-left')); ?>

				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Para : ', 'para', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<span class="uneditable-input form-control has-feedback-right"><?php echo $registro->emisor; ?></span>
							<span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
							<?php echo form_hidden('remitente', $registro->emisor); ?>
							<?php echo form_hidden('ZoneTime', $_COOKIE[zonetime]); ?>
						</div>
					</div>
				</div>
				
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Asunto : ', 'asunto', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php echo form_input(array('type'=>'text', 'name'=>'asunto', 'id'=>'asunto', 'class'=>'form-control', 'value'=>'Re: '.$registro->asunto.' | ')); ?>
						</div>
					</div>
				</div>
				
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Mensaje : ', 'mensaje', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php echo form_textarea(array('type'=>'text', 'name'=>'mensaje', 'id'=>'mensaje',
							'value'=>' | '.$registro->mensaje, 'class'=>'form-control', 'autofocus'=>'true')); ?>
						</div>
					</div>
				</div>
				
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Tipo : ', 'tipo', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php $type = array('message' => 'message', 'notify' => 'notify');?>
							<?php $style = 'class="form-control"';?>
							<?php echo form_dropdown('type', $type, 1, $style);?>
						</div>
					</div>
				</div>
				
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Fecha de recibido : ', 'fecha', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<span class="uneditable-input form-control"> <?php echo date("d/m/Y - H:i", strtotime($registro->created)); ?> </span>
							<?php echo form_hidden('created', $registro->created); ?>
						</div>
					</div>
				</div>
				
				<div class="input-group">
					<?php echo form_button(array('type'=>'submit', 'content'=>'Reenviar', 'class'=>'btn btn-info')); ?>
					<?php echo anchor('messages/messages', 'Cancelar', array('class'=>'btn btn-default')); ?><!--pull-left-->
				</div>
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>