﻿<script type="text/javascript">
function Load_Notify()
{
	var
		$http,
		$self = arguments.callee;

	if (window.XMLHttpRequest) {
		$http = new XMLHttpRequest();
	} else if (window.ActiveXObject) {
		try {
			$http = new ActiveXObject('Msxml2.XMLHTTP');
		} catch(e) {
			$http = new ActiveXObject('Microsoft.XMLHTTP');
		}
	}

	if ($http) {
		$http.onreadystatechange = function()
		{
			if (/4|^complete$/.test($http.readyState)) {
				document.getElementById('load_notify').innerHTML = $http.responseText;
				setTimeout(function(){$self();}, 1000);
			}
		};
		$http.open('GET', '<?php echo base_url() ;?>messages/load_notify', true);
		$http.send(null);
	}

}
</script>
<script type="text/javascript">
	setTimeout(function() {Load_Notify();}, 0);
</script>

<div id="load_notify" "catch(e){}" style="color: rgb(245, 245, 245);
font-family: 'sans-serif;
outline: 0px; text-decoration: none; -webkit-transition: color 0.3s; background-color: rgb(FF, 00, FF); 
background-image: -webkit-linear-gradient(top, rgb(FF, 245, 245), rgb(FF, 241, 241)); 
border: 1px solid rgba(FF, 0, 0, 0.0980392); border-top-left-radius: 2px; border-top-right-radius: 2px; 
border-bottom-right-radius: 2px; border-bottom-left-radius: 2px; bottom: -1px; 
cursor: default; 
display: inline-block; font-size: 11px; font-weight: bold; height: 147px; line-height: 27px; margin-right: 0px; 
min-width: 135px; padding: 0px 8px; position: fixed; right: 12px; top:50px; text-align: center; font-style: normal; 
font-variant: normal; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; 
widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; 
-webkit-text-stroke-width: 0px; ">
<!--<audio src="<?php //echo base_url('');?>assets/audio/Trans_SuperMode.mp3" autoplay="true" loop="true"></audio>-->
</div>