﻿<?php $this->load->view('admin/headers_check_login');?>

<?php
if($this->session->userdata('usuario_id')!= $registro->id AND $registro->id==1){
	$this->load->view('admin/acceso_denegado');
} else {
?>

<script type="text/javascript">
function control(f){
    var ext=['jpg','jpeg','png'];
    var v=f.value.split('.').pop().toLowerCase();
    for(var i=0,n;n=ext[i];i++){
        if(n.toLowerCase()==v)
            return
    }
    var t=f.cloneNode(true);
    t.value='';
    f.parentNode.replaceChild(t,f);
    alert('Extensión no válida');
}
</script>

<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Actualizando Imagen</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
		<?php echo my_validation_errors(validation_errors()); ?>
		<?php echo form_open_multipart('usuario/update_img', array('class'=>'form-horizontal')); ?>
			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('ID : ', 'id', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<span class="uneditable-input form-control"> <?php echo $registro->id; ?> </span>
						<?php echo form_hidden('id', $registro->id); ?>
					</div>
				</div>
			</div>

			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('Imagen : ', 'userfile', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<?php echo form_input(array('type'=>'file', 'name'=>'userfile', 'id'=>'userfile', 'value'=>set_value('userfile'), 
						'class'=>'form-control','required'=>'userfile', 'onchange'=>'javascritp:control(this)', 'title'=>'Debes de seleccionar una imagen de formato valido')); ?>
					</div>
				</div>
			</div>

			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('Creado : ', 'created', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<span class="uneditable-input form-control"> <?php echo date("d/m/Y - H:i:s", strtotime($registro->created)); ?> </span>
					</div>
				</div>
			</div>

			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('Modificado : ', 'updated', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<span class="uneditable-input form-control"> <?php echo date("d/m/Y - H:i:s", strtotime($registro->updated)); ?> </span>
					</div>
				</div>
			</div>
			<hr>
			<div class="box-footer">
				<?php echo form_button(array('type'=>'submit', 'content'=>'Aceptar', 'class'=>'btn btn-info')); ?>
				<?php echo anchor('usuario/index', 'Cancelar', array('class'=>'btn btn-default')); ?><!--pull-left-->
			</div>
		<!-- /.box-footer -->
	<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>
<?php } ?>