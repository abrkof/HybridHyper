﻿<?php $this->load->view('admin/headers_check_login');?>

<?php $this->load->view('admin/headers_check_logued');?>

<style type="text/css">
<!--
.Estilo1 {color: #FF3333}
-->
</style>

<div class="page-header">
	<h1> Usuario <small>|| Acceso Común </small> </h1>
</div>

<hr>
<a class="btn btn-large btn-block btn-primary" type="button" href="<?php echo base_url('usuario/usr_common_edit/'.$this->session->userdata('usuario_id').'');?>">Actualizar Información</a>
<a class="btn btn-large btn-block btn-success" type="button" href="<?php echo base_url('usuario/usr_common_edit_img/'.$this->session->userdata('usuario_id').'');?>">Actualizar Imagen</a>
<a class="btn btn-large btn-block btn-warning" type="button" href="<?php echo base_url('admin/cambio_clave/'.$this->session->userdata('usuario_id').'');?>">Cambiar Clave</a>
<?php if ($this->session->userdata('usuario_state') == '0'){?>
<a class="btn btn-large btn-block btn-default" type="button" href="<?php echo base_url('usuario/update_state1/'.$this->session->userdata('usuario_id').'');?>">Set OnLine</a>
<?php } else { ?>
<a class="btn btn-large btn-block btn-default" type="button" href="<?php echo base_url('usuario/update_state0/'.$this->session->userdata('usuario_id').'');?>">Set OffLine</a>
<?php } ?>
<hr>