<?php $this->load->view('admin/headers_check_login');?>

<?php $this->load->view('admin/headers_check_logued');?>

<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Actualizando Registro</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
		<?php echo my_validation_errors(validation_errors()); ?>
		<?php echo form_open('usuario/usr_common_update', array('class'=>'form-horizontal')); ?>
			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('ID : ', 'id', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<span class="uneditable-input form-control"> <?php echo $this->session->userdata('usuario_id'); ?> </span>
						<?php echo form_hidden('id', $this->session->userdata('usuario_id')); ?>
					</div>
				</div>
			</div>

			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('Nombres : ', 'name', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<?php echo form_input(array('type'=>'text', 'name'=>'nombres', 'id'=>'nombres', 'value'=>$registro->nombres, 'autofocus'=>'nombres', 'class'=>'form-control', 'placeholder'=>'nombres', 'required'=>'nombres')); ?>
					</div>
				</div>
			</div>

			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('Apellidos : ', 'ape', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<?php echo form_input(array('type'=>'text', 'name'=>'apellidos', 'id'=>'apellidos', 'value'=>$registro->apellidos, 'class'=>'form-control', 'placeholder'=>'apellidos', 'required'=>'apellidos')); ?>
					</div>
				</div>
			</div>

			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('Usuario (Nick) : ', 'login', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<?php echo form_input(array('type'=>'text', 'name'=>'login', 'id'=>'login', 'value'=>$registro->login, 'class'=>'form-control', 'placeholder'=>'Usuario (Nick)', 'minlength'=>'9', 'maxlength'=>'15', 'required'=>'login')); ?>
					</div>
				</div>
			</div>

			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('E-Mail : ', 'email', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<?php echo form_input(array('type'=>'email', 'name'=>'email', 'id'=>'email', 'value'=>$registro->email, 'class'=>'form-control', 'placeholder'=>'E-Mail', 'required'=>'email')); ?>
					</div>
				</div>
			</div>

			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('Creado : ', 'created', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<span class="uneditable-input form-control"> <?php echo date("d/m/Y - H:i:s", strtotime($registro->created)); ?> </span>
					</div>
				</div>
			</div>

			<div class="box-body">
				<div class="form-group">
					<?php echo form_label('Modificado : ', 'updated', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<span class="uneditable-input form-control"> <?php echo date("d/m/Y - H:i:s", strtotime($registro->updated)); ?> </span>
					</div>
				</div>
			</div>
		<hr>
		<!-- /.box-body -->
		<div class="box-footer">
			<?php echo form_button(array('type'=>'submit', 'content'=>'Aceptar', 'class'=>'btn btn-info')); ?>
			<?php echo anchor('admin/acerca_de', 'Cancelar', array('class'=>'btn btn-default')); ?><!--pull-left-->
		</div>
		<!-- /.box-footer -->
	<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>