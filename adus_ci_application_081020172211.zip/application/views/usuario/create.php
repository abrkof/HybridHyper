<?php $this->load->view('admin/headers_check_login');?>
<?php $this->load->view('admin/capture_lat_lon');?>

<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Creando Registro</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
			<?php echo my_validation_errors(validation_errors()); ?>
			<?php echo form_open('usuario/insert', array('class'=>'form-horizontal')); ?>
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Nombres : ', 'name', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php echo form_input(array('type'=>'text', 'name'=>'nombres', 'id'=>'nombres', 'value'=>set_value('nombres'), 'autofocus'=>'nombres', 
							'class'=>'form-control', 'placeholder'=>'nombres', 'required'=>'true')); ?>
						</div>
					</div>
				</div>
	
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Apellidos : ', 'ape', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php echo form_input(array('type'=>'text', 'name'=>'apellidos', 'id'=>'apellidos', 'value'=>set_value('apellidos'), 'class'=>'form-control', 
														'placeholder'=>'apellidos', 'required'=>'true')); ?>
						</div>
					</div>
				</div>
	
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Usuario (Login) : ', 'login', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php echo form_input(array('type'=>'text', 'name'=>'login', 'id'=>'login', 'value'=>set_value('login'), 'class'=>'form-control', 'placeholder'=>'Usuario (Nick)', 
														'minlength'=>'9', 'maxlength'=>'15', 'required'=>'true')); ?>
						</div>
					</div>
				</div>
	
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('E-Mail : ', 'email', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php echo form_input(array('type'=>'email', 'name'=>'email', 'id'=>'email', 'value'=>set_value('email'), 'class'=>'form-control', 'placeholder'=>'E-Mail', 'required'=>'true')); ?>
						</div>
					</div>
				</div>
	
				<div class="box-body">
					<div class="form-group">
						<?php echo form_label('Perfil : ', 'perfil_id', array('class'=>'col-sm-2 control-label')); ?>
						<div class="col-sm-10">
							<?php $style = 'class="form-control"';?>
							<?php echo form_dropdown('perfil_id', $perfiles, 0, $style); ?>
						</div>
					</div>
				</div>
				<hr>
				<div class="input-group">
					<?php echo form_button(array('type'=>'submit', 'content'=>'Aceptar', 'class'=>'btn btn-info')); ?>
					<?php echo anchor('usuario/index', 'Cancelar', array('class'=>'btn btn-default')); ?><!--pull-left-->
				</div>
			<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>