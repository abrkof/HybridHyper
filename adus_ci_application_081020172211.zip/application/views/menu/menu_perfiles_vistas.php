<?php $this->load->view('admin/headers_check_login');?>

<div class="right_col" role="main">
  <div class="">
	<div class="page-title">
	  <div class="title_left">
		<h3>Accesos</h3>
	  </div>

	  <div class="title_right">
	  </div>
	</div>
	<div class="clearfix"></div>

	<div class="row">
	  <div class="col-md-6 col-xs-12">
		<div class="x_panel">
		  <div class="x_title">
			<h2>Perfiles <small>|| No Asignados</small></h2>
			<ul class="nav navbar-right panel_toolbox">
			  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
			  </li>
			  <li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
			  </li>
			  <li><a class="close-link"><i class="fa fa-close"></i></a>
			  </li>
			</ul>
			<div class="clearfix"></div>
		  </div>
		  <div class="x_content">
			<br>
				<table class="table table-bordered table-hover">
					<caption> <h1> No Asignados </h1> </caption>
			
					<thead>
					<tr>
						<th> ID </th>
						<th> Nombre </th>
						<th> </th>
					</tr>
					</thead>
			
					<tbody>
					<?php foreach ($query_izq as $registro): ?>
					<tr>
						<td> <?php echo $registro[0]; ?> </td>
						<td> <?php echo $registro[1]; ?> </td>
						<td> <?php echo anchor('menu/mpv_asig/'.$registro[0].'/'.$registro[2], '<i class="icon-arrow-right"></i>'); ?> </td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<div class="btn-toolbar">
					<?php echo anchor('menu/index', 'Volver', 'class="btn btn-primary"'); ?>
				</div>
			</div>
		</div>
	  </div>

	<div class="row">
	  <div class="col-md-6 col-xs-12">
		<div class="x_panel">
		  <div class="x_title">
			<h2>Perfiles <small>|| Asignados</small></h2>
			<ul class="nav navbar-right panel_toolbox">
			  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
			  </li>
			  <li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
			  </li>
			  <li><a class="close-link"><i class="fa fa-close"></i></a>
			  </li>
			</ul>
			<div class="clearfix"></div>
		  </div>
		  <div class="x_content">
			<br>
				<table class="table table-bordered table-hover">
					<caption> <h1> Asignados </h1> </caption>
			
					<thead>
					<tr>
						<th> </th>
						<th> ID </th>
						<th> Nombre </th>
					</tr>
					</thead>
			
					<tbody>
					<?php foreach ($query_der as $registro): ?>
					<tr>
						<td> <?php echo anchor('menu/mpv_noasig/'.$registro[0].'/'.$registro[2], '<i class="icon-arrow-left"></i>'); ?> </td>
						<td> <?php echo $registro[0]; ?> </td>
						<td> <?php echo $registro[1]; ?> </td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
  </div>
</div>
