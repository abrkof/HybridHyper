<?php $this->load->view('admin/capture_lat_lon');?>
<?php
//echo $chart->render();
//require_once APPPATH."/third_party/include/header.php";
//require_once '../include/header.php';
//echo $series->render();
//echo $chart->render();
?>
<iframe src="../cityguides_xplorer" 
scrolling="yes" frameborder="0" style="/*border:none;*/ overflow:hidden; width:100%; height:130%;" allowtransparency="true"/>
<?php //require_once 'application/third_party/include/footer.php'; ?>