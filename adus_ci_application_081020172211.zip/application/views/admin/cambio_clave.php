﻿<?php $this->load->view('admin/headers_check_login');?>

<?php $this->load->view('admin/headers_check_logued');?>

<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Cambiando Contraseña</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<?php echo my_validation_errors(validation_errors()); ?>
				<?php echo form_open('admin/cambiar_clave', array('class'=>'form-horizontal')); ?>
		
					<div class="box-body">
						<div class="form-group">
							<?php echo form_label('Clave Actual :', 'clave_act', array('class'=>'col-sm-2 control-label')); ?>
							<div class="col-sm-10">
								<?php echo form_input(array('type'=>'password', 'name'=>'clave_act', 'id'=>'clave_act', 'class'=>'form-control', 'value'=>set_value('clave_act'))); ?>
							</div>
						</div>
					</div>
		
					<div class="box-body">
						<div class="form-group">
							<?php echo form_label('Clave Nueva :', 'clave_new', array('class'=>'col-sm-2 control-label')); ?>
							<div class="col-sm-10">
								<?php echo form_input(array('type'=>'password', 'name'=>'clave_new', 'id'=>'clave_new', 'class'=>'form-control', 'value'=>set_value('clave_new'))); ?>
							</div>
						</div>
					</div>
		
					<div class="box-body">
						<div class="form-group">
							<?php echo form_label('Confirmar Clave Nueva :', 'clave_rep', array('class'=>'col-sm-2 control-label')); ?>
							<div class="col-sm-10">
								<?php echo form_input(array('type'=>'password', 'name'=>'clave_rep', 'id'=>'clave_rep', 'class'=>'form-control', 'value'=>set_value('clave_rep'))); ?>
							</div>
						</div>
					</div>
		
				<hr>
				<!-- /.box-body -->
				<div class="box-footer">
					<?php echo form_button(array('type'=>'submit', 'content'=>'Aceptar', 'class'=>'btn btn-info')); ?>
					<?php echo anchor('admin/acerca_de', 'Cancelar', array('class'=>'btn btn-default')); ?><!--pull-left-->
				</div>
				<!-- /.box-footer -->
			<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>