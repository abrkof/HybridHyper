<?php $this->load->view('admin/headers_check_logued');?>

<?php echo $this->load->view('admin/acerca_de');?>