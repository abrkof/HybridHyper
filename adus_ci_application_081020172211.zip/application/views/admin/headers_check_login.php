<?php
echo headers();
$loguedx = ($this->session->userdata('usuario_id'));
if(!$loguedx){
	$this->session->sess_destroy();
	redirect('admin/acceso_denegado');
	exit();
}	
?>