<?php
echo headers();
$usuario = (!$this->session->userdata('usuario_id'));
if($usuario == TRUE){
	$this->session->sess_destroy();
	redirect('admin/acceso_denegado');
	exit();
 } 	
?>