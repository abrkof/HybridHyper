<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>ADUS CI - ABRKOF</title>
		<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Arimo' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Hind:300' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
		<?php echo packstylecss('admin/login-form/css/style');?><!--<link rel="stylesheet" href="css/style.css">-->
		<?php $this->load->view('admin/capture_lat_lon');?>
	</head>
	<body onload="find_location();return false;">
		<div id="login-button">
			<img src="<?php echo base_url('');?>assets/admin/login-form/img/login-w-icon.png">
			</img>
		</div>
		<div id="container">
			<br>
			<?php echo my_validation_errors_info(validation_errors()); $plain_password;?>
			<h1>Ingreso al Sistema</h1>
			<span class="close-btn">
				<img src="<?php echo base_url('');?>assets/admin/login-form/img/circle_close_delete_-128.png"></img>
			</span>
			<?php echo form_open('admin/ingresar'); ?>
				<?php echo form_input(array('type'=>'text', 'name'=>'login', 'id'=>'login', 'placeholder'=>'Usuario...', 
				'value'=>set_value('login'), 'autofocus'=>'login', 'required'=>'login')); ?>
				<?php echo form_input(array('type'=>'password', 'name'=>'password', 'id'=>'password', 'placeholder'=>'Password...', 
					'value'=>set_value('password'), 'required'=>'password')); ?>
				<?php //echo form_button(array('type'=>'submit', 'content'=>'Ingresar', 'class'=>'btn btn-info pull-right')); ?>
				<input type="submit" value="Ingresar" class="login">
				<?php //echo anchor('admin/inicio_sesion', 'Cancelar', array('class'=>'orange-btn')); ?>
				<?php echo form_hidden('ZoneTime', $_COOKIE['onlinedate']); ?>
			<?php echo form_close(); ?>
		</div>
		<?php echo packstylejs('admin/login-form/js/TweenMax.min');?><!--<script src='http://cdnjs.cloudflare.com/ajax/libs/gsap/1.16.1/TweenMax.min.js'></script>-->
		<?php echo packstylejs('admin/login-form/js/jquery.min');?><!--<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>-->
		<?php echo packstylejs('admin/login-form/js/index');?><!--<script src="js/index.js"></script>-->
	</body>
</html>
