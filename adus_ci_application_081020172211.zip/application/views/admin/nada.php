<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             	// Expira en fecha pasada
//header("Expires", 0);
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");	// Siempre p�gina modificada
header("Cache-Control: no-cache, must-revalidate");           	// Evitar guardado en cache del cliente HTTP/1.1
header("Cache-Control: no-store");
header("Pragma: no-cache");                               		// Evitar guardado en cache del cliente HTTP/1.0

     $logued = $this->session->userdata('usuario_id');
	 //$session = $this->session->userdata('session_id');
    
if($logued === FALSE /*|| $session === FALSE */){ /* por seguridad hacemos doble verificaci�n; aunque estas 
                                               * 2 variables siempre van a tener el mismo estado */
	redirect('admin/acceso_denegado'); exit();
	
 } 	
?>
<div class="hero-unit">
	<h1> Noze </h1>
	<hr>
	<p> A qui no hay nada</p>
    <p> Tampoco aca no hay nada. </p>
</div>
