<?php //?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>ADUS CI - ABRKOF</title>
		<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Arimo' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Hind:300' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>

		<?php echo packstylecss('admin/login/css/normalize');?>
		<?php echo packstylecss('admin/dashboard/gentelella-master/vendors/bootstrap/dist/css/bootstrap.min');?>
		<!--<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css'>-->
		<link rel='stylesheet prefetch' href='<?php echo base_url('');?>assets/admin/login/css/fonts.css?family=Raleway:400,200' rel='stylesheet' type='text/css'>
		<?php echo packstylecss('admin/login/css/style');?>
		<?php echo packstylecss('admin/css/bootstrap.min');?>
		<?php $this->load->view('admin/capture_lat_lon');?>

	</head>
	<body onload="find_location();return false;">
		
		<div class="col-xs-12 wrapper">
		  <div class="row">
			<div class="col-xs-8 col-center clearfix">
			  <div class="wrapper login pos-vert clearfix">
				<?php echo form_open('admin/ingresar'); ?>
				  <!--AVATAR-->
				  <div class="avatar_pwd pull-left" style="background-image:url(<?php echo base_url('');?>assets/images/usuario_image/<?php echo get_instance()->session->userdata('usuario_image');?>);background-repeat: no-repeat;"></div>
				  <div class="form-group pull-left">
				  <div style="color:#FFFFFF; font-size:24px;"><?php echo $this->session->userdata('perfil_name');?></div>
				  <?php echo my_validation_errors_info(validation_errors());?>
					<label class="h1 user-name"><?php echo $this->session->userdata('usuario_name').' '.$this->session->userdata('usuario_ape'); ?><small class="pull-right glyphicon glyphicon-cog"></small></label>
					<div class="input-group">
					  <div class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></div>
					  <?php echo form_hidden('login', $_REQUEST['login']); ?>

					  <?php echo form_input(array('type'=>'password', 'name'=>'password', 'id'=>'password', 'placeholder'=>'USUARIO ID', 
										'value'=>set_value('password'), 'autofocus'=>'password', 'required'=>'true', 'class'=>'hidden_box', 'autocomplete'=>'off', 'title'=>' ')); ?>
					  <?php echo form_hidden('ZoneTime', $_COOKIE['onlinedate']); ?>
					  <?php echo form_button(array('type'=>'submit', 'content'=>'Introduzca Su PIN de Seguridad', 'class'=>'form-control')); ?>
					  
					  <div class="input-group-addon"><span class="glyphicon glyphicon-chevron-right"></span></div>
					</div>
				  </div>
				<?php echo form_close(); ?>
			  </div>
			</div>
		  </div>
		</div>
	
	</body>
</html>
