<?php $this->load->view('admin/headers_check_login');?>
<?php $this->load->view('admin/headers_check_logued');?>

<style type="text/css">
<!--
.Estilo1x {
	color: #21759B;
	font-weight: bold;
}
-->
</style>
<div class="row">
	<div class="col-md-12 col-sm-6 col-xs-6">
	<div class="col-md-12 col-xs-12">
		<div class="row x_title">
		  <div class="col-md-6">
			<h3>Información</h3>
			<h1> <?php echo ADUS_CI ;?> </h1><p>
			<hr>
			<p> Sistema de Administración de Usuarios - <?php echo ADUS_CI_VERSION ;?> </p>
			<p> <img src="<?php echo base_url('');?>assets/admin/images/abrkof_logo_x.png" height="300" width="300"> </p>
			<p> <h3>Información del Sistema:</h3> </p>
			<p> Administración de Perfiles. </p>
			<p> Administración de Usuarios. </p>
			<p> Administracón de Menús, sub Menús. </p>
			<p> Administración por Módulos. </p>
			<p> Administración de Contenido. </p>
			<p> Generación de Reportes. </p>
			<hr>
			<p> <h3>Lo que se espera en próximas versiones.</h3> </p>
			<p> Instalación de paquetes. </p>
			<hr>
			<p ><h3> Nota: </h3> </p>
			<p> La opción de respaldo de la base de datos esta en face de brueba, solo funciona de forma local.</p>
			<p> Utilizala bajo tu propio criterio. </p>
			<?php
			$count_session = $_SESSION['count_session']++;
			if ($count_session ==0){
				echo '<script>alertify.success("Bienvendio '.'<br>'.$this->session->userdata('usuario_name').' '.$this->session->userdata('usuario_ape').'");</script>';
			}
			?>
		  </div>
		  <div class="col-md-6">
		  </div>
		</div>
		<div class="col-md-9 col-sm-9 col-xs-12">
		</div>
	</div>
</div>
