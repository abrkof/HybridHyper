<?php
$password = '9530e5a6e8d27551339a8801b6e9585fe6288a041bd1a797d11bb80d528161e36c8043eed04fda2933b11f4217665cc815d46cd2dc16a516b2a04f3ce2cd838835OZtErMFku/+/RwK9fOXAMhViZcEXFE5VaGimXxFzI=';
$plain_password = $this->encryption->decrypt($password);
//echo $plain_password;
$this->session->sess_destroy();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>ADUS CI - ABRKOF</title>
		<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Arimo' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Hind:300' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>

		<?php echo packstylecss('admin/login/css/normalize');?>
		<?php echo packstylecss('admin/dashboard/gentelella-master/vendors/bootstrap/dist/css/bootstrap.min');?>
		<!--<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css'>-->
		<link rel='stylesheet prefetch' href='<?php echo base_url('');?>assets/admin/login/css/fonts.css?family=Raleway:400,200' rel='stylesheet' type='text/css'>
		<?php echo packstylecss('admin/login/css/style');?>
		<?php echo packstylecss('admin/css/bootstrap.min');?>
		<?php $this->load->view('admin/capture_lat_lon');?>

	</head>
	<body onload="find_location();return false;">
		
		<div class="col-xs-12 wrapper">
		  <div class="row">
			<div class="col-xs-8 col-center clearfix">
			  <div class="wrapper login pos-vert clearfix">
				<?php echo form_open('admin/auth'); ?>
				  <!--AVATAR-->
				  <div class="avatar pull-left"></div>
				  <div class="form-group pull-left">
				  <?php echo my_validation_errors_info(validation_errors());?>
					<label class="h1 user-name">Identificación de Usuario<small class="pull-right glyphicon glyphicon-cog"></small></label>
					<div class="input-group">
					  <div class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></div>
					  <?php echo form_input(array('type'=>'text', 'name'=>'login', 'id'=>'login', 'placeholder'=>'USUARIO ID', 
										'value'=>set_value('login'), 'autofocus'=>'login', 'required'=>'true', 'class'=>'hidden_box', 'autocomplete'=>'off', 'title'=>' ')); ?>
					  <?php //echo form_hidden('ZoneTime', $_COOKIE['onlinedate']); ?>
					  <?php echo form_button(array('type'=>'submit', 'content'=>'Deslice su Tarjeta', 'class'=>'form-control')); ?>
					  <div class="input-group-addon"><span class="glyphicon glyphicon-chevron-right"></span></div>
					</div>
				  </div>
				<?php echo form_close(); ?>
			  </div>
			</div>
		  </div>
		</div>
	
	</body>
</html>
