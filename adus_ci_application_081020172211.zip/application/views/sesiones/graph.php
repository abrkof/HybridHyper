<?php $this->load->view('admin/headers_check_login');?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
<!--
.Estilo1 {color: #FF3333}
-->
</style>

<div class="x_panel">
  <div class="x_title">
	<h2> Sesiones de Usuarios (Gráficas) <small>|| Lista de Registros</small></h2>
	<ul class="nav navbar-right panel_toolbox">
	  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
	  </li>
	  <li class="dropdown">
		<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
	  </li>
	  <li><a class="close-link"><i class="fa fa-close"></i></a>
	  </li>
	</ul>
	<div class="clearfix"></div>
  </div>
  <div class="x_content">

<div style="width:400px;">
<button type="button" class="btn btn-primary btn-lrg ajax" title="Ajax Request">
	<i class="fa fa-spin fa-refresh"></i>
	<?php echo anchor('Sesiones_Graph/index/', 'Refrescar', array('style'=>'color:#FFFFFF;')); ?>
</button>
</div>

<?php if(!$query) { ?>
<div class="col-xs-3">
	<div class="alert alert-error">
	  <button type="button" class="close" data-dismiss="alert">&times;</button>
	  <strong>Alerta!</strong> No hay nada que mostrar.!!!
	</div>
</div>
<?php }else{ ?>

<?php echo packstylejs('analitycs/js/jquery.min');?>

<style type="text/css">
${demo.css}
</style>
<script language="Javascript">
	function imprSelec(impresion) {
	  var ficha = document.getElementById(impresion);
	  var ventimp = window.open(' ', 'popimpr');
	  //$("#seleccion").append('<img src="../img/coed2.png">');
	  ventimp.document.write( ficha.innerHTML );
	  ventimp.document.close();
	  ventimp.print( );
	  ventimp.close();
	}
</script>
<div id="seleccion" align="center">
	<div class="table-responsive">
					<script type="text/javascript">
						$(function () {
							$('#container').highcharts({
								chart: {
									plotBackgroundColor: null,
									plotBorderWidth: null,
									plotShadow: false,
									type: 'pie'
								},
								title: {
									text: 'Total Sesiones de Usuarios: <?php foreach ($total_count as $registro): ?> <?php echo $registro->total; ?><?php endforeach; ?>'
								},
								tooltip: {
									pointFormat: '{series.name}: (<b>{point.y:,.0f}</b>), <b>{point.percentage:.1f}%</b>'
								},
								/*legend: {
									layout: 'vertical',
									align: 'right',
									verticalAlign: 'top',
									x: -40,
									y: 100,
									floating: true,
									borderWidth: 1,
									backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
									shadow: true
								},*/
								plotOptions: {
									pie: {
										allowPointSelect: true,
										cursor: 'pointer',
										dataLabels: {
											enabled: true,
											//format: '<b>{point.name}</b>: {point.percentage:.1f} %',
											format: '<b>{point.name}</b>: <br>Entradas {point.y:,.0f}, ({point.percentage:.1f} %)',
											style: {
												color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
											}
										},
										showInLegend: true
									}
								},
								series: [{
									type: 'pie',
									name: 'Total Sesiones',
									data: [
										<?php foreach ($query as $registro): ?>	
										['<?php echo $registro->usuario_name.' '.$registro->usuario_ape; ?> - <br>(Perfil: <?php echo $registro->perfil_name; ?>)', <?php echo $registro->total; ?>],
										<?php endforeach; ?>
									]
								}],
							});
						});
					</script>
					<div id="container" style="min-width: 410px; height: 540px; max-width: 1600px; margin: 0 auto"></div>
		</div>
	  </div>
	</div>

<?php if ($this->session->userdata('perfil_id')<=2) {?>
<a href="javascript:imprSelec('seleccion')" class="btn btn-primary"><img src="<?php echo base_url('');?>assets/admin/img/print.png"/> Imprimir Resultado</a>
<?php }else{  }?>
</div>
<?php } ?>