<?php $this->load->view('admin/headers_check_login');?>

<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Actualizando Registro</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
					<?php echo my_validation_errors(validation_errors()); ?>
					<?php echo form_open('SubMenu_Perfil/update', array('class'=>'form-horizontal')); ?>
						<div class="box-body">
							<div class="form-group">
								<?php echo form_label('ID : ', 'id', array('class'=>'col-sm-2 control-label')); ?>
								<div class="col-sm-10">
									<span class="uneditable-input form-control"> <?php echo $registro->id; ?> </span>
									<?php echo form_hidden('id', $registro->id); ?>
								</div>
							</div>
						</div>
						
						<div class="box-body">
							<div class="form-group">
								<?php echo form_label('Sub Menú : ', 'submenu_id', array('class'=>'col-sm-2 control-label')); ?>
								<div class="col-sm-10">
									<?php $style='class="form-control"'; ?>
									<?php echo form_dropdown('submenu_id', $submenus, 0, $style); ?>
								</div>
							</div>
						</div>
			
						<div class="box-body">
							<div class="form-group">
								<?php echo form_label('Perfil : ', 'perfil_id', array('class'=>'col-sm-2 control-label')); ?>
								<div class="col-sm-10">
									<?php echo form_dropdown('perfil_id', $perfiles, 0, $style); ?>
								</div>
							</div>
						</div>
			
						<div class="box-body">
							<div class="form-group">
								<?php echo form_label('Creado : ', 'created', array('class'=>'col-sm-2 control-label')); ?>
								<div class="col-sm-10">
									<span class="uneditable-input form-control"> <?php echo date("d/m/Y - H:i:s", strtotime($registro->created)); ?> </span>
								</div>
							</div>
						</div>
			
						<div class="box-body">
							<div class="form-group">
								<?php echo form_label('Modificado : ', 'updated', array('class'=>'col-sm-2 control-label')); ?>
								<div class="col-sm-10">
									<span class="uneditable-input form-control"> <?php echo date("d/m/Y - H:i:s", strtotime($registro->updated)); ?> </span>
								</div>
							</div>
						</div>
			
					<hr>
					<!-- /.box-body -->
					<div class="box-footer">
						<?php echo form_button(array('type'=>'submit', 'content'=>'Aceptar', 'class'=>'btn btn-info')); ?>
						<?php echo anchor('SubMenu_Perfil/index', 'Cancelar', array('class'=>'btn btn-default')); ?><!--pull-left-->
						<?php if ($registro->id ==1) {?>
								<script type='text/javascript'>
									alertify.alert("Advertencia de Procesos","No puede eliminar este registro, es de existencia prioritaria!", function(ok){
										alertify.error('Puedes Continuar!');
									  }).set('label', 'De Acuerdo');
								</script>
						<?php }else{ ?>
							<?php echo anchor('SubMenu_Perfil/delete/'.$registro->id, 'Eliminar', array('class'=>'btn btn-warning pull-right', 'onClick'=>"return confirm('¿Está Seguro?')")); ?>
						<?php } ?>
					</div>
					<!-- /.box-footer -->
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>