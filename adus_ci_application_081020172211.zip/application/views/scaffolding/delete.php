<?php $this->load->view('admin/headers_check_login');?>

<p><?php echo $message; ?></p>
<p><div class="btn btn-default"><?php echo $no; ?></div>&nbsp;&nbsp;|&nbsp;&nbsp;<div class="btn btn-warning"><?php echo $yes; ?></div>

<?php

/* Fin del archivo delete.php */
/* Localizacion: ./application/views/scaffolding/delete.php */
