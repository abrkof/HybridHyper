<?php $this->load->view('admin/headers_check_login');?>
<p></p>
<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Creando Registro</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<?php echo form_open('scaffolding/insert'.$table_url); ?>
					
					<?php foreach($fields as $field): ?>
					
					<?php if ($field->primary_key == 1) continue; ?>
					<?php echo $field->name; echo ' '.$field->default; ?>
					
						
						<?php if ($field->type == 'blob'): ?>
							<div class="box-body">
								<div class="form-group">
									<?php //echo form_label('Nombre : ', 'name', array('class'=>'col-sm-2 control-label')); ?>
									<div class="col-sm-10">
										<textarea name="<?php echo $field->name; ?>" cols="60" rows="10"><?php echo form_prep($field->default); ?></textarea>
									</div>
								</div>
							</div>
						<?php else : ?>
							<div class="box-body">
								<div class="form-group">
									<?php //echo form_label('Nombre : ', 'name', array('class'=>'col-sm-2 control-label')); ?>
									<div class="col-sm-10">
										<input name="<?php echo $field->name; ?>" value="<?php echo form_prep($field->default); ?>" size="60"  class="form-control"/>
									</div>
								</div>
							</div>
						<?php endif; ?>
					<?php endforeach; ?>
					<hr>
					<!-- /.box-body -->
					<div class="box-footer">
						<input type="submit" class="btn btn-primary" value="Insertar" /><!--pull-left-->
						<?php echo anchor('scaffolding'.$table_url, ''.$this->lang->line('scaff_view_all'), array('class'=>'btn btn-default')); ?>
					</div>
					<!-- /.box-footer -->
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>

<?php

/* Fin del archivo add.php */
/* Localizacon: ./application/views/scaffolding/add.php */