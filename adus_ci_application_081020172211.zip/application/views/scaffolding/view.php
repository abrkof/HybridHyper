<?php $this->load->view('admin/headers_check_login');?>

<div class="x_panel">
  <div class="x_title">
	<h2> Consulta Realizada <small>|| mantenimiento de registros</small></h2>
	<ul class="nav navbar-right panel_toolbox">
	  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
	  </li>
	  <li class="dropdown">
		<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
	  </li>
	  <li><a class="close-link"><i class="fa fa-close"></i></a>
	  </li>
	</ul>
	<div class="clearfix"></div>
  </div>
  <div class="x_content">

<script language="Javascript">
	function imprSelec(impresion) {
	  var ficha = document.getElementById(impresion);
	  var ventimp = window.open(' ', 'popimpr');
	  //$("#seleccion").append('<img src="../img/coed2.png">');
	  ventimp.document.write( ficha.innerHTML );
	  ventimp.document.close();
	  ventimp.print( );
	  ventimp.close();
	}
</script>
<?php echo packstylejs('admin/js/jquery-1.3.2.min');?>
<script language="javascript">
	$(document).ready(function() {
		$("#botonExcel").click(function(event) {
			$("#datos_a_enviar").val( $("<div>").append( $("#Exportar_a_Excel").eq(0).clone()).html());
			$("#FormularioExportacion").submit();
		});
	});
</script>
<div id="seleccion" align="center">
	<div class="table-responsive">
				<table class="table table-striped jambo_table bulk_action" border="1" bordercolor="#CCCCCC" id="Exportar_a_Excel">
					<thead>
						<tr class="headings">
							<?php foreach($fields as $field): ?>
							<th><?php echo $field; ?></th>
							<?php endforeach; ?>
							<th width="35"><?php echo $this->lang->line('scaff_edit'); ?></th>
							<th width="45"><?php echo $this->lang->line('scaff_delete'); ?></th>
						</tr>
					</thead>
					
					<tbody>
					<?php foreach($query->result() as $row): ?>
					 <tr>
						<?php foreach($fields as $field): ?>	
						<td><div align="justify"> <?php echo form_prep($row->$field);?> </div></td>
						<?php endforeach; ?>
						<td>&nbsp;<?php echo anchor('scaffolding/edit/'.$row->$primary.$table_url, $this->lang->line('scaff_edit')); ?>&nbsp;</td>
						<td><?php echo anchor('scaffolding/delete/'.$row->$primary.$table_url, $this->lang->line('scaff_delete')); ?></td>
					 </tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php if ($this->session->userdata('perfil_id')<=2) {?>
<?php echo form_open('admin/export_to_excel', array('id'=>'FormularioExportacion', 'target'=>'_blank')); ?>
<p><span class="label label-info">Exportar a Excel!</span> <img src="<?php echo base_url('');?>assets/admin/img/xlsx.png" style="cursor:pointer" name="botonExcel" id="botonExcel"></p>
<input type="hidden" id="title" name="title" value="<?php echo $titulo ;?>">
<input type="hidden" id="datos_a_enviar" name="datos_a_enviar">
<?php echo form_close();?>
<a href="javascript:imprSelec('seleccion')" class="btn btn-primary"><img src="<?php echo base_url('');?>assets/admin/img/print.png"/> Imprimir Resultado</a>
<?php }else{  }?>
<!--<div><ul class="pagination"><li><?php //echo $this->pagination->create_links(); ?></li></ul></div>-->

<?php echo $paginate;

/* Fin del archivo view.php */
/* Localizacion: ./application/views/scaffolding/view.php */