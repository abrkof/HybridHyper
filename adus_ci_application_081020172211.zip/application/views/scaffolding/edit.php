<?php $this->load->view('admin/headers_check_login');?>

<p></p>

<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Creando Registro</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<?php echo form_open('scaffolding/update/'.$this->uri->segment(3).$table_url); ?>
				
					<?php foreach($fields as $field): ?>
					
					<?php if ($field->primary_key == 1) continue; ?>
					
						<?php echo  $field->name; ?>
						
						<?php if ($field->type == 'blob'): ?>
				
							<div class="box-body">
								<div class="form-group">
									<div class="col-sm-10">
										<textarea class="textarea" name="<?php echo $field->name;?>" cols="60" rows="10"><?php $f = $field->name; echo form_prep($query->$f); ?></textarea>
									</div>
								</div>
							</div>
					<?php else : ?>
							<div class="box-body">
								<div class="form-group">
									<div class="col-sm-10">
										<input class="form-control" value="<?php $f = $field->name; echo form_prep($query->$f); ?>" name="<?php echo $field->name; ?>" size="60" />
									</div>
								</div>
							</div>
					<?php endif; ?>
				
					<?php endforeach; ?>
			
					<hr>
					<!-- /.box-body -->
					<div class="box-footer">
						<input type="submit" class="btn btn-primary" value="Actualizar"/><!--pull-left-->
						<?php echo anchor('scaffolding'.$table_url, ''.$this->lang->line('scaff_view_all'), array('class'=>'btn btn-default'));?>
					</div>
					<!-- /.box-footer -->
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>

<?php echo form_close(); 

/* Fin del archivo edit.php */
/* Localizacion: ./application/views/scaffolding/edit.php */