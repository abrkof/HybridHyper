<?php $this->load->view('admin/headers_check_login');?>

<?php //$this->load->view('scaffolding/header');  ?>

<p><?php echo $this->lang->line('scaff_no_data'); ?></p>
<p><?php echo anchor('scaffolding/add'.$table_url, $this->lang->line('scaff_create_record')); ?></p>

<?php

/* Fin del archivo no_data.php */
/* Localizacion: ./application/views/scaffolding/no_data.php */