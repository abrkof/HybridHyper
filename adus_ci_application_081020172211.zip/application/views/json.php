<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<title>JSON PHP MYSQL</title>
		<script src="http://code.jquery.com/jquery-1.11.1.js"></script>
		<style>
		.grilla{
			background-color: #fff; 
			margin: 5px 0 10px 0; 
			border: solid 1px black; 
			border-collapse:collapse; 
		}
		.grilla td{ 
			padding: 2px; 
			border: solid 1px black; 
			color: #717171; 
			text-align:center;
		}
		.grilla th{ 
			padding: 4px 2px;
			background: gray repeat-x;
			border-left: solid 1px #525252; 
			font-size: 1 em; 
		}
		
		tr:nth-child(odd){
			background-color:#eee;
		}
		tr:nth-child(even){
			background-color:#fff;
		}
		</style>
	</head>
	<body>
		<header>
			<h1>Consultando Registros</h1>
		</header>
		<table class="grilla" id="tablajson">
			<thead>
				<th>Id</th>
				<th>Foto</th>
				<th>Usuario</th>
				<th>Perfil</th>
				<th>Ip</th>
				<th>Tiempo en Linea</th>
				<th>Latitude</th>
				<th>Longitude</th>
				<th>ZoneTime</th>
				<th>Mapa</th>
				<th>Hora Entrada</th>
			</thead>
			<tbody></tbody>
		</table>

		<script type="text/javascript">
		$(document).ready(function(){
		var data = "../JSONs/json.php";//open('GET', data, true)
		$("#tablajson tbody").html("");
		$.getJSON(data, function(users){
			$.each(users, function(i,users){
				var newRow =
				"<tr>"
					+"<td>"+users.id+"</td>"
					+"<td><img src='http://localhost/jcride/assets/images/usuario_image/"+users.foto+"' height='100px'></td>"
					+"<td>"+users.nombres+" "+users.apellidos+"</td>"
					+"<td>"+users.perfil+"</td>"
					+"<td>"+users.ip+"</td>"
					+"<td>"+users.date+"</td>"
					+"<td>"+users.lat+"</td>"
					+"<td>"+users.lng+"</td>"
					+"<td>"+users.zonetime+"</td>"
					+"<td>"+"<a href='http://localhost/jcride/Load_System/lat_lon/"+users.id+"'>Mapa</a>"+"</td>"
					+"<td>"+users.entrada+"</td>"
				+"</tr>";
				$(newRow).appendTo("#tablajson tbody");
				});
			});
		});
		</script>

	</body>
</html>