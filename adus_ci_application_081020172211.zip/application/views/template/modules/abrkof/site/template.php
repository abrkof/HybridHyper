<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<!--<link rel="shortcut icon" href="<?php echo base_url('assets/images/favicon.ico');?>" type="image/vnd.microsoft.icon"/>
<link rel="icon" type="image/png" href="/images/mifavicon.png"/>-->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('');?>assets/images/favicon.ico"/>
<meta name="description" content="Red colaborativa de educación y red juvenil para el aprendizaje y desarrollo cognitivo."/>
<meta name="keywords" content="ABRKOF, abrkof, mundo virtual, red social, documentación de ayuda academica, servicios informáticos, baul de archivos, herramienta de apoyo académico."/>
<meta name="generator" content="ADUS CI v1.1.2 (http://www.abrkof.com)"/>
<link rel="canonical" href="http://abrkof.com/"/>
<link rel="shortlink" href="http://abrkof.com/"/>
<meta name="twitter:card" content="summary_large_image"/>
<meta name="twitter:site" content="@abrkof"/>
<meta name="twitter:creator" content="@abrkof"/>
<meta name="twitter:url" content="http://www.abrkof.com/"/>
<meta name="twitter:title" content="ABRKOF El Salvador"/>
<meta name="twitter:image:src" content="https://scontent-yyz1-1.xx.fbcdn.net/v/t1.0-9/551632_10150983444286021_907012032_n.jpg?oh=12b90980420ce65083be0958e35ca514&oe=57DD2BF4"/>

<meta property="og:title" content="ABRKOF ::.A Vitual Place.::" />
<meta property="og:type" content="video.movie" />
<meta property="og:url" content="http://www.abrkof.com/" />
<meta property="og:image" content="<?php echo base_url('');?>assets/images/abrkof_logo_x.png" />

<title>ABRKOF ::.A Vitual Place.::</title>
<meta name="MobileOptimized" content="width">
<meta name="HandheldFriendly" content="true">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="cleartype" content="on">


<meta name="viewport" content="width=device-width, initial-scale=1">
<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic|Oswald:400,300,700' rel='stylesheet' type='text/css'>
		
    <!-- Bootstrap -->
    <?php //echo packstylecss('admin/dashboard/gentelella-master/vendors/bootstrap/dist/css/bootstrap.min');?>
    <!-- Font Awesome -->
    <?php //echo packstylecss('admin/dashboard/gentelella-master/vendors/font-awesome/css/font-awesome.min');?>
    <!-- NProgress -->
    <?php //echo packstylecss('admin/dashboard/gentelella-master/vendors/nprogress/nprogress');?>
    <!-- Custom Theme Style -->
    <?php echo packstylecss('modules/abrkof/site/Srikandi-v2/css/custom.min_modified');?>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css"><!---->

	<?php echo packstylecss('admin/css/bootstrap.min_modified');?>
	
	<?php echo packstylecss('alertifyjs/css/alertify.min');?>
	<?php echo packstylecss('alertifyjs/css/themes/default.min');?>
	<?php echo packstylejs('alertifyjs/alertify.min');?>

	<?php echo packstylecss('modules/abrkof/site/Srikandi-v2/css/font-awesome.min');?>
	<?php echo packstylecss('modules/abrkof/site/Srikandi-v2/css/bootstrap.min');?>
	<?php echo packstylecss('modules/abrkof/site/Srikandi-v2/css/bootstrap-reset');?>
    <?php echo packstylecss('modules/abrkof/site/Srikandi-v2/css/style');?>
	

	<?php echo css('reset');?>
	<?php echo css('style') ?>
	<?php echo packstylecss('themes/banner/banner');?>
    <!-- css for this page -->

	<script>
	var r = new Date();
	document.cookie = "zonetime="+r;
	</script>

	<?php $this->load->view('template/modules/abrkof/site/menu_asistente_2');?>
<style>
.li {color:#000; outline:none;}
.li:hover {color:#000;text-decoration:none;}
</style>
  </head>

  <body>
    <!-- start:wrapper -->
    <div id="wrapper">
        <div class="header-top">
            <!-- start:navbar -->
            <nav class="navbar navbar-inverse navbar-static-top" role="navigation" style="margin-bottom: 0">
                <div class="container">
                    <!-- start:navbar-header -->
                    <div class="navbar-header">
                        <a class="navbar-brand" href="#"><img src="<?php echo base_url('');?>assets/admin/images/abrkof_logo_x.png" height="100" width="100"> <strong>ABRKOF</strong><strong>.</strong></a>
                    </div>
                    <!-- end:navbar-header -->
					<!--<ul class="nav navbar-nav navbar-left top-menu">-->
                        <!-- start dropdown 1 -->
                        <!--<li class="dropdown">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <i class="fa fa-tasks" data-original-title="" title=""></i>
                                <span class="badge bg-success">6</span>
                            </a>
                            <ul class="dropdown-menu extended tasks-bar">
                                <div class="notify-arrow notify-arrow-green"></div>
                                <li>
                                    <p class="green">Tienes 6 tareas pendientes</p>
                                </li>
                                <li>
                                     <a href="#">
                                        <div class="task-info">
                                            <div class="desc">Dashboard v1.3</div>
                                            <div class="percent">40%</div>
                                        </div>
                                        <div class="progress progress-striped">
                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                                                <span class="sr-only">40% Complete (success)</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li class="external">
                                    <a href="#">Ver todas las tareas</a>
                                </li>
                            </ul>
                        </li>-->
                        <!-- end dropdown 1 -->
                        <!-- start dropdown 2 -->
                        <!--<li id="header_inbox_bar" class="dropdown">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <i class="fa fa-envelope-o" data-original-title="" title=""></i>
                                <span class="badge bg-important">5</span>
                            </a>
                            <ul class="dropdown-menu extended inbox">
                                <div class="notify-arrow notify-arrow-red"></div>
                                <li>
                                    <p class="red">Tienes 5 mensajes nuevos</p>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="photo"><img alt="avatar" src="./img/avatar-mini.jpg"></span>
                                            <span class="subject">
                                            <span class="from">Admin</span>
                                            <span class="time">Ahora</span>
                                        </span>
                                        <span class="message">
                                            Hello, Hello Hello Hello Hello.
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">Ver todos los mensajes</a>
                                </li>
                            </ul>
                        </li>-->
                        <!-- end dropdown 2 -->
                        <!-- start dropdown 3 -->
                        <!--<li id="header_notification_bar" class="dropdown">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <i class="fa fa-bell-o" data-original-title="" title=""></i>
                                <span class="badge bg-warning">7</span>
                            </a>
                            <ul class="dropdown-menu extended notification">
                                <div class="notify-arrow notify-arrow-yellow"></div>
                                <li>
                                    <p class="yellow">Tienes 7 notificaciones nuevas</p>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="label label-danger"><i class="fa fa-bolt" data-original-title="" title=""></i></span>
                                        Server #3 overloaded.
                                        <span class="small italic">34 mins</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="label label-warning"><i class="fa fa-bell" data-original-title="" title=""></i></span>
                                        Server #10 not respoding.
                                        <span class="small italic">1 Hours</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="label label-danger"><i class="fa fa-bolt" data-original-title="" title=""></i></span>
                                        Database overloaded 24%.
                                        <span class="small italic">4 hrs</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="label label-success"><i class="fa fa-plus" data-original-title="" title=""></i></span>
                                        New user registered.
                                        <span class="small italic">Just now</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="label label-info"><i class="fa fa-bullhorn" data-original-title="" title=""></i></span>
                                        Application error.
                                        <span class="small italic">10 mins</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">Ver todas las notificaciones</a>
                                </li>
                            </ul>
                        </li>-->
                        <!-- end dropdown 3 -->
                    <!--</ul>-->
                    <ul class="nav navbar-nav navbar-right top-menu">
                        <!-- user login dropdown start-->
                        <?php echo my_menu_common_user_site();?>
						<li class="dropdown">
							<a href="#myModal" data-toggle="modal" class="btn btn-drop" data-original-title="" title="">
								<div class="text-center">
									<i class="fa fa-globe" data-original-title="" title=""></i><br>
									Ubicación
								</div>
							</a>
						</li>
                    </ul>
                </div>
            </nav>
            <!-- end:navbar -->
        </div>
        <!-- start:header -->
        <div id="header">
            <div class="overlay">
                <nav class="navbar" role="navigation">
                    <div class="container">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="btn-block btn-drop navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                                <strong>MENU</strong>
                            </button>
                        </div>
                    
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse navbar-ex1-collapse">
                            <ul class="nav navbar-nav">
                                <!--<li class="active li">
                                    <a href="#" class="btn btn-drop" data-original-title="" title="">
                                        <div class="text-center">
                                            <i class="fa fa-dashboard fa-3x" data-original-title="" title=""></i><br>
                                            <?php //echo $titulo ;?>
                                        </div>
                                    </a>
                                </li>-->
								<?php echo my_hierarchic_menu_ppal_site(); ?>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </div>
                </nav>
            </div>
        </div>
        <!-- end:header -->

        <!-- start:main -->
        <div class="container">
            <div id="main">
                <!-- start:breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="<?php echo base_url('');?><?php echo $this->uri->segment(1);?>"><?php echo $this->uri->segment(1);?></a></li>
                    <li class="active"><?php echo $this->uri->segment(2);?></li>
					<li class="active"><?php echo $this->uri->segment(3);?></li>
                </ol>
                <!-- end:breadcrumb -->  

                <div class="row" id="nav-md">
                    <div class="col-lg-12 container body">
						<div class="main_container">
							<!-- start:content Aplication -->
							<section class="panel">
								<?php $this->load->view($contenido);?>
							</section>
							<?php $this->load->view('template/modules/abrkof/site/direccion');?>
							<!-- end:content Aplication -->
						</div>
                    </div>
                    <div class="col-lg-4">
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                    </div>
                    <div class="col-lg-8">
                    </div>
                </div>
            </div>
        </div>
        <!-- end:main -->

        <!-- start:footer -->
		<footer>
            <div class="container">
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                   <div class="footer-widget">
                        <h1 class="page-header"><strong>Navegación</strong><strong></strong></h1> 
                        <span class="divider-hr"></span>
                        <div class="row content-widget-footer">
                            <div class="col-sm-8">
								<div class="indent-left2">
									<ul class="list-1">
										<?php echo my_menu_site();?>
									</ul>
								</div>
                            </div>
                        </div>
                   </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="footer-widget">
                        <h1 class="page-header"><strong>Contáctanos</strong><strong></strong></h1>
                        <span class="divider-hr"></span>
                        <div class="row content-widget-footer">
                            <div class="col-sm-8">
								<dl class="contact">
									<dt>Col. Lizzy Josefina del Carmen. <br>Sonsonate <br>Frente a Terminal Nueva de Buses de Sonsonate.</dt>
								 </dl>
								<dd><span>Teléfonos:</span>(503) 76165028 / 71037139 (Whatsapp)</dd>
								<span>Email:</span><a class="link" href="http://www.cityguidesv.com/site/contacto/">abrkof@gmail.com</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="footer-widget">
                        <h1 class="page-header"><strong>Información Legal</strong></h1>
                        <span class="divider-hr"></span>
                        <div class="row content-widget-footer">
                            <div class="col-sm-8">
							<p">Propiedad de ABRKOF</p>
							<p>Copyright © 2003 - <?php echo date('Y');?>.</p>
							<p>Powered by<a href="http://www.abrkof.com/" style="text-decoration:none;" target="_blank" title="Carlos Abraham Ayala Herrera"> ADUS CI</a>.</p>
							<!--<p class="prev-indent-bot3 color-1">Powered by ABRKOF</p>
							<p>Friendly pages:<br><a href="http://www.cityguidesv.com/" target="_blank">CITYGUIDES</a>.</p>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<hr>
        <div><!--class="footer-bottom"-->
            <div class="container">
                <div class="footer-bottom-widget">
                    <div class="row">
                        <div class="col-sm-10">
                            <p><a href="http://www.twitter.com/abrkof" target="_blank" style="text-decoration:none;">ABRKOF</a> ©, 2003 - <?php echo date('Y');?></p>
                        </div>
                        <div class="col-sm-2">
                            <p class="footer-bottom-links">
                                 <a href="#" style="text-decoration:none;"><?php echo SYSNAME ;?></a> <strong></strong> <?php echo VERSION ;?><strong></strong>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end:footer -->

    </div>
    <!-- end:wrapper -->

    <!-- jQuery -->
    <?php echo packstylejs('admin/dashboard/gentelella-master/vendors/jquery/dist/jquery.min');?>
    <!-- Bootstrap -->
    <?php echo packstylejs('admin/dashboard/gentelella-master/vendors/bootstrap/dist/js/bootstrap.min');?>
    <!-- NProgress -->
    <?php //echo packstylejs('admin/dashboard/gentelella-master/vendors/nprogress/nprogress');?>
    <!-- FastClick -->
    <?php //echo packstylejs('admin/dashboard/gentelella-master/vendors/fastclick/lib/fastclick');?>
    <!-- Skycons -->
    <?php //echo packstylejs('admin/dashboard/gentelella-master/vendors/skycons/skycons');?>

    <!-- Custom Theme Scripts -->
    <?php //echo packstylejs('admin/dashboard/gentelella-master/build/js/custom.min');?>
	
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAAZnaZBXLqNBRXjd-82km_NO7GUItyKek"></script>

	<!-- start:javascript -->
	<!-- javascript default for all pages-->
	<?php echo packstylecss('modules/abrkof/site/Srikandi-v2/css/bootstrap.min');?>
	
  </body>
</html>
