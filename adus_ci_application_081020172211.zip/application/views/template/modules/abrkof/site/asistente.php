﻿<link href="<?php echo base_url('');?>assets/css/asistente.css" rel="stylesheet">
<div class="wholeShit">
	<div class="showVal"><br>
	<span class="showVal1"></span>
	</div>
	<div class="container">
	<div class="rightClick showing">
    <script>
    $(function() {
        $('#revista').click(function() {
            window.location = '<?php echo base_url().'revista/index'; ?>';
        });
    });
    </script>

    <script>
    $(function() {
        $('#clasificados').click(function() {
            window.location = 'http://www.cityguidesv.com/clasificados';
        });
    });
    </script>
	
    <script>
    $(function() {
        $('#contacto').click(function() {
            window.location = '<?php echo base_url().'contacto/index'; ?>';
        });
    });
    </script>

    <script>
    $(function() {
        $('#home').click(function() {
            window.location = '<?php echo base_url().'home/index'; ?>';
        });
    });
    </script>

<?php $this->load->view('template/menu_asistente_2');?>

	</div>
	</div>
</div>
<script>
document.oncontextmenu = function () {
    return false;
};
$(document).mousedown(function (e) {
    if (e.button === 2) {
        $('.rightClick').removeClass('showing');
        var n = $('.rightClick').clone(true);
        $('.rightClick').fadeOut(100);
        setTimeout(function () {
            $('.rightClick').css({
                top: e.pageY - 100,
                left: e.pageX - 100
            }).fadeIn(100).addClass('showing');
        }, 200);
    } else if (e.button === 0) {
        setTimeout(function () {
            $('.rightClick').removeClass('showing').fadeOut(100);
        }, 150);
    }
});
$('.rightClick .home').click(function () {
    $('.showVal1').text('');
});
$('.rightClick .revista').click(function () {
    $('.showVal1').text('');
});
$('.rightClick .clasificados').click(function () {
    $('.showVal1').text('');
});
$('.rightClick .contacto').click(function () {
    $('.showVal1').text('');
});
//@ sourceURL=pen.js
</script>