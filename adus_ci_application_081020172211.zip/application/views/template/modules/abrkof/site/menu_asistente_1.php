﻿<link href="<?php echo base_url('');?>assets/css/asistente.css" rel="stylesheet">
<div class="wholeShit">
	<div class="showVal"><br>
	<span class="showVal1"></span>
	</div>
	<div class="container">
	<div class="rightClick showing">
    <script>
    $(function() {
        $('#revista').click(function() {
            window.location = '<?php echo base_url().'revista/index'; ?>';
        });
    });
    </script>

    <script>
    $(function() {
        $('#clasificados').click(function() {
            window.location = 'http://www.cityguidesv.com/clasificados';
        });
    });
    </script>
	
    <script>
    $(function() {
        $('#contacto').click(function() {
            window.location = '<?php echo base_url().'contacto/index'; ?>';
        });
    });
    </script>

    <script>
    $(function() {
        $('#home').click(function() {
            window.location = '<?php echo base_url().'home/index'; ?>';
        });
    });
    </script>

<div class="buttons">
	<button id="revista" class="but revista"><img src="<?php echo base_url('assets/images/revista-3d.png')?>" width="30" height="30" title="revista"></button>
	<button id="clasificados" class="but clasificados"><img src="<?php echo base_url('assets/images/clasificados.png')?>" width="30" height="30" title="clasificados"></button>
	<button id="contacto" class="but contacto"><img src="<?php echo base_url('assets/images/correo.png')?>" width="30" height="30" title="contacto"></i></button>
</div>
<div id="home"><img src="<?php echo base_url('assets/images/unnamed.gif')?>"
style="
cursor: pointer;
margin-top: 50%;
border-radius: 0 0 100px 100px;
z-index: 100;
text-align: center;
font-size: 50px;
color: #fff; "></div>

	</div>
	</div>
</div>
<script>
document.oncontextmenu = function () {
    return false;
};
$(document).mousedown(function (e) {
    if (e.button === 2) {
        $('.rightClick').removeClass('showing');
        var n = $('.rightClick').clone(true);
        $('.rightClick').fadeOut(100);
        setTimeout(function () {
            $('.rightClick').css({
                top: e.pageY - 100,
                left: e.pageX - 100
            }).fadeIn(100).addClass('showing');
        }, 200);
    } else if (e.button === 0) {
        setTimeout(function () {
            $('.rightClick').removeClass('showing').fadeOut(100);
        }, 150);
    }
});
$('.rightClick .home').click(function () {
    $('.showVal1').text('');
});
$('.rightClick .revista').click(function () {
    $('.showVal1').text('');
});
$('.rightClick .clasificados').click(function () {
    $('.showVal1').text('');
});
$('.rightClick .contacto').click(function () {
    $('.showVal1').text('');
});
</script>