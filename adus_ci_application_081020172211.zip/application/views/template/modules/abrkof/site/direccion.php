﻿<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade" style="display: none;">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
				<h4 class="modal-title">Form Tittle</h4>
			</div>
			<div class="modal-body">
				<iframe src="https://www.google.com/maps/d/embed?mid=1ZzkuObDuPOiXnYaW-6NCwDsPgDk" width="640" height="480"></iframe>
			</div>
			<div align="center">
			<dd><span>Teléfono:</span> (503) 76165028 / 71037139</dd>
			<span>Email:</span><a class="link" href="<?php echo base_url('');?>contacto/index">abrkof@gmail.com</a>
			<div>
		</div>
	</div>
</div>
