﻿<?php echo css('asistente');?>
<div class="wholeShit">
	<div class="showVal"><br>
	<span class="showVal1"></span>
	</div>
	<div class="container">
	<div class="rightClick showing">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<div class="buttonx" id="home"><div id="home"><a href="<?php echo base_url().'home/index'; ?>" class="back"><img src="<?php echo base_url('assets/images/unnamed.gif')?>"
style="
cursor: pointer;
/*margin-top: 50%;
border-radius: 0 0 100px 100px;
z-index: 100;*/
text-align: center;
font-size: 50px;
color: #fff;
height:100%;" title="inicio"></a></div>
<div class="m2 menu-but buttonx" id="servicios"><a href="<?php echo base_url('');?>servicios/index" class="back"><img src="<?php echo base_url('');?>assets/images/service_clkd.png" style="height:100%; width:120%;" title="Servicios"></a></div>
<div class="m3 menu-but buttonx" id="articulos"><a href="<?php echo base_url('');?>articulo/index" class="back"><img src="<?php echo base_url('');?>assets/images/article_clkd.png" style="height:100%; width:120%;" title="Artículos"></a></div>
<div class="m4 menu-but buttonx" id="contacto"><a href="<?php echo base_url('');?>contacto/index" class="back"><img src="<?php echo base_url('');?>assets/images/contacto.jpeg" style="height:100%;" title="Contacto"></a></div>
<div class="m1 menu-but buttonx" id="haa"><a href="http://www.abrkof.org/av" class="back"><img src="<?php echo base_url('')?>assets/images/haa_clkd.png" height="140%" width="100%" title="Herramienta de apoyo académico"></a>
<div class="m1_1 menu-but" id="repositorio"><a href="http://www.abrkof.info" class="back"><img src="<?php echo base_url('');?>assets/images/repositorie_clkd.png" width="100%" height="100%" title="Repositorio de datos"></a></div></div>
</div>

	</div>
	</div>
</div>
<script>
document.oncontextmenu = function () {
    return false;
};
$(document).mousedown(function (e) {
    if (e.button === 2) {
        $('.rightClick').removeClass('showing');
        var n = $('.rightClick').clone(true);
        $('.rightClick').fadeOut(100);
        setTimeout(function () {
            $('.rightClick').css({
                top: e.pageY - 100,
                left: e.pageX - 100
            }).fadeIn(100).addClass('showing');
        }, 200);
    } else if (e.button === 0) {
        setTimeout(function () {
            $('.rightClick').removeClass('showing').fadeOut(100);
        }, 150);
    }
});
</script>