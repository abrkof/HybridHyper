﻿<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('');?>assets/admin/images/favicon.ico"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title> ADUS CI - ABRKOF </title>
	
    <!-- Bootstrap -->
    <?php echo packstylecss('admin/dashboard/gentelella-master/vendors/bootstrap/dist/css/bootstrap.min');?>
    <!-- Font Awesome -->
    <?php echo packstylecss('admin/dashboard/gentelella-master/vendors/font-awesome/css/font-awesome.min');?>
    <!-- NProgress -->
    <?php echo packstylecss('admin/dashboard/gentelella-master/vendors/nprogress/nprogress');?>
	<!-- Switchery -->
	<?php echo packstylecss('admin/dashboard/gentelella-master/vendors/switchery/dist/switchery.min');?>
    <!-- Custom Theme Style -->
    <?php echo packstylecss('admin/dashboard/gentelella-master/build/css/custom.min');?>
	<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">-->
	
	<?php echo css('scrollbar_abrkof');?>

	<?php echo packstylecss('admin/css/bootstrap.min_modified');?>
	<?php echo packstylecss('admin/css/scrib');?>
	
	<?php echo packstylecss('alertifyjs/css/alertify.min');?>
	<?php echo packstylecss('alertifyjs/css/themes/default.min');?>
	<?php echo packstylejs('alertifyjs/alertify.min');?>

	<script>
	var r = new Date();
	document.cookie = "zonetime="+r;
	</script>
	
	<script language="JavaScript">
	function toggleFullScreen() {
		if ((document.fullScreenElement && document.fullScreenElement !== null) ||
			(!document.mozFullScreen && !document.webkitIsFullScreen)) {
			if (document.documentElement.requestFullScreen) {
				document.documentElement.requestFullScreen();
			} else if (document.documentElement.mozRequestFullScreen) {
				document.documentElement.mozRequestFullScreen();
			} else if (document.documentElement.webkitRequestFullScreen) {
				document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
			}
		} else {
			if (document.cancelFullScreen) {
				document.cancelFullScreen();
			} else if (document.mozCancelFullScreen) {
				document.mozCancelFullScreen();
			} else if (document.webkitCancelFullScreen) {
				document.webkitCancelFullScreen();
			}
		}
	}
	
	$('.toggle-fullscreen').click(function() {
		toggleFullScreen();
	});
	</script>

  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="<?php echo base_url('');?>admin/acerca_de" class="site_title"><img src="<?php echo base_url('');?>assets/admin/images/abrkof_logo_x.png" height="30" width="30"> <span><b><?php echo SYSNAME ;?> </b><?php echo VERSION ;?></span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img src="<?php echo base_url('');?>assets/images/usuario_image/<?php echo get_instance()->session->userdata('usuario_image');?>" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Bienvenido,</span>
                <h2><?php echo $this->session->userdata('usuario_name').' '.$this->session->userdata('usuario_ape'); ?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br/>

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>
				<?php $state = $this->session->userdata('usuario_state');?>
				<i class="fa fa-circle <?php if($state == 1){echo 'text-success';}else{echo 'text-inactive';}?>"></i><?php echo $this->session->userdata('perfil_name');?> (<?php if($state == 1){echo 'Online';}else{echo 'Offline';}?>)
		  		</h3><br>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-dashboard" style="color:#ffffff; cursor:pointer"> </i>Menú Administrador</span></a></li>
				  <li><a><i class="fa fa-home"></i> Menú Público <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <?php echo my_menu_public(); ?>
                    </ul>
                  </li>
                  <li><a href="<?php echo base_url('');?>admin/acerca_de"><i class="fa fa-book"></i>Acerca De</a></li><!---->
                  <?php echo my_hierarchal_menu_ppal_system(); ?>
				  <?php //echo my_menu_ppal_app(); ?>
                </ul>
              </div>
              <div class="menu_section">
                <h3><i class="glyphicon glyphicon-globe" style="color:#ffffff;"> </i> Sitio Web (Visualización) </h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-laptop"></i> Menú Sitio (ABRKOF) <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <?php echo my_menu_site_system();?>
                    </ul>
                  </li>
                </ul>
              </div><!---->

            </div>
            <!-- /sidebar menu -->
			
            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen" href="javascript:void(0);" onclick="toggleFullScreen();">
			  <!--a data-toggle="tooltip" data-placement="top" title="FullScreen" href="javascript:void(0);" onclick="fullScreen('fullscreen.jsp');"-->
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo base_url('');?>admin/salir" onClick="return confirm('Cerrando Sesión, ¿Está Seguro?')">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
			
          </div>
        </div>

        <!-- top navigation -->
        <?php echo my_menu_common_user();?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
			<section class="content-header">
			  <h1>
				Dashboard
				<small>|| Control panel</small>
			  </h1>
			  <ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> <?php echo $this->uri->segment(1);?></a></li>
				<li class="active"><?php echo $this->uri->segment(2);?></li>
				<li class="active"><?php echo $this->uri->segment(3);?></li>
				<li class="active"><?php echo $this->uri->segment(4);?></li>
			  </ol>
			</section>
          <!-- /top tiles -->

			  <div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
				  <div class="dashboard_graph">
					<div class="row x_title">
					  <div class="col-md-6">
						<h3></h3>
					  </div>
					  <div class="col-md-6">
					  </div>
					</div>
					<script src="https://maps.googleapis.com/maps/api/js?v=3.11&key=AIzaSyAAZnaZBXLqNBRXjd-82km_NO7GUItyKek"></script>
					<?php $this->load->view($contenido);?>
					<div class="col-md-9 col-sm-9 col-xs-12">
					<?php $this->load->view('directly_messages/load_notify');?>
					<?php //$this->load->view('modules/abrkof/app/dashboard/online/load_latlon');?>
					</div>
				</div>
			  </div>
			  <br />

                <!-- End to do list -->
                
                <!-- start of weather widget -->
                <div class="col-md-6 col-sm-6 col-xs-12">
                </div>
                </div>

                </div>
                <!-- end of weather widget -->
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-left">
			<strong>Copyright &copy; 2016 - <?php echo date ('Y') ;?> <a href="http://www.abrkof.com" target="_blank">ABRKOF</a>.</strong> All rights reserved.
          </div>
          <div class="pull-right">
			 <b>Versión del Núcleo</b> <?php echo CI_VERSION ;?>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <?php echo packstylejs('admin/dashboard/gentelella-master/vendors/jquery/dist/jquery.min');?>
    <!-- Bootstrap -->
    <?php echo packstylejs('admin/dashboard/gentelella-master/vendors/bootstrap/dist/js/bootstrap.min');?>
    <!-- NProgress -->
    <?php echo packstylejs('admin/dashboard/gentelella-master/vendors/nprogress/nprogress');?>
	<!-- Switchery -->
	<?php echo packstylejs('admin/dashboard/gentelella-master/vendors/switchery/dist/switchery.min');?>
    <!-- FastClick -->
    <?php //echo packstylejs('admin/dashboard/gentelella-master/vendors/fastclick/lib/fastclick');?>
    <!-- Skycons -->
    <?php echo packstylejs('admin/dashboard/gentelella-master/vendors/skycons/skycons');?>

    <!-- Custom Theme Scripts -->
    <?php echo packstylejs('admin/dashboard/gentelella-master/build/js/custom.min');?>

	<?php 
	if ($this->uri->segment(2) == 'menu_orden' OR $this->uri->segment(2) == 'submenu_orden' OR 
		$this->uri->segment(3) == 'orden_servicio' OR $this->uri->segment(3) == 'orden_categoria' OR
		$this->uri->segment(2) == 'Menu_Site' OR $this->uri->segment(3) == 'orden_slider' OR
		$this->uri->segment(2) == 'SubMenu_Site'){
		echo packstylejs('admin/js/jquery_ordenar');
		echo packstylejs('admin/js/jquery-ui-1.8.12.custom.min');
	}
	?>

	<?php echo packstylejs('analitycs/Highcharts-4.1.9/js/highcharts');?>
	<?php echo packstylejs('analitycs/Highcharts-4.1.9/js/modules/exporting');?>
	
	<!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAAZnaZBXLqNBRXjd-82km_NO7GUItyKek"></script>-->

	<?php
	$count_session = $_SESSION['count_session']++;
	if ($count_session ==1){?>
		<?php echo packstylecss('admin/load-dashboard/css/style');?>
		  <!-- Start Page Loading -->
		  <div id="loader-wrapper">
			  <div id="loader"></div>        
			  <div class="loader-section section-left"></div>
			  <div class="loader-section section-right"></div>
		  </div>
		  <!-- End Page Loading -->
		<!--<audio src="<?php //echo base_url('');?>assets/audio/Trans_SuperMode.mp3" autoplay="true">--><!-- loop="true" -->
		<?php echo packstylejs('admin/load-dashboard/js/plugins');?>	
	<?php } ?>
		
	<?php echo js('tooltip');?>

  </body>
</html>
