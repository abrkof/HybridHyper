﻿<?php $this->load->view('admin/headers_check_login');?>

	<!--<h1>Google Maps Geoposicionamiento</h1> <legend> Visualizando Registro </legend>-->

<div class="page-header">
	<h1> Geoposicionamiento <small>|| Visualizando Registro </small> </h1>
</div>

<?php echo packstylecss('geolocalizacion/css/geo1');?>
<?php echo packstylejs('admin/js/jquery.min');?>
<script src='https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false'></script>
<?php echo packstylejs('geolocalizacion/js/geo1');?>

<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-6"></div>
	<div class="col-md-6 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Visualizando Geolocalización</h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a></li>
					<li><a class="close-link"><i class="fa fa-close"></i></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<div class="form-group">
					<?php echo form_label('ID : ', 'id', array('class'=>'col-sm-2 control-label')); ?>
					<div class="col-sm-10">
						<span class="uneditable-input form-control"> <?php echo $registro->id; ?> </span>
						<?php echo form_hidden('id', $registro->id); ?>
					</div>
				</div>
				<hr>
				<a href="#" class="map-toggle arrow">Click para visualizar mapa</a>
				
				<div id="map">
				  <div class="marker" data-lat="<?php echo $registro->Latitude;?>" data-lng="<?php echo $registro->Longitude;?>" itemprop="map"></div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
function goBack() {
    window.history.back();
}
</script>
	<div class="form-actions">
		<?php echo anchor('Sesiones_Temp/index', 'Regresar', array('class'=>'btn btn-primary')); ?>
		<?php //echo anchor('sesiones_temp/index', 'Regresar', array('class'=>'btn btn-primary', 'onclick'=>'goBack()')); ?>
	</div>
	</html>