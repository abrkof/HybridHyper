﻿<?php $this->load->view('admin/headers_check_login');?>

<style type="text/css">
<!--
.Estilo1 {color: #FF3333}
-->
</style>

<div class="x_panel">
  <div class="x_title">
	<h2> Lista de usuarios en linea <small>|| Lista de Registros</small></h2>
	<ul class="nav navbar-right panel_toolbox">
	  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
	  </li>
	  <li class="dropdown">
		<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
	  </li>
	  <li><a class="close-link"><i class="fa fa-close"></i></a>
	  </li>
	</ul>
	<div class="clearfix"></div>
  </div>
  <div class="x_content">

<div style="width:400px;">
<button type="button" class="btn btn-primary btn-lrg ajax" title="Ajax Request">
	<i class="fa fa-spin fa-refresh"></i>
	<?php echo anchor('Sesiones_Temp/index/', 'Refrescar', array('style'=>'color:#FFFFFF;')); ?>
</button>
</div>

<?php echo form_open('Sesiones_Temp/validar', array('class'=>'sidebar-form')); ?>
<div class="title_right">
	<div class="col-md-3 col-sm-8 col-xs-12 form-group pull-left top_search">
		<div class="input-group">
			<?php echo form_input(array('type'=>'text', 'name'=>'buscar', 'id'=>'buscar', 'placeholder'=>'Buscar Usuario - Perfil...', 'class'=>'form-control', 'required'=>'true')); ?>
			<span class="input-group-btn">
				<?php echo form_button(array('type'=>'submit', 'content'=>'Buscar', 'class'=>'btn btn-default', 'type'=>'submit')); ?>
			</span>
		</div>
	</div>
</div>
<?php echo form_close(); ?>

<?php if(!$query) { ?>
<div class="col-xs-3">
	<div class="alert alert-error">
	  <button type="button" class="close" data-dismiss="alert">&times;</button>
	  <strong>Alerta!</strong> No hay nada que mostrar.!!!
	</div>
</div>
<?php }else{ ?>

<script language="Javascript">
	function imprSelec(impresion) {
	  var ficha = document.getElementById(impresion);
	  var ventimp = window.open(' ', 'popimpr');
	  //$("#seleccion").append('<img src="../img/coed2.png">');
	  ventimp.document.write( ficha.innerHTML );
	  ventimp.document.close();
	  ventimp.print( );
	  ventimp.close();
	}
</script>
<?php echo packstylejs('admin/js/jquery-1.3.2.min');?>
<script language="javascript">
	$(document).ready(function() {
		$("#botonExcel").click(function(event) {
			$("#datos_a_enviar").val( $("<div>").append( $("#Exportar_a_Excel").eq(0).clone()).html());
			$("#FormularioExportacion").submit();
		});
	});
</script>
<div id="seleccion" align="center">
	<div class="table-responsive">
			<table class="table table-striped jambo_table bulk_action" border="1" bordercolor="#CCCCCC" id="Exportar_a_Excel">
				<thead>
					<tr class="headings">
						<th> ID </th>
						<th> Imagen </th>
						<th> Usuario </th>
						<th> Perfil </th>
						<th> Tiempo enLinea </th>
						<th> Ip </th>
						<th> Latitud </th>
						<th> Longitud </th>
						<th> Ver Mapa </th>
						<!--<th> Zona Horaria </th>-->
						<th> Entrada </th>
					</tr>
				</thead>
			
				<tbody>
					<?php foreach ($query as $registro): ?>
					<?php 
					  $now=time() - $registro->Date;
					 if ($now<60) $now=$now." segundos.";
					
					else if ($now>60 AND $now<3600){
						$now_minute= intval($now/60);
						$now_second=$now%60;
						$now=$now_minute." minutos, ".$now_second. " segundos.";
					}
					else if ($now>3600 AND $now<86400){
						$now_hour=intval($now/3600);
						$now_minute=intval(($now%3600)/60);
						$now_second=$now%60;
						$now=$now_hour." horas, ".$now_minute. " minutos, ".$now_second." segundos.";
					}
					else if ($now>86400 AND $now<604800)
					$now='Hace '.intval($now/86400)." dia(s).";
					else if ($now>604800 AND $now<2592000)
					$now="Hace mas de ".intval($now/604800)." semana(s).";
					else if ($now>2592000 AND $now<31104000)
					$now="Hace mas de ".intval($now/2592000)." mes(es).";
					else if ($now>31104000)
					$now="Hace mas de 1 año.";
					?>
					<tr>
						<td> <span class="Estilo3"><?php echo $registro->id ;?></span> </td>
						<td> <a href='#' onClick=window.open('<?php echo base_url('assets/images/usuario_image/'.$registro->usuario_image) ;?>','new','width=430,height=250,status=no,resizable=no,top=300,left=500,dependent=yes,alwaysRaised=yes')><!---->
						<img src="<?php echo base_url('assets/images/usuario_image/'.$registro->usuario_image) ;?>" width="116" height="119" class="img-rounded"></a><!--data-action="zoom"--><div align="right"></div>
						</span> </td>
						<td width="300px"> <span class="Estilo3"><?php echo $registro->usuario_name.' '.$registro->usuario_ape ;?></span> </td>
						<td> <span class="Estilo3"><?php echo $registro->perfil_name ;?></span> </td>
						<td width="300px"> <span class="Estilo3"><?php echo $now ;?></span> </td>
						<td> <span class="Estilo3"><?php echo $registro->ip ;?></span> 
						<form action="http://www.cual-es-mi-ip.net/geolocalizar-ip-mapa" method="post" target="_blank">            
							<input type="hidden" class="form-control" name="direccion-ip" id="direccion-ip" placeholder="Introduzca una dirección IP" value="<?php echo $registro->ip ;?>">
								<span class="input-group-btn">
									<button class="btn btn-primary" type="submit"><i class="glyphicon glyphicon-search"></i>GeoLocalizar</button>
								</span>
						</form>
						</td>
						<td> <span class="Estilo3"><?php echo $registro->Latitude ;?></span> </td>
						<td> <span class="Estilo3"><?php echo $registro->Longitude ;?></span> </td>
						<td> <span class="Estilo3"><?php echo anchor('Sesiones_Temp/lat_lon_temp/'.$registro->id, '<i class="icon-globe"></i>'); ?></span> </td>
						<!--<td> <span class="Estilo3"><?php //echo $registro->ZoneTime ;?></span> </td>-->
						<td> <span class="Estilo3"><?php echo $registro->entrada ;?></span> </td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	  </div>
	</div>
</div>
<?php if ($this->session->userdata('perfil_id')<=2) {?>
<?php echo form_open('admin/export_to_excel', array('id'=>'FormularioExportacion', 'target'=>'_blank')); ?>
<p><span class="label label-info">Exportar a Excel!</span> <img src="<?php echo base_url('');?>assets/admin/img/xlsx.png" style="cursor:pointer" name="botonExcel" id="botonExcel"></p>
<input type="hidden" id="title" name="title" value="<?php echo $titulo ;?>">
<input type="hidden" id="datos_a_enviar" name="datos_a_enviar">
<?php echo form_close();?>
<a href="javascript:imprSelec('seleccion')" class="btn btn-primary"><img src="<?php echo base_url('');?>assets/admin/img/print.png"/> Imprimir Resultado</a>
<?php }else{  }?>
<?php } ?>
<div><ul class="pagination"><li><?php echo $this->pagination->create_links(); ?></li></ul></div>