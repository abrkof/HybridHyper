﻿<table class="table table-bordered table-hover" border="1" bordercolor="#CCCCCC" id="Exportar_a_Excel">
	<thead>
		<tr>
			<th> ID </th>
			<th> Imagen </th>
			<th> Usuario </th>
			<th> Perfil </th>
			<th> Tiempo enLinea </th>
			<th> Ip </th>
			<th> Latitud </th>
			<th> Longitud </th>
			<th> Ver Mapa </th>
			<!--<th> Zona Horaria </th>-->
			<th> Entrada </th>
		</tr>
	</thead>

	<tbody>
		<?php foreach ($query as $registro): ?>
		<?php 
		  $now=time() - $registro->Date;
		 if ($now<60) $now=$now." segundos.";
		
		else if ($now>60 AND $now<3600){
			$now_minute= intval($now/60);
			$now_second=$now%60;
			$now=$now_minute." minutos, ".$now_second. " segundos.";
		}
		else if ($now>3600 AND $now<86400){
			$now_hour=intval($now/3600);
			$now_minute=intval(($now%3600)/60);
			$now_second=$now%60;
			$now=$now_hour." horas, ".$now_minute. " minutos, ".$now_second." segundos.";
		}
		else if ($now>86400 AND $now<604800)
		$now='Hace '.intval($now/86400)." dia(s).";
		else if ($now>604800 AND $now<2592000)
		$now="Hace mas de ".intval($now/604800)." semana(s).";
		else if ($now>2592000 AND $now<31104000)
		$now="Hace mas de ".intval($now/2592000)." mes(es).";
		else if ($now>31104000)
		$now="Hace mas de 1 año.";
		?>
		<tr>
			<td> <span class="Estilo3"><?php echo $registro->id ;?></span> </td>
			<td> <a href='#' onClick=window.open('<?php echo base_url('assets/images/usuario_image/'.$registro->usuario_image) ;?>','new','width=430,height=250,status=no,resizable=no,top=300,left=500,dependent=yes,alwaysRaised=yes')><!---->
			<img src="<?php echo base_url('assets/images/usuario_image/'.$registro->usuario_image) ;?>" width="116" height="119" class="img-rounded"></a><!--data-action="zoom"--><div align="right"></div>
			</span> </td>
			<td width="300px"> <span class="Estilo3"><?php echo $registro->usuario_name.' '.$registro->usuario_ape ;?></span> </td>
			<td> <span class="Estilo3"><?php echo $registro->perfil_name ;?></span> </td>
			<td width="300px"> <span class="Estilo3"><?php echo $now ;?></span> </td>
			<td> <span class="Estilo3"><?php echo $registro->ip ;?></span> 
			<form action="http://www.cual-es-mi-ip.net/geolocalizar-ip-mapa" method="post" target="_blank">            
				<input type="hidden" class="form-control" name="direccion-ip" id="direccion-ip" placeholder="Introduzca una dirección IP" value="<?php echo $registro->ip ;?>">
					<span class="input-group-btn">
						<button class="btn btn-primary" type="submit"><i class="glyphicon glyphicon-search"></i>GeoLocalizar</button>
					</span>
			</form>
			</td>
			<td> <span class="Estilo3"><?php echo $registro->Latitude ;?></span> </td>
			<td> <span class="Estilo3"><?php echo $registro->Longitude ;?></span> </td>
			<td> <span class="Estilo3"><?php echo anchor('Sesiones_Temp/lat_lon_temp/'.$registro->id, '<i class="icon-globe"></i>'); ?></span> </td>
			<!--<td> <span class="Estilo3"><?php //echo $registro->ZoneTime ;?></span> </td>-->
			<td> <span class="Estilo3"><?php echo $registro->entrada ;?></span> </td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>