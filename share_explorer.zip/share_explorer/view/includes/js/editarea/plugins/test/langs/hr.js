editArea.add_lang("hr",{
test_select: "Odaberi tag",
test_but: "Probna tipka"
});
