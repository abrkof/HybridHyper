<?php

/*
AjaxExplorer Copyright (C) 2007-2013 S.M.Sid Software

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. Head to
GNU site http://www.gnu.org/licenses/ for license copy.
*/

function aeData($strData, $strCase = '') {	
	switch($strCase) {
		case 'file':
			return str_replace(array('\\', '/', '"', '*', ':', '?', '<', '>', '|'), '', strtolower($strData));
		default:
			return $strData;
	}
}

function aePost($strName, $strData = '', $strCase = '') {
	return aeData(isset($_POST[$strName])? $_POST[$strName]:$strData, $strCase);
}

if(isset($_REQUEST['intExit'])) {
	if(unlink(__FILE__)) {
		header('Location: .');
	}
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	$strFilePath = str_replace('\\', '/', __FILE__);
	$strFilePath = str_replace('/'. basename($strFilePath), '', $strFilePath);

	$strUserName = aePost('fldUserName', '', 'file');
	$strUserView = aePost('fldUserView', '', 'file');

	$arrFile = array('', 'myprofile', 'recyclebin');
	$dbsConf = $strFilePath .'/ae.db/conf.ini';
	$dbsUser = $strFilePath .'/ae.db/user.ini';

	foreach($arrFile as $strFile) {
		$strFile = $strFilePath .'/ae.user/'. $strUserName .'/'. $strFile;
		if(!file_exists($strFile)) {
			mkdir($strFile);
		}
	}

	if(($objFile = fopen($strFilePath .'/ae.user/'. $strUserName .'/myprofile/terminal', 'w+'))) {
		fwrite($objFile, '');
		fclose($objFile);
	}

	if(($objConf = fopen($dbsConf, 'w+'))) {
		fwrite($objConf, "1\t0\t0\t0\t0\t30\t100\t5000\t2000\t". aePost('fldConfFilePath') ."\t". aePost('fldConfTimeZone') ."\t". basename($strFilePath) .",ae.xml\t7z,doc,docx,pdf,ppt,pptx,rar,xls,xlsx,zip\tcss,js,htaccess,htm,html,ini,log,php,sql,txt,xml\tphp,php2,php3,php4,php5,phtml,pwml,inc,asp,aspx,ascx,jsp,cfm,cfc,pl,bat,exe,com,dll,vbs,js,reg,cgi,htaccess\t");
		fclose($objConf);
	}

	if(($objUser = fopen($dbsUser, 'w+'))) {
		fwrite($objUser, "guest\t\t\t0\t". $strUserView ."\t\n". $strUserName ."\t". aePost('fldUserPass') ."\t\t31\t". $strUserView ."\t");
		fclose($objUser);
	}

	if(file_exists($dbsConf) && file_exists($dbsUser) && unlink(__FILE__)) {
		if(isset($_SESSION[$_SERVER['REMOTE_ADDR'] . $_SERVER['DOCUMENT_ROOT']])) {
			session_destroy();
		}

		session_start();
		$_SESSION[$_SERVER['REMOTE_ADDR'] . $_SERVER['DOCUMENT_ROOT']] = array('sesCurrPath' => '', 'sesCurrTime' => 0, 'sesUserPKey' => 1, 'sesPostPath' => '');

		header('Location: .');
	}
}

$strHref = 'http'. (isset($_SERVER['HTTPS'])? 's':'') .'://'. $_SERVER['SERVER_NAME'] . ($_SERVER['SERVER_PORT'] != ':'. $_SERVER['SERVER_PORT']? '':'') . str_replace('/'. basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);

$strHrefIncludes = $strHref .'/view/includes';
$strHrefTemplate = $strHref .'/view/ae.winxp';

$arrFile = explode('/', str_replace('\\', '/', __FILE__));
$strFile = '';
$strSel1 = '';
$intHref = count($arrFile) - count(explode('/', $_SERVER['PHP_SELF']));

for($intLoop = 0; $intLoop < count($arrFile)-2; $intLoop++) {
	$strFile = $strFile . ($intLoop? '/':'') . $arrFile[$intLoop];
	$strSel1 = $intLoop >= $intHref? '<option value="'. $strFile .'" style="background-color:#'. (is_writable($strFile)? '99FF99':'FF9999') .';"> '. $strFile .'</option>'. $strSel1:'';
}

$strPath = $strFile;
$strSel2 = '';

if($objFile = opendir('view/')) {
	while($strFile = readdir($objFile)) {
		if(strpos($strFile, 'ae.') !== false) {
			$strSel2 .= '<option value="'. substr($strFile, 3) .'"> '. substr($strFile, 3) .'</option>';
		}
	}

	closedir($objFile);
}

?><!DOCTYPE html>
<html lang='en' dir="ltr">
	<head>
		<title>AjaxExplorer</title>

		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="author" content="SMSID Software" />
		<meta name="keywords" content="ajax,explorer,file,manager" />
		<meta name="description" content="Ajax File Manager - AjaxExplorer" />

		<link rel="SHORTCUT ICON" href="<?php echo $strHrefTemplate; ?>/css/images/logo_ae.gif" />
		<link rel="STYLESHEET" href="<?php echo $strHrefTemplate; ?>/css/style.css" type="text/css" />

		<script src="<?php echo $strHrefIncludes; ?>/js/ae.base.js" type="text/javascript"></script>
		<script src="<?php echo $strHrefIncludes; ?>/js/md5.js" type="text/javascript"></script>
		<script type="text/javascript">
			/*<![CDATA[*/
			var objMenuTabs;

			function userCancel() {
				if(!confirm('Previous installation of AjaxExplorer detected!\n\nWould you want to continue with this installation which will rewrite your existing database,\nor click \'Cancel\' to allow the AjaxExplorer to skip and delete this installer?')) {
					location.href += '?intExit=1';
				}
			}

			function userInstall() {
				if(get('fldUserName').value) {
					if(get('fldUserPass').value.length > 7) {
						if(get('fldUserPass').value == get('fldTestPass').value) {
							get('fldUserPass').value = MD5(get('fldUserPass').value);
							get('aeInstall').submit();
						}
						else alert('Error: Your password does not match');
					}
					else alert('Error: Your password must be at least 8 characters long');
				}
				else alert('Error: Please key in your username');
			}

			function userToggle(intTabs) {
				var objThis = get('tab'+ intTabs);

				if(intTabs > 1 && get('fldConfFilePath').selectedIndex == -1) {
					intTabs = 1;
					alert("Please ensure below requirements are meet:\n- PHP version 4.0 or higher\n- Adjust your folder writable permissions\n- Make sure AjaxExplorer folder are not place on www root folder\n\nPress F5 once you did the required changes");
				}

				if(intTabs == 3 && !confirm("By clicking 'OK' you have read & understand the license.")) {
					intTabs = 2;
				}

				if(objMenuTabs != undefined) {
					objMenuTabs.className = '';
				}

				objMenuTabs = objThis;
				objThis.className = 'active';

				for(var intLoop = 1; intLoop < 4; intLoop++) {
					setDisplay('Btn'+ intLoop, intLoop == intTabs? 1:0);
					setDisplay('Tab'+ intLoop, intLoop == intTabs? 1:0);
				}
			}

			window.onload = function() {
				get('fldConfFilePath').select();
				userToggle(1);
			}
			/*]]>*/ 
		</script>
	</head>
	<body>
		<div id="aeSystMenu" style="display:block;">
			<form id="aeInstall" class="page" style="display:block;" method="POST" enctype="application/x-www-form-urlencoded">
				<div class="head">Setup AjaxExplorer</div>
				<div class="menu"><span id="tab1" class="href" onclick="userToggle(1)">Requirement</span><span id="tab2" class="href" onclick="userToggle(2)">License</span><span id="tab3" class="href" onclick="userToggle(3)">Install</span></div>
				<div class="area">
					<div id="Tab1">
						<div>In order for the system to work, do ensure below requirements are meet.</div>
						<fieldset><legend>System Requirement</legend>
							<span class="alignright"><img alt="" src="<?php echo $strHrefTemplate; ?>/css/images/icon/<?php echo phpversion()>=5? 'yes':'no'; ?>.gif" /></span>PHP 5.0 or latest<br />
							<span class="alignright"><img alt="" src="<?php echo $strHrefTemplate; ?>/css/images/icon/<?php echo isset($_SERVER['HTACCESS'])? 'yes':'no'; ?>.gif" /></span>HTAccess permission<br />
							<span class="alignright"><img alt="" src="<?php echo $strHrefTemplate; ?>/css/images/icon/<?php echo is_writable('./ae.db/') && is_writable('./ae.log/') && is_writable('./ae.user/')? 'yes':'no'; ?>.gif" /></span>Readable & writable permission<br />
						</fieldset>
						<div>The starting directory which the system will begin explore.</div>
						<fieldset><legend>Starting Directory</legend>
							<?php if($strSel1) { ?><input id="fldConfFilePath" name="fldConfFilePath" type="text" class="input4" value="<?php echo $strPath; ?>" /><select class="input2" onchange="get('fldConfFilePath').value = this.value;this.selectedIndex = 0;"><option></option><?php echo $strSel1; ?></select><?php } else echo '<div class="red">AjaxExplorer cannot be place on www root folder!</div>'; ?>
						</fieldset>
						<fieldset><legend>Time Zone</legend>
							<select id="fldConfTimeZone" name="fldConfTimeZone" class="input2" />
								<option></option>
								<option value="Pacific/Midway">(GMT-11:00) Midway Island</option>
								<option value="US/Samoa">(GMT-11:00) Samoa</option>
								<option value="US/Hawaii">(GMT-10:00) Hawaii</option>
								<option value="US/Alaska">(GMT-09:00) Alaska</option>
								<option value="US/Pacific">(GMT-08:00) Pacific Time (US &amp; Canada)</option>
								<option value="America/Tijuana">(GMT-08:00) Tijuana</option>
								<option value="US/Arizona">(GMT-07:00) Arizona</option>
								<option value="US/Mountain">(GMT-07:00) Mountain Time (US &amp; Canada)</option>
								<option value="America/Chihuahua">(GMT-07:00) Chihuahua</option>
								<option value="America/Mazatlan">(GMT-07:00) Mazatlan</option>
								<option value="America/Mexico_City">(GMT-06:00) Mexico City</option>
								<option value="America/Monterrey">(GMT-06:00) Monterrey</option>
								<option value="Canada/Saskatchewan">(GMT-06:00) Saskatchewan</option>
								<option value="US/Central">(GMT-06:00) Central Time (US &amp; Canada)</option>
								<option value="US/Eastern">(GMT-05:00) Eastern Time (US &amp; Canada)</option>
								<option value="US/East-Indiana">(GMT-05:00) Indiana (East)</option>
								<option value="America/Bogota">(GMT-05:00) Bogota</option>
								<option value="America/Lima">(GMT-05:00) Lima</option>
								<option value="America/Caracas">(GMT-04:30) Caracas</option>
								<option value="Canada/Atlantic">(GMT-04:00) Atlantic Time (Canada)</option>
								<option value="America/La_Paz">(GMT-04:00) La Paz</option>
								<option value="America/Santiago">(GMT-04:00) Santiago</option>
								<option value="Canada/Newfoundland">(GMT-03:30) Newfoundland</option>
								<option value="America/Buenos_Aires">(GMT-03:00) Buenos Aires</option>
								<option value="Greenland">(GMT-03:00) Greenland</option>
								<option value="Atlantic/Stanley">(GMT-02:00) Stanley</option>
								<option value="Atlantic/Azores">(GMT-01:00) Azores</option>
								<option value="Atlantic/Cape_Verde">(GMT-01:00) Cape Verde Is.</option>
								<option value="Africa/Casablanca">(GMT) Casablanca</option>
								<option value="Europe/Dublin">(GMT) Dublin</option>
								<option value="Europe/Lisbon">(GMT) Lisbon</option>
								<option value="Europe/London">(GMT) London</option>
								<option value="Africa/Monrovia">(GMT) Monrovia</option>
								<option value="Europe/Amsterdam">(GMT+01:00) Amsterdam</option>
								<option value="Europe/Belgrade">(GMT+01:00) Belgrade</option>
								<option value="Europe/Berlin">(GMT+01:00) Berlin</option>
								<option value="Europe/Bratislava">(GMT+01:00) Bratislava</option>
								<option value="Europe/Brussels">(GMT+01:00) Brussels</option>
								<option value="Europe/Budapest">(GMT+01:00) Budapest</option>
								<option value="Europe/Copenhagen">(GMT+01:00) Copenhagen</option>
								<option value="Europe/Ljubljana">(GMT+01:00) Ljubljana</option>
								<option value="Europe/Madrid">(GMT+01:00) Madrid</option>
								<option value="Europe/Paris">(GMT+01:00) Paris</option>
								<option value="Europe/Prague">(GMT+01:00) Prague</option>
								<option value="Europe/Rome">(GMT+01:00) Rome</option>
								<option value="Europe/Sarajevo">(GMT+01:00) Sarajevo</option>
								<option value="Europe/Skopje">(GMT+01:00) Skopje</option>
								<option value="Europe/Stockholm">(GMT+01:00) Stockholm</option>
								<option value="Europe/Vienna">(GMT+01:00) Vienna</option>
								<option value="Europe/Warsaw">(GMT+01:00) Warsaw</option>
								<option value="Europe/Zagreb">(GMT+01:00) Zagreb</option>
								<option value="Europe/Athens">(GMT+02:00) Athens</option>
								<option value="Europe/Bucharest">(GMT+02:00) Bucharest</option>
								<option value="Africa/Cairo">(GMT+02:00) Cairo</option>
								<option value="Africa/Harare">(GMT+02:00) Harare</option>
								<option value="Europe/Helsinki">(GMT+02:00) Helsinki</option>
								<option value="Europe/Istanbul">(GMT+02:00) Istanbul</option>
								<option value="Asia/Jerusalem">(GMT+02:00) Jerusalem</option>
								<option value="Europe/Kiev">(GMT+02:00) Kyiv</option>
								<option value="Europe/Minsk">(GMT+02:00) Minsk</option>
								<option value="Europe/Riga">(GMT+02:00) Riga</option>
								<option value="Europe/Sofia">(GMT+02:00) Sofia</option>
								<option value="Europe/Tallinn">(GMT+02:00) Tallinn</option>
								<option value="Europe/Vilnius">(GMT+02:00) Vilnius</option>
								<option value="Asia/Baghdad">(GMT+03:00) Baghdad</option>
								<option value="Asia/Kuwait">(GMT+03:00) Kuwait</option>
								<option value="Africa/Nairobi">(GMT+03:00) Nairobi</option>
								<option value="Asia/Riyadh">(GMT+03:00) Riyadh</option>
								<option value="Asia/Tehran">(GMT+03:30) Tehran</option>
								<option value="Europe/Moscow">(GMT+04:00) Moscow</option>
								<option value="Asia/Baku">(GMT+04:00) Baku</option>
								<option value="Europe/Volgograd">(GMT+04:00) Volgograd</option>
								<option value="Asia/Muscat">(GMT+04:00) Muscat</option>
								<option value="Asia/Tbilisi">(GMT+04:00) Tbilisi</option>
								<option value="Asia/Yerevan">(GMT+04:00) Yerevan</option>
								<option value="Asia/Kabul">(GMT+04:30) Kabul</option>
								<option value="Asia/Karachi">(GMT+05:00) Karachi</option>
								<option value="Asia/Tashkent">(GMT+05:00) Tashkent</option>
								<option value="Asia/Kolkata">(GMT+05:30) Kolkata</option>
								<option value="Asia/Kathmandu">(GMT+05:45) Kathmandu</option>
								<option value="Asia/Yekaterinburg">(GMT+06:00) Ekaterinburg</option>
								<option value="Asia/Almaty">(GMT+06:00) Almaty</option>
								<option value="Asia/Dhaka">(GMT+06:00) Dhaka</option>
								<option value="Asia/Novosibirsk">(GMT+07:00) Novosibirsk</option>
								<option value="Asia/Bangkok">(GMT+07:00) Bangkok</option>
								<option value="Asia/Jakarta">(GMT+07:00) Jakarta</option>
								<option value="Asia/Krasnoyarsk">(GMT+08:00) Krasnoyarsk</option>
								<option value="Asia/Chongqing">(GMT+08:00) Chongqing</option>
								<option value="Asia/Hong_Kong">(GMT+08:00) Hong Kong</option>
								<option value="Asia/Kuala_Lumpur">(GMT+08:00) Kuala Lumpur</option>
								<option value="Australia/Perth">(GMT+08:00) Perth</option>
								<option value="Asia/Singapore">(GMT+08:00) Singapore</option>
								<option value="Asia/Taipei">(GMT+08:00) Taipei</option>
								<option value="Asia/Ulaanbaatar">(GMT+08:00) Ulaan Bataar</option>
								<option value="Asia/Urumqi">(GMT+08:00) Urumqi</option>
								<option value="Asia/Irkutsk">(GMT+09:00) Irkutsk</option>
								<option value="Asia/Seoul">(GMT+09:00) Seoul</option>
								<option value="Asia/Tokyo">(GMT+09:00) Tokyo</option>
								<option value="Australia/Adelaide">(GMT+09:30) Adelaide</option>
								<option value="Australia/Darwin">(GMT+09:30) Darwin</option>
								<option value="Asia/Yakutsk">(GMT+10:00) Yakutsk</option>
								<option value="Australia/Brisbane">(GMT+10:00) Brisbane</option>
								<option value="Australia/Canberra">(GMT+10:00) Canberra</option>
								<option value="Pacific/Guam">(GMT+10:00) Guam</option>
								<option value="Australia/Hobart">(GMT+10:00) Hobart</option>
								<option value="Australia/Melbourne">(GMT+10:00) Melbourne</option>
								<option value="Pacific/Port_Moresby">(GMT+10:00) Port Moresby</option>
								<option value="Australia/Sydney">(GMT+10:00) Sydney</option>
								<option value="Asia/Vladivostok">(GMT+11:00) Vladivostok</option>
								<option value="Asia/Magadan">(GMT+12:00) Magadan</option>
								<option value="Pacific/Auckland">(GMT+12:00) Auckland</option>
								<option value="Pacific/Fiji">(GMT+12:00) Fiji</option>		
							</select><br />
						</fieldset><br />
					</div>
					<div id="Tab2" style="display:none;">
						AjaxExplorer Copyright (C) 2007-2013 S.M.Sid Software.<br /><br />
						This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation.<br /><br />
						This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.<br /><br />Head to GNU site for <a href="http://www.gnu.org/licenses/" target="_blank">license copy</a>.
					</div>

					<div id="Tab3" style="display:none;">
						<div>Setup your account information below.</div>
						<fieldset><legend>Setup Account</legend>
							Username:<br /><input id="fldUserName" name="fldUserName" type="text" class="input2" value="owner" onkeyup="this.value = this.value.toLowerCase();" /><br />
							Password:<br /><input id="fldUserPass" name="fldUserPass" type="password" class="input2" /><br />
							Confirm Password:<br /><input id="fldTestPass" type="password" class="input2" />
						</fieldset>
						<div>Each theme have different javascript library, So it may works differently.</div>
						<fieldset><legend>Default Themes</legend>
							<select id="fldUserView" name="fldUserView" class="input2"><?php echo $strSel2; ?></select>
						</fieldset>
					</div>
				</div>

				<div class="padding">
					<span class="alignright"><input id="Btn1" type="button" class="button" value="License" onclick="userToggle(2)" /><input id="Btn2" type="button" class="button" style="display:none;" value="Install" onclick="userToggle(3)" /><input id="Btn3" type="button" class="button" style="display:none;" value="Submit" onclick="userInstall()" /></span>	
					<a href="readme.html" target="_blank"><img alt="" src="<?php echo $strHrefTemplate; ?>/css/images/icon/manual.gif" /></a>
				</div>
			</form>
		</div>
	</body>
</html>