<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase del modelo
class Model_Menu extends Model{
	//Creamos el constructor
	public function __construct(){ 
		parent::__construct();
	}

	//Generamos un m�todo para una vista de los datos a obtener
	public function all(){
		$query = $this->db->query('SELECT * FROM menu');
		return $query;
	}
	
	//Generamos un m�todo para una vista de los datos a obtener
	public function allx(){
		$query = $this->db->query('SELECT * FROM menu ORDER BY orden ASC');
		return $query;
	}
	
	//Generamos un m�todo y cargamos los registros de la tabla requerida seg�n su id
	public function allFiltered($id){
		$query = $this->db->by_id('SELECT * FROM menu WHERE id = :id', array(':id'=>$id));
		return $query;
	}
	
	//Generamos el m�todo de registro de datos a la tabla
	public function insert($registro){
		$query = $this->db->insert('menu', $registro);
		return $query;
	}
	
	//Generamos un m�todo para sentencia de actualizacion de datos mediante SQL
	public function update($registro){
        $query = $this->db->update('menu', $registro, 'id = '.$registro['id'].'');
		return $query;
	}
	
	//Generamos el m�todo de eleminaci�n de registros
	public function delete($id){
		$query = $this->db->delete('menu', 'id = '.$id.'');
		return $query;
	}

}