<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase del modelo
class Model_Grupo_Usuario extends Model{
	//Creamos el constructor
	public function __construct(){ 
		parent::__construct();
	}

	//Generamos un m�todo para una vista de los datos a obtener
	public function all(){
		$query = $this->db->query('SELECT grupo_usuario.*, grupo.name as grupo_name, usuario.name as usuario_name
										 FROM grupo_usuario
										 left join grupo ON (grupo_usuario.grupo_id = grupo.id)
										 left join usuario ON (grupo_usuario.usuario_id = usuario.id)');
		return $query;
	}
	
	//Generamos un m�todo y cargamos los registros de la tabla requerida seg�n su id
	public function allFiltered($id){
		$query = $this->db->by_id('SELECT grupo_usuario.*, grupo.name as grupo_name, usuario.name as usuario_name
										 FROM grupo_usuario
										 left join grupo ON (grupo_usuario.grupo_id = grupo.id)
										 left join usuario ON (grupo_usuario.usuario_id = usuario.id)
										 WHERE grupo.id = :id', array(':id'=>$id));
		return $query;
	}
	
	//Generamos el m�todo de registro de datos a la tabla
	public function insert($registro){
		$query = $this->db->insert('grupo_usuario', $registro);
		return $query;
	}
	
	//Generamos un m�todo para sentencia de actualizacion de datos mediante SQL
	public function update($registro){
        $query = $this->db->update('grupo_usuario', $registro, 'id = '.$registro['id'].'');
		return $query;
	}
	
	//Generamos el m�todo de eleminaci�n de registros
	public function delete($id){
		$query = $this->db->delete('grupo_usuario', 'id = '.$id.'');
		return $query;
	}

    function get_grupos(){
        $lista = array();
        $this->Model_Grupo = $this->load->model('Model_Grupo');
        $registros = $this->Model_Grupo->all();
        foreach ($registros as $registro) {
            $lista[$registro->id] = $registro->name;
        }
        return $lista;
    }

    function get_usuarios(){
        $lista = array();
        $this->Model_Usuario = $this->load->model('Model_Usuario');
        $registros = $this->Model_Usuario->all();
        foreach ($registros as $registro) {
            $lista[$registro->id] = $registro->name;
        }
        return $lista;
    }

}