<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase del modelo
class Model_Grupo extends Model{
	//Creamos el constructor
	public function __construct(){ 
		parent::__construct();
	}
	
	//Generamos un m�todo para una vista de los datos a obtener
	public function all(){
		$query = $this->db->query('SELECT * FROM grupo');
		return $query;
	}
	
	//Generamos un m�todo y cargamos los registros de la tabla requerida seg�n su id
	public function allFiltered($id){
		$query = $this->db->by_id('SELECT * FROM grupo WHERE id = :id', array(':id'=>$id));
		return $query;
	}
	
	//Generamos el m�todo de registro de datos a la tabla
	public function insert($registro){
		$query = $this->db->insert('grupo', $registro);
		return $query;
	}
	
	//Generamos un m�todo para sentencia de actualizacion de datos mediante SQL
	public function update($registro){
        $query = $this->db->update('grupo', $registro, 'id = '.$registro['id'].'');
		return $query;
	}
	
	//Generamos el m�todo de eleminaci�n de registros
	public function delete($id){
		$query = $this->db->delete('grupo', 'id = '.$id.'');
		return $query;
	}

}