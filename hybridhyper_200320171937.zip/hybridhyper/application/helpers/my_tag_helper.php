﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Tag Helper
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
//Muestra TODOS los errores de validación de un formulario
if (!function_exists('my_validation_errors')) {
	function my_validation_errors($errors) {
		$salida = '';

		if ($errors) {
			$salida = '<div class="alert alert-error">';
			$salida = $salida.'<button type="button" class="close" data-dismiss="alert"> × </button>';
			$salida = $salida.'<h4><i class="icon fa fa-ban"></i> Mensajes de Validación </h4>';
			$salida = $salida.'<small>'.$errors.'</small>';
			$salida = $salida.'</div>';
		}
		return $salida;
	}
}

if (!function_exists('my_validation_errors_info')) {
	function my_validation_errors_info($errors_info) {
		$salida = '';

		if ($errors_info) {
			$salida = '<div class="alert-info">';
			//$salida = $salida.'<button type="button" class="close" data-dismiss="alert"> × </button>';
			$salida = $salida.'<h4> Mensajes de Validación </h4>';
			$salida = $salida.'<small>'.$errors_info.'</small>';
			$salida = $salida.'</div>';
		}
		return $salida;
	}
}

//Opciones de menú de la barra superior (las opciones dependen si hay session o no)
if (!function_exists('my_admin_menu_ppal_left')) {
	function my_admin_menu_ppal_left() {
		$opciones = null;

		//$opciones = '<li>'.anchor('admin/index', 'Inicio').'</li>';
		$opciones = $opciones.'<li>'.anchor('admin/acerca_de', 'Acerca De').'</li>';

		if (get_instance()->session->userdata('usuario_id')) {
			//$opciones = $opciones.'<li>'.anchor('admin/cambio_clave', 'Cambio Clave').'</li>';
			//$opciones = $opciones.'<li>'.anchor('admin/salir', 'Salir').'</li>';
		} else {
			//$opciones = $opciones.'<li>'.anchor('products/qp', 'Tienda en Línea').'</li>';
			//$opciones = $opciones.'<li>'.anchor('admin/inicio_sesion', 'Iniciar Sesión').'</li>';
		}
		return $opciones;
	}

}

if (!function_exists('my_admin_menu_ppal_right')) {
	function my_menu_ppal_right() {
		$opciones = null;
		
		if (get_instance()->session->userdata('usuario_id')) {
			$opciones = $opciones.anchor('usuario/usr_common_config/'.get_instance()->session->userdata('usuario_id'), 
			'<img src="'.base_url('').'assets/images/usuario_image/'.get_instance()->session->userdata('usuario_image').'" width="40" height="29" class="img-rounded">');
			$opciones = $opciones.'<li>'.anchor('admin/cambio_clave', 'Cambio Clave').'</li>';
			$opciones = $opciones.'<li>'.anchor('admin/salir', 'Salir').'</li>';
		} else {
			$opciones = $opciones.'<li>'.anchor('admin/inicio_sesion', 'Iniciar Sesión').'</li>';
		}
		return $opciones;
	}
}

if (!function_exists('my_menu_common_user')) {
	function my_menu_common_user() {
         $opciones = null;
		 get_instance()->load->model('Model_Messages');
		 if (get_instance()->session->get_userdata('usuario_id')) {
		 $opciones = $opciones.'<div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="'.base_url('').'assets/images/usuario_image/'.get_instance()->session->userdata('usuario_image').'" alt="">
					'.get_instance()->session->userdata('usuario_name').' '.get_instance()->session->userdata('usuario_ape').'
                    <span class=" fa fa-angle-down"></span>
                  </a>';

                  $opciones = $opciones.'<ul class="dropdown-menu dropdown-usermenu pull-right">
					<li class="user-header" style="background-color:#0099CC;">
						<div align="center"><img src="'.base_url('').'assets/images/usuario_image/'.get_instance()->session->userdata('usuario_image').'" class="img-circle" alt="User Image" height="150px">
					  </div>
						<p align="center">
							<small style="color:#FFFFFF">'.get_instance()->session->userdata('perfil_name').'</small>
						</p>
					</li>
					<li>
                      <a href="'.base_url('usuario/usr_common_edit/'.get_instance()->session->userdata('usuario_id').'').'">
                        <!--<span class="badge bg-red pull-right">50%</span>-->
                        <span>Actualizar Información</span>
                      </a>
                    </li>
					<li><a href="'.base_url('usuario/usr_common_edit_img/'.get_instance()->session->userdata('usuario_id').'').'"> Actualizar Imagen</a></li>';
					  /*if (get_instance()->session->userdata('usuario_id') == 1) {
					  $opciones = $opciones.'<div class="col-xs-4 text-center">
					  <img src="'.base_url('').'assets/admin/img/exclamation.png" title="Acción no Permitida">
					  </div>';
					  } else {
					  $opciones = $opciones.'<div class="col-xs-4 text-center">
						<a href="'.base_url('usuario/usr_common_baja/'.get_instance()->session->userdata('usuario_id').'').'">Dar de Baja</a>
					  </div>';
					  }*/
                    $opciones = $opciones.'<li><a href="'.base_url('').'admin/cambio_clave">Cambiar Clave</a></li>
                    <li><a href="'.base_url('').'admin/salir"><i class="fa fa-sign-out pull-right"></i>Cerrar Sesión</a></li>
                  </ul>
                </li>';
				$query = get_instance()->Model_Messages->count_recived_messages();
				$opciones = $opciones.'<!-- messages -->
				<li role="presentation" class="dropdown">
				  <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
					<i class="fa fa-envelope-o"></i>';
					if($query){
						foreach($query as $registro){
							if($registro->total > 0){
								$opciones = $opciones.'<span class="badge bg-green">'.$registro->total.'</span>';
							} else {
								$opciones = $opciones.'<span class="badge bg-green">'.$registro->total.'</span>';
							}
						}
					}
				  $query = get_instance()->Model_Messages->get_all_x();
				  $opciones = $opciones.'</a>
				  <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">';
					foreach($query as $registro){
					$opciones = $opciones.'<li>
					  <a href="'.base_url('').'messages/resend_x/'.$registro->id.'">
						<span class="image"><img src="'.base_url('').'assets/images/usuario_image/'.$registro->image.'" alt="Profile Image"></span>
						<span>
						  <span>'.$registro->emisor.'</span>
						  <span class="time">'.date("d/m/Y - H:i:s", strtotime($registro->created)).'</span>
						</span>
						<span class="message">
						  '.substr($registro->mensaje, 0, 80).'...
						</span>
					  </a>
					</li>';
					}
					$opciones = $opciones.'<li>
					  <div class="text-center">
						<a>
						  <strong><a href="'.base_url().'messages/read">Ver Todos los Mensajes</a></strong>
						  <i class="fa fa-angle-right"></i>
						</a>
					  </div>
					</li>
				  </ul>
				</li>
				<!-- messages -->
              </ul>
            </nav>
          </div>
        </div>';
		} else {
			$opciones = $opciones.'<li>'.anchor('admin/inicio_sesion', 'Iniciar Sesión').'</li>';
		}
		return $opciones;
	}
}

if (!function_exists('my_messages')) {
	function my_messages() {
    	$opciones = null;
		get_instance()->load->model('Model_Messages');
		$query = get_instance()->Model_Messages->count_recived_messages();
		if (get_instance()->session->userdata('usuario_id')) {
			if($query){
				foreach($query as $registro){
					if($registro->total > 0){
						$opciones = $opciones.'<span class="badge bg-green">'.$registro->total.'</span>';
					} else {
						$opciones = $opciones.'<span class="badge bg-green">'.$registro->total.'</span>';
					}
				}
			}
		}
		return $opciones;
	}
}

if (!function_exists('my_menu_common_user_site')) {
	function my_menu_common_user_site() {
         $opciones = null;
		 if (get_instance()->session->userdata('usuario_id')) {
                  $opciones = $opciones.'<li class="dropdown" style="height:40px; width:370px;">
						<a data-toggle="dropdown" class="dropdown-toggle" href="#">
							<img alt="" src="'.base_url('').'assets/images/usuario_image/'.get_instance()->session->userdata('usuario_image').'" class="img-circle profile_img" style="height:50px; width:50px;">
							<span class="username">'.get_instance()->session->userdata('usuario_name').' '.get_instance()->session->userdata('usuario_ape').'</span>
							<b class="caret"></b>
						</a>
						<ul class="dropdown-menu">
							<div class="log-arrow-up"></div>
							<li><a href="'.base_url('usuario/usr_common_edit/'.get_instance()->session->userdata('usuario_id').'').'">
							<i class=" fa fa-suitcase" data-original-title="" title=""></i>Actualizar Información</a></li>
							<li><a href="'.base_url('usuario/usr_common_edit_img/'.get_instance()->session->userdata('usuario_id').'').'"><i class="fa fa-cog" data-original-title="" title=""></i> Actualizar Imagen</a></li>
							<li><a href="'.base_url('').'admin/cambio_clave"><i class="fa fa-bell-o" data-original-title="" title=""></i> Cambiar Contraseña</a></li>
							<li><a href="'.base_url('').'admin/salir"><i class="fa fa-key" data-original-title="" title=""></i> Cerrar Sesión</a></li>
							<li class="divider"></li>
							<li aling="center">
							  <div align="center"><i class="fa fa-circle text-success"></i> '.get_instance()->session->userdata('perfil_name').'</div>
							</li>
						</ul>
					</li>';
		} else {
			$opciones = $opciones.'<li>'.anchor('admin/inicio_sesion', 'Iniciar Sesión').'</li>';
		}
		return $opciones;
	}
}

if (!function_exists('my_menu_app')) {
	function my_menu_app() {
		$opciones = null;

		if (get_instance()->session->userdata('usuario_id')) {
			$opciones = '';
			get_instance()->load->model('Model_Menu');
			$opciones = $opciones.'<hr>';
			$opciones = $opciones.'<hr><li class="header">Menú Administrador</li><hr>';
			$query = get_instance()->Model_Menu->allForMenu();

			foreach ($query as $opcion) {
				if ($opcion->url != '') {
					$irA = $opcion->url;
					$param = array('target'=>'_blank');
				} else {
					$irA = $opcion->controlador.'/'.$opcion->accion;
					$param = array();
				}
				$opciones = $opciones.'<li>'.anchor($irA, $opcion->name, $param).'</li>';
			}
		}
		return $opciones;
	}

}

if (!function_exists('my_menu_public')) {
	function my_menu_public() {
		$opciones = null;

			$opciones = '';
			get_instance()->load->model('Model_Menu_Public');
			$query = get_instance()->Model_Menu_Public->allForMenu_Public();

			foreach ($query as $opcion) {
				if ($opcion->url != '') {
					$irA = $opcion->url;
					$param = array('target'=>"_blank");
				} else {
					$irA = $opcion->controlador.'/'.$opcion->accion;
					$param = array('target'=>'_blank');
				}
				$opciones = $opciones.'<li>'.anchor($irA, $opcion->name, $param).'</li>';
			}
		return $opciones;
	}

}

if (!function_exists('my_menu_site_system')) {
	function my_menu_site_system() {
		$opciones = null;

		if (get_instance()->session->userdata('usuario_id')) {
			$opciones = '';
			get_instance()->load->model('Model_Menu');
			//$opciones = $opciones.'<hr>';
			//$opciones = $opciones.'<li class="nav-header"><i class="icon-globe"></i>Menú del Sitio</li>';
			$query = get_instance()->Model_Menu->all_site();

			foreach ($query as $opcion) {
				if ($opcion->url != '') {
					$irA = $opcion->url;
					$param = array('target'=>'_blank');
				} else {
					$irA = $opcion->controlador.'/'.$opcion->accion;
					$param = array('target'=>'_blank');
				}
				$opciones = $opciones.'<li>'.anchor($irA, $opcion->name, $param).'</li>';
			}
		}
		return $opciones;
	}
}

if (!function_exists('my_menu_site')) {
	function my_menu_site() {
		$opciones = null;

		if (get_instance()->session->userdata('usuario_id')>=0) {
			$opciones = '';
			get_instance()->load->model('Model_Menu');
			$query = get_instance()->Model_Menu->all_site();

			foreach ($query as $opcion) {
				if ($opcion->url != '') {
					$irA = $opcion->url;
					$param = array();
					$param = array('target'=>'_blank');
				} else {
					$irA = $opcion->controlador.'/'.$opcion->accion;
					$param = array();
				}
				$opciones = $opciones.'<li>'.anchor($irA, $opcion->name, $param).'</li>';
			}//<li class="wow fadeIn"><h3 class="areas-admin-title"><h3></li>
		}
		return $opciones;
	}
}
