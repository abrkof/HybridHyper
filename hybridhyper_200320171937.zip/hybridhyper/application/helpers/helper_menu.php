﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.

if (!function_exists('my_menu_ppal')){

	function my_menu_ppal(){
		//Instanciamos a la clase de conexion de la base de datos
		$ABRKOF = & get_instance();
				
		$stmtp = $ABRKOF->dbx->prepare('SELECT id, name, controlador, accion, url, orden FROM menu ORDER BY orden ASC');
		$stmtp->execute();
		$stmtpx = $stmtp->fetchAll();

		foreach($stmtpx as $menux){
			//Preparamos la primera consulta de acceso
			$stmt1 = $ABRKOF->dbx->prepare('SELECT menu_perfil.*, menu.name AS name 
							from menu_perfil 
							LEFT JOIN menu ON (menu_perfil.menu_id = menu.id)
							WHERE menu_id = "'.$menux['id'].'" AND perfil_id = "'.$ABRKOF->session->get_userdata('perfil_id').'"');
			$stmt1->execute();
			//Delvemos un arreglo con la siguiente fila
			$stmtx = $stmt1->fetchAll();
			//if ($stmtp != 0){
			$menu_urlx = $menux['controlador'].'/'.$menux['accion'];
			$menu_url = substr($menu_urlx,0,strripos($menu_urlx,"/"));
			//}
			$menu = "\n";
	
			//Evaluamos si el arreglo trae algo
			if(count($stmtx) > 0);
			foreach($stmtx as $row1){
				//Preparamos la segunda consulta de acceso
				$stmt2 = $ABRKOF->dbx->prepare('SELECT id, name, controlador, accion, url, menu_id, orden FROM submenu 
										WHERE menu_id = "'.$row1['menu_id'].'" ORDER BY orden ASC');
				$stmt2->execute();
				//Contamos el número de filas que trae.
				$rows = $stmt2->rowCount();
				
				$m = $menu_url;
				//Evaluamos si el arreglo viene vacío
				if($rows == 0){//Si no se relaciona con un sub menú, imprime un link normal.
					echo $menu .= "<li><a href=".base_url('')."$m>".$row1['name']."</a></li>\n";
				} else {//Si hay un sub menú relacionado, imprime un menú en cascada.
					$menu .= "<li class='dropdown'>\n <a href='#' class='dropdown-toggle' data-toggle='dropdown'>".$row1['name']."<b class='caret'></b></a>\n
							 <ul class='dropdown-menu'>\n";
					foreach($stmt2 as $row2){
						$submenu_urlx = $row2['controlador'].'/'.$row2['accion'];
						$submenu_url = substr($submenu_urlx,0,strripos($submenu_urlx,'/'));
						
						$menu .= "<li><a href=".base_url('')."$submenu_url>".$row2['name']."</a></li>\n";
					}
				$menu .= "</ul></li>\n";
				echo $menu;
				}
			}
		}
		
		//$menu .="";
		//return $menu;
	}
}