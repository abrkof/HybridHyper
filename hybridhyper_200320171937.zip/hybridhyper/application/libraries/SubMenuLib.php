﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
class SubMenuLib{
private $pdo;
	function __construct(){
		//Realizamos la conexion a la base de datos.
		try{
			$this->ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga el super objeto.
		}
		catch(Exception $e){
			die($e->getMessage());
		}
		$this->ABRKOF->Model_Perfil = $this->ABRKOF->load->model('Model_Perfil');
    }    

    public function get_perfiles_asig_noasig($submenu_id){
        if(isset($_REQUEST['id'])){
            $submenu_id = $_REQUEST['id'];
        }
        $lista_asig = array();
        $lista_noasig = array();
		
		$perfiles = $this->ABRKOF->Model_Perfil->all();
		
		foreach($perfiles as $perfil){
			$query = $this->ABRKOF->db->row_array('SELECT * FROM submenu_perfil WHERE submenu_id = :submenu_id AND perfil_id = :perfil_id', 
												array(':submenu_id'=>$submenu_id, ':perfil_id'=>$perfil->id));
			$existe = (count($query) > 0);
			
            if($existe){
                $lista_asig[] = array($perfil->id, $perfil->name, $submenu_id);
            }
            else{
                $lista_noasig[] = array($perfil->id, $perfil->name, $submenu_id);
            }
        }
		return array($lista_noasig, $lista_asig);
    }

    public function findByControlador($controlador){
		$query = $this->ABRKOF->db->next_row('SELECT * FROM submenu WHERE controlador = :controlador', 
											array(':controlador'=>$controlador));
		return $query;
    }

}