﻿<?php if (!defined('BASEPATH')) exit('No permitir el acceso directo al script');
class UsuarioLib{
	function __construct(){
		//Realizamos la conexion a la base de datos
		try{
			$this->ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librería
		}
		catch(Exception $e){
			die($e->getMessage());
		}
		$this->ABRKOF->Model_Usuario = $this->ABRKOF->load->model('Model_Usuario');
		$this->ABRKOF->Model_Perfil = $this->ABRKOF->load->model('Model_Perfil');
    }

	public function login(){
        define('ERROR_LOGIN','Error, Usuario o Contraseña Incorrectos!!!.');
		
		$login = $_REQUEST['login'];
        $password = md5($_REQUEST['password']);
		
		$stmt = $this->ABRKOF->db->next_row('SELECT * FROM usuario WHERE login = :login AND password = :password', 
											array(':login'=>$login, ':password'=>$password));
		
		if(count($stmt) == 1){
			$this->ABRKOF->session->sess_destroy();
			return FALSE;
		} else {
    		$usuario = $stmt;
			
			$stmtp = $this->ABRKOF->db->next_row('SELECT * FROM perfil WHERE id = :id', 
												array(':id'=>$usuario['perfil_id']));
			
			$perfil = $stmtp;
			
			//////////////////////////////////////////////////////////////////////////////////////////////
			$stmtm = $this->ABRKOF->db->next_row('SELECT * FROM menu');
			
			$menu = $stmtm;
			
			$stmtr = $this->ABRKOF->db->next_row('SELECT * FROM menu_perfil WHERE perfil_id = :perfil_id', 
												array(':perfil_id'=>$perfil['id']));
			
			$menu_perfil = $stmtr;
			//////////////////////////////////////////////////////////////////////////////////////////////

			$this->ABRKOF->session->set_userdata('usuario', $usuario['name']);
			$this->ABRKOF->session->set_userdata('usuario_id', $usuario['id']);
			$this->ABRKOF->session->set_userdata('perfil_id', $usuario['perfil_id']);
			$this->ABRKOF->session->set_userdata('perfil_name', $perfil['name']);
			
			//////////////////////////////////////////////////////////////////////////////////////////////
			
		return TRUE;
		}
	}

    public function cambiarPWD($act, $new){
    	if($this->ABRKOF->session->get_userdata('usuario_id') == NULL){
    		throw new Exception('No existe el usuario o los datos de sesión vienen vacios');//return FALSE;
    	}
		
		$id = $this->ABRKOF->session->get_userdata('usuario_id');

		$usuario = $this->ABRKOF->Model_Usuario->find($id);

		if($usuario['password'] == $act){
    		$registro = array('id' => $id,
               			  'password' => $new,
						  'updated' => date('Y/m/d H:i:s'));
			$this->ABRKOF->Model_Usuario->update_pass($registro);
		} else {
			redirect('inicio/error_pwdusr');
			//throw new Exception('La Nueva Contraseña No Coincide Con La Contraseña Actual');//return FALSE;
		}
    }

    public function my_validation($registro){
		$registro->login = $_REQUEST['login'];
		
		$stmt = $this->ABRKOF->dbx->prepare('SELECT * FROM usuario WHERE login = :login');
		$stmt->execute(array($registro->login));
		$stmtx = $stmt->fetchAll();

		$rt = redirect('usuario/procesos');
			
        if (count($stmtx) > 0 AND (!isset($registro['id']) OR ($registro['id'] != $stmt->fetchAll('id')))){
            return FALSE;
        }
        else{
            return $rt;
        }
    }

}