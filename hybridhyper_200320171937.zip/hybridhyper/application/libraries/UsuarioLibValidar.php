﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Validaciones para el model de usuarios (login, cambio de clave, CRUD Usuarios)
class UsuarioLibValidar{

	function __construct(){
		$this->ABRKOF = & get_instance(); //Esto es para acceder a la instancia que carga la libreria
		
		$this->ABRKOF->form_validation->set_message('required', 'Debe ingresar un valor para %s');
	}

	public function set_rules_ingresar(){
		$this->ABRKOF->form_validation->set_rules('login', 'Usuario', 'required');
		$this->ABRKOF->form_validation->set_rules('password', 'Clave', 'required');
	}

}