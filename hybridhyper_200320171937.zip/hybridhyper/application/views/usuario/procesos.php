﻿<?php
?>
<br><br>
<h1 class="page-header">
    <?php echo $registro->id != null ? 'Editando Registro' : 'Creando Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><?php echo open_link('usuario', 'Usuario'); ?></li>
  <li class="active">/ <?php echo $registro->id != null ? $registro->name : 'Creando Nuevo Registro'; ?></li>
</ol>
<?php echo form_open_multipart("usuario/insert", array('id'=>'frm-usuario', 'class'=>'form-horizontal')); ?>
		<?php echo form_hidden('id', $registro->id); ?>
    
    <div class="control-group">
        <?php echo form_label('Nombre Completo : ', 'name', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'name', 'id'=>'name', 'value'=>$registro->name, 'class'=>'form-control', 'placeholder'=>'Ingrese el Nombre del Usuario', 'autocomplete'=>'off'));?>
    </div>
    
    <div class="control-group">
        <?php echo form_label('Usuario (Nick): ', 'login', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'login', 'id'=>'login', 'value'=>$registro->login, 'class'=>'form-control', 'placeholder'=>'Ingrese el Login del Usuario (Nick)', 'data-validacion-tipo'=>'requerido|min:6', 'autocomplete'=>'off'));?>
    </div>

	<?php if ( $registro->id != null ){ ?>
	<?php } else { ?>
    <div class="control-group">
        <?php echo form_label('Password: ', 'password', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'password', 'name'=>'password', 'id'=>'password', 'value'=>$registro->password, 'class'=>'form-control', 'placeholder'=>'Ingrese la Constraseña', 'data-validacion-tipo'=>'requerido|min:6', 'autocomplete'=>'off'));?>
    </div>
	<?php } ?>

    <div class="control-group">
        <?php echo form_label('E-Mail : ', 'email', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'email', 'id'=>'email', 'value'=>$registro->email, 'class'=>'form-control', 'placeholder'=>'Ingrese un Correo', 'autocomplete'=>'off'));?>
    </div>

    
    <div class="control-group">
        <?php echo form_label('Perfil : ', 'perfil_id', array('class'=>'control-label')); ?>
		<?php $style = 'class="form-control"' ;?>
		<?php echo form_dropdown('perfil_id', $perfiles, $registro->perfil_id, $style); ?>
    </div>
    
    <hr>
    
    <div class="control-group">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Guardar', 'class'=>'btn btn-success')); ?>
		<?php echo anchor('usuario', 'Cancelar', 'class="btn btn-warning"'); ?>
    </div>
<?php echo form_close();?>

<script>
    $(document).ready(function(){
        $("#frm-usuario").submit(function(){
            return $(this).validate();
        });
    })
</script>