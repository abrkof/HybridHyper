﻿<?php
?>
<br><br>
<h1 class="page-header">
    <?php echo $registro->id != null ? 'Editando Registro' : 'Creando Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><?php echo open_link('perfil', 'Perfil'); ?></li>
  <li class="active">/ <?php echo $registro->id != null ? $registro->name : 'Creando Nuevo Registro'; ?></li>
</ol>
<?php echo form_open_multipart("perfil/insert", array('id'=>'frm-perfil', 'class'=>'form-horizontal')); ?>
		<?php echo form_hidden('id', $registro->id); ?>
    
    <div class="control-group">
        <?php echo form_label('Nombre : ', 'name', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'name', 'id'=>'name', 'value'=>$registro->name, 'class'=>'form-control', 'placeholder'=>'Ingrese el Nombre del Perfil', 'data-validacion-tipo'=>'requerido|min:3'));?>
    </div>
    
    <div class="control-group">
		<?php echo form_label('Descripción : ', 'descripcion', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'descripcion', 'id'=>'descripcion', 'value'=>$registro->descripcion, 'class'=>'form-control', 'placeholder'=>'Ingrese una Descripción', 'data-validacion-tipo'=>'requerido|min:5'));?>
    </div>
    
    <hr>
    
    <div class="control-group">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Guardar', 'class'=>'btn btn-success')); ?>
		<?php echo anchor('perfil', 'Cancelar', 'class="btn btn-warning"'); ?>
    </div>
<?php echo form_close();?>

<script>
    $(document).ready(function(){
        $("#frm-perfil").submit(function(){
            return $(this).validate();
        });
    })
</script>