<br><br>
<article class="format-standard hentry">
	<header class="entry-header">
		<h1 class="entry-title">Acceso Denegado !! </h1>

		<div class="entry-meta">
			<span class="posted-on"></span></div>
	</header>
<div class="hero-unit">
	<h1>No tiene acceso a esta opción</h1>
	<hr>
	<p align="center"> <img src="<?php echo base_url('')?>assets/img/174.png"></p>
    <p><h3> Comuníquese con el administrador. </h3></p>
</div>
</article>