<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Inicio de Sesión</title>

	<?php echo css('reset') ;?>
	<?php echo css('stylez') ;?>
	<?php echo css('colors') ;?>
	<?php echo css('css') ;?>
	<?php echo css('font-awesome.min') ;?>

</head>

<body>

<section class="preHeader">
	<div class="row">
		<?php //echo img('assets/img/iconos_01.png'); ?>
		<?php $img = array('name'=>'logo', 'id'=>'logo', 'src'=>'assets/img/iconos_01.png', 'class'=>'logo', 'alt'=>'ABRKOF');?>
		<?php echo img($img);?>
	</div>
</section>

<div class="fullscreenBackground"></div>

<section class="login">
	<div class="row margin padding noFloat">
		<div class="span12 textCenter">
			<h1 class="splash">Inicio de Sesión</h1>
		</div>
		<div class="span4 noPadding borderRadius transparentBorder ">

			<?php echo form_open('inicio/ingresar', array('id'=>'frm-login', 'class'=>'form-stacked')); ?>		
			    <fieldset class="control-group">
			
				    <div class="control-group">
					    <label class="control-label" for="username">Usuario:</label>
						<div class="controls">
							<?php echo form_input(array('type'=>'text', 'name'=>'login', 'id'=>'login', 'placeholder'=>'Login (Nick)', 
							'class'=>'input-xlarge', 'autofocus'=>'login', 'autocomplete'=>'off', 'required'=>'login')); ?>
						</div>
					</div>
			
					<div class="control-group">
					    <label class="control-label" for="password">Contraseña:</label>
						<div class="controls">
						<?php echo form_input(array('type'=>'password', 'name'=>'password', 'id'=>'password', 'placeholder'=>'Password', 
						'autocomplete'=>'off', 'required'=>'password')); ?>
						</div>
					</div>
			
			     <div>
					  <div><?php echo form_button(array('type'=>'submit', 'name'=>'submit', 'id'=>'submit', 
							'content'=>'Iniciar Sesión', 'class'=>'largeBtn primaryColor pullRight')); ?></div>
						
			          <!--<div class="rememberMe">
			          	<input type="checkbox" id="rememberMe" name="rememberme"><label for="rememberMe">Recordar Sesión</label></div>-->
			         
			          <span class="passwordReset"><a href="#">Olvide mi Contraseña</a></span>
						 <span class="passwordReset">
						 <?php if (isset($error_login)): ?>
						<div class="alert alert-error">
							<a class="close" data-dismiss="alert-close" href="#">&times;</a>
							<h4 class="alert-heading"><?php echo $error_login; ?></h4>
						</div>
						<?php endif; ?>
						</span>
			     </div>
			
				</fieldset>

			<?php echo form_close(); ?>

		</div>
	</div>
</section>	

<script type="text/javascript">
$("#login").focus();
</script>

<section class="footer">
	<div class="row centered padding margin textCenter">
		<div class="span12">
		<div class="clear"></div>
		</div></div></section>
<div class="footerdivider">
    <div class="fill"></div>
</div>

<div class="footer-wrap">
    <div class="footer">
        <div style="display:none;" id="copyright">Copyright © 2003 - 2015 ABRKOF. All Rights Reserved.</div>
                <div class="clear"></div>
    </div>
</div>
</body>
</html>