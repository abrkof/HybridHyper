<?php //$this->load->view('inicio/capture_lat_lon');?>

<body onload="find_location();return false;">

<div class="hero-unit">
<img src="<?php echo base_url('');?>assets/images/abrkof_logo_x.png" height="300" width="300">
	<h1> Sistema de Administración de Usuarios </h1>
	<hr>
	<p> Sistema de Administracion de Usuarios - <?php echo VERSION ;?> </p>
    <p> Para acceder a las opciones del sistema debe autenticarse como usuario del mismo. </p>
</div>
</body>