<?php

?>
<br><br>
<div class="page-header">
	<h1> Datos Estudiante <small>|| mantenimiento de registros </small> </h1>
</div>

<div class="well well-sm text-right">
    <a class="btn btn-primary" href="datos_estudiante/create" style="color:#FFF;">Nuevo Estudiante</a>
</div>
	<!--<link rel="stylesheet" href="<?php //echo host_url('') ;?>assets/css/paginator.css" />-->
	<?php //$selectFiles = $paginator->SelectPage($_GET['npg'], $array_de_resultados);?>
<table class="table table-striped">
    <thead>
        <tr>
            <th style="width:10px;">Id</th>
			<th style="width:100px;">Nombres</th>
            <th style="width:100px;">Apellidos</th>
            <th style="width:120px;">Género</th>
            <th style="width:120px;">Fecha de Nacimiento</th>
            <th style="width:60px;">Creado</th>
            <th style="width:60px;">Modificado</th>			
            <th style="width:60px;"></th>
            <th style="width:60px;"></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($query as $registro): ?>
        <tr>
			<td><?php echo $registro->id_dat_est; ?></td>
            <td><?php echo $registro->nombres; ?></td>
            <td><?php echo $registro->apellidos; ?></td>
            <td><?php echo $registro->genero == 1 ? 'Masculino' : 'Femenino'; ?></td>
            <td><?php echo $registro->fecha_nacimiento; ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->created)); ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->updated)); ?></td>
			<td><?php echo open_link('datos_estudiante/edit/'.$registro->id_dat_est, 'Editar') ;?></td>
            <td><a onclick="alertify.confirm('Estas Eliminado El ID de Registro Nº<?php echo $registro->id_dat_est; ?>','¿Estas seguro de eliminar este registro?',
			  function(ok){
				window.location='datos_estudiante/delete/<?php echo $registro->id_dat_est; ?>';
				alertify.success('Eliminación Exitosa');
			  },
			  function(cancel){
				alertify.message('Cancelado');
			  }); return false" href="#">Eliminar</a></td>
			<td><?php echo anchor('datos_estudiante/pdf/'.$registro->id_dat_est,'Reporte', 'target=_blank') ;?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php //$paginator->ShowControls(); ?>
<?php //echo $this->load->view('pagination/pagination');
?>
<div class="backtotop">
<span id="top" class="dashicons dashicons-arrow-up-alt2"></span>
</div>