﻿<?php
?>
<br><br>
<h1 class="page-header">Mantenimiento de Registros</h1>

<div class="well well-sm text-right">
    <a class="btn btn-primary" href="grupo/procesos" style="color:#FFF;">Nuevo Grupo</a>
</div>
<article class="format-standard hentry">
	<header class="entry-header">
		<h1 class="entry-title">Grupos</h1>

		<div class="entry-meta">
			<span class="posted-on">Lista de Registros</span></div>
	</header>

<table class="table table-striped">
    <thead>
        <tr>
            <th style="width:10px;">Id</th>
			<th style="width:100px;">Nombre del Grupo</th>
			<th style="width:120px;">Descripción</th>
            <th style="width:60px;">Creado</th>
            <th style="width:60px;">Modificado</th>	
            <th style="width:60px;"></th>
            <th style="width:60px;"></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($query as $registro): ?>
        <tr>
			<td><?php echo $registro->id; ?></td>
            <td><?php echo $registro->name; ?></td>
			<td><?php echo $registro->descripcion; ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->created)); ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->updated)); ?></td>
			<td><?php echo open_link('grupo/procesos/'.$registro->id, 'Editar') ;?></td>
            <td><a onclick="alertify.confirm('Estas Eliminado El ID de Registro Nº<?php echo $registro->id; ?>','¿Estas seguro de eliminar este registro?',
			  function(ok){
				window.location='grupo/delete/<?php echo $registro->id; ?>';
				alertify.success('Eliminación Exitosa');
			  },
			  function(cancel){
				alertify.message('Cancelado');
			  }); return false" href="#">Eliminar</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</article>