﻿<?php
?>
<br><br>
<h1 class="page-header">
    <?php echo $registro->id != null ? 'Editando Registro' : 'Creando Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><?php echo open_link('grupo', 'Grupos'); ?></li>
  <li class="active"><?php echo $registro->id != null ? $registro->name : 'Creando Nuevo Registro'; ?></li>
</ol>
<article class="format-standard hentry">
	<header class="entry-header">
		<h1 class="entry-title">Grupos</h1>

		<div class="entry-meta">
			<span class="posted-on"><?php echo $registro->id != null ? '('.$registro->name.')' : 'Nuevo Registro'; ?></span></div>
	</header>
<?php echo form_open_multipart("grupo/insert", array('id'=>'frm-perfil', 'class'=>'form-horizontal')); ?>
		<?php echo form_hidden('id', $registro->id); ?>
    
    <div class="form-group">
        <label>Nombre del Grupo</label>
		<?php echo form_input(array('type'=>'text', 'name'=>'name', 'id'=>'name', 'value'=>$registro->name, 'class'=>'form-control', 'placeholder'=>'Ingrese el Nombre del Grupo', 'data-validacion-tipo'=>'requerido|min:3'));?>
    </div>
    
    <div class="form-group">
        <label>Descripción</label>
		<?php echo form_input(array('type'=>'text', 'name'=>'descripcion', 'id'=>'descripcion', 'value'=>$registro->descripcion, 'class'=>'form-control', 'placeholder'=>'Ingrese una Descripción', 'data-validacion-tipo'=>'requerido|min:5'));?>
    </div>
    
    <hr>
    
    <div class="text-right">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Guardar', 'class'=>'btn btn-success')); ?>
		<?php echo anchor('grupo', 'Cancelar', 'class="btn btn-warning"'); ?>
    </div>
</article>
<?php echo form_close();?>

<script>
    $(document).ready(function(){
        $("#frm-grupo").submit(function(){
            return $(this).validate();
        });
    })
</script>