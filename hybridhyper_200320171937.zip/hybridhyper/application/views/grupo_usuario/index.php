﻿<?php
?>
<br><br>
<h1 class="page-header">Mantenimiento de Registros</h1>

<div class="well well-sm text-right">
    <a class="btn btn-primary" href="grupo_usuario/procesos" style="color:#FFF;">Nuevo Usuario</a>
</div>
<article class="format-standard hentry">
	<header class="entry-header">
		<h1 class="entry-title">Grupos de Usuarios</h1>

		<div class="entry-meta">
			<span class="posted-on">Lista de Registros</span></div>
	</header>

<table class="table table-striped">
    <thead>
        <tr>
            <th style="width:10px;">Id</th>
			<th style="width:160px;">Nombre del Grupo de Usuario</th>
            <th style="width:120px;">Grupo</th>
			<th style="width:120px;">Usuario</th>
			<th style="width:120px;">Descripción</th>
			<th style="width:120px;">Creado</th>
			<th style="width:120px;">Modificado</th>
            <th style="width:60px;"></th>
            <th style="width:60px;"></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($query as $registro): ?>
        <tr>
			<td><?php echo $registro->id; ?></td>
            <td><?php echo $registro->name; ?></td>
            <td><?php echo $registro->grupo_name; ?></td>
			<td><?php echo $registro->usuario_name; ?></td>
			<td><?php echo $registro->descripcion; ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->created)); ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->updated)); ?></td>
			<td><?php echo open_link('grupo_usuario/procesos/'.$registro->id, 'Editar') ;?></td>
            <td><a onclick="alertify.confirm('Estas Eliminado El ID de Registro Nº<?php echo $registro->id; ?>','¿Estas seguro de eliminar este registro?',
			  function(ok){
				window.location='grupo_usuario/delete/<?php echo $registro->id; ?>';
				alertify.success('Eliminación Exitosa');
			  },
			  function(cancel){
				alertify.message('Cancelado');
			  }); return false" href="#">Eliminar</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</article>