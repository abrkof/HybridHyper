﻿<?php
?>
<br><br>
<h1 class="page-header">
    <?php echo $registro->id != null ? 'Editando Registro' : 'Creando Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><?php echo open_link('submenu', 'Sub Menú'); ?></li>
  <li class="active">/ <?php echo $registro->id != null ? $registro->name : 'Creando Nuevo Registro'; ?></li>
</ol>

<script>
function index(){
	if(document.frm_submenu.accion.value == "index"){
		var alert = alertify.alert("Error de Validación","La Acción “index” es reservada por el sistema! <br> Escribe una Acción valida o deja el espacio en blanco.", function(){     	 
			alert.set({transition:'flipx'}); //slide, zoom, flipx, flipy, fade, pulse (default)
			alert.set('modal', false);  //al pulsar fuera del dialog se cierra o no.
			alertify.error('Intenta de Nuevo');
		}).set('label', 'Aceptar');
		return false;
	}
}
</script>

<script>
function slash(e) { // 1
    tecla = (document.all) ? e.keyCode : e.which; // 2
    if (tecla==8) return true; // 3
    patron =/[A-Za-z _\s]/; // 4
    te = String.fromCharCode(tecla); // 5
    return patron.test(te); // 6
}
</script>

<?php echo form_open_multipart("submenu/insert", array('name'=>'frm_submenu', 'id'=>'frm_submenu', 'class'=>'form-horizontal', 'onSubmit'=>'return index();')); ?>
		<?php echo form_hidden('id', $registro->id); ?>
    
    <div class="control-group">
		<?php echo form_label('Sub Menú : ', 'sub_menu', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'name', 'id'=>'name', 'value'=>$registro->name, 'class'=>'form-control', 'placeholder'=>'Ingrese el Nombre del Menú', 'data-validacion-tipo'=>'requerido|min:3'));?>
    </div>

    <div class="control-group">
		<?php echo form_label('Menú : ', 'menu', array('class'=>'control-label')); ?>
		<?php $style = 'class="form-control"' ;?>
		<?php echo form_dropdown('menu_id', $menus, $registro->menu_id, $style); ?>
    </div>

    <div class="control-group">
       <?php echo form_label('Controlador : ', 'controlador', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'controlador', 'id'=>'controlador', 'value'=>$registro->controlador, 'class'=>'form-control', 'placeholder'=>'Ingrese el Controlador', 'data-validacion-tipo'=>'requerido|min:1', 'onkeypress'=>'return slash(event);', 'pattern'=>'[a-z _ A-Z]*', 'title'=>'a-z _ A-Z'));?>
    </div>

    <div class="control-group">
        <?php echo form_label('Acción : ', 'accion', array('class'=>'control-label')); ?>
		<?php $slice = substr($registro->accion,0,strripos($registro->accion,'/')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'accion', 'id'=>'accion', 'value'=>$slice, 'class'=>'form-control', 'placeholder'=>'Ingrese la Acción', 'onkeypress'=>'return slash(event);', 'pattern'=>'[a-z _ A-Z]*', 'title'=>'a-z _ A-Z'));?>
    </div>

    <div class="control-group">
        <?php echo form_label('URL : ', 'url', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'url', 'id'=>'url', 'value'=>$registro->url, 'class'=>'form-control', 'placeholder'=>'Ingrese la Url', 'data-validacion-tipo'=>'requerido|min:1'));?>
    </div>

    <div class="control-group">
        <?php echo form_label('Orden : ', 'orden', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'number', 'name'=>'orden', 'id'=>'orden', 'value'=>$registro->orden, 'class'=>'form-control', 'placeholder'=>'Ingrese el orden', 'data-validacion-tipo'=>'requerido|min:1'));?>
    </div>
    
    <div class="form-group">
        <?php echo form_label('Descripción : ', 'descripcion', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'descripcion', 'id'=>'descripcion', 'value'=>$registro->descripcion, 'class'=>'form-control', 'placeholder'=>'Ingrese una Descripción', 'data-validacion-tipo'=>'requerido|min:5'));?>
    </div>
    
    <hr>
    
    <div class="control-group">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Guardar', 'class'=>'btn btn-success')); ?>
		<?php echo anchor('submenu', 'Cancelar', 'class="btn btn-warning"'); ?>
    </div>
<?php echo form_close();?>

<script>
    $(document).ready(function(){
        $("#frm_submenu").submit(function(){
            return $(this).validate();
        });
    })
</script>