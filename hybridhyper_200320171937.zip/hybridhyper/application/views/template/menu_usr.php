﻿<?php

?>
<?php echo js('saved_resource(3)') ;?>
<div id="bit" class="loggedout-follow-normal" style="bottom: -332px;">
	<a class="bsub" href="javascript:void(0)"><span id="bsub-text">Opciones de Usuario</span></a>
	<div id="bitsubscribe" class="">
		<h3><label for="loggedout-follow-field">Bienvenido</label></h3>
		<p><?php echo $this->session->get_userdata('usuario');?>.</p>
		<p id="loggedout-follow-error" style="display: none;"></p>
		<p class="bit-follow-count">Perfil: “<?php echo $this->session->get_userdata('perfil_name');?>”</p>
		<p><?php $this->load->template('cambio_clave');?></p>
		<form action="<?php echo base_url('') ;?>inicio/salir" method="post">
			<input type="submit" value="Cerrar Sesión">
		</form>
		<p id="bsub-subscribe-button"></p>
		<div id="bsub-credit"><a href="http://www.abrkof.org" target="_blank">Desarrollado en HybridHyper®</a></div>
	</div>
</div>