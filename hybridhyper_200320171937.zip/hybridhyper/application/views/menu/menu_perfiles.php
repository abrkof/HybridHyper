﻿<?php
?>
<br><br>
<h1 class="page-header">Mantenimiento de Accesos</h1>

<article class="format-standard hentry">
	<header class="entry-header">
		<h1 class="entry-title">Menús</h1>

		<div class="entry-meta">
			<span class="posted-on">Asignación de Permisos</span></div>
	</header>
	<table class="table table-condensed table-bordered">
		<caption> <h1> No Asignados </h1> </caption>

		<thead>
		<tr>
			<th> ID </th>
			<th> Nombre </th>
			<th> </th>
		</tr>
		</thead>

		<tbody>
		<?php
		foreach ($query_izq as $registro): ?>
		<tr>
			<td> <?php echo $registro[0]; ?> </td>
			<td> <?php echo $registro[1]; ?> </td>
			<td> <?php echo anchor('menu/mp_asig&perfil_id='.$registro[0].'&menu_id='.$registro[2], '<img src="'.base_url('').'assets/img/flecha_derecha.png">'); ?> </td>
		</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

	<table class="table table-condensed table-bordered">
		<caption> <h1> Asignados </h1> </caption>

		<thead>
		<tr>
			<th> </th>
			<th> ID </th>
			<th> Nombre </th>
		</tr>
		</thead>

		<tbody>
		<?php
		foreach ($query_der as $registro): ?>
		<tr>
			<td> <?php echo anchor('menu/mp_noasig&perfil_id='.$registro[0].'&menu_id='.$registro[2], '<img src="'.base_url('').'assets/img/flecha_izquierda.png">'); ?> </td>
			<td> <?php echo $registro[0]; ?> </td>
			<td> <?php echo $registro[1]; ?> </td>
		</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

<div class="btn-toolbar">
	<?php echo open_link('menu', 'Volver', 'class="btn btn-primary" style="color:#FFF;"'); ?>
</div>
</article>