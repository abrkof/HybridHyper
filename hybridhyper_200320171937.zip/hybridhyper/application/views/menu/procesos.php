﻿<?php
?>
<br><br>
<h1 class="page-header">
    <?php echo $registro->id != null ? 'Editando Registro' : 'Creando Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><?php echo open_link('menu', 'Menú'); ?></li>
  <li class="active">/ <?php echo $registro->id != null ? $registro->name : 'Creando Nuevo Registro'; ?></li>
</ol>


<script>
function index(){
	if(document.frm_menu.accion.value == "index"){
		var alert = alertify.alert("Error de Validación","La Acción “index” es reservada por el sistema! <br> Escribe una Acción valida o deja el espacio en blanco.", function(){     	 
			alert.set({transition:'flipx'}); //slide, zoom, flipx, flipy, fade, pulse (default)
			alert.set('modal', false);  //al pulsar fuera del dialog se cierra o no.
			alertify.error('Intenta de Nuevo');
		}).set('label', 'Aceptar');
		return false;
	}
}
</script>

<script>
function slash(e) { // 1
    tecla = (document.all) ? e.keyCode : e.which; // 2
    if (tecla==8) return true; // 3
    patron =/[A-Za-z_0-9 _\s]/; // 4
    te = String.fromCharCode(tecla); // 5
    return patron.test(te); // 6
}
</script>

<script>
function char_set(e) { // 1
    tecla = (document.all) ? e.keyCode : e.which; // 2
    if (tecla==8) return true; // 3
    patron =/[A-Za-z_0-9/ _\s]/; // 4
    te = String.fromCharCode(tecla); // 5
    return patron.test(te); // 6
}
</script>

<?php echo form_open("menu/insert", array('name'=>'frm_menu', 'id'=>'frm_menu', 'class'=>'form-horizontal', 'onSubmit'=>'return index();')); ?>
		<?php echo form_hidden('id', $registro->id); ?>
    
    <div class="control-group">
		<?php echo form_label('Nombre : ', 'name', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'name', 'id'=>'name', 'value'=>$registro->name, 'class'=>'form-control', 'placeholder'=>'Ingrese el Nombre del Menú', 'data-validacion-tipo'=>'requerido|min:3'));?>
    </div>
    
    <div class="control-group">
		<?php echo form_label('Módulo o Controlador : ', 'name', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'controlador', 'id'=>'controlador', 'value'=>$registro->controlador, 'class'=>'form-control', 'placeholder'=>'Ingrese el Controlador', 'data-validacion-tipo'=>'requerido|min:1', 'onkeypress'=>'return char_set(event);', 'pattern'=>'[a-z_A-Z0-9/]*', 'title'=>'a-z _ A-Z 0-9 /'));?>
    </div>

    <div class="control-group">
		<?php echo form_label('Acción : ', 'name', array('class'=>'control-label')); ?>
		<?php $slice = substr($registro->accion,0,strripos($registro->accion,'/')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'accion', 'id'=>'accion', 'value'=>$slice, 'class'=>'form-control', 'placeholder'=>'Ingrese la Acción', 'onkeypress'=>'return slash(event);', 'pattern'=>'[a-z_A-Z0-9]*', 'title'=>'a-z _ A-Z 0-9'));?>
    </div>

    <div class="control-group">
		<?php echo form_label('Url : ', 'name', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'url', 'id'=>'url', 'value'=>$registro->url, 'class'=>'form-control', 'placeholder'=>'Ingrese la Url', 'data-validacion-tipo'=>'requerido|min:1'));?>
    </div>

    <div class="control-group">
		<?php echo form_label('Orden : ', 'name', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'number', 'name'=>'orden', 'id'=>'orden', 'value'=>$registro->orden, 'class'=>'form-control', 'placeholder'=>'Ingrese el orden', 'data-validacion-tipo'=>'requerido|min:1'));?>
    </div>

    <div class="control-group">
		<?php echo form_label('Descripción : ', 'name', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'descripcion', 'id'=>'descripcion', 'value'=>$registro->descripcion, 'class'=>'form-control', 'placeholder'=>'Ingrese una Descripción', 'data-validacion-tipo'=>'requerido|min:5'));?>
    </div>
    
    <hr>
    
    <div class="control-group">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Guardar', 'class'=>'btn btn-success')); ?>
		<?php echo anchor('menu', 'Cancelar', 'class="btn btn-warning"'); ?>
    </div>
</article>
<?php echo form_close();?>

<script>
    $(document).ready(function(){
        $("#frm_menu").submit(function(){
            return $(this).validate();
        });
    })
</script>