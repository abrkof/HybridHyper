<?php defined('BASEPATH') OR exit('No direct script access allowed');

define('tbl0', 'datos_estudiante');
define('tbl2', 'grupo');
define('tbl3', 'grupo_usuario');
define('tbl4', 'menu');
define('tbl5', 'menu_perfil');
define('tbl7', 'perfil');
define('tbl8', 'submenu');
define('tbl9', 'submenu_perfil');
define('tbl11', 'usuario');