<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['site_folder'] = 'hybridhyper'; //Identificaci�n de la carpeta contenedora del sitio en desarrollo.
$config['sess_start'] = TRUE; //Seteamos un valor bool para el uso de las variables de sesi�n.
$config['sess_time_on'] = TRUE; //Seteamos un valor bool para el uso de tiempo en las variables de sesi�n.
$config['sess_time'] = 7200; //1440 segundos (24 minutos), 7200 segundos (dos horas o 120 minutos), 3600 segundos (1 hora o 60 minutos)
$config['time_zone'] = 'UTC'; //Seteamos la zona horaria para el sistema.

$config['enable_hooks'] = TRUE;