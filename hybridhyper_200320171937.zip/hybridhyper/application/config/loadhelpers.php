<?php defined('BASEPATH') OR exit('No direct script access allowed');
//construimos la clase de conexion a la base de datos
class LoadHelpers{
	//Seteamos una funcion publica de orden estatico para la carga de librerias.
    public static function helpers(){
		require_once MY_HELPERPATH.('helper_menu.php');
		require_once BASEPATH.('helpers/form_helper.php');
		require_once BASEPATH.('helpers/url_helper.php');
		require_once BASEPATH.('helpers/html_helper.php');
    }
}