﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Menu_Perfil extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Menu_Perfil = $this->load->model('Model_Menu_Perfil');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Seguridad (Menús)';
			$data['query'] = $this->Model_Menu_Perfil->all();
			$data['contenido'] = 'menu_perfil/index';
			$this->load->view('template/template',$data);
		}
    }
    //Creamos el crud de procesos
    public function procesos($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Seguridad (Menús)';
			$data['menus'] = $this->Model_Menu_Perfil->get_menus(); /* Lista de los Menús */
			$data['perfiles'] = $this->Model_Menu_Perfil->get_perfiles(); /* Lista de los Perfiles */
			$data['registro'] = $this->Model_Menu_Perfil->allFiltered($id);
			$data['contenido'] = 'menu_perfil/procesos';
			$this->load->view('template/template',$data);
		}
    }
    
    public function insert(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$registro['id'] = $_REQUEST['id'];
			$registro['menu_id'] = $_REQUEST['menu_id'];
			$registro['perfil_id'] = $_REQUEST['perfil_id'];
			
			//$myCallback = new Menu_PerfilLib();
			//Llamada al método de un objeto
			//if (call_user_func(array($myCallback, 'my_validation')));
	
			$registro['id'] > 0
				? $this->Model_Menu_Perfil->update($registro)
				: $this->Model_Menu_Perfil->insert($registro);
			
			redirect('menu_perfil');
		}
    }
    
    public function delete($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$this->Model_Menu_Perfil->delete($id);
			$this->redirect('menu_perfil');
		}
    }
}