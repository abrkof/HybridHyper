﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class SubMenu_Perfil extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_SubMenu_perfil = $this->load->model('Model_SubMenu_Perfil');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Seguridad (Sub Menús)';
			$data['query'] = $this->Model_SubMenu_perfil->all();
			$data['contenido'] = 'submenu_perfil/index';
			$this->load->view('template/template',$data);
		}
    }
    //Creamos el crud de procesos
    public function procesos($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Seguridad (Sub Menús)';
			$data['submenus'] = $this->Model_SubMenu_perfil->get_submenus(); /* Lista de los Sub Menús */
			$data['perfiles'] = $this->Model_SubMenu_perfil->get_perfiles(); /* Lista de los Perfiles */
			$data['registro'] = $this->Model_SubMenu_perfil->allFiltered($id);
			$data['contenido'] = 'submenu_perfil/procesos';
			$this->load->view('template/template',$data);
		}
    }
    
    public function insert(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$registro['id'] = $_REQUEST['id'];
			$registro['submenu_id'] = $_REQUEST['submenu_id'];
			$registro['perfil_id'] = $_REQUEST['perfil_id'];
	
			//$myCallback = new SubMenu_PerfilLib();
			//Llamada al método de un objeto
			//if (call_user_func(array($myCallback, 'my_validation')));
	
			$registro['id'] > 0
				? $this->Model_SubMenu_perfil->update($registro) 
				: $this->Model_SubMenu_perfil->insert($registro);
			
			redirect('submenu_perfil');
		}
    }
    
    public function delete($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$this->Model_SubMenu_perfil->delete($id);
			redirect('submenu_perfil');
		}
    }
}