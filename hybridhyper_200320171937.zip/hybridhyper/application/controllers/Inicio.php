﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase.
class Inicio extends Controller{ 
	//Constructor de la Clase
	function __construct(){
		parent::__construct();
		$this->usuariolib = $this->load->library('UsuarioLib');
	}

	public function index(){
        if($this->session->get_userdata('usuario_id')){
            redirect('inicio/home');
            exit;
        } else {
			$data['titulo'] = 'Inicio de Sesión';
			//$data['error_login'] = '';
			$this->load->view('inicio/inicio_sesion',$data);
		}
	}

	public function home() {
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Inicio';
			$data['contenido'] = 'inicio/index';
			$this->load->view('template/template',$data);
		}
	}

	public function acerca_de(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Acerca De';
			$data['contenido'] = 'inicio/acerca_de';
			$this->load->view('template/template',$data);
		}
	}

	public function acceso_denegado(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio/inicio_sesion');
            exit;
        } else {
			$data['titulo'] = 'Acceso Denegado';
			$data['contenido'] = 'inicio/acceso_denegado';
			$this->load->view('template/template',$data);
		}
	}

	public function ingresar(){
		if (call_user_func(array($this->usuariolib, 'login'))){
			redirect('inicio/home');
		} else {
			$data['error_login'] = ERROR_LOGIN;
			$this->load->view('inicio/inicio_sesion', $data);
		}
	}

	public function salir(){
		$this->session->sess_destroy();
		redirect('inicio/inicio_sesion');
	}

	public function cambiar_clave(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			if ($this->cambiook()){
				return FALSE;
			} else {
			redirect('inicio/home');
			}
		}
	}

	public function cambiook(){
		$act = $_REQUEST['clave_act'];
		$new = $_REQUEST['clave_new'];
		return $this->usuariolib->cambiarPWD(md5($act), md5($new));
	}

	public function error_pwdusr(){
		echo packstylecss('alertifyjs/css/alertify.min');
		echo packstylecss('alertifyjs/css/themes/default.min');
		echo packstylejs('alertifyjs/alertify.min');
		
		echo js('val_pass');
	}

}