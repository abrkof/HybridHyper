﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Usuario extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Usuario = $this->load->model('Model_Usuario');
		$this->usuariolib = $this->load->library('UsuarioLib');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Usuarios';
			$data['query'] = $this->Model_Usuario->all();
			$data['contenido'] = 'usuario/index';
			$this->load->view('template/template',$data);
		}
    }
    //Creamos el crud de procesos
    public function procesos($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Usuarios';
			$data['perfiles'] = $this->Model_Usuario->get_perfiles(); /* Lista de los Perfiles */
			$data['registro'] = $this->Model_Usuario->allFiltered($id);
			$data['contenido'] = 'usuario/procesos';
			$this->load->view('template/template',$data);
		}
    }
    
    public function insert(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$registro['id'] = $_REQUEST['id'];
			$registro['name'] = $_REQUEST['name'];
			$registro['login'] = $_REQUEST['login'];
			$registro['password'] = $_REQUEST['password'];
			$registro['email'] = $_REQUEST['email'];
			$registro['perfil_id'] = $_REQUEST['perfil_id'];
	
			//Llamada al método de un objeto
			//if (call_user_func(array($this->usuariolib, 'my_validation')));
	
			if ($registro['id'] > 0){
				$this->Model_Usuario->update($registro);
			} else {
				$this->Model_Usuario->insert($registro);
				$this->Model_Usuario->passrecovery($registro);
			}
			
			redirect('usuario');
		}
    }
    
    public function delete($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$this->Model_Usuario->delete($id);
			redirect('usuario');
		}
    }

	public function comprobar(){
		//Llamada al método de un objeto
		call_user_func(array($this->usuariolib, 'my_validation'));
	}

}