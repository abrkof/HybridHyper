﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Menu extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Menu = $this->load->model('Model_Menu');
		$this->menulib = $this->load->library('MenuLib');
		$this->menu_perfillib = $this->load->library('Menu_PerfilLib');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
		$data['titulo'] = 'Menús';
		$data['query'] = $this->Model_Menu->all();
		$data['contenido'] = 'menu/index';
		$this->load->view('template/template',$data);
    }
    //Creamos el crud de procesos
    public function procesos($id){
		$data['titulo'] = 'Menús';
		$data['registro'] = $this->Model_Menu->allFiltered($id);
		$data['contenido'] = 'menu/procesos';
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$registro['id'] = $_REQUEST['id'];
		$registro['name'] = $_REQUEST['name'];
		$registro['controlador'] = $_REQUEST['controlador'];
		$registro['accion'] = $_REQUEST['accion'];
		$registro['url'] = $_REQUEST['url'];
		$registro['orden'] = $_REQUEST['orden'];
		$registro['descripcion'] = $_REQUEST['descripcion'];

		$registro['id'] > 0 
			? $this->Model_Menu->update($registro)
			: $this->Model_Menu->insert($registro);
		
		redirect('menu');
    }
    
    public function delete($id){
		$this->Model_Menu->delete($id);
		redirect('menu');
    }
#**********************************************************************************#
    //Creamos el metodo de asiganción de permisos
    public function menu_perfiles($menu_id){
		/*if(isset($_REQUEST['id'])){
			$menu_id = $_REQUEST['id'];
		}*/
		$data['titulo'] = 'Menú Perfiles';
		//Cargar arreglos Izquierda y Derecha
		$perfiles = $this->menulib->get_perfiles_asig_noasig($menu_id);
		$data['query_izq'] = $perfiles[0];
		$data['query_der'] = $perfiles[1];
		$data['contenido'] = 'menu/menu_perfiles';
		$this->load->view('template/template',$data);
    }

	public function mp_noasig(){
			$perfil_id = $_REQUEST['perfil_id'];
			$menu_id = $_REQUEST['menu_id'];
			$this->menu_perfillib->quitar_acceso($perfil_id, $menu_id);
			redirect('menu/menu_perfiles/'.$menu_id);
	}

	public function mp_asig(){
		$perfil_id = $_REQUEST['perfil_id'];//$this->uri->segment(3);
		$menu_id = $_REQUEST['menu_id'];//$this->uri->segment(4);
		$this->menu_perfillib->dar_acceso($perfil_id, $menu_id);
		redirect('menu/menu_perfiles/'.$menu_id);
	}
    //Creamos una acción para cargar el ordenar los menús
    public function menu_ordenar(){
		$data['titulo'] = 'Odenando Menús';
		$data['query'] = $this->Model_Menu->allx();
		$data['contenido'] = 'menu/menu_ordenar';
		$this->load->view('template/template',$data);
    }
    //Creamos una acción para actualizar el orden de los menús
    public function update_orden(){
		//aquí ordenaremos los articulos con ajax
		//array con el nuevo orden de nuestros registros
		$menus_ordenados = $_REQUEST['menu'];
		$pos = 1;
		foreach ($menus_ordenados as $key){
		//actualizamos el campo orden_articulo
		$stmt = $this->db->prepare('UPDATE menu SET orden = ? WHERE id = ?');
		$stmt->execute(array($pos, $key));
			$pos++;
		}
		echo "El Menú se ha actualizado con Exito";
	}

}