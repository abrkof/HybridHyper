﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Perfil extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Perfil = $this->load->model('Model_Perfil');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Perfiles';
			$data['query'] = $this->Model_Perfil->all();
			$data['contenido'] = 'perfil/index';
			$this->load->view('template/template',$data);
		}
    }
    //Creamos el crud de procesos
    public function procesos($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Perfiles';
			$data['registro'] = $this->Model_Perfil->allFiltered($id);
			$data['contenido'] = 'perfil/procesos';
			$this->load->view('template/template',$data);
		}
    }
    
    public function insert(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$registro['id'] = $_REQUEST['id'];
			$registro['name'] = $_REQUEST['name'];
			$registro['descripcion'] = $_REQUEST['descripcion'];

			$registro['id'] > 0 
				? $this->Model_Perfil->update($registro)
				: $this->Model_Perfil->insert($registro);
			
			redirect('perfil');
		}
    }
    
    public function delete($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$this->Model_Perfil->delete($id);
			redirect('perfil');
		}
    }

}