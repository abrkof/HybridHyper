﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Datos_Estudiante extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Datos_Estudiante = $this->load->model('Model_Datos_Estudiante'); 
		$this->pdf = $this->load->library('Pdf');
		$this->pagination = $this->load->baseLibrary('pagination');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			//$page = $this->getInt('page');
			//$records  = $this->getInt('records');
			//$condition = '';
			//$this->_view->assign('posts', $this->pagination->paginate($this->_post->getPrueba($condicion), $page, $records));
			//$this->_view->assign('paginacion', $paginador->getView('paginacion_ajax'));
			//$this->pagination->paginate($this->Model_Datos_Estudiante->all(), $page, $records);
			
			$page = '5';
			$records  = '3';
			
			$data['titulo'] = 'Bienvenido';
			$data['query'] = $this->Model_Datos_Estudiante->all();//$this->pagination->paginate($this->Model_Datos_Estudiante->all(), $page, $records);
			# JSON-encode the response
			//$json_response = json_encode($this->Model_Datos_Estudiante->all());
			//$data['json_response'] = json_encode($this->Model_Datos_Estudiante->all());
			# Return the response
			//echo $json_response;
			$data['contenido'] = 'datos_estudiante/index';//$this->pagination->view('pagination/pagination');
			$this->load->view('template/template',$data);
		}
    }
	public function asd(){
		//Limito la busqueda 
		$pagination = 5; 
		//examino la página a mostrar y el inicio del registro a mostrar 
		$page = 1;
		$start = 0;
		
		if(isset($_GET["page"])){
			$page = $_GET["page"];
			$start = ($page - 1) * $pagination;
		}
			
		//veo el número total de campos que hay en la tabla con esa búsqueda 
		$total_rows = count($this->Model_Datos_Estudiante->all());
		//echo count($total_rows);
		
		//calculo el total de páginas 
		$total_pages = ceil($total_rows / $pagination); 
		/*//pongo el número de registros total, el tamaño de página y la página que se muestra 
		echo "Número de registros encontrados: " . $total_rows . "<br>"; 
		echo "Se muestran páginas de " . $pagination . " registros cada una<br>"; 
		echo "Mostrando la página " . $page . " de " . $total_pages . "<p>";*/
			
		//construyo la sentencia SQL 
		$query = $this->Model_Datos_Estudiante->all_paginate($start, $pagination);
		foreach($query as $registro){
			echo $registro['nombres']."<br>";
		}
		
		
		//muestro los distintos índices de las páginas, si es que hay varias páginas 
		if ($total_pages > 1){ 
			for ($i = 1;$i <= $total_pages; $i++){ 
			   if ($page.'?' == $i){
				  //si muestro el índice de la página actual, no coloco enlace 
				  echo $page.' '; 
				} else {
				  //si el índice no corresponde con la página mostrada actualmente, coloco el enlace para ir a esa página 
				  echo '<a href="'.base_url('').'datos_estudiante/asd/?page='.$i.'">'.$i.'</a> '; 
				}
			} 
		} 
	}

    public function create(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Datos Estudiante';
			$data['contenido'] = 'datos_estudiante/create';
			$this->load->view('template/template',$data);
		}
    }
    
    public function insert(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$registro['nombres'] = $_REQUEST['nombres'];
			$registro['apellidos'] = $_REQUEST['apellidos'];
			$registro['genero'] = $_REQUEST['genero'];
			$registro['fecha_nacimiento'] = $_REQUEST['fecha_nacimiento'];
			$registro['created'] = date('Y/m/d H:i:s');
			$registro['updated'] = date('Y/m/d H:i:s');
	
			$this->Model_Datos_Estudiante->insert($registro);
			
			redirect('datos_estudiante');
		}
    }	
	
    public function edit($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Datos Estudiante';
			$data['registro'] = $this->Model_Datos_Estudiante->allFiltered($id);
			$data['contenido'] = 'datos_estudiante/edit';
			$this->load->view('template/template',$data);
		}
    }


    public function update(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$registro['id_dat_est'] = $_REQUEST['id_dat_est'];
			$registro['nombres'] = $_REQUEST['nombres'];
			$registro['apellidos'] = $_REQUEST['apellidos'];
			$registro['genero'] = $_REQUEST['genero'];
			$registro['fecha_nacimiento'] = $_REQUEST['fecha_nacimiento'];
			$registro['updated'] = date('Y/m/d H:i:s');
	
			$this->Model_Datos_Estudiante->update($registro);
			
			redirect('datos_estudiante');
		}
    }
    
    public function delete($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$this->Model_Datos_Estudiante->delete($id);
			redirect('datos_estudiante');
		}
    }

	public function pdf($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
            $registro = $this->Model_Datos_Estudiante->allFiltered($id);
        //Creacion del PDF
 
        /*
         * Se crea un objeto de la clase Pdf, recuerda que la clase Pdf
         * heredó todos las variables y métodos de fpdf
         */
        //$this->pdf = new Pdf();
		$this->pdf->SetDatosHeader($datosHeader);
        // Agregamos una página
        $this->pdf->AddPage();
        // Define el alias para el número de página que se imprimirá en el pie
        $this->pdf->AliasNbPages();
 
        /* Se define el titulo, márgenes izquierdo, derecho y
         * el color de relleno predeterminado
         */
        $this->pdf->SetTitle("Ficha de Matricula");
        $this->pdf->SetLeftMargin(15);
        $this->pdf->SetRightMargin(15);
        $this->pdf->SetFillColor(200,200,200);
 
        //Se define el formato de fuente: Arial, negritas, tamaño 9
        $this->pdf->SetFont('Arial', 'B', 9);
        /*
         * TITULOS DE COLUMNAS
         *
         * $this->pdf->Cell(Ancho, Alto,texto,borde,posición,alineación,relleno);
         */

        /*$this->pdf->Cell(15,7,'NUM','TBL',0,'C','1');
        $this->pdf->Cell(25,7,'Nombres','TB',0,'L','1');
        $this->pdf->Cell(25,7,'Apellidos','TB',0,'L','1');
        $this->pdf->Cell(25,7,'Genero','TB',0,'L','1');
        $this->pdf->Cell(40,7,'Fecha Nacimiento','TB',0,'C','1');
        $this->pdf->Cell(25,7,'Grado','TB',0,'L','1');
        $this->pdf->Cell(25,7,'Sección','TBR',0,'C','1');
        $this->pdf->Ln(7);*/
		
        //La variable $x se utiliza para mostrar un número consecutivo
        $x = 1;
        //foreach($query as $registro){
            // se imprime el numero actual y despues se incrementa el valor de $x en uno
            //$this->pdf->Cell(15,5,$x++,'BL',0,'C',0);
            // Se imprimen los datos de cada estudiante
			$this->pdf->Ln(9);
			$this->pdf->Cell(37,5,'Nombre del Estudiante: ',0,0,'L').
            $this->pdf->Cell(40,5,utf8_decode($registro->nombres),'B',0,'L',0).
            $this->pdf->Cell(40,5,utf8_decode($registro->apellidos),'B',0,'L',0);
			$this->pdf->Cell(14,5,utf8_decode('Género: '),0,0,'L').
            $this->pdf->Cell(20,5,utf8_decode($registro->genero == 1 ? 'Masculino' : 'Femenino'),'B',0,'L',0);
			$this->pdf->Cell(12,5,'Fecha:',0,0,'L').
            $this->pdf->Cell(30,5,utf8_decode($registro->fecha_nacimiento),'B',0,'L',0);
			$this->pdf->Ln(9);
		//}
			
        //}
		
        /*
         * Se manda el pdf al navegador
         *
         * $this->pdf->Output(nombredelarchivo, destino);
         *
         * I = Muestra el pdf en el navegador
         * D = Envia el pdf para descarga
         *
         */
		 ob_end_clean();
		 //$this->pdf->Cell(25,5,html_entity_decode($estudiante->turno_name));
		 //$this->pdf->Cell(25,5,html_entity_decode("&aacute;").$estudiante->turno_name);
		 //utf8_encode();
        $this->pdf->Output($registro->apellidos.', '.$registro->nombres.' - '."Ficha Matricula.pdf", 'I');
		}
	}

	/*public function pdfx($nombres, $apellidos){
		$this->pdf->AddPage();
		$this->pdf->SetFont('Arial', 'B', 16);
		$this->pdf->Cell(40,10,utf8_decode($nombres.' '.$apellidos));
		$this->pdf->Output();
	}*/

}