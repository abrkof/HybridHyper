﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Grupo_Usuario extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Grupo_Usuario = $this->load->model('Model_Grupo_Usuario');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Grupo de Usuarios';
			$data['query'] = $this->Model_Grupo_Usuario->all();
			$data['contenido'] = 'grupo_usuario/index';
			$this->load->view('template/template',$data);
		}
    }
    //Creamos el crud de procesos
    public function procesos($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$data['titulo'] = 'Grupo de Usuarios';
			$data['registro'] = $this->Model_Grupo_Usuario->allFiltered($id);
			$data['grupos'] = $this->Model_Grupo_Usuario->get_grupos(); /* Lista de los Grupos */
			$data['usuarios'] = $this->Model_Grupo_Usuario->get_usuarios(); /* Lista de los Grupos */
			$data['contenido'] = 'grupo_usuario/procesos';
			$this->load->view('template/template',$data);
		}
    }
    
    public function insert(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$registro['id'] = $_REQUEST['id'];
			$registro['name'] = $_REQUEST['name'];
			$registro['grupo_id'] = $_REQUEST['grupo_id'];
			$registro['usuario_id'] = $_REQUEST['usuario_id'];
			$registro['descripcion'] = $_REQUEST['descripcion'];
	
			//$myCallback = new UsuarioLib();
			//Llamada al método de un objeto
			//if (call_user_func(array($myCallback, 'my_validation')));
	
			$registro['id'] > 0
				? $this->Model_Grupo_Usuario->update($registro)
				: $this->Model_Grupo_Usuario->insert($registro);
			
			redirect('grupo_usuario');
		}
    }
    
    public function delete($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
			$this->Model_Grupo_Usuario->delete($id);
			redirect('grupo_usuario');
		}
    }
}