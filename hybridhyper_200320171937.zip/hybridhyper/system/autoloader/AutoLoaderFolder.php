﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
#This is CORE of HybridHyper - ABRKOF, ABRKOF - HybridHyper, HybridHyper, HybridHyper ABRKOF, ABRKOF HybridHyper, ABRKOF.©
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * AutoloaderFolder File
 *
 * Inicializa todos los componentes requeridos para el funcionamiento total del framework.
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Loader
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
//Método para cargar todos los ficheros de un directorio.
function include_folder($hybridhyperPath,$read=false){
    //Separador de directorios.
    $slice = '/';
    //Verificamos si es la primera vez que usamos la función.
    if(!$read){
        //Obtenemos los dos últimos caracteres.
        $tree = substr($hybridhyperPath,-2);
        if($tree=='.*'){
            //Descriminamos el asterisco y activamos la recursividad.
            $hybridhyperPath = preg_replace('!\.\*$!','',$hybridhyperPath);
            $read = TRUE;
        }
        //Obtenemos el document_root del archivo en caso de usarse.
        $hybridhyperPath = preg_replace('!^root\.!',$_SERVER['DOCUMENT_ROOT'].$slice,$hybridhyperPath);
        //Cambiamos el punto por el separador.
        $hybridhyperPath = str_replace('.',$slice,$hybridhyperPath);
    }
    //Abrimos el directorio.
    if ($handle = opendir($hybridhyperPath)){
        while (FALSE !== ($file = readdir($handle))){ //handle = Manejador.
            if ($file != "." && $file != ".."){
                //Si es un directorio lo recorremos en caso de activar la recursividad.
                if(is_dir($hybridhyperPath.$slice.$file) and $read){
                    include_folder($hybridhyperPath.$slice.$file,TRUE);
                } else {
                    $ext = substr(strtolower($file),-3);
                    if($ext == 'php') @include_once($hybridhyperPath.$slice.$file);
                }
            }
        }
        //Cerramos el directorio.
        closedir($handle);
    }
}

/* End of file AutoLoaderFolder.php */
/* Location: ./system/autoloader/AutoLoaderFolder.php */