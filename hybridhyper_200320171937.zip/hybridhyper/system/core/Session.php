﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Session Class
 *
 * Carga las configuraciones de sesiones de usuarios.
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

//Clase para inicializar las variables de sesión.
class Session{
    public static function sess_start(){ //Metodo para inicializar las sesiones.
        if (SESSION_START == TRUE){
			session_start();
			session_name('HybridHyper');
		} else {
			session_destroy();
			session_name('FALSE');
		}
    }
    
    public static function sess_destroy($usuario = FALSE){ //Metodo para destruir variables de sesión.
        if($usuario){
            if(is_array($usuario)){ //Veificamos el array con los datos del usuario logeado.
                for($i = 0; $i < count($usuario); $i++){ //Recorremos el arreglo en busca del usuario.
                    if(isset($_SESSION[$usuario[$i]])){ //verificamos si existe el usuario.
                        unset($_SESSION[$usuario[$i]]); //destruimos la variable que lo contiene.
                    }
                }
            } else {
                if(isset($_SESSION[$usuario])){ //verficamos si existe el usuario.
                    unset($_SESSION[$usuario]); //destruimos la variable que lo contiene.
                }
            }
        } else {
            session_destroy(); //Destruimos la sesión
        }
    }
    
    public static function set_userdata($usuario, $value){ //Método contenedor de las variables de sesión.
        if(!empty($usuario)) //Si no esta vacia.
        $_SESSION[$usuario] = $value; //Se llena con los datos del usuario a logear.
    }
    
    public static function get_userdata($usuario){ //Método para obtener los datos del usuario logeado.
        if(isset($_SESSION[$usuario])) //Si existe.
			return $_SESSION[$usuario]; //Cargamos sus datos.
    }
    
    public static function sess_time(){ //Método para crear tiempo de sesiones.
		$inactivity = SESSION_TIME; //Segundos que tardara en cerrarse la sesión.
		if(isset($_SESSION['timeout'])){
			$session_life = time() - $_SESSION['timeout'];
			if($session_life > $inactivity){ 
				session_destroy();
				redirect('inicio/inicio_sesion'); 
			}
		}
		$_SESSION['timeout'] = time();
    }

}

/* End of file Session.php */
/* Location: ./system/core/Session.php */