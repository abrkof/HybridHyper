<?php defined('BASEPATH') OR exit('Acceso no permitido al n�cleo del sistema, ABRKOF');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Singleton Class
 *
 * Carga las configuraciones de sesiones de usuarios.
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

//Clase para gestionar un super objeto.
class Singleton{
	private static $instance; //$ABRKOF
	private $storage;

	//Nos aseguramos que no se pueda instanciar la clase Singleton.
	private function __construct(){
	
	}
	
	//Asigna todos los objetos de una clase que fueron instanciadas por el
	//Archivo de arranque (start.php) para las variables de clases locales
	//Contenidas en el archivo principal del core llamado "HybridHyper.php"
	//Por lo que ABRKOF ($instance) puede funcionar como un gran super objeto.
	public static function getInstance(){
		if(!self::$instance instanceof self){ //Se verifica si el atributo no contiene una instancia de una clase.
			self::$instance = new Singleton(); //Crea una instancia de la clase solicitada.
		}
		//De haber ya una instancia, retornamos la clase ya instanciada.
		return self::$instance; //
	}
	//M�todo m�gico.
	public function __set($key, $val){ //Llave, Valor.
		$this->storage[$key] = $val; //Arreglo asociativo con el nombre de objetos.
	}
	//M�todo m�gico.
	public function __get($key){
		if(isset($this->storage[$key])){ //Clave del elemeto del arreglo del elemento instanciado.
			return $this->storage[$key]; //Si existe un objeto, se retornan los elementos del arreglo del objeto contenido.
		}
		return false;
	}

}