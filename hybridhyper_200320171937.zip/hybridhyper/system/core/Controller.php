﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */
 
/**
 * Application Controller Class
 *
 * Esta clase objeto es la superclase que cada libreria in
 * HybridHyper será asignado a.
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
 
//Creamos una clase abstracta, clase firmada, interface.
abstract class Controller{
    private static $instance;
	private $ABRKOF;
	static $load; //Creamos una variable u objeto de tipo static.
	static $session; //Creamos una variable u objeto de tipo static.
	static $db; //Creamos una variable u objeto de tipo protegido.
	static $dbx; //Creamos una variable u objeto de tipo static.
    
    public function __construct(){ //Inicializamos el contrstuctor.
		self::$instance = & $this;
		$this->ABRKOF = Singleton::getInstance();
		$this->load = $this->ABRKOF->load; //Instanciamos.
		$this->session = $this->ABRKOF->session; //Instanciamos.
		$this->dbx = $this->ABRKOF->dbx; //Cargara las SQL nativo de clase PDO
		
		$this->db = $this->ABRKOF->ActiveRecord; //Instanciamos.

		$ABRKOF = & get_instance();
		foreach (get_object_vars($ABRKOF) as $key => $var){
			if (!isset($this->$key)){
				$this->$key = & $ABRKOF->$key;
			}
		}

    }
    
    abstract public function index(); //Método o función abstracta.
	//Asigna todos los objetos de una clase que fueron instanciadas por el
	//Archivo de arranque (start.php) para las variables de clases locales
	//Contenidas en el archivo principal del core llamado "HybridHyper.php"
	//Por lo que ABRKOF puede funcionar como un gran super objeto.
	public static function &get_instance(){
		return self::$instance;
	}

}

/* End of file Controller.php */
/* Location: ./system/core/Controller.php */