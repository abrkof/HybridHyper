﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Common Class
 *
 * Carga las clases base y ejecuta la solicitud.
 *
 * @package		HybridHyper
 * @subpackage	HybridHyper
 * @category	Common Functions
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

//Creamos la clase que cargara todas las librerias del sistema.
class Common{
    private $controller; //Creamos una variable de tipo privada.
	//private $load = array(); //Creamos una variable de tipo pública. 
	protected $module; //Creamos una variable de tipo privada.
	protected $session; //Creamos un variable u objeto de tipo pública.
	protected $_ci_cached_vars = array();
	protected $css;
	private $ABRKOF;
	protected $db;
	protected $_ci_view_paths =	array(VIEWSPATH	=> TRUE);
    
    public function __construct(Loader $request){ //Inicializamos el constructor, cargamos la clase Loader.
		$this->ABRKOF = Singleton::getInstance();
		$this->module = $request->getModule(); //Instanciamos.
		$this->controller = $request->getController(); //Seteamos los valores que se obtienen del controlador.
		$this->session = $this->ABRKOF->session; //Instanciamos.
		$this->_ci_view_paths = array_merge($this->_ci_view_paths, array(APPPATH.'views/' => TRUE));
    }

	public function view($view, $vars = array(), $return = FALSE)
	{
		return $this->_ci_load(array('_ci_view' => $view, '_ci_vars' => $this->_ci_object_to_array($vars), '_ci_return' => $return));
	}

	public function vars($vars, $val = '')
	{
		if (is_string($vars))
		{
			$vars = array($vars => $val);
		}

		$vars = $this->_ci_object_to_array($vars);

		if (is_array($vars) && count($vars) > 0)
		{
			foreach ($vars as $key => $val)
			{
				$this->_ci_cached_vars[$key] = $val;
			}
		}

		return $this;
	}


	public function clear_vars()
	{
		$this->_ci_cached_vars = array();
		return $this;
	}

	public function get_var($key)
	{
		return isset($this->_ci_cached_vars[$key]) ? $this->_ci_cached_vars[$key] : NULL;
	}

	public function get_vars(){
		return $this->_ci_cached_vars;
	}

	protected function _ci_object_to_array($object)
	{
		return is_object($object) ? get_object_vars($object) : $object;
	}

	public function file($path, $return = FALSE){
		return $this->load(array('path' => $path, 'return' => $return));
	}

	protected function _ci_load($_ci_data)
	{
		// Set the default data variables
		foreach (array('_ci_view', '_ci_vars', '_ci_path', '_ci_return') as $_ci_val)
		{
			$$_ci_val = isset($_ci_data[$_ci_val]) ? $_ci_data[$_ci_val] : FALSE;
		}

		$file_exists = FALSE;

		// Set the path to the requested file
		if (is_string($_ci_path) && $_ci_path !== '')
		{
			$_ci_x = explode('/', $_ci_path);
			$_ci_file = end($_ci_x);
		}
		else
		{
			$_ci_ext = pathinfo($_ci_view, PATHINFO_EXTENSION);
			$_ci_file = ($_ci_ext === '') ? $_ci_view.'.php' : $_ci_view;

			foreach ($this->_ci_view_paths as $_ci_view_file => $cascade)
			{
				if (file_exists($_ci_view_file.$_ci_file))
				{
					$_ci_path = $_ci_view_file.$_ci_file;
					$file_exists = TRUE;
					break;
				}

				if ( ! $cascade)
				{
					break;
				}
			}
		}

		if ( ! $file_exists && ! file_exists($_ci_path))
		{
			show_error('Unable to load the requested file: '.$_ci_file);
		}

		// This allows anything loaded using $this->load (views, files, etc.)
		// to become accessible from within the Controller and Model functions.
		$_ci_CI =& get_instance();
		foreach (get_object_vars($_ci_CI) as $_ci_key => $_ci_var)
		{
			if ( ! isset($this->$_ci_key))
			{
				$this->$_ci_key =& $_ci_CI->$_ci_key;
			}
		}

		/*
		 * Extract and cache variables
		 *
		 * You can either set variables using the dedicated $this->load->vars()
		 * function or via the second parameter of this function. We'll merge
		 * the two types and cache them so that views that are embedded within
		 * other views can have access to these variables.
		 */
		if (is_array($_ci_vars))
		{
			foreach (array_keys($_ci_vars) as $key)
			{
				if (strncmp($key, '_ci_', 4) === 0)
				{
					unset($_ci_vars[$key]);
				}
			}

			$this->_ci_cached_vars = array_merge($this->_ci_cached_vars, $_ci_vars);
		}
		extract($this->_ci_cached_vars);

		/*
		 * Buffer the output
		 *
		 * We buffer the output for two reasons:
		 * 1. Speed. You get a significant speed boost.
		 * 2. So that the final rendered template can be post-processed by
		 *	the output class. Why do we need post processing? For one thing,
		 *	in order to show the elapsed page load time. Unless we can
		 *	intercept the content right before it's sent to the browser and
		 *	then stop the timer it won't be accurate.
		 */
		ob_start();

		// If the PHP installation does not support short tags we'll
		// do a little string replacement, changing the short tags
		// to standard PHP echo statements.
		if ( ! is_php('5.4') && ! ini_get('short_open_tag') && config_item('rewrite_short_tags') === TRUE)
		{
			echo eval('?>'.preg_replace('/;*\s*\?>/', '; ?>', str_replace('<?=', '<?php echo ', file_get_contents($_ci_path))));
		}
		else
		{
			include($_ci_path); // include() vs include_once() allows for multiple views with the same name
		}

		log_message('info', 'File loaded: '.$_ci_path);

		// Return the file data if requested
		if ($_ci_return === TRUE)
		{
			$buffer = ob_get_contents();
			@ob_end_clean();
			return $buffer;
		}

		/*
		 * Flush the buffer... or buff the flusher?
		 *
		 * In order to permit views to be nested within
		 * other views, we need to flush the content back out whenever
		 * we are beyond the first level of output buffering so that
		 * it can be seen and included properly by the first included
		 * template and any subsequent ones. Oy!
		 */
		if (ob_get_level() > $this->_ci_ob_level + 1)
		{
			ob_end_flush();
		}
		else
		{
			$_ci_CI->output->append_output(ob_get_contents());
			@ob_end_clean();
		}

		return $this;
	}

    public function viewx($view, $vars = array(), $val = ''/*array $vars = NULL*/){ //$vars Es el contenedor de nuestras variables, es un arreglo(Vector) del tipo llave => valor, opcional.
		if($this->module){
            $pathView = APPPATH.('modules/'.$this->module.'/views/'.$view.'.php'); //Establecemos la ruta de las vistas de los modulos.
        } else {
			$pathView = APPPATH.('views/'.$view.'.php'); //De no existir, se carga la ruta de las vistas por defecto.
		}
		//echo '<br><br><br>'.print_r($pathView);
        $this->load = new Common (new Loader); //Instanciamos.
		$this->db = $this->ABRKOF->activeRecord; //Instanciamos.
		// Set the default data variables
		foreach (array('view', 'vars', 'path', 'return') as $val){
			$$val = isset($data[$val]) ? $data[$val] : FALSE;
		}

		$file_exists = FALSE;

		// Set the path to the requested file
		if (is_string($path) && $path !== ''){
			$x = explode('/', $path);
			$file = end($x);
		} else {
			$ext = pathinfo($view, PATHINFO_EXTENSION);
			$file = ($ext === '') ? $view.'.php' : $view;

			foreach ($this->view_paths as $view_file => $cascade){
				if (file_exists($view_file.$file)){
					$path = $view_file.$file;
					$file_exists = TRUE;
					break;
				}

				if ( ! $cascade)
				{
					break;
				}
			}
		}
		if(is_readable($pathView)){ //Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			$CI =& get_instance();
			foreach (get_object_vars($CI) as $key => $var){
				if ( ! isset($this->$key)){
					$this->$key =& $CI->$key;
				}
			}
			if (is_array($vars)){
				foreach (array_keys($vars) as $key){
					if (strncmp($key, '', 4) === 0){
						unset($vars[$key]);
					}
				}
				$this->cached_vars = array_merge($this->cached_vars, $vars); //Almacenamos las variables en un objeto.
			}
			extract($this->cached_vars); //Las extraemos para su posterior utilización.
			ob_start();
			$buffer = ob_get_contents();
			@ob_end_clean();
			return $buffer;

			include ($pathView); // include() vs include_once() permite múltiples vista con el mismo nombre.
			return true;
		}
        else {//Error 404
            echo css('bootstrap.min');
			throw new Exception('Error, no se puede cargar la vista - '.$view.'.php'); //Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }

    public function template($template, $vars = array() /*array $vars = NULL*/){ //$vars Es el contenedor de nuestras variables, es un arreglo(Vector) del tipo llave => valor, opcional.
		if($this->module){
            $pathTemplate = APPPATH.('modules/'.$this->module.'/views/template/'.$template.'.php'); //Establecemos la ruta de las vistas de los modulos.
        } else {
			$pathTemplate = APPPATH.('views/template/'.$template.'.php'); //De no existir, se carga la ruta de las vistas por defecto.
		}
		
        $this->load = new Common (new Loader); //Instanciamos.
        if(is_readable($pathTemplate)){ //Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			//Si existen variables para asignar, las pasamos una a una.
			if (is_array($vars)){
				$this->cached_vars = array_merge($vars); //Almacenamos las variables en un objeto.
			}
			extract($this->cached_vars); //Las extraemos para su posterior utilización.
				include_once $pathTemplate;
		} 
        else {//Error 404
            echo css('bootstrap.min');
			throw new Exception('Error, no se puede cargar la plantilla - '.$template.'.php'); //Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
		
    }

    public function model($model){ //Protegemos el metodo y sus lógica.
		if($this->module){
            $pathModel = APPPATH.('modules/'.$this->module.'/models/'.$model.'.php'); //Establecemos la ruta de las vistas de los modulos.
        } else {
			$pathModel = APPPATH.('models/'.$model.'.php'); //De no existir, se carga la ruta de las vistas por defecto.
		}        
        if(is_readable($pathModel)){ //Verificamos si existe.
            require_once $pathModel; //Lo incluimos.
            $model = new $model; //Lo instanciamos.
            return $model; //Lo cargamos.
        }
        else {
            echo css('bootstrap.min');
			throw new Exception('Error al cargar el modelo - '.$model.'.php'); //Si no existe, cargamos un mesaje de error.
        }
    }

    public function library($library){ //Protegemos el método para las libreias del sistema.
        $library = $library;
		$pathLibrary = APPPATH .'libraries/'.$library.'.php'; //Seteamos el origen del la clase.
        //$this->model = new Model (); //Instanciamos a la clase Model.
        if(is_readable($pathLibrary)){ //Verificamos si existe.
            require_once $pathLibrary; //La incluimos o cargamos.
			$library = new $library; //La instanciamos.
			return $library; //La cargamos.
        }
        else{
            echo css('bootstrap.min');
			throw new Exception('Error al cargar la libreria - '.$library.'.php'); //Si no existe, cargamos un mesaje de error.
        }
    }

    public function baseLibrary($baseLibrary){ //Protegemos el método para las libreias del sistema.
        $baseLibrary = $baselibrary;
		$pathBaseLibrary = BASEPATH .'libraries/'.$baseLibrary.'.php'; //Seteamos el origen del la clase.
        //$this->model = new Model (); //Instanciamos a la clase Model.
        if(is_readable($pathBaseLibrary)){ //Verificamos si existe.
            require_once $pathBaseLibrary; //La incluimos o cargamos.
			$baseLibrary = new $baseLibrary; //La instanciamos.
			return $baseLibrary; //La cargamos.
        }
        else{
            echo css('bootstrap.min');
			throw new Exception('Error al cargar la libreria del sistema - '.$baseLibrary.'.php'); //Si no existe, cargamos un mesaje de error.
        }
    }

}

/* End of file Common.php */
/* Location: ./system/core/Common.php */