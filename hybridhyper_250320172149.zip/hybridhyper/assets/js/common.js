function selectMunicipio(depto_id){
	if(depto_id!="-1"){
		loadData('munpo',depto_id);
		$("#canton_id").html("<option value='-1'>::.Canton.::</option>");	
	}else{
		$("#munpo_id").html("<option value='-1'>::.Municipio.::</option>");
		$("#canton_id").html("<option value='-1'>::.Canton.::</option>");
		$("#caserio_id").html("<option value='-1'>::.Caserio.::</option>");
	}
}

function selectCanton(munpo_id){
	if(munpo_id!="0"){
		loadData('canton',munpo_id);
	}else{
		$("#canton_id").html("<option value='-1'>::.Canton.::</option>");
	}
}

function selectCaserio(canton_id){
	if(canton_id!="-1"){
		loadData('caserio',canton_id);
	}else{
		$("#caserio_id").html("<option value='-1'>::.Caserio.::</option>");		
	}
}

function loadData(loadType,loadId){
	var dataString = 'loadType='+ loadType +'&loadId='+ loadId;
	$("#"+loadType+"_loader").show();
    $("#"+loadType+"_loader").fadeIn(400).html('Cargando... <img src="../../img/loading.gif" />');
	$.ajax({
		type: "POST",
		url: "loadData",
		data: dataString,
		cache: false,
		success: function(result){
			$("#"+loadType+"_loader").hide();
			$("#"+loadType+"_id").html("<option value='-1'>::.SELECCIONE.::</option>");  
			$("#"+loadType+"_id").append(result);  
		}
	});
}






function munpos(str1){
var xmlhttp;

if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else{// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function(){
  if (xmlhttp.readyState==4 && xmlhttp.status==200){
    document.getElementById("munpo").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("POST","http://www.abrkof.com/regsys/clientes/munpos",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("depto_id="+str1);
}

function cantones(str2){
var xmlhttp;

if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else{// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function(){
  if (xmlhttp.readyState==4 && xmlhttp.status==200){
    document.getElementById("canton").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("POST","http://www.abrkof.com/regsys/clientes/cantones",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("munpo_id="+str2);
}

function caserios(str3){
var xmlhttp;

if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else{// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function(){
  if (xmlhttp.readyState==4 && xmlhttp.status==200){
    document.getElementById("caserio").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("POST","http://www.abrkof.com/regsys/clientes/caserios",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("canton_id="+str3);
}



