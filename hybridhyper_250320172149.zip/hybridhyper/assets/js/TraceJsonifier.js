<script>
'use strict';

var assert = require('assert');

function TraceJsonifier (roadmap) {
    assertArguments(roadmap);

    this.roadmap = roadmap;
}

TraceJsonifier.prototype.jsonifyTrace = function (trace) {
    var jsonifiedTrace = {};

    this.roadmap.forEach(function (element) {
        jsonifiedTrace[element.name] = parseElement(element, trace);
    });

    return jsonifiedTrace;
}

function parseElement (element, trace) {
    var parsedElement;

    switch (element.type) {
        case 'struct':
            parsedElement = parseStructElement(element, trace);
            break;
        case 'vector':
            parsedElement = parseVectorElement(element, trace);
            break;
        default:
            parsedElement = extractElementFromTrace(element, trace);
            break;
    }

    return parsedElement;
}

function parseVectorElement (vectorElement, trace) {
    var children = vectorElement.elements,
        vector   = [];

    children.forEach(function (child) {
        vector.push(parseElement(child, trace));
    });

    return vector;
}

function parseStructElement (structElement, trace) {
    var children = structElement.elements,
        struct   = {};

    children.forEach(function (child) {
        struct[child.name] = parseElement(child, trace);
    });

    return struct;
}

function extractElementFromTrace (element, trace) {
    return trace.substring(element.initialPosition, element.finalPosition);
}

function assertArguments (roadmap) {
    assert(roadmap, 'Roadmap cannot be null');
}

module.exports = TraceJsonifier;
</script>