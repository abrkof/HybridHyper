﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Inicialización de los archivos del sistema.
 *
 * Carga las clases base y ejecuta las solicitudes, procesa las llamadas a los controladores y a los metodos.
 *
 * @package		HybridHyper
 * @subpackage	HybridHyper
 * @category	Front-Controller
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

//Creamos la super clase que trabaja como enrutador.
class HybridHyper{
    //instanciamos la clase que interactua con la url del navegador.
	public static function core(Loader $request){
		$module = $request->getModule(); //Seteamos el modulo.
		$controller = $request->getController(); //Seteamos el nombre del controlador pricipal.
        $pathController = APPPATH.'controllers/'.$controller.'.php'; //Asiganmos el patrón de carga.
        $method = $request->getMethod(); //Seteamos el metodo.
        $args = $request->getArgs(); //Seteamos sus argumentos.

        //------------ Inicio Módulos ------------
		if($module){
            $patchModule = APPPATH.'modules/'.$module.'.php';
            
            if(is_readable($patchModule)){
                require_once $patchModule;
                $pathController = APPPATH.'modules/'.$module.'/controllers/'.$controller.'.php';
            } else {
                echo css('bootstrap.min');
				throw new Exception('Error al cargar el módulo - '.$module);
            }
        } else {
            $pathController = APPPATH.'controllers/'.$controller.'.php';
        }
		//------------ Fin Módulos ------------
        
        if(is_readable($pathController)){ //Verificamos su origen.
            require_once $pathController; //Hacemos un requermiento al controlador.
            $controller = new $controller; //Instanciamos al controlador.
            
            if(is_callable(array($controller, $method))){ //Creamos un callback (Llamada de retorno) para el controlador y el metodo. Verificacmos si existe.
                $method = $request->getMethod(); //Seteamos el metodo, si existe se carga.
            } else {
                $method = $controller->index(); //De no existir el metodo requerido, cargamos el método principal, en este caso es "index".
            }
            
            if(isset($args)){ //Verificamos sus argumentos ó parametros.
                call_user_func_array(array($controller, $method), $args); //Callback.
            } else {
                call_user_func(array($controller, $method)); //Callback.
            }
            
        } else {
            echo css('bootstrap.min');
			throw new Exception('Error al cargar el método principal - '.$method.', no existe el controlador - '.$controller); //Cargamos error si no existe el método.
        }
    }

}

/* End of file HybridHyper.php */
/* Location: ./system/core/HybridHyper.php */