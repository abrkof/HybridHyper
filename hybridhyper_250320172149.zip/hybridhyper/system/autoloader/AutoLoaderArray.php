﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
#This is CORE of HybridHyper - ABRKOF, ABRKOF - HybridHyper, HybridHyper, HybridHyper ABRKOF, ABRKOF HybridHyper, ABRKOF.©
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * AutoloaderArray File
 *
 * Inicializa todos los componentes requeridos para el funcionamiento total del framework.
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Loader
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

//Ejemplo de archivos de clase de auto-carga de varios directorios utilizando el método spl_autoload_register.
//Se carga automáticamente cualquier archivo que encuentra comenzando por la class <classname> .php 
//(en minúsculas), por ejemplo:. Class.from.php, class.db.php.

spl_autoload_register(function($class) {

	//Definir un array de directorios en el orden de prioridad para recorrer.
	$directories = array(
		'core/', //Project specific classes (+Core Overrides)
		//'classes/', //Core classes example
		//'tests/',   //Unit test classes, if using PHP-Unit
	);

	//Bucle a través de cada directorio para cargar todas las clases. Sólo se requerirá el archivo una vez.
	//Si encuentra la misma clase en un directorio más adelante, sera ignorado! Debido a se que requiere una sola vez!
	foreach($directories as $folder){
		if (file_exists(BASEPATH.$folder.strtolower($class).'.php')){
			require_once(BASEPATH.$folder.strtolower($class).'.php');
			return;
		}
	}
});


/* End of file AutoLoaderArray.php */
/* Location: ./system/autoloader/AutoLoaderArray.php */