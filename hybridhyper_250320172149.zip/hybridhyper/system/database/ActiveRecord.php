﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * ActiveRecord Class
 *
 * Carga los componentes framework.
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Database
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

//Creamos la clase ActiveRecord.
class ActiveRecord{
    /*protected $select;
	protected $insert;
	protected $update;
	protected $delete;
	protected $where;
	protected $or_where;
	protected $like;
	protected $or_like;
	protected $left_join;
	protected $right_join;*/
	//private $ABRKOF;
	protected $db;
    
    public function __construct(){ //Inicializamos en constructor.
		$this->db = Database::pdoDB();
    }
	
    /**
     * select_from
	 * @param query $fields, nombre de los campos de la tabla
	 * @param query $table, sentencia SQL
     * @return mixed, conjunto de resultados
     */
    public function select_from($fields = '', $table = ''){ //Obtenemos los argumentos o parametros.
		try{
			//Generamos la sentencia SQL de la tabla requerida
			#$stmt sería un objeto de tipo PDOStatement (consulta preparada)
			$stmt = $this->db->prepare('SELECT '.$fields.' FROM '.$table.'');
			$stmt->execute();
			//Devuelve la siguiente fila como un objeto anónimo con nombres de columna como propiedades
			return $stmt->fetchAll(PDO::FETCH_OBJ);
		}
        catch(Exception $e){//Error 404
            die($e->getMessage());//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }
	
    /**
     * query
	 * @param query $table, sentencia SQL
	 * @param array $array, para unir parametros (bind)
     * @return mixed, conjunto de resultados
     */
    public function query($query = '', $array = array()){ //Obtenemos los argumentos o parametros.
		try{
			//Generamos la sentencia SQL de la tabla requerida
			#$stmt sería un objeto de tipo PDOStatement (consulta preparada)
			$stmt = $this->db->prepare($query);
			foreach ($array as $key => $value){
				$stmt->bindValue($key, $value);
			}
			$stmt->execute();
			//Devuelve la siguiente fila como un objeto anónimo con nombres de columna como propiedades
			return $stmt->fetchAll(PDO::FETCH_OBJ);
		}
        catch(Exception $e){//Error 404
            die($e->getMessage());//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }

    /**
     * row_array
	 * @param query $table, sentencia SQL
	 * @param array $array, para unir parametros (bind)
     * @return mixed, conjunto de resultados
     */
    public function row_array($query = '', $array = array()){ //Obtenemos los argumentos o parametros.
		try{
			//Generamos la sentencia SQL de la tabla requerida
			#$stmt sería un objeto de tipo PDOStatement (consulta preparada)
			$stmt = $this->db->prepare($query);
			foreach ($array as $key => $value){
				$stmt->bindValue($key, $value);
			}
			$stmt->execute();
			//Devuelve un array que contiene todas las filas del conjunto de resultados
			return $stmt->fetchAll();
		}
        catch(Exception $e){//Error 404
            die($e->getMessage());//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }

    /**
     * row_count
	 * @param query $table, sentencia SQL
     * @param array $array, para unir parametros (bind)
     * @return mixed, conjunto de resultados
     */
    public function row_count($query = '', $array = array()){ //Obtenemos los argumentos o parametros.
		try{
			//Generamos la sentencia SQL de la tabla requerida
			#$stmt sería un objeto de tipo PDOStatement (consulta preparada)
			$stmt = $this->db->prepare($query);
			foreach ($array as $key => $value){
				$stmt->bindValue($key, $value);
			}
			$stmt->execute();
			//Devuelve el número de filas afectadas por la última sentencia SQL
			return $stmt->rowCount();
		}
        catch(Exception $e){//Error 404
            die($e->getMessage());//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }

    /**
     * get
	 * @param $table, obtencion de todos los campos de la tabla
     * @return mixed, conjunto de resultados
     */
    public function get($table = ''){ //Obtenemos los argumentos o parametros.
		try{
			//Generamos la sentencia SQL de la tabla requerida
			#$stmt sería un objeto de tipo PDOStatement (consulta preparada)
			$stmt = $this->db->prepare('SELECT * FROM '.$table.'');
			$stmt->execute();
			//Devuelve el número de filas afectadas por la última sentencia SQL
			return $stmt->rowCount();
		}
        catch(Exception $e){//Error 404
            die($e->getMessage());//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }
	
    /**
     * by_id
	 * @param query $table, sentencia SQL
     * @param array $array, para unir parametros (bind)
     * @return mixed, conjunto de resultados
     */
    public function by_id($query = '', $array = array()){ //Obtenemos los argumentos o parametros.
		try{
			//Generamos la sentencia SQL de la tabla requerida
			#$stmt sería un objeto de tipo PDOStatement (consulta preparada)
			$stmt = $this->db->prepare($query);
			foreach ($array as $key => $value){
				$stmt->bindValue($key, $value);
			}
			$stmt->execute();
			//Obtiene la siguiente fila de un conjunto de resultados
			return $stmt->fetch(PDO::FETCH_OBJ);
		}
        catch(Exception $e){//Error 404
            die($e->getMessage());//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }

    /**
     * next_row
	 * @param query $table, sentencia SQL
     * @param array $array, para unir parametros (bind)
     * @return mixed, conjunto de resultados
     */
    public function next_row($query = '', $array = array()){ //Obtenemos los argumentos o parametros.
		try{
			//Generamos la sentencia SQL de la tabla requerida
			#$stmt sería un objeto de tipo PDOStatement (consulta preparada)
			$stmt = $this->db->prepare($query);
			foreach ($array as $key => $value){
				$stmt->bindValue($key, $value);
			}
			$stmt->execute();
			//Obtiene la siguiente fila de un conjunto de resultados
			return $stmt->fetch();
		}
        catch(Exception $e){//Error 404
            die($e->getMessage());//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }

    /**
     * select
     * @param string $fields, nombre de los campos de la tabla
	 * @param string $table, nombre de la tabla
     * @param array $array, para unir parametros (bind)
     * @return mixed, conjunto de resultados
     */
    public function select($fields = '', $table = '', $array = array()){
		try{
			//Generamos la sentencia SQL de la tabla requerida
			#$stmt sería un objeto de tipo PDOStatement (consulta preparada)
			$stmt = $this->db->prepare('SELECT '.$fields.' FROM '.$table.'');
			foreach ($array as $key => $value){
				$stmt->bindValue($key, $value);
			}
			$stmt->execute();
			////Devuelve la siguiente fila como un objeto anónimo con nombres de columna como propiedades
			return $stmt->fetchAll(PDO::FETCH_OBJ);
		}
        catch(Exception $e){//Error 404
            die($e->getMessage());//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }
    
    /**
     * insert
     * @param string $table, nombre de una tabla para la clausula INSERT (insert into)
     * @param string $fields, arreglo asociativo
     */
    public function insert($table, $fields){
		try{
			ksort($fields);//"ksort" ordena un array por clave, manteniendo la correlación entre la clave y los datos. Esto es útil principalmente para arrays asociativos.
			
			$fieldNames = implode(', ', array_keys($fields));
			
			$fieldValues = ':'.implode(', :', array_keys($fields));
			
			$stmt = $this->db->prepare('INSERT INTO '.$table.' ('.$fieldNames.') VALUES ('.$fieldValues.')');
			
			foreach ($fields as $key => $value){
				$stmt->bindValue(':'.$key.'', $value);
			}
			
			$stmt->execute();
		}
        catch(Exception $e){//Error 404
            die($e->getMessage());//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }
    
    /**
     * update
     * @param string $table, nombre de una tabla para la clausula UPDATE (update into)
     * @param string $fields, un arreglo asociativo
     * @param string $params, parte de una consulta con la clausula WHERE
     */
    public function update($table, $fields, $params){
		try{
			ksort($fields);//"ksort" ordena un array por clave, manteniendo la correlación entre la clave y los datos. Esto es útil principalmente para arrays asociativos.
			
			$fieldDetails = NULL;
			
			foreach($fields as $key => $value){
				$fieldDetails .= ''.$key.'=:'.$key.',';
			}
			
			$fieldDetails = rtrim($fieldDetails, ',');
			
			$stmt = $this->db->prepare('UPDATE '.$table.' SET '.$fieldDetails.' WHERE '.$params.'');
			
			foreach ($fields as $key => $value){
				$stmt->bindValue(':'.$key.'', $value);
			}
			
			$stmt->execute();
		}
        catch(Exception $e){//Error 404
            die($e->getMessage());//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }
    
    /**
     * delete
     * 
     * @param string $table
     * @param string $params
     * @return integer, filas afectadas (Affected Rows)
     */
    public function delete($table, $params){
        try{
			return $this->db->exec('DELETE FROM '.$table.' WHERE '.$params.'');
		}
		catch (Exception $e){
			die($e->getMessage());
		}
    }

}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//Test para conexiones personalizadas a bases de datos y para su posterior uso e instanciarlas
/////////////////////////////////////////////////////////////////////////////////////////////////////
/*if (CUSTOM_PDO == TRUE){$pdo = DataBaseX::pdoDB();}
if (CUSTOM_MySQLNative == TRUE){$mysqlnative = DataBaseX::mySQLNativeDB();}
if (CUSTOM_MySQLi == TRUE){$mysqli = DataBaseX::mySQLiDB();}
if (CUSTOM_mySQLDBTest == TRUE){$mysqlitest = DataBaseX::mySQLiDBTest();}
if (CUSTOM_odbcDB == TRUE){$odbc = DataBaseX::odbcDB();}

//Intentamos ejecutar el siguiente código
try{
	$pdo = $pdo;
	#$stmt sería un objeto de tipo PDOStatement (consulta preparada)
	$stmt = $pdo->prepare('SELECT * FROM usuario');
	$stmt->execute();
	#Devuelve la siguiente fila como un objeto anónimo con nombres de columna como propiedades
	$rt = $stmt->fetchALL(PDO::FETCH_OBJ);
	//return $rt;
	//return $stmt->fetchAll(PDO::FETCH_OBJ);
	var_dump($rt);
}
//Obtenemos una lista de los mensajes de error.
catch (Exception $e){
	die($e->getMessage());
}*/
/////////////////////////////////////////////////////////////////////////////////////////////////////

/*
Here are the correspondences:

mysql_fetch_array = fetch(PDO::FETCH_BOTH) - The rows are arrays with both numeric and named indexes.
mysql_fetch_assoc = fetch(PDO::FETCH_ASSOC) - The rows are arrays with named indexes.
mysql_fetch_row = fetch(PDO::FETCH_NUM) - The rows are arrays with numeric indexes.
mysql_fetch_object = fetch(PDO::FETCH_OBJ) or fetch(PDO::FETCH_CLASS) depending on whether you specify the optional className argument to mysql_fetch_object. The rows are objects, either of the specified class or stdClass.
The while loop is equivalent to:

$data = $query->fetchAll(PDO::FETCH_BOTH);
*/


//$dsn = 'mysql:host=localhost; dbname=hybridhyper; charset=utf8;';
/*$dsn = 'mysql:host=localhost; dbname=hybridhyper; charset=utf8; port=3306;', 'root','vertrigo';
$this->load->database($dsn);
*/

/* End of file ActiveRecord.php */
/* Location: ./system/core/ActiveRecord.php */