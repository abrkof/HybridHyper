<?php
//for($i = 1; $i <= 5; $i += 1) echo $i . "\n";
/*$galletas = 1;
while ($galletas < 5 + 1){
	$galletas;
	$arr = array($galletas++); 
	$word = "?"; 
	echo strtr($word,$arr);
}
echo '<br>'; 
function generarCodigo($longitud) {
	$key = '';
	$pattern = '?';
	$max = strlen($pattern)-1;
	for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)}.',';
	//return $key;
	return substr($key,0,strripos($key,','));
}
echo generarCodigo(5);*/
?>
<?php phpinfo(); ?>