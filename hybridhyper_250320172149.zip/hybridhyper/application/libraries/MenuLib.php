﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
class MenuLib {
private $pdo;
	function __construct(){
		//Realizamos la conexion a la base de datos
		try{
			$this->ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librería
		}
		catch(Exception $e){
			die($e->getMessage());
		}
		$this->ABRKOF->Model_Perfil = $this->ABRKOF->load->model('Model_Perfil');
    }    

    public function get_perfiles_asig_noasig($menu_id){
        $lista_asig = array();
        $lista_noasig = array();
		
		$perfiles = $this->ABRKOF->Model_Perfil->all();
		
		foreach($perfiles as $perfil){
			$query = $this->ABRKOF->db->row_array('SELECT * FROM menu_perfil WHERE menu_id = :menu_id AND perfil_id = :perfil_id', 
												array(':menu_id'=>$menu_id, ':perfil_id'=>$perfil->id));
			$existe = (count($query) > 0);
			
            if($existe){
                $lista_asig[] = array($perfil->id, $perfil->name, $menu_id);
            }
            else{
                $lista_noasig[] = array($perfil->id, $perfil->name, $menu_id);
            }
        }
		return array($lista_noasig, $lista_asig);
    }

    public function findByControlador($controlador){
		$query = $this->ABRKOF->db->next_row('SELECT * FROM menu WHERE controlador = :controlador', 
											array(':controlador'=>$controlador));
		return $query;
    }

}