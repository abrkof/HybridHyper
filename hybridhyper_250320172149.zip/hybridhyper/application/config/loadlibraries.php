<?php defined('BASEPATH') OR exit('No direct script access allowed');
//construimos la clase de conexion a la base de datos
class LoadLibraries{
	//seteamos una funcion publica de orden estatico para la conexion
    public static function libraries(){
		//require_once BASEPATH.('libraries/Form_validation.php');
		//require_once BASEPATH.('libraries/Pagination.php');
		//require_once BASEPATH.('libraries/Profiler.php');
    }
}