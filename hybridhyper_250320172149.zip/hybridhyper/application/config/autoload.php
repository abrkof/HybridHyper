<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['app_helpers_folder'] = TRUE; //array();
//$config['app_libraries_folder'] = FALSE; //

//$config['base_helpers_folder'] = TRUE; //
//$config['base_libraries_folder'] = TRUE; //