<?php defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_module_name'] = array('testmodule','webservice4android'); //Identificaci�n del m�dulo principal a iniciar.
$route['default_module_controller'] = 'app1'; //Identificaci�n del controlador del m�dulo principal a iniciar.
$route['default_controller'] = 'admin'; //Identificaci�n del controlador principal a iniciar.