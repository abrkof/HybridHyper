﻿<?php $this->load->view('admin/headers_check_login');?>
<br><br>
<h1 class="page-header">
    <?php echo 'Creando Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><?php echo open_link('perfil', 'Perfil'); ?></li>
  <li class="active">/ <?php echo 'Creando Registro'; ?></li>
</ol>
<?php echo form_open_multipart("perfil/insert", array('id'=>'frm-perfil', 'class'=>'form-horizontal')); ?>
    <div class="control-group">
        <?php echo form_label('Nombre : ', 'name', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'perfil', 'id'=>'perfil', 'value'=>set_value('perfil'), 'class'=>'form-control', 'placeholder'=>'Ingrese el Nombre del Perfil', 'data-validation-type'=>'requerido|min:3'));?>
    </div>
    
    <div class="control-group">
		<?php echo form_label('Descripción : ', 'descripcion', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'descripcion', 'id'=>'descripcion', 'value'=>set_value('descripcion'), 'class'=>'form-control', 'placeholder'=>'Ingrese una Descripción', 'data-validation-type'=>'requerido|min:5'));?>
    </div>
    
    <hr>
    
    <div class="control-group">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Guardar', 'class'=>'btn btn-success')); ?>
		<?php echo anchor('perfil', 'Cancelar', 'class="btn btn-warning"'); ?>
    </div>
<?php echo form_close();?>

<script>
    $(document).ready(function(){
        $("#frm-perfil").submit(function(){
            return $(this).validate();
        });
    })
</script>