﻿<?php $this->load->view('admin/headers_check_login');?>
<br><br>
<div class="page-header">
	<h1> Opciones de Sub Menús <small>|| mantenimiento de registros </small> </h1>
</div>

<div class="well well-sm text-right">
    <a class="btn btn-primary" href="<?php echo base_url('');?>submenu_perfil/create" style="color:#FFF;">Nueva Seguridad (Sub Menús)</a>
</div>

<table class="table table-striped">
    <thead>
        <tr>
            <th style="width:10px;">Id</th>
			<th style="width:100px;">Sub Menú</th>
            <th style="width:120px;">Perfil</th>
            <th style="width:60px;">Creado</th>
            <th style="width:60px;">Modificado</th>	
            <th style="width:60px;"></th>
            <th style="width:60px;"></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($query as $registro): ?>
        <tr>
			<td><?php echo $registro->id; ?></td>
            <td><?php echo $registro->submenu_name; ?></td>
            <td><?php echo $registro->perfil_name; ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->created)); ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->updated)); ?></td>
            <td><a href="submenu_perfil/procesos&id=<?php echo $registro->id; ?>">Editar</a></td>
            <td><a onclick="alertify.confirm('Estas Eliminado El ID de Registro Nº<?php echo $registro->id; ?>','¿Estas seguro de eliminar este registro?',
			  function(ok){
				window.location='submenu_perfil/delete&id=<?php echo $registro->id; ?>';
				alertify.success('Eliminación Exitosa');
			  },
			  function(cancel){
				alertify.message('Cancelado');
			  }); return false" href="#">Eliminar</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>