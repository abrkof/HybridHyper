<?php
echo headers();
$logued = ($this->session->userdata('perfil_id')==7);
if($logued == TRUE){
	$this->session->sess_destroy();
	redirect('admin/acceso_denegado');
	exit();
}
?>