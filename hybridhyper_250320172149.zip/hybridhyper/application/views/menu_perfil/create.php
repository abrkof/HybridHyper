﻿<?php $this->load->view('admin/headers_check_login');?>
<br><br>
<h1 class="page-header">
    <?php echo 'Creando Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><?php echo open_link('menu_perfil', 'Menú Perfil'); ?></li>
  <li class="active">/ <?php echo $registro->menu_name.' - '.$registro->perfil_name; ?></li>
</ol>

<?php echo form_open_multipart("menu_perfil/insert", array('id'=>'frm-menu_perfil', 'class'=>'form-horizontal')); ?>    
    <div class="control-group">
        <?php echo form_label('Menú : ', 'menu_id', array('class'=>'control-label')); ?>
		<?php $style = 'class="form-control"' ;?>
		<?php echo form_dropdown('menu_id', $menus, 0, $style); ?>
    </div>
    
    <div class="control-group">
        <?php echo form_label('Perfil : ', 'perfil_id', array('class'=>'control-label')); ?>
		<?php $style = 'class="form-control"' ;?>
		<?php echo form_dropdown('perfil_id', $perfiles, 0, $style); ?>
    </div>
    
    <hr>
    
    <div class="control-group">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Guardar', 'class'=>'btn btn-success')); ?>
		<?php echo anchor('menu_perfil', 'Cancelar', 'class="btn btn-warning"'); ?>
    </div>
<?php echo form_close();?>

<script>
    $(document).ready(function(){
        $("#frm-menu_perfil").submit(function(){
            return $(this).validate();
        });
    })
</script>