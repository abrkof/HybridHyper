﻿<?php //$this->load->view('admin/headers_check_login');?>
<?php echo js('saved_resource(3)') ;?>
<div id="bit" class="loggedout-follow-normal" style="bottom: -332px;">
	<a class="bsub" href="javascript:void(0)"><span id="bsub-text">Opciones de Usuario</span></a>
	<div id="bitsubscribe" class="">
<?php
if($this->session->get_userdata('usuario_id')==0){?>
	<div align="center"><?php echo anchor('admin/inicio_sesion', 'Iniciar Sesión', 'class="btn btn-primary"'); ?></div>
<?php } else {
?>
		<h3><label for="loggedout-follow-field">Bienvenido</label></h3>
		<p><?php echo $this->session->get_userdata('usuario_name').' '.$this->session->get_userdata('usuario_ape');?>.</p>
		<p id="loggedout-follow-error" style="display: none;"></p>
		<p class="bit-follow-count">Perfil: “<?php echo $this->session->get_userdata('perfil_name');?>”</p>
		<p><?php $this->load->template('cambio_clave');?></p>
		<form action="<?php echo base_url('') ;?>admin/salir" method="post">
			<input type="submit" value="Cerrar Sesión">
		</form>
<?php } ?>
		<p id="bsub-subscribe-button"></p>
		<div id="bsub-credit"><a href="http://www.abrkof.org" target="_blank">Development by HybridHyper®</a></div>
	</div>
</div>