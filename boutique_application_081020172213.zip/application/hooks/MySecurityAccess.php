﻿



<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Security Access Library Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
//Acceso por autentificación de usuarios.
class AccessTrue{
	public function authenticate(){
		$this->CI = & get_instance();

		$controlador = $this->CI->uri->segment(1);
		$accion = $this->CI->uri->segment(2);
		$url = $controlador.'/'.$accion;

		$freeCtrlAcc = array(
			'/',
			'admin/',
			'admin/index',
			'admin/acceso_denegado',
			'admin/acerca_de',
			'admin/inicio_sesion',
			'admin/ingresar',
			'admin/cambio_clave',
			'admin/cambiar_clave',
			'admin/salir',
			'admin/export_to_excel',
			'clientes/',
			'clientes/munpos',
			'clientes/cantones',
			'clientes/caserios',
			'usuario/edit_imgx',
			'anuncio/veranuncio',
			'anuncio/',
			'home/index',
			'home/',
			'home/cv',
			'servicios/index',
			'servicios/',
			'articulo/index',
			'articulo/ajax',
			'articulo/',
			'contacto/index',
			'contacto/send_mail',
			'contacto/',
			'pages/page7',
			'pages/page8',
			'pages/page9',
			'pages/page10'
		);

		if(in_array($url, $freeCtrlAcc)){
			echo $this->CI->output->get_output();
		}
		else {
			if($this->CI->session->userdata('usuario_id')){
				if($this->authorize_menu_submenu()){
					echo $this->CI->output->get_output();
				} else {
					redirect('admin/acceso_denegado');
				}
			} else {
				redirect('admin/acceso_denegado');
			}
		}

	}

	public function authorize_menu_submenu(){
		$this->CI = & get_instance();
	
		//El perfil del usuario logueado
		$perfil_id = $this->CI->session->userdata('perfil_id');
	
		//Con el controlador, buscar la opción de Menú y Sub Menú
		$this->CI->load->library('MenuLib');
		$this->CI->load->library('SubMenuLib');
		$controlador = $this->CI->uri->segment(1);
		$menu_id = $this->CI->menulib->findByControlador($controlador)->id;
		$submenu_id = $this->CI->submenulib->findByControlador($controlador)->id;
	
		if(!$menu_id AND !$submenu_id){
			return FALSE;
		}
	
		//Recuperar de la tabla de permisos, la combinación Menú, Sub Menú - Perfil
		$this->CI->load->library('Menu_PerfilLib');
		$this->CI->load->library('SubMenu_PerfilLib');
		$acceso = $this->CI->menu_perfillib->findByMenuAndPerfil($menu_id, $perfil_id);
		$acceso2 = $this->CI->submenu_perfillib->findBySubMenuAndPerfil($submenu_id, $perfil_id);
		if(!$acceso AND !$acceso2){
			return FALSE;
		}
		return TRUE;
	}

}


/*
Vamos a ver de forma rápida como utilizar hooks con codeigniter, imaginemos que tenemos un gran portal y no queremos 
dejar pasar a ningún usuario a según que zonas del mismo, podríamos poner en cada página una comprobación de si existe 
la sesión o no, pero eso en codeigniter es ‘pecado’.

Gracias a los hooks podemos hacer eso en una sola función y diciéndole cuando queremos que haga las comprobaciones, 
por ejemplo, nosotros lo haremos en el post_controller_constructor que es cuando el constructor se instancia pero cuando 
todavía ningún método haya sido llamado, veamos las opciones que nos dá codeigniter.

pre_system
Llamado muy pronto durante la ejecución del sistema. En este punto, solamente se cargaron las clases de
hooks y benchmark. No ocurrió ningún ruteo u otro proceso.

pre_controller
Llamado inmediatamente antes de que cualquiera de sus controladores haya sido llamado. Se hicieron
todas las clases base, ruteo y verificaciones de seguridad.

post_controller_constructor
Llamado inmediatamente después que su controlador se instanció, pero antes que haya ocurrido cualquier
llamada a un método.

post_controller
Llamado inmediatamente después que su controlador se ejecutó completamente.

display_override
Anula la función _display(), usada para enviar la página finalizada al navegador web al final de la
ejecución del sistema. Esto le permite usar su propia metodología de impresión. Advierta que necesitará
referenciar al superobjeto CI con $this->CI =& get_instance() y luego los datos finalizados estarán
disponibles llamando a $this->CI->output->get_output()

cache_override
Le permite llamar a su propia función en lugar de la función _display_cache() en la clase Output. Esto le
permite usar su propio mecanismo de visualización del caché.

post_system
Llamado después que la página final renderizada se envíe al navegador, en el final de la ejecución del
sistema y después que los datos finalizados se envían al navegador.
*/