﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Pago Creditos Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Pago_Creditos_Bo extends CI_Controller {

	//Constructor de Clase
	function __construct() {
		parent::__construct();

		$this->load->model('Model_Pago_Creditos_Bo');
		//$this->load->library('Pago_Creditos_BoLib');

		//$this->db2 = $this->load->database('db2', TRUE);

		$this->form_validation->set_message('required', 'Debe ingresar un valor para %s');
		$this->form_validation->set_message('norep', 'Existe otro registro con el mismo nombre');
	}

	public function index(){
		$pagination = 20;
			
        $config['base_url'] = base_url().'Pago_Creditos_Bo/index';
        $config['total_rows'] = $this->db->get('bo_pago_creditos')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

		$data['titulo'] = 'Pago Créditos';
		$data['contenido'] = 'pago_creditos/index';
		$data['query'] = $this->Model_Pago_Creditos_Bo->get_pago($pagination, $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}

    //con esta función validamos y protegemos el buscador
    public function validar(){
		$this->form_validation->set_rules('buscar', 'Pago Crédito', 'required|min_length[2]|max_length[20]|trim|xss_clean');
        if ($this->form_validation->run() == TRUE) {
            $buscador = $this->input->post('buscar');
            $this->session->set_userdata('buscar', $buscador);
            redirect('Pago_Creditos_Bo/consultar');
        } else {
			$data['titulo'] = 'Pago Creditos';
			$data['contenido'] = 'pago_creditos/result';
			$this->load->view('template/template', $data);
        }
    }

	public function consultar(){
		$buscador = $this->session->userdata('buscar');
        $pages = 20; //Número de registros mostrados por páginas
        $config['base_url'] = base_url().'Pago_Creditos_Bo/consultar'; // parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php
        $config['total_rows'] = $this->Model_Pago_Creditos_Bo->got_pago($buscador); //calcula el número de filas
        $config['per_page'] = $pages; //Número de registros mostrados por páginas
        $config['num_links'] = 10; //Número de links mostrados en la paginación
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //inicializamos la paginación
        //el array con los datos a paginar ya preparados
        $data['query'] = $this->Model_Pago_Creditos_Bo->total_posts_paginados($buscador, $config['per_page'], $this->uri->segment(3));

		$data['titulo'] = 'Pago Créditos';
		$data['contenido'] = 'pago_creditos/result';
		$this->load->view('template/template', $data);
	}

	public function norep() {
		//return $this->Pago_Creditos_Bolib->norep($this->input->post());
	}

	public function create($id) {
		
		$data['titulo'] = 'Registrar Pago Crédito';
		$data['contenido'] = 'pago_creditos/create';
		$data['registro'] = $this->Model_Pago_Creditos_Bo->set_pago($id);
		$this->load->view('template/template', $data);
	}

	public function insert() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('monto_pagado', 'Monto a Pagar', 'required|callback_norep');
		if($this->form_validation->run() == FALSE) {
			$this->create();
		} else {
			$count = $this->db->get('bo_pago_creditos')->num_rows();
			$id = $count + 1;
			$registro['id'] = $id;
			$registro['usuario_id'] = $this->session->userdata('usuario_id');
				
			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['created'] = $today;
			$registro['updated'] = $today;
			$this->Model_Pago_Creditos_Bo->insert($registro);
			redirect('Pago_Creditos_Bo/index');
		}
	}

	public function edit($id) {
		//$id = $this->uri->segment(3);
		$data['titulo'] = 'Actualizar Pago Crédito';
		$data['contenido'] = 'pago_creditos/edit';
		$data['registro'] = $this->Model_Pago_Creditos_Bo->find($id);
		$this->load->view('template/template', $data);
	}

	public function update() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('monto_pagado', 'Monto a Pagar', 'required|callback_norep');
		if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		} else {
			$registro['usuario_id'] = $this->session->userdata('usuario_id');
			
			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['updated'] = $today;
			$this->Model_Pago_Creditos_Bo->update($registro);
			redirect('Pago_Creditos_Bo/index');
		}
	}

	public function delete($id) {
		if($this->session->userdata('usuario_id')>2){
            redirect('admin/acceso_denegado');
            exit;
        } else {
			$this->Model_Pago_Creditos_Bo->delete($id);
			redirect('Pago_Creditos_Bo/index');
		}
	}

}
