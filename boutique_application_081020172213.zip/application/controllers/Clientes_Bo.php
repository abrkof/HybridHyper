﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class Clientes_Bo extends CI_Controller {

	// Constructor de Clase
	function __construct() {
		parent::__construct();

		$this->load->model('Model_Clientes_Bo');
		$this->load->model('Model_Producto_Bo');
		$this->load->model('Model_Deptos_X');
		$this->load->library('clientes_BoLib');
		
        $this->form_validation->set_message('required', 'El campo %s no puede ir vacío!');
        $this->form_validation->set_message('min_length', 'El campo %s debe tener al menos %s carácteres');
        $this->form_validation->set_message('max_length', 'El campo %s no puede tener más de %s carácteres');/**/
		
		$this->form_validation->set_message('my_validation1', 'Existe otro registro con el mismo Código de Cliente');
		$this->form_validation->set_message('my_validation2', 'Existe otro registro con el mismo DUI de Cliente');
		$this->form_validation->set_message('my_validation3', 'Existe otro registro con el mismo NIT de Cliente');
		$this->form_validation->set_message('my_validation4', 'Existe otro registro con el mismo E-Mail de Cliente');

		$this->form_validation->set_message('required', 'Debe ingresar un valor para %s');
		$this->form_validation->set_message('numeric', '%s debe ser un número');
		$this->form_validation->set_message('is_natural', '%s debe ser un número mayor a cero');
	}

	public function index() {
		
		$pagination = 10;
			
        $config['base_url'] = base_url().'Clientes_Bo/index';
        $config['total_rows'] = $this->db->get('bo_clientes')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);
		
		$data['titulo'] = 'Inscripción de Clientes';
		$data['contenido'] = 'clientes/index';
		$data['query'] = $this->Model_Clientes_Bo->get_all($pagination, $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}

    //con esta función validamos y protegemos el buscador
    public function validar(){
		
		$this->form_validation->set_rules('buscar', 'Cliente', 'required|min_length[2]|max_length[20]|trim|xss_clean');
        if ($this->form_validation->run() == TRUE) {
            $buscador = $this->input->post('buscar');
            $this->session->set_userdata('buscar', $buscador);
            redirect('Clientes_Bo/consultar');
        } else {
			$data['titulo'] = 'Inscripción de Clientes';
			$data['contenido'] = 'clientes/result';
			$this->load->view('template/template', $data);
        }
    }

	public function consultar(){
		
		$buscador = $this->session->userdata('buscar');
        $pages = 10; //Número de registros mostrados por páginas
        $config['base_url'] = base_url().'Clientes_Bo/consultar'; //parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php
        $config['total_rows'] = $this->Model_Clientes_Bo->got_cliente($buscador); //calcula el número de filas
        $config['per_page'] = $pages; //Número de registros mostrados por páginas
        $config['num_links'] = 10; //Número de links mostrados en la paginación
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //inicializamos la paginación
        //el array con los datos a paginar ya preparados
        $data['query'] = $this->Model_Clientes_Bo->total_posts_paginados($buscador, $config['per_page'], $this->uri->segment(3));

		$data['titulo'] = 'Inscripción de Clientes';
		$data['contenido'] = 'clientes/result';
		$this->load->view('template/template', $data);
	}

	public function my_validation1() {
		return $this->clientes_bolib->my_validation1($this->input->post());
	}

	public function my_validation2() {
		return $this->clientes_bolib->my_validation2($this->input->post());
	}

	public function my_validation3() {
		return $this->clientes_bolib->my_validation3($this->input->post());
	}

	public function my_validation4() {
		return $this->clientes_bolib->my_validation4($this->input->post());
	}

	public function create() {
		
		$data['titulo'] = 'Inscribiendo Cliente';
		$data['contenido'] = 'clientes/create';
		$data['deptos'] = $this->Model_Clientes_Bo->get_deptos(); /* Lista de los Deptos */
		$data['munpos'] = $this->Model_Clientes_Bo->get_munpos(); /* Lista de los Munpo */
		$data['cantones'] = $this->Model_Clientes_Bo->get_cantones(); /* Lista de los Cantones */
		$data['caserios'] = $this->Model_Clientes_Bo->get_caserios(); /* Lista de los Caserios */
		$this->load->view('template/template', $data);
	}

	public function create_request($id) {
		
		$data['titulo'] = 'Inscribiendo Cliente';
		$data['contenido'] = 'clientes/create_request';
		$data['deptos'] = $this->Model_Clientes_Bo->get_deptos(); /* Lista de los Deptos */
		$data['munpos'] = $this->Model_Clientes_Bo->get_munpos(); /* Lista de los Munpo */
		$data['cantones'] = $this->Model_Clientes_Bo->get_cantones(); /* Lista de los Cantones */
		$data['caserios'] = $this->Model_Clientes_Bo->get_caserios(); /* Lista de los Caserios */
		$data['registro'] = $this->Model_Clientes_Bo->find($id);
		
		//$data['tipo_acreedor'] = get_instance()->db->get_where('m_clientes', array('id'=>$id))->row();
		
		$this->load->view('template/template', $data);
	}

	function generarCodigo($longitud) {
		
		$key = '';
		$pattern = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ12345noze67890abcdefghijklmnopqrstuvwxyz';
		$max = strlen($pattern)-1;
		for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)};
		return $key;
	}

	public function codeHAA(){
		$string= $registro['apellidos'];
		$position=1;
		
		for ($i=0; $i<strlen($string); $i++){
			if($string[$i]!=" " && $position==1){
				$result .= $string[$i];
				$position=0;
			}
			if($string[$i]==" "){ 
				$position=1;
			}
		}
	}

    public function insert() {
        //
		
		$registro = $this->input->post();
		$this->form_validation->set_rules('nombres', 'Nombres', 'required');
		$this->form_validation->set_rules('apellidos', 'Apellidos', 'required');
		$this->form_validation->set_rules('dui', 'DUI Cliente', 'required|callback_my_validation2');
		$this->form_validation->set_rules('nit', 'NIT Cliente', 'required|callback_my_validation3');
		$this->form_validation->set_rules('email', 'E-Mail Cliente', 'required|callback_my_validation4');
        if ($this->form_validation->run() == FALSE){
			$this->create();
		}else{
			$config['upload_path'] = 'assets/boutique/images/clientes/';
			$config['allowed_types'] = 'gif|jpg|jpe|jpeg|png';
			//$config['max_size'] = '2000';
			//$config['max_width'] = '2024';
			//$config['max_height'] = '2008';
			//Hacemos el requeriento de la libreria "upload"
			$this->load->library('upload', $config);
			//SI LA IMAGEN FALLA AL SUBIR MOSTRAMOS EL ERROR EN LA VISTA ACTUAL
			if (!$this->upload->do_upload()) {
			$data = array('error' => $this->upload->display_errors());
			$this->create($data);
			/*$data['titulo'] = 'Registrando Producto';
			$data['contenido'] = 'slider/create';
			$this->load->view('template/template', $data);*/
            //redirect('upload/do_upload', $error);
			} else {
				//EN OTRO CASO SUBIMOS LA IMAGEN, CREAMOS LA MINIATURA Y HACEMOS
				//ENVÍAMOS LOS DATOS AL MODELO PARA HACER LA INSERCIÓN
				$file_info = $this->upload->data();
				//USAMOS LA FUNCIÓN create_thumbnail Y LE PASAMOS EL NOMBRE DE LA IMAGEN,
				//ASÍ YA TENEMOS LA IMAGEN REDIMENSIONADA
				$this->_create_thumbnail($file_info['file_name']);
				$data = array('upload_data' => $this->upload->data());

				/*Script para obtener primera letra de cada apellido*/
				//Forma incorrecta para obtener primera letra de cada apellido, pero funciona.
				$string= $registro['apellidos'];
				$position=1;
				
				for ($i=0; $i<strlen($string); $i++){
					if($string[$i]!=" " && $position==1){
						$result .= $string[$i];
						$position=0;
					}
					if($string[$i]==" "){ 
						$position=1;
					}
				}
				/*Script para obtener primera letra de cada apellido*/
	
				$count = $this->db->get('bo_clientes')->num_rows();
				$n_e = $count + 1;
				
				$apellidos = $result;
				$c = 'C';
				$random_code = $this->generarCodigo(7); //Genera un código de 7 caracteres de longitud.
				$year = date('Y');	
			
				$registro['id'] = $apellidos.$c.$n_e.'_'/*.$random_code*/.$year;
				$id = $registro['id'];
				$userfile = $file_info['file_name'];

				$registro['image'] = $userfile;
			
				$registro['usuario_id'] = $this->session->userdata('usuario_id');

				$timezone = "America/Managua";
				date_default_timezone_set($timezone);
				$today = date('Y-m-d H:i:s');
				
				$registro['created'] = $today;
				$registro['updated'] = $today;
				$this->Model_Clientes_Bo->insert($registro);
			}
			redirect('Clientes_Bo/index');
		}
	}

	public function edit($id) {
		$data['titulo'] = 'Actualizando Datos Cliente';
		$data['contenido'] = 'clientes/edit';
		$data['registro'] = $this->Model_Clientes_Bo->find($id);
		$data['deptos'] = $this->Model_Clientes_Bo->get_deptos(); /* Lista de los Deptos */
		$data['munpos'] = $this->Model_Clientes_Bo->get_munpos(); /* Lista de los Munpo */
		$data['cantones'] = $this->Model_Clientes_Bo->get_cantones(); /* Lista de los Cantones */
		$data['caserios'] = $this->Model_Clientes_Bo->get_caserios(); /* Lista de los Caserios */
		$this->load->view('template/template', $data);
	}

	public function update() {
		
		$registro = $this->input->post();

		/*$this->form_validation->set_rules('name', 'Nombre', 'required|callback_my_validation');
		$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		}
		else {*/
			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['updated'] = $today;
			$this->Model_Clientes_Bo->update($registro);
			redirect('Clientes_Bo/index');
		//}
	}

	public function edit_img($id) {
		$data['titulo'] = 'Actualizar Imagen Cliente';
		$data['contenido'] = 'clientes/edit_img';
		$data['registro'] = $this->Model_Clientes_Bo->find($id);
		$this->load->view('template/template', $data);
	}

	public function update_img() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('id', 'id', 'required');
		
		if($this->form_validation->run() == FALSE) {
			$this->edit_img($registro['id']);
			}else{
				$config['upload_path'] = './assets/boutique/images/clientes/';
				$config['allowed_types'] = 'gif|jpg|jpe|jpeg|png';
				$config['max_size'] = '2000';
				$config['max_width'] = '2024';
				$config['max_height'] = '2008';
				//Hacemos el requeriento de la libreria "upload"
				$this->load->library('upload', $config);
				//SI LA IMAGEN FALLA AL SUBIR MOSTRAMOS EL ERROR EN LA VISTA ACTUAL
				if (!$this->upload->do_upload()) {
				$data = array('error' => $this->upload->display_errors());
				$this->edit_img($registro['id']);
				//redirect('upload/do_upload', $error);
			} else {
				//EN OTRO CASO SUBIMOS LA IMAGEN, CREAMOS LA MINIATURA Y HACEMOS 
				//ENVÍAMOS LOS DATOS AL MODELO PARA HACER LA INSERCIÓN
				$file_info = $this->upload->data();
				//USAMOS LA FUNCIÓN create_thumbnail Y LE PASAMOS EL NOMBRE DE LA IMAGEN,
				//ASÍ YA TENEMOS LA IMAGEN REDIMENSIONADA
				$this->_create_thumbnail($file_info['file_name']);
				$data = array('upload_data' => $this->upload->data());
				$imagen = $file_info['file_name'];
				$registro['image'] = $imagen;

				$timezone = "America/Managua";
				date_default_timezone_set($timezone);
				$today = date('Y-m-d H:i:s');
				
				$registro['updated'] = $today;
				$this->Model_Clientes_Bo->update($registro);
				
				redirect('Clientes_Bo/index');
			}
		}
	}
	
    //FUNCIÓN PARA CREAR LA MINIATURA A LA MEDIDA QUE LE DIGAMOS
    public function _create_thumbnail($filename){
        //
		
		$config['image_library'] = 'gd2';
        //CARPETA EN LA QUE ESTÁ LA IMAGEN A REDIMENSIONAR
        $config['source_image'] = './assets/boutique/images/clientes/'.$filename;
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = TRUE;
        //CARPETA EN LA QUE GUARDAMOS LA MINIATURA.
        $config['new_image']='./assets/boutique/images/clientes/thumbs/';
        $config['width'] = 150;
        $config['height'] = 150;
        $this->load->library('image_lib', $config); 
        $this->image_lib->resize();
    }
	
	public function info($id) {
		$data['titulo'] = 'Consultando Datos Cliente';
		$data['contenido'] = 'clientes/info';
		$data['registro'] = $this->Model_Clientes_Bo->find($id);
		$data['deptos'] = $this->Model_Clientes_Bo->get_deptos(); /* Lista de los Deptos */
		$data['munpos'] = $this->Model_Clientes_Bo->get_munpos(); /* Lista de los Munpo */
		$data['cantones'] = $this->Model_Clientes_Bo->get_cantones(); /* Lista de los Cantones */
		$data['caserios'] = $this->Model_Clientes_Bo->get_caserios(); /* Lista de los Caserios */
		$this->load->view('template/template', $data);
	}

	public function delete($id) {
		
		$this->Model_Clientes_Bo->delete($id);
		redirect('Clientes_Bo/index');
	}

	public function procesos($id){
		$data['titulo'] = 'Proceso General de Inscripción';
		$data['contenido'] = 'clientes/procesos';
		$data['registro'] = $this->Model_Clientes_Bo->find($id);
		$_COOKIE['cliente_id'] = $id;
		$data['cliente_id'] = $_COOKIE['cliente_id'];
		$this->load->view('template/template', $data);
	}

	public function munpos(){
		$depto_id = $_POST['depto_id'];
		$query = $this->Model_Clientes_Bo->munpos($depto_id);
		
		echo '<select name="munpo_id" id="munpo_id" class="form-control">';
		foreach($query as $fila){
			echo '<option value="'.$fila->cod.'">'.$fila->munpo.'</option>';
		}
		echo '</select>';
		$required = array('name'=>'required', 'id'=>'required', 'src'=>'assets/img/exclamation.png', 'title'=>'Campo Obligatorio');
		//echo img($required);
	}

	public function cantones(){
		$munpo_id = $_POST['munpo_id'];
		$query = $this->Model_Clientes_Bo->cantones($munpo_id);

		echo '<select name="canton_id" id="canton_id" onchange="caserios(this.value)">';
		foreach($query as $fila){
			echo '<option value="'.$fila->cod.'">'.$fila->canton.'</option>';
		}
		echo '</select>';
		$required = array('name'=>'required', 'id'=>'required', 'src'=>'assets/img/exclamation.png', 'title'=>'Campo Obligatorio');
		//echo img($required);
	}

	public function caserios(){
		$canton_id = $_POST['canton_id'];
		$query = $this->Model_Clientes_Bo->caserios($canton_id);

		echo '<select name="caserio_id" id="caserio_id">';
		foreach($query as $fila){
			echo '<option value="'.$fila->cod.'">'.$fila->caserio.'</option>';
		}
		echo '</select>';
		$required = array('name'=>'required', 'id'=>'required', 'src'=>'assets/img/exclamation.png', 'title'=>'Campo Obligatorio');
		//echo img($required);
	}
	
	public function lista_referidos_boutique($id) {
		$data['titulo'] = 'Consultando Información - Cliente';
		$data['contenido'] = 'clientes/referidos';
		$data['registro'] = $this->Model_Clientes_Bo->find($id);
		$data['query'] = $this->Model_Referidos->lista_referidos_boutique($id);
		$this->load->view('template/template', $data);
	}
	
	public function create_venta($cliente_id) {
		
		$pagination = 20;
			
        $config['base_url'] = base_url().'Clientes_Bo/create_venta';
        $config['total_rows'] = $this->db->get('bo_producto')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

		$data['titulo'] = 'Producto - Descargo';
		$data['contenido'] = 'producto_descargo/proceso_venta/index';
		$_COOKIE['cliente_id'] = $cliente_id;
		$data['cliente_id'] = $_COOKIE['cliente_id'];
		$data['query'] = $this->Model_Producto_Bo->allx($pagination, $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}
	
}
