<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Sub Menu Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class SubMenu extends CI_Controller {

	//Constructor de Clase
	function __construct() {
		parent::__construct();

		$this->load->model('Model_SubMenu');
		$this->load->library('subMenuLib');
		$this->load->library(array('pagination'));

		$this->form_validation->set_message('required', 'Debe ingresar un valor para %s');
		$this->form_validation->set_message('numeric', '%s debe ser un número');
		$this->form_validation->set_message('is_natural', '%s debe ser un número mayor a cero');
	}

	public function index() {
	    $pagination = 20;
			
        $config['base_url'] = base_url().'SubMenu/index';
        $config['total_rows'] = $this->db->get('submenu')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 1; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

		$data['contenido'] = 'submenu/index';
		$data['titulo'] = 'Sub Menús';
		$data['query'] = $this->Model_SubMenu->all($pagination, $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}

    //con esta función validamos y protegemos el buscador
    public function validar(){
        $this->form_validation->set_rules('buscar', 'Sub Menú', 'required|min_length[2]|max_length[20]|trim|xss_clean');
        if ($this->form_validation->run() == TRUE) {
            $buscador = $this->input->post('buscar');
            $this->session->set_userdata('buscar', $buscador);
            redirect('SubMenu/consultar');
        } else {
			$data['titulo'] = 'Sub Menús';
			$data['contenido'] = 'submenu/result';
			$this->load->view('template/template', $data);
        }
    }

	public function consultar(){
        $buscador = $this->session->userdata('buscar');
        $pages = 10; //Número de registros mostrados por páginas
        $config['base_url'] = base_url().'SubMenu/consultar'; // parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php
        $config['total_rows'] = $this->Model_SubMenu->got_submenu($buscador); //calcula el número de filas
        $config['per_page'] = $pages; //Número de registros mostrados por páginas
        $config['num_links'] = 10; //Número de links mostrados en la paginación
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //inicializamos la paginación
        //el array con los datos a paginar ya preparados
        $data['query'] = $this->Model_SubMenu->total_posts_paginados($buscador, $config['per_page'], $this->uri->segment(3));

		$data['titulo'] = 'Sub Menús';
		$data['contenido'] = 'submenu/result';
		$this->load->view('template/template', $data);
	}

	public function my_validation() {
		return $this->submenulib->my_validation($this->input->post());
	}

	public function create() {
		$data['titulo'] = 'Crear Sub Menú';
		$data['contenido'] = 'submenu/create';
		$data['menus'] = $this->Model_SubMenu->get_menus(); /* Lista de los Menús */
		$data['count'] = $this->db->get('submenu')->num_rows();
		$this->load->view('template/template', $data);
	}

	public function insert() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('name', 'Nombre', 'required|callback_my_validation');
		$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		if($this->form_validation->run() == FALSE) {
			$this->create();
		} else {
			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['created'] = $today;
			$registro['updated'] = $today;
			
			$this->Model_SubMenu->insert($registro);
			redirect('SubMenu/index');
		}
	}

	public function edit($id) {
		$data['titulo'] = 'Actualizar Sub Menú';
		$data['contenido'] = 'submenu/edit';
		$data['menus'] = $this->Model_SubMenu->get_menus(); /* Lista de los Menús */
		$data['registro'] = $this->Model_SubMenu->find($id);
		$this->load->view('template/template', $data);
	}

	public function update() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('name', 'Nombre', 'required|callback_my_validation');
		$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		} else {
			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['updated'] = $today;
			$this->Model_SubMenu->update($registro);
			redirect('SubMenu/index');
		}
	}

	public function delete($id) {
		$this->Model_SubMenu->delete($id);
		redirect('SubMenu/index');
	}

	public function submenu_perfiles($submenu_id) {
		$data['contenido'] = 'submenu/submenu_perfiles';
		$data['titulo'] = 'Accesos de '.$this->Model_SubMenu->find($submenu_id)->name;

		//Cargar arreglos Izquierda y Derecha
		$perfiles = $this->submenulib->get_perfiles_asig_noasig($submenu_id);
		$data['query_izq'] = $perfiles[0];
		$data['query_der'] = $perfiles[1];

		$this->load->view('template/template', $data);
	}

	public function smp_noasig() {
		$perfil_id = $this->uri->segment(3);
		$submenu_id = $this->uri->segment(4);

		$this->load->library('subMenu_PerfilLib');
		$this->submenu_perfillib->quitar_acceso($perfil_id, $submenu_id);
		redirect('SubMenu/submenu_perfiles/'.$submenu_id);
	}

	public function smp_asig() {
		$perfil_id = $this->uri->segment(3);
		$submenu_id = $this->uri->segment(4);

		$this->load->library('subMenu_PerfilLib');
		$this->submenu_perfillib->dar_acceso($perfil_id, $submenu_id);
		redirect('SubMenu/submenu_perfiles/'.$submenu_id);
	}

//--------------------------Vistas para accesos de partes del sistema
	public function submenu_vistas($id) {
		$data['contenido'] = 'submenu/submenu_vistas';
		$data['titulo'] = 'Mostrando Links';
		$data['registro'] = $this->Model_SubMenu->find($id); /*Lista de los Sub Menús*/
		$data['perfiles'] = $this->Model_SubMenu_Perfil->get_perfiles(); /*Lista de los Perfiles */
		$this->load->view('template/template', $data);
	}

	public function update_submenu_vistas() {
		$registro = $this->input->post();
		$registro['updated'] = date('Y/m/d H:i:s');
		$this->Model_SubMenu_Vistas->update($registro);
		redirect('submenu/index');
	}

	public function submenu_perfiles_vistas($submenu_id) {
		$data['contenido'] = 'submenu/submenu_perfiles_vistas';
		$data['titulo'] = 'Accesos de '.$this->Model_SubMenu->find($submenu_id)->name;

		//Cargar arreglos Izquierda y Derecha
		$perfiles = $this->submenulib->get_perfilesx_asig_noasig($submenu_id);
		$data['query_izq'] = $perfiles[0];
		$data['query_der'] = $perfiles[1];

		$this->load->view('template/template', $data);
	}

	public function smpv_noasig() {
		$perfil_id = $this->uri->segment(3);
		$submenu_id = $this->uri->segment(4);

		$this->load->library('submenu_Perfil_VistasLib');
		$this->submenu_perfil_vistaslib->quitar_acceso_vistas($perfil_id, $submenu_id);
		redirect('SubMenu/submenu_perfiles_vistas/'.$submenu_id);
	}

	public function smpv_asig() {
		$perfil_id = $this->uri->segment(3);
		$submenu_id = $this->uri->segment(4);

		$this->load->library('subMenu_Perfil_VistasLib');
		$this->submenu_perfil_vistaslib->dar_acceso_vistas($perfil_id, $submenu_id);
		redirect('SubMenu/submenu_perfiles_vistas/'.$submenu_id);
	}
//--------------------------Vistas para accesos de partes del sistema.

    //Creamos una acción para cargar el ordenar los sub menús.
    public function submenu_orden(){
		$data['titulo'] = 'Odenando Sub Menús';
		$data['query'] = $this->Model_SubMenu->allx();
		$data['contenido'] = 'submenu/submenu_system_ordenar';
		$this->load->view('template/template',$data);
    }
    //Creamos una acción para actualizar el orden de los sub menús.
    public function update_orden(){
		//aquí ordenaremos los articulos con ajax.
		//array con el nuevo orden de nuestros registros.
		$submenus_ordenados = $_POST['submenu'];
		$pos = 1;
		foreach ($submenus_ordenados as $key){
			//actualizamos el campo orden.
			$this->db->set('orden', $pos);
			$this->db->where('id', $key);
			$this->db->update('submenu');
			$pos++;
		}
		echo "El Sub Menú se ha Actualizado con Exito!!!";
	}

}
