﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Load System Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Load_System extends CI_Controller {

	//Constructor de la clase
	function __construct() {
		parent::__construct();

		$this->load->model('Model_Load_System');
		$this->load->library(array('pagination'));
    }

	public function index() {
	    $pagination = 20;
        $config['base_url'] = base_url().'Load_System/index';
        $config['total_rows'] = $this->db->get('load_system')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

		$data['contenido'] = 'load_system/index';
		$data['titulo'] = 'Load System';
		$data['query'] = $this->Model_Load_System->all($pagination, $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}

    //Con esta función validamos y protegemos el buscador.
    public function validar(){
        $this->form_validation->set_rules('fechaini', 'Fecha Incio', 'required|min_length[2]|max_length[20]|trim|xss_clean');
		$this->form_validation->set_rules('fechafin', 'Fecha Fin', 'required|min_length[2]|max_length[20]|trim|xss_clean');
        if ($this->form_validation->run() == TRUE) {
            $buscador1 = $this->input->post('fechaini');
			$buscador2 = $this->input->post('fechafin');
            $this->session->set_userdata('fechaini', $buscador1);
			$this->session->set_userdata('fechafin', $buscador2);
            redirect('load_system/consultar');
        } else {
			$data['titulo'] = 'Load System';
			$data['contenido'] = 'load_system/result';
			$this->load->view('template/template', $data);
        }
    }

	public function consultar(){
        $buscador1 = $this->session->userdata('fechaini');
		$buscador2 = $this->session->userdata('fechafin');
        $pages = 20; //Número de registros mostrados por páginas.
        $config['base_url'] = base_url().'load_system/consultar'; //Parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php.
        $config['total_rows'] = $this->Model_Load_System->got_fechas($buscador1, $buscador2); //Calcula el número de filas.
        $config['per_page'] = $pages; //Número de registros mostrados por páginas.
        $config['num_links'] = 10; //Número de links mostrados en la paginación.
		$config['first_link'] = 'Primera';//Primer link.
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//Último link.
		
        $config['next_link'] = 'Siguiente »';//Siguiente link.
        $config['prev_link'] = '« Anterior';//Anterior link.
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //Inicializamos la paginación.
        //El array con los datos a paginar ya preparados.
        $data['query'] = $this->Model_Load_System->total_posts_paginados($buscador1, $buscador2, $config['per_page'], $this->uri->segment(3));

		$data['titulo'] = 'Load System';
		$data['contenido'] = 'load_system/result';
		$this->load->view('template/template', $data);
	}

	public function lat_lon($id){
		$data['contenido'] = 'load_system/lat_lon';
		$data['titulo'] = 'Geolocalización';
		$data['registro'] = $this->Model_Load_System->findx1($id);
		$this->load->view('template/template', $data);
	}

}
