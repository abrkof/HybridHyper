<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Menu Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Menu extends CI_Controller {

	//Constructor de Clase
	function __construct() {
		parent::__construct();

		$this->load->model('Model_Menu');
		$this->load->library('menuLib');
		$this->load->library(array('pagination'));

		$this->form_validation->set_message('required', 'Debe ingresar un valor para %s');
		$this->form_validation->set_message('numeric', '%s debe ser un número');
		$this->form_validation->set_message('is_natural', '%s debe ser un número mayor a cero');
	}

	public function index() {
	    $pagination = 20;
			
        $config['base_url'] = base_url().'menu/index';
        $config['total_rows'] = $this->db->get('menu')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 1; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

		$data['contenido'] = 'menu/index';
		$data['titulo'] = 'Menús';
		$data['query'] = $this->Model_Menu->all($pagination, $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}

    //con esta función validamos y protegemos el buscador
    public function validar(){
        $this->form_validation->set_rules('buscar', 'Menú', 'required|min_length[2]|max_length[20]|trim|xss_clean');
        if ($this->form_validation->run() == TRUE) {
            $buscador = $this->input->post('buscar');
            $this->session->set_userdata('buscar', $buscador);
            redirect('menu/consultar');
        } else {
			$data['titulo'] = 'Menús';
			$data['contenido'] = 'menu/result';
			$this->load->view('template/template', $data);
        }
    }

	public function consultar(){
        $buscador = $this->session->userdata('buscar');
        $pages = 10; //Número de registros mostrados por páginas
        $config['base_url'] = base_url().'menu/consultar'; // parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php
        $config['total_rows'] = $this->Model_Menu->got_menu($buscador); //calcula el número de filas
        $config['per_page'] = $pages; //Número de registros mostrados por páginas
        $config['num_links'] = 10; //Número de links mostrados en la paginación
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //inicializamos la paginación
        //el array con los datos a paginar ya preparados
        $data['query'] = $this->Model_Menu->total_posts_paginados($buscador, $config['per_page'], $this->uri->segment(3));

		$data['titulo'] = 'Menús';
		$data['contenido'] = 'menu/result';
		$this->load->view('template/template', $data);
	}

	public function my_validation() {
		return $this->menulib->my_validation($this->input->post());
	}

	public function create() {
		$data['titulo'] = 'Crear Menú';
		$data['contenido'] = 'menu/create';
		$data['count'] = $this->db->get('menu')->num_rows();
		$this->load->view('template/template', $data);
	}

	public function insert() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('name', 'Nombre', 'required|callback_my_validation');
		$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		if($this->form_validation->run() == FALSE) {
			$this->create();
		} else {
			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['created'] = $today;
			$registro['updated'] = $today;
			
			$this->Model_Menu->insert($registro);
			redirect('menu/index');
		}
	}

	public function edit($id) {
		$data['titulo'] = 'Actualizar Menú';
		$data['contenido'] = 'menu/edit';
		$data['registro'] = $this->Model_Menu->find($id);
		$this->load->view('template/template', $data);
	}

	public function update() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('name', 'Nombre', 'required|callback_my_validation');
		$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		} else {
			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['updated'] = $today;
			$this->Model_Menu->update($registro);
			redirect('menu/index');
		}
	}

	public function delete($id) {
		$this->Model_Menu->delete($id);
		redirect('menu/index');
	}

	public function menu_perfiles($menu_id) {
		$data['contenido'] = 'menu/menu_perfiles';
		$data['titulo'] = 'Accesos de '.$this->Model_Menu->find($menu_id)->name;

		// Cargar arreglos Izquierda y Derecha
		$perfiles = $this->menulib->get_perfiles_asig_noasig($menu_id);
		$data['query_izq'] = $perfiles[0];
		$data['query_der'] = $perfiles[1];

		$this->load->view('template/template', $data);
	}

	public function mp_noasig() {
		$perfil_id = $this->uri->segment(3);
		$menu_id = $this->uri->segment(4);

		$this->load->library('menu_PerfilLib');
		$this->menu_perfillib->quitar_acceso($perfil_id, $menu_id);
		redirect('menu/menu_perfiles/'.$menu_id);
	}

	public function mp_asig() {
		$perfil_id = $this->uri->segment(3);
		$menu_id = $this->uri->segment(4);

		$this->load->library('menu_PerfilLib');
		$this->menu_perfillib->dar_acceso($perfil_id, $menu_id);
		redirect('menu/menu_perfiles/'.$menu_id);
	}

//--------------------------Vistas para accesos de partes del sistema
	public function menu_vistas($id) {
		$data['contenido'] = 'menu/menu_vistas';
		$data['titulo'] = 'Mostrando Links';
		$data['registro'] = $this->Model_Menu->find($id); /*Lista de los Menús*/
		$data['perfiles'] = $this->Model_Menu_Perfil->get_perfiles(); /*Lista de los Perfiles */
		$this->load->view('template/template', $data);
	}

	public function update_menu_vistas() {
		$registro = $this->input->post();
		$registro['updated'] = date('Y/m/d H:i:s');
		$this->Model_Menu_Vistas->update($registro);
		redirect('menu/index');
	}

	public function menu_perfiles_vistas($menu_id) {
		$data['contenido'] = 'menu/menu_perfiles_vistas';
		$data['titulo'] = 'Accesos de '.$this->Model_Menu->find($menu_id)->name;

		// Cargar arreglos Izquierda y Derecha
		$perfiles = $this->menulib->get_perfilesx_asig_noasig($menu_id);
		$data['query_izq'] = $perfiles[0];
		$data['query_der'] = $perfiles[1];

		$this->load->view('template/template', $data);
	}

	public function mpv_noasig() {
		$perfil_id = $this->uri->segment(3);
		$menu_id = $this->uri->segment(4);

		$this->load->library('menu_Perfil_VistasLib');
		$this->menu_perfil_vistaslib->quitar_acceso_vistas($perfil_id, $menu_id);
		redirect('menu/menu_perfiles_vistas/'.$menu_id);
	}

	public function mpv_asig() {
		$perfil_id = $this->uri->segment(3);
		$menu_id = $this->uri->segment(4);

		$this->load->library('menu_Perfil_VistasLib');
		$this->menu_perfil_vistaslib->dar_acceso_vistas($perfil_id, $menu_id);
		redirect('menu/menu_perfiles_vistas/'.$menu_id);
	}
//--------------------------Vistas para accesos de partes del sistema.

    //Creamos una acción para cargar el ordenar los menús.
    public function menu_orden(){
		$data['titulo'] = 'Odenando Menús';
		$data['query'] = $this->Model_Menu->allx();
		$data['contenido'] = 'menu/menu_system_ordenar';
		$this->load->view('template/template',$data);
    }
    //Creamos una acción para actualizar el orden de los menús.
    public function update_orden(){
		//aquí ordenaremos los articulos con ajax.
		//array con el nuevo orden de nuestros registros.
		$menus_ordenados = $_POST['menu'];
		$pos = 1;
		foreach ($menus_ordenados as $key){
			//actualizamos el campo orden.
			$this->db->set('orden', $pos);
			$this->db->where('id', $key);
			$this->db->update('menu');
			$pos++;
		}
		echo "El Menú se ha Actualizado con Exito!!!";
	}

}
