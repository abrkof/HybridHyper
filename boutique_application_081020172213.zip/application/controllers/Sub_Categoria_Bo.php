﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Sub Categoria Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Sub_Categoria_Bo extends CI_Controller{

	//Constructor de Clase
	function __construct(){
		parent::__construct();

		$this->load->model('Model_Sub_Categoria_Bo');
		
	    $this->form_validation->set_message('required', 'El %s no puede ir vacío!');
        $this->form_validation->set_message('min_length', 'La %s debe tener al menos %s carácteres');
        $this->form_validation->set_message('max_length', 'La %s no puede tener más de %s carácteres');/**/
	}

	public function index(){
	    //
		
		$pagination = 10;
			
        $config['base_url'] = base_url().'Sub_Categoria_Bo/index';
        $config['total_rows'] = $this->db->get('bo_subcategoria')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);
		
		$data['titulo'] = 'Sub Categorías';
		$data['contenido'] = 'subcategoria/index';
		$data['query'] = $this->Model_Sub_Categoria_Bo->all($pagination, $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}

    //con esta función validamos y protegemos el buscador
    public function validar(){
        //
		
		$this->form_validation->set_rules('buscar', 'Sub Categoría', 'required|min_length[2]|max_length[20]|trim|xss_clean');

        if ($this->form_validation->run() == TRUE) {
            $buscador = $this->input->post('buscar');
            $this->session->set_userdata('buscar', $buscador);
            redirect('Sub_Categoria_Bo/consultar');
        } else {
			$data['titulo'] = 'Sub Categorías';
			$data['contenido'] = 'subcategoria/result';
			$this->load->view('template/template', $data);
        }
    }

	public function consultar(){
        //
		
		$buscador = $this->session->userdata('buscar');
        $pages = 10; //Número de registros mostrados por páginas
        $config['base_url'] = base_url() . 'Sub_Categoria_Bo/consultar'; // parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php
        $config['total_rows'] = $this->Model_Sub_Categoria_Bo->got_subcategoria($buscador); //calcula el número de filas
        $config['per_page'] = $pages; //Número de registros mostrados por páginas
        $config['num_links'] = 10; //Número de links mostrados en la paginación
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //inicializamos la paginación

		$data['titulo'] = 'Sub Categorías';
		$data['contenido'] = 'subcategoria/result';
		$data['query'] = $this->Model_Sub_Categoria_Bo->total_posts_paginados($buscador, $config['per_page'], $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}

	public function create() {
		//
		
		$data['titulo'] = 'Registrando Sub Categoría';
		$data['contenido'] = 'subcategoria/create';
		$data['categorias'] = $this->Model_Sub_Categoria_Bo->get_categorias(); /* Lista de las Categorias */
		$data['count'] = $this->db->get('bo_subcategoria')->num_rows();
		$this->load->view('template/template', $data);
	}

	public function insert() {
		//
		
		$registro = $this->input->post();

		//$this->form_validation->set_rules('name', 'Titulo', 'required|callback_my_validation');
		//$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		/*if($this->form_validation->run() == FALSE) {
			$this->create();
		} else {*/
			$registro['image'] = 'afd-8475.jpg';
			$registro['usuario_id'] = $this->session->userdata('usuario_id');

			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['created'] = $today;
			$registro['updated'] = $today;
			$this->Model_Sub_Categoria_Bo->insert($registro);
			redirect('Sub_Categoria_Bo/index');
		//}
	}

	public function edit($id) {
		//
		
		$data['titulo'] = 'Actualizando Sub Categoría';
		$data['contenido'] = 'subcategoria/edit';
		$data['registro'] = $this->Model_Sub_Categoria_Bo->find($id);
		$data['categorias'] = $this->Model_Sub_Categoria_Bo->get_categorias(); /* Lista de las Categorias */
		$this->load->view('template/template', $data);
	}

	public function update() {
		//
		
		$registro = $this->input->post();

		//$this->form_validation->set_rules('name', 'Titulo', 'required|callback_my_validation');
		//$this->form_validation->set_rules('orden', 'Orden', 'numeric|is_natural');
		/*if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		} else {*/
			$registro['usuario_id'] = $this->session->userdata('usuario_id');

			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['updated'] = $today;
			$this->Model_Sub_Categoria_Bo->update($registro);
			redirect('Sub_Categoria_Bo/index');
		//}
	}

	public function delete($id) {
		//
		
		$this->Model_Sub_Categoria_Bo->delete($id);
		redirect('Sub_Categoria_Bo/index');
	}
	
}
