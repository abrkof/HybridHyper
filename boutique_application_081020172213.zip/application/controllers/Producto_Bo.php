﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Producto Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Producto_Bo extends CI_Controller{

	//Constructor de Clase
	function __construct(){
		parent::__construct();

		$this->load->model('Model_Categoria_Bo');
		$this->load->model('Model_Producto_Bo');
		$this->load->library('producto_BoLib');
		$this->load->model('Model_Producto_Bo_Cargo');

	    $this->form_validation->set_message('required', 'El %s no puede ir vacío!');
        $this->form_validation->set_message('min_length', 'La %s debe tener al menos %s carácteres');
        $this->form_validation->set_message('max_length', 'La %s no puede tener más de %s carácteres');/**/
		
		$this->form_validation->set_message('norep', 'Existe otro registro con el mismo nombre');
	}

	public function index(){
		//
		
		$pagination = 21;
			
        $config['base_url'] = base_url().'Producto_Bo/index';
        $config['total_rows'] = $this->db->get('bo_producto')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);
		
		$data['titulo'] = 'Producto';
		$data['contenido'] = 'producto/index';
		$data['query'] = $this->Model_Producto_Bo->allx($pagination, $this->uri->segment(3));
		$data['categoria'] = $this->Model_Categoria_Bo->all();
		$this->load->view('template/template', $data);
	}

	public function ajax(){
		//
		
		$data['titulo'] = 'Producto';
		$data['subcategoria'] = $this->Model_Categoria_Bo->subcategoria();
		$data['get_subcategoria'] = $this->Model_Producto_Bo->get_subcategoria();
		
		$id = $_REQUEST['i'];
		
		$data['articulo'] = $this->Model_Producto_Bo->all($id);
		$data['get_producto'] = $this->Model_Producto_Bo->get_producto();
		$this->load->view('/producto/ajax', $data);
	}

	public function consultar(){
	    //
		
		$pagination = 10;
			
        $config['base_url'] = base_url().'Producto_Bo/consultar';
        $config['total_rows'] = $this->db->get('bo_producto')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 10; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

		$data['titulo'] = 'Producto (Administrar)';
		$data['contenido'] = 'producto/index';
		$data['query'] = $this->Model_Producto_Bo->allx($pagination, $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}

    //con esta función validamos y protegemos el buscador
    public function validar(){
        //
		
		$this->form_validation->set_rules('buscar', 'Producto', 'required|min_length[2]|max_length[20]|trim|xss_clean');

        if ($this->form_validation->run() == TRUE) {
            $buscador = $this->input->post('buscar');
            $this->session->set_userdata('buscar', $buscador);
            redirect('Producto_Bo/search');
        } else {
			$data['titulo'] = 'Artículos';
			$data['contenido'] = 'producto/result';
			$this->load->view('template/template', $data);
        }
    }

	public function search(){
        //
		
		$buscador = $this->session->userdata('buscar');
        $pages = 10; //Número de registros mostrados por páginas
        $config['base_url'] = base_url().'cityguides/Producto_Bo/search'; // parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php
        $config['total_rows'] = $this->Model_Producto_Bo->got_producto($buscador); //calcula el número de filas
        $config['per_page'] = $pages; //Número de registros mostrados por páginas
        $config['num_links'] = 10; //Número de links mostrados en la paginación
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //inicializamos la paginación
        //el array con los datos a paginar ya preparados
        $data['query'] = $this->Model_Producto_Bo->total_posts_paginados($buscador, $config['per_page'], $this->uri->segment(4));
        //cargamos la vista y el array data

		$data['titulo'] = 'Productos';
		$data['contenido'] = 'producto/result';
		$this->load->view('template/template', $data);
	}

	public function all() {
		//
		
		$data['titulo'] = 'Producto';
		$data['contenido'] = 'producto/all';
		$data['query'] = $this->Model_Producto_Bo->all_productos();
		$count_total = $this->Model_Producto_Bo->countTotal();
		//$data['count'] = $this->Model_Producto->countTotal();
		$data['total1'] = $count_total->total_cantidad;
		$data['total2'] = $count_total->total_costo_unidad;
		$data['total3'] = $count_total->total_precio_costo;
		$data['total4'] = $count_total->total_precio_venta;
		$data['total5'] = $count_total->total_precio_oferta;
		$data['total6'] = $count_total->total_precio_credito;
		//$data['total4'] = $count_total->total4;/**/
		$this->load->view('template/template', $data);
	}
	
	public function norep() {
		return $this->producto_bolib->norep($this->input->post());
	}

	public function create() {
		//
		
		$data['titulo'] = 'Registrando Producto';
		$data['contenido'] = 'producto/create';
		$data['categorias'] = $this->Model_Producto_Bo->get_categorias(); /* Lista de las Categorias */
		$data['subcategorias'] = $this->Model_Producto_Bo->get_subcategorias(); /* Lista de las Sub Categorias */
		$data['marcas'] = $this->Model_Producto_Bo->get_marcas(); /* Lista de las Marcas */
		$data['proveedores'] = $this->Model_Producto_Bo->get_proveedores(); /* Lista de los Proveedores */
		$this->load->view('template/template', $data);
	}

    //FUNCIÓN PARA SUBIR LA IMAGEN Y VALIDAR EL TÍTULO
    public function do_upload() {
        //
		
		$registro = $this->input->post();
		$this->form_validation->set_rules('subcategoria_id', 'Sub Categoria', 'required|callback_norep');
		//$this->form_validation->set_rules('descripcion', 'Descripción', 'required|xss_clean');
		//$this->form_validation->set_rules('userfile', 'Imagen', 'required');
        //SI EL FORMULARIO PASA LA VALIDACIÓN HACEMOS TODO LO QUE SIGUE
        if ($this->form_validation->run() == FALSE){
			$this->create();
		}else{
			$config['upload_path'] = 'assets/boutique/images/producto/';
			$config['allowed_types'] = 'gif|jpg|jpe|jpeg|png';
			//$config['max_size'] = '2000';
			//$config['max_width'] = '2024';
			//$config['max_height'] = '2008';
			//Hacemos el requeriento de la libreria "upload"
			$this->load->library('upload', $config);
			//SI LA IMAGEN FALLA AL SUBIR MOSTRAMOS EL ERROR EN LA VISTA ACTUAL
			if (!$this->upload->do_upload()) {
			$data = array('error' => $this->upload->display_errors());
			$this->create($data);
			/*$data['titulo'] = 'Registrando Producto';
			$data['contenido'] = 'slider/create';
			$this->load->view('template/template', $data);*/
            //redirect('upload/do_upload', $error);
			} else {
				//EN OTRO CASO SUBIMOS LA IMAGEN, CREAMOS LA MINIATURA Y HACEMOS
				//ENVÍAMOS LOS DATOS AL MODELO PARA HACER LA INSERCIÓN
				$file_info = $this->upload->data();
				//USAMOS LA FUNCIÓN create_thumbnail Y LE PASAMOS EL NOMBRE DE LA IMAGEN,
				//ASÍ YA TENEMOS LA IMAGEN REDIMENSIONADA
				$this->_create_thumbnail($file_info['file_name']);
				$data = array('upload_data' => $this->upload->data());
				$count = $this->db->get('bo_producto')->num_rows();
				$id = $count + 1;
				$registro['id'] = $id;
				$total = $this->input->post('cantidad') * $this->input->post('precio_costo_unidad');
				$registro['producto'] = $this->input->post('producto');
				$registro['opcion1'] = strtoupper($this->input->post('opcion1'));
				$registro['detalles'] = strtoupper($this->input->post('detalles'));
				$registro['opcion2'] = strtoupper($this->input->post('opcion2'));
				$registro['valores'] = strtoupper($this->input->post('valores'));
				$registro['size'] = strtoupper($this->input->post('size'));
				$registro['total_precio_costo'] = $total;
				
				//if $registro['userfile'] = NULL ? 'afd-8475.jpg' : $file_info['file_name'];
				/*if ($registro['userfile'] = NULL){
					$registro['userfile'] = base_url('assets/images/afd-8475.jpg');
				} else {*/
					$registro['userfile'] = $file_info['file_name'];
				//}
			
				$registro['usuario_id'] = $this->session->userdata('usuario_id');

				$timezone = "America/Managua";
				date_default_timezone_set($timezone);
				$today = date('Y-m-d H:i:s');
				
				$registro['created'] = $today;
				$registro['updated'] = $today;
				$this->Model_Producto_Bo->insert($registro);
				//$this->Model_Producto->insert($registro);
			}
			redirect('Producto_Bo/index');
		}
	}

	public function edit($id) {
		//
		
		$data['titulo'] = 'Actualizando Producto';
		$data['contenido'] = 'producto/edit';
		$data['registro'] = $this->Model_Producto_Bo->find($id);
		$data['categorias'] = $this->Model_Producto_Bo->get_categorias(); /* Lista de las Categorias */
		$data['subcategorias'] = $this->Model_Producto_Bo->get_subcategorias(); /* Lista de las Sub Categorias */
		$data['marcas'] = $this->Model_Producto_Bo->get_marcas(); /* Lista de las Marcas */
		$data['proveedores'] = $this->Model_Producto_Bo->get_proveedores(); /* Lista de los Proveedores */
		//$count = $this->Model_Producto_Bo->countRegs($id);
		//$data['total_producto'] = $count->cantidad;
		$this->load->view('template/template', $data);
	}

	public function update() {
		//
		
		$registro = $this->input->post();

		$this->form_validation->set_rules('producto', 'Nombre Producto', 'required|callback_norep');
		//$this->form_validation->set_rules('nombre_version', 'Nombre Versión', 'required|callback_nombre_version');
		if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		} else {/**/
			//$registro['producto'] = strtoupper($this->input->post('producto'));
			$total = $this->input->post('cantidad') * $this->input->post('precio_costo_unidad');
			$registro['total_precio_costo'] = $total;
			$registro['usuario_id'] = $this->session->userdata('usuario_id');
			
			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['updated'] = $today;
			$this->Model_Producto_Bo->update($registro);
			redirect('Producto_Bo/index');
		}//
	}
	
	public function edit_img($id) {
		//
		
		$data['titulo'] = 'Actualizar Producto';
		$data['contenido'] = 'producto/edit_img';
		$data['registro'] = $this->Model_Producto_Bo->find($id);
		$this->load->view('template/template', $data);
	}

	public function update_img() {
		//
		
		$registro = $this->input->post();

		$this->form_validation->set_rules('id', 'id', 'required');
		
		if($this->form_validation->run() == FALSE) {
			$this->edit_img($registro['id']);
			}else{
				$config['upload_path'] = './assets/boutique/images/producto/';
				$config['allowed_types'] = 'gif|jpg|jpe|jpeg|png';
				//$config['max_size'] = '2000';
				//$config['max_width'] = '2024';
				//$config['max_height'] = '2008';
				//Hacemos el requeriento de la libreria "upload"
				$this->load->library('upload', $config);
				//SI LA IMAGEN FALLA AL SUBIR MOSTRAMOS EL ERROR EN LA VISTA ACTUAL
				if (!$this->upload->do_upload()) {
				$data = array('error' => $this->upload->display_errors());
				$this->edit_img($registro['id']);
				//redirect('upload/do_upload', $error);
			} else {
				//EN OTRO CASO SUBIMOS LA IMAGEN, CREAMOS LA MINIATURA Y HACEMOS 
				//ENVÍAMOS LOS DATOS AL MODELO PARA HACER LA INSERCIÓN
				$file_info = $this->upload->data();
				//USAMOS LA FUNCIÓN create_thumbnail Y LE PASAMOS EL NOMBRE DE LA IMAGEN,
				//ASÍ YA TENEMOS LA IMAGEN REDIMENSIONADA
				$this->_create_thumbnail($file_info['file_name']);
				$data = array('upload_data' => $this->upload->data());
				$ip = $_SERVER['REMOTE_ADDR'];
				$usrx = $this->session->userdata('usuario_id');
				$imagen = $file_info['file_name'];
				$registro['userfile'] = $imagen;

				$timezone = "America/Managua";
				date_default_timezone_set($timezone);
				$today = date('Y-m-d H:i:s');
				
				$registro['updated'] = $today;
				$this->Model_Producto_Bo->update($registro);
				
				redirect('Producto_Bo/index');
			}
		}
	}
	
    //FUNCIÓN PARA CREAR LA MINIATURA A LA MEDIDA QUE LE DIGAMOS
    public function _create_thumbnail($filename){
        //
		
		$config['image_library'] = 'gd2';
        //CARPETA EN LA QUE ESTÁ LA IMAGEN A REDIMENSIONAR
        $config['source_image'] = './assets/boutique/images/producto/'.$filename;
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = TRUE;
        //CARPETA EN LA QUE GUARDAMOS LA MINIATURA.
        $config['new_image']='./assets/boutique/images/producto/thumbs/';
        $config['width'] = 150;
        $config['height'] = 150;
        $this->load->library('image_lib', $config); 
        $this->image_lib->resize();
    }

	public function delete($id) {
		//
		
		$this->Model_Producto_Bo->delete($id);
		redirect('Producto_Bo/consultar');
	}
	
	public function procesos($id){
		//
		
		$data['titulo'] = 'Realizar Tipo Descargo';
		$data['contenido'] = 'producto/procesos';
		$data['registro'] = $this->Model_Producto_Bo->find($id);
		$this->load->view('template/template', $data);
	}

	public function proceso($id) {
		//
		
		$data['titulo'] = 'Cargando Producto';
		$data['contenido'] = 'producto/proceso';
		$data['registro'] = $this->Model_Producto_Bo->proceso($id);
		$count = $this->Model_Producto_Bo->countRegs($id);
		$data['total_productos'] = $count->cantidad;
		//$data['detalles'] = $this->Model_Perfumeria->get_product($id);
		//$data['valores'] = $this->Model_Perfumeria->get_valores($id);
		//$data['valoresx'] = $this->db->get_where('bo_perfumes', array('id'=>$id))->result();
		$this->load->view('template/template', $data);
	}

	public function query($id) {
		//
		
		$data['titulo'] = 'Cargando Producto';
		$data['contenido'] = 'producto/query';
		$data['registro'] = $this->Model_Producto_Bo->proceso($id);
		$count = $this->Model_Producto_Bo->countRegs($id);
		$data['total_producto'] = $count->cantidad;
		$this->load->view('template/template', $data);
	}

	public function update_proceso() {
		//
		
		//$registro = $this->input->post();

		/*$this->form_validation->set_rules('casa_id', 'Casa', 'required|callback_norep');
		if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		} else {*/
			$registro['id'] = $this->input->post('id');
			$rc['cantidad'] = $this->input->post('total_producto') + $this->input->post('cantidad');
			$rc['total_precio_costo'] = $rc['cantidad'] * $this->input->post('precio_costo_unidad');
			
			$registro['cantidad'] = $this->input->post('total_producto') + $this->input->post('cantidad');
			
			$rc['opcion1'] = strtoupper($this->input->post('opcion1'));
			$rc['detalles'] = strtoupper($this->input->post('detalles'));
			$rc['opcion2'] = strtoupper($this->input->post('opcion2'));
			$rc['valores'] = strtoupper($this->input->post('valores'));
			$rc['estilo'] = strtoupper($this->input->post('estilo'));
			$rc['size'] = strtoupper($this->input->post('size'));
						
			$registro['categoria_id'] = $this->input->post('categoria_id');
			$registro['subcategoria_id'] = $this->input->post('subcategoria_id');
			$registro['producto'] = $this->input->post('producto');
			$registro['marca_id'] = $this->input->post('marca_id');
			$registro['proveedor_id'] = $this->input->post('proveedor_id');
			$registro['userfile'] = $this->input->post('userfile');
			
			$registro['opcion1'] = strtoupper($this->input->post('opcion1'));
			$registro['detalles'] = strtoupper($this->input->post('detalles'));
			$registro['opcion2'] = strtoupper($this->input->post('opcion2'));
			$registro['valores'] = strtoupper($this->input->post('valores'));
			$registro['estilo'] = strtoupper($this->input->post('estilo'));
			$registro['size'] = strtoupper($this->input->post('size'));
			
			$registro['precio_costo_unidad'] = $this->input->post('precio_costo_unidad');
			$registro['precio_venta'] = $this->input->post('precio_venta');
			$registro['precio_oferta'] = $this->input->post('precio_oferta');
			$registro['precio_credito'] = $this->input->post('precio_credito');
			
			$registro['created'] = date('Y-m-d H:i:s');
			
			$rc['precio_costo_unidad'] = $this->input->post('precio_costo_unidad');
			$rc['precio_venta'] = $this->input->post('precio_venta');
			$rc['precio_oferta'] = $this->input->post('precio_oferta');
			$rc['precio_credito'] = $this->input->post('precio_credito');
			
			$registro['total_precio_costo'] = (($this->input->post('cantidad') + $this->input->post('total_producto')) * $registro['precio_costo_unidad']);
			$registro['updated'] = date('Y-m-d H:i:s');
			$registro['usuario_id'] = $this->session->userdata('usuario_id');
			$this->Model_Producto_Bo->updatex($rc);
			$this->Model_Producto_Bo_Cargo->insert($registro);
			redirect('Producto_Bo/index');
		//}
	}
	
	public function subcategoria(){
		$categoria_id = $_POST['categoria_id'];
		$query = $this->Model_Producto_Bo->subcategorias($categoria_id);
		
		echo '<select name="subcategoria_id" id="subcategoria_id" class="form-control">';
		foreach($query as $fila){
			echo '<option value="'.$fila->id.'">'.$fila->subcategoria.'</option>';
		}
		echo '</select>';
		$required = array('name'=>'required', 'id'=>'required', 'src'=>'assets/img/exclamation.png', 'title'=>'Campo Obligatorio');
		//echo img($required);
	}
	
}
