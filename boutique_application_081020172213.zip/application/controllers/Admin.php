﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Admin Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Admin extends CI_Controller{

	// Constructor de Clase
	function __construct(){
		parent::__construct();

		$this->load->library('usuarioLib');
		$this->load->model('Model_Load_System');
		$this->load->model('Model_Sesiones');
		$this->form_validation->set_message('required', 'Debe ingresar un valor para %s');
		$this->form_validation->set_message('loginOk', 'Usuario o clave incorrectos');
		$this->form_validation->set_message('matches', '%s no coincide con %s');
		$this->form_validation->set_message('cambiook', 'No se puede realizar el cambio de clave');
	}


	public function index(){
		$this->Model_Load_System->load_system();
		//$segmentos = array('inicio', 'acceso_denegado');
		//echo site_url($segments);
		$data['contenido'] = 'admin/index';
		$data['titulo'] = 'Inicio';
		$this->load->view('template/template', $data);
	}

	public function acerca_de(){
		$data['contenido'] = 'admin/acerca_de';
		$data['titulo'] = 'Acerca De';
		$this->load->view('template/template', $data);
	}

	public function acceso_denegado(){
		$data['contenido'] = 'admin/acceso_denegado';
		$data['titulo'] = 'Acceso Denegado';
		$this->load->view('template/template', $data);
	}

	public function inicio_sesion(){
        //$this->Model_Load_System->load_system();
		
		if($this->session->userdata('usuario_id')){
            redirect('admin/acerca_de');
            exit;
        } else {
			$data['contenido'] = 'admin/inicio_sesion';
			$data['titulo'] = 'Inicio de Sesión';
			$this->load->view('template/template', $data);
		}
	}

	public function ingresar(){
		$this->form_validation->set_rules('login', 'Usuario', 'required|callback_loginOk');
		$this->form_validation->set_rules('password', 'Clave', 'required');
		if($this->form_validation->run() == FALSE){
			$this->inicio_sesion();
		} else {
			$this->Model_Sesiones->insert();
			redirect('admin/acerca_de');//$this->acerca_de();//
		}
	}

	public function loginOk(){
		$user = $this->input->post('login');
		$password = $this->input->post('password');
		return $this->usuariolib->login($user, $password);
	}

	public function salir(){
		$this->Model_Sesiones->delete();
		$this->session->sess_destroy();
		redirect('admin/acerca_de');//$this->acerca_de();//
	}

	public function cambio_clave(){
		$data['contenido'] = 'admin/cambio_clave';
		$data['titulo'] = 'Cambiar Clave';
		$this->load->view('template/template', $data);
	}

	public function cambiar_clave(){
		$this->form_validation->set_rules('clave_act', 'Clave Actual', 'required|callback_cambioOk');
		$this->form_validation->set_rules('clave_new', 'Clave Nueva', 'required|matches[clave_rep]');
		$this->form_validation->set_rules('clave_rep', 'Confirmar Clave Nueva', 'required');
		if($this->form_validation->run() == FALSE){
			$this->cambio_clave();
		} else {
			redirect('admin/acerca_de');
		}
	}

	public function cambioOk(){
		$act = $this->input->post('clave_act');
		$new = $this->input->post('clave_new');
		return $this->usuariolib->cambiarPWD($act, $new);
	}


	public function export_to_excel(){
		header("Content-type: application/vnd.ms-excel; name='excel'");
		$datestring = date('Y/m/d');
		header("Content-Disposition: filename=".$_REQUEST['title']."  ".$datestring.".xls");
		header("Pragma: no-cache");
		header("Expires: 0");
		
		echo $_REQUEST['datos_a_enviar'];
	}

}
