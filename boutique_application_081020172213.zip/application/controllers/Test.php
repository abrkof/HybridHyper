<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Test Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Test extends CI_Controller {

	//php 5 constructor
	function __construct() {
		parent::__construct();
		//$this->load->scaffolding('usr');
		echo anchor('inicio/acerca_de','Regresar al Sistema');
		echo ' ';
		echo anchor('test/index','Cargar Perfil del Test');
		echo ' ';
		echo anchor('test/rendimiento','Cargar Test de Rendimiento');
		echo ' ';
		echo anchor('test/testx','Cargar Test de Operaciones');
		echo ' ';
		//echo anchor('test/message','Cargar Mensaje Particular');
		echo '<hr>';
		echo 'noze, ';
		echo '<meta charset="utf-8">';
		//$this->load->view('inicio/testx');
	}

	
	function index() {
		$this->output->enable_profiler(TRUE);
		echo "Mensaje de salida";
	}
	
	function rendimiento(){
		$this->benchmark->mark('inicio_test');
		
		for($i=0;$i<1000000;$i++){
			$a = md5('test'.$i);
		}
		
		$this->benchmark->mark('fin_test');
		
		echo "Tiempo del test:". $this->benchmark->elapsed_time('inicio_test', 'fin_test');
	}
	
	function testx(){
		$this->load->library('unit_test');
		
		$tests = Array(3+2, 2+3, 1+4, 2+1, 'texto');
		$res_esperado = 5;
		
		foreach($tests as $test){
			$this->unit->run($test, $res_esperado, 'Test de operaciones');
		}
		
		echo $this->unit->report();
		
	}

	public function message($to = 'Mundo', $foo = 'ke pex'){
		echo "¡Hola {$to}, {$foo}!".PHP_EOL;
	}

}