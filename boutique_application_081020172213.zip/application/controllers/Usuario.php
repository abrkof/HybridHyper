﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Usuario Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
class Usuario extends CI_Controller {

	//Constructor de la clase
	function __construct() {
		parent::__construct();

		$this->load->model('Model_Usuario');
		$this->load->library('usuarioLib');
		$this->load->library(array('pagination'));

		$this->form_validation->set_message('required', 'Debe ingresar campo %s');
        $this->form_validation->set_message('valid_email', 'Campo %s no es un eMail valido');
        $this->form_validation->set_message('my_validation', 'Existe otro registro con el mismo nombre de usuario');
		$this->form_validation->set_message('my_validation_mail', 'Existe otro registro con el mismo correo');
    }

	public function index() {
	    $pagination = 10;
		.
        $config['base_url'] = base_url().'usuario/index';
        $config['total_rows'] = $this->db->get('usuario')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 1; 
		
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

		$data['contenido'] = 'usuario/index';
		$data['titulo'] = 'Usuarios';
		$data['query'] = $this->Model_Usuario->get_usuariox($pagination, $this->uri->segment(3));
		$this->load->view('template/template', $data);
	}

    //con esta función validamos y protegemos el buscador
    public function validar(){
        $this->form_validation->set_rules('buscar', 'Usuario', 'required|min_length[2]|max_length[20]|trim|xss_clean');
        if ($this->form_validation->run() == TRUE) {
            $buscador = $this->input->post('buscar');
            $this->session->set_userdata('buscar', $buscador);
            redirect('usuario/consultar');
        } else {
			$data['titulo'] = 'Usuarios';
			$data['contenido'] = 'usuario/result';
			$this->load->view('template/template', $data);
        }
    }

	public function consultar(){
        $buscador = $this->session->userdata('buscar');
        $pages = 10; //Número de registros mostrados por páginas
        $config['base_url'] = base_url().'usuario/consultar'; // parametro base de la aplicación, si tenemos un .htaccess nos evitamos el index.php
        $config['total_rows'] = $this->Model_Usuario->got_usuario($buscador); //calcula el número de filas
        $config['per_page'] = $pages; //Número de registros mostrados por páginas
        $config['num_links'] = 10; //Número de links mostrados en la paginación
		$config['first_link'] = 'Primera';//primer link
		$config['last_link'] = '<li>Última<a href="#"><i class="icon-refresh"></i></a></li>';//ultimo link
		
        $config['next_link'] = 'Siguiente »';//siguient link
        $config['prev_link'] = '« Anterior';//anterior link
		
		$config['next_tag_open'] = '<li>';
    	$config['next_tag_close'] = '</li>';
		
    	$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config); //inicializamos la paginación
        //el array con los datos a paginar ya preparados
        $data['query'] = $this->Model_Usuario->total_posts_paginados($buscador, $config['per_page'], $this->uri->segment(3));

		$data['titulo'] = 'Usuarios';
		$data['contenido'] = 'usuario/result';
		$this->load->view('template/template', $data);
	}

	public function my_validation() {
		return $this->usuariolib->my_validation($this->input->post());
	}

	public function my_validation_mail() {
		return $this->usuariolib->my_validation_mail($this->input->post());
	}

	function generarCodigo($longitud) {
		$key = '';
		$pattern = '1234567890$P$BDMwkjeFe1yqvOCDQmk5M9SiHPeU5b1noze';
		$max = strlen($pattern)-1;
		for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)};
		return $key;
	}

	public function create() {
		$data['contenido'] = 'usuario/create';
		$data['titulo'] = 'Crear Usuario';
		$data['perfiles'] = $this->Model_Usuario->get_perfiles(); /* Lista de los Perfiles */
		$this->load->view('template/template', $data);
	}

	public function insert() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('nombres', 'Nombres', 'required');
		$this->form_validation->set_rules('apellidos', 'Apellidos', 'required');
        $this->form_validation->set_rules('login', 'Usuario', 'required|callback_my_validation|min_length[9]|max_length[16]');
        $this->form_validation->set_rules('email', 'eMail', 'required|callback_my_validation_mail|valid_email');
        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
			$count = $this->Model_Usuario->countRegs();
			foreach($count as $row){
				$n_e = $row->total + 1;

				/*Script para obtener primera letra de cada apellido*/
				//Forma incorrecta para obtener primera letra de cada apellido, pero funciona.
				$ape = $registro['apellidos'];
				$r = 1;
			
				for($i=0; $i<strlen($ape); $i++){ 
					if($ape[$i]!=" " && $r == 1){
						$a1 = "".$ape[$i];
						$r = 0;
					} 
				}
			
				for($j=0; $j<strlen($ape); $j++){ 
					if($ape[$j]!=" " && $r == 1){ 
						$a2 = "".$ape[$j];
						$r = 0;
					} 
					if($ape[$j] == " ")
					$r = 1;
				}
				/*Script para obtener primera letra de cada apellido*/
				
				$key = $this->config->item('encryption_key');
				$registro['password'] = $this->encrypt->encode($registro['login'], $key); //Por defecto misma login y pwd
			//$registro['password'] = md5($registro['login']); //Por defecto misma login y pwd
				$apellidos = $a1.$a2;
				$e = 'U';
				$random_code = $this->generarCodigo(7); //Genera un código de 7 caracteres de longitud.
				$year = date('Y');
				$registro['id'] = $apellidos.$e.$n_e.$random_code.$year;
				
				$registro['image'] = 'unknow_large.jpe';

				$timezone = "America/Managua";
				date_default_timezone_set($timezone);
				$today = date('Y-m-d H:i:s');
				
				$registro['created'] = $today;
				$registro['updated'] = $today;
				$this->Model_Usuario->insert($registro);
			}
			redirect('usuario/index');
        }
	}

	public function edit($id) {
		$data['contenido'] = 'usuario/edit';
		$data['titulo'] = 'Actualizar Usuario';
		$data['registro'] = $this->Model_Usuario->find($id);
		$data['perfiles'] = $this->Model_Usuario->get_perfiles(); /* Lista de los Perfiles */
		$this->load->view('template/template', $data);
	}

	public function update() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('nombres', 'Nombres', 'required');
		$this->form_validation->set_rules('apellidos', 'Apellidos', 'required');
		$this->form_validation->set_rules('login', 'Usuario', 'required|callback_my_validation|min_length[9]|max_length[16]');
        $this->form_validation->set_rules('email', 'eMail', 'required|valid_email');
		if($this->form_validation->run() == FALSE) {
			$this->edit($registro['id']);
		} else {
			$timezone = "America/Managua";
			date_default_timezone_set($timezone);
			$today = date('Y-m-d H:i:s');
			
			$registro['updated'] = $today;
			$this->Model_Usuario->update($registro);
			redirect('usuario/index');
		}
	}

	public function norep() {
		//eturn $this->usuariolib->norep($this->input->post());
	}

	public function edit_img($id) {
		$data['titulo'] = 'Actualizar Imagen Usuario';
		$data['contenido'] = 'usuario/edit_img';
		$data['registro'] = $this->Model_Usuario->find($id);
		$this->load->view('template/template', $data);
	}

	public function update_img() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('id', 'id', 'required');
		
		if($this->form_validation->run() == FALSE) {
			$this->edit_img($registro['id']);
			}else{
				$config['upload_path'] = './assets/images/';
				$config['allowed_types'] = 'gif|jpg|jpe|jpeg|png';
				$config['max_size'] = '2000';
				$config['max_width'] = '2024';
				$config['max_height'] = '2008';
				//Hacemos el requeriento de la libreria "upload"
				$this->load->library('upload', $config);
				//SI LA IMAGEN FALLA AL SUBIR MOSTRAMOS EL ERROR EN LA VISTA ACTUAL
				if (!$this->upload->do_upload()) {
				$data = array('error' => $this->upload->display_errors());
				$this->edit_img($registro['id']);
				//redirect('upload/do_upload', $error);
			} else {
				//EN OTRO CASO SUBIMOS LA IMAGEN, CREAMOS LA MINIATURA Y HACEMOS 
				//ENVÍAMOS LOS DATOS AL MODELO PARA HACER LA INSERCIÓN
				$file_info = $this->upload->data();
				//USAMOS LA FUNCIÓN create_thumbnail Y LE PASAMOS EL NOMBRE DE LA IMAGEN,
				//ASÍ YA TENEMOS LA IMAGEN REDIMENSIONADA
				$this->_create_thumbnail($file_info['file_name']);
				$data = array('upload_data' => $this->upload->data());
				$imagen = $file_info['file_name'];
				$registro['image'] = $imagen;
				$registro['ip'] = $_SERVER['REMOTE_ADDR'];

				$timezone = "America/Managua";
				date_default_timezone_set($timezone);
				$today = date('Y-m-d H:i:s');
				
				$registro['updated'] = $today;
				$this->Model_Usuario->update($registro);
				
				redirect('usuario/index');
			}
		}
	}

	public function edit_imgx($id) {
		$data['titulo'] = 'Actualizar Imagen Usuario';
		$data['contenido'] = 'usuario/edit_imgx';
		$data['registro'] = $this->Model_Usuario->find($id);
		$this->load->view('template/template', $data);
	}

	public function update_imgx() {
		$registro = $this->input->post();

		$this->form_validation->set_rules('id', 'id', 'required');
		
		if($this->form_validation->run() == FALSE) {
			$this->edit_img($registro['id']);
			}else{
				$config['upload_path'] = './assets/images/usuario_image/';
				$config['allowed_types'] = 'gif|jpg|jpe|jpeg|png';
				$config['max_size'] = '2000';
				$config['max_width'] = '2024';
				$config['max_height'] = '2008';
				//Hacemos el requeriento de la libreria "upload"
				$this->load->library('upload', $config);
				//SI LA IMAGEN FALLA AL SUBIR MOSTRAMOS EL ERROR EN LA VISTA ACTUAL
				if (!$this->upload->do_upload()) {
				$data = array('error' => $this->upload->display_errors());
				$this->edit_img($registro['id']);
				//redirect('upload/do_upload', $error);
			} else {
				//EN OTRO CASO SUBIMOS LA IMAGEN, CREAMOS LA MINIATURA Y HACEMOS 
				//ENVÍAMOS LOS DATOS AL MODELO PARA HACER LA INSERCIÓN
				$file_info = $this->upload->data();
				//USAMOS LA FUNCIÓN create_thumbnail Y LE PASAMOS EL NOMBRE DE LA IMAGEN,
				//ASÍ YA TENEMOS LA IMAGEN REDIMENSIONADA
				$this->_create_thumbnail($file_info['file_name']);
				$data = array('upload_data' => $this->upload->data());
				$imagen = $file_info['file_name'];
				$registro['image'] = $imagen;
				$registro['ip'] = $_SERVER['REMOTE_ADDR'];

				$timezone = "America/Managua";
				date_default_timezone_set($timezone);
				$today = date('Y-m-d H:i:s');
				
				$registro['updated'] = $today;
				$this->Model_Usuario->update($registro);
				
				redirect('admin/acerca_de');
			}
		}
	}

    //FUNCIÓN PARA CREAR LA MINIATURA A LA MEDIDA QUE LE DIGAMOS
    function _create_thumbnail($filename){
        $config['image_library'] = 'gd2';
        //CARPETA EN LA QUE ESTÁ LA IMAGEN A REDIMENSIONAR
        $config['source_image'] = 'assets/images/usuario_image/'.$filename;
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = TRUE;
        //CARPETA EN LA QUE GUARDAMOS LA MINIATURA.
        $config['new_image']='assets/images/usuario_image/thumbs/';
        $config['width'] = 150;
        $config['height'] = 150;
        $this->load->library('image_lib', $config); 
        $this->image_lib->resize();
    }


	public function delete($id) {
		$this->Model_Usuario->delete($id);
		redirect('usuario/index');
	}

	public function resetpwd($id){
		return $this->usuariolib->resetPWD($id);
	}

}
