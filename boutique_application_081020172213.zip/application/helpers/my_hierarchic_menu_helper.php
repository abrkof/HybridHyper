﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Hierarchic Menu Helper
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
if (!function_exists('my_hierarchic_menu_ppal')){
	function my_hierarchic_menu_ppal(){
		//Cargamos el super objeto.
		$CI = & get_instance();
		if ($CI->session->userdata('usuario_id')>=1){
			//Instanciamos a la clase de conexión de la base de datos personalizada.
			$pdo = DataBaseX::pdoDB();
			//Obtenemos el perfil_id del usuario logeado.
			$perfil_id = $CI->session->userdata('perfil_id');
			//Preparamos la primera consulta de acceso y cargamos los permisos de visualización para los Menús.
			$stmtp = $pdo->prepare('SELECT menu.* FROM menu WHERE EXISTS (SELECT * FROM menu_perfil_vistas 
									WHERE menu_perfil_vistas.menu_id = menu.id AND perfil_id= :perfil_id) 
									AND tipo = :system ORDER BY orden ASC');
			$stmtp->execute(array(':system'=>'system', ':perfil_id'=>$perfil_id));
			$stmtpx = $stmtp->fetchAll();
			//Imprimimos el encabezado.
			echo '<hr><li class="nav-header"><i class="icon-wrench"></i>Menú Administrador</li>';
			foreach($stmtpx as $menux){
				//Preparamos la segunda consulta de acceso y sus permisos de visualización.
				$stmt1 = $pdo->prepare('SELECT menu_perfil_vistas.*, menu.name AS name 
										from menu_perfil_vistas 
										LEFT JOIN menu ON (menu_perfil_vistas.menu_id = menu.id)
										WHERE menu_id = :menu_id AND perfil_id = :perfil_id');
				$stmt1->execute(array(':menu_id'=>$menux['id'], ':perfil_id'=>$perfil_id));
				//Devolvemos un arreglo con la siguiente fila.
				$stmtx = $stmt1->fetchAll();
				$menu_url = $menux['controlador'].'/'.$menux['accion'];
				//Creamos un salto o nueva linea.
				$menu = '';
				//Evaluamos si el arreglo trae algo.
				if(count($stmtx) > 0);
				foreach($stmtx as $row1){
					//Preparamos la tercera consulta de accesoo y cargamos los permisos de visualización para los Sub Menús.
					$stmt2 = $pdo->prepare('SELECT * FROM submenu 
											WHERE menu_id = :menu_id 
											AND EXISTS (SELECT * FROM submenu_perfil_vistas WHERE 
											submenu_perfil_vistas.submenu_id = submenu.id AND perfil_id = :perfil_id)
											ORDER BY orden ASC');
					$stmt2->execute(array(':menu_id'=>$row1['menu_id'], ':perfil_id'=>$perfil_id));
					//Contamos el número de filas que trae.
					$submenu_ppal = $stmt2->rowCount();
					//Llenamos variable con el controlador y su acción.
					$menu_ppal = $menu_url;
					//Evaluamos si el arreglo viene vacío.
					if($submenu_ppal == 0){//Si no se relaciona con un sub menú, imprime un link normal.
						echo $menu .='<li><a href="'.base_url('').$menu_ppal.'">'.$row1['name'].'</a></li>';
					} else {//Si hay un sub menú relacionado, imprime un menú en cascada.
						$menu .= '<li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">'.$row1['name'].'<b class="caret"></b></a>
								 <ul class="dropdown-menu">';
						foreach($stmt2 as $row2){
							$submenu_url = $row2['controlador'].'/'.$row2['accion'];
							$menu .= '<li><a href="'.base_url('').$submenu_url.'">'.$row2['name'].'</a></li>';
						}
					$menu .= '</ul></li>';
					echo $menu;
					}
				}
			}
		} else {
			echo '<hr><li class="nav-header"><i class="icon-wrench"></i>Menú Restringido</li>';
		}
	}
}