﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Tag Helper
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
//Muestra TODOS los errores de validación de un formulario
if (!function_exists('my_validation_errors')) {

	function my_validation_errors($errors) {
		$salida = '';

		if ($errors) {
			$salida = '<div class="alert alert-error">';
			$salida = $salida.'<button type="button" class="close" data-dismiss="alert"> × </button>';
			$salida = $salida.'<h4> Mensajes de Validación </h4>';
			$salida = $salida.'<small>'.$errors.'</small>';
			$salida = $salida.'</div>';
		}
		return $salida;
	}

}

//Opciones de menú de la barra superior (las opciones dependen si hay session o no)
if (!function_exists('my_admin_menu_ppal')) {

	function my_admin_menu_ppal() {

		$opciones = null;

		//$opciones = '<li>'.anchor('inicio/index', 'Inicio').'</li>';
		$opciones = $opciones.'<li>'.anchor('admin/acerca_de', 'Acerca De').'</li>';

		if (get_instance()->session->userdata('usuario_id')) {
			//$opciones = $opciones.'<li>'.anchor('inicio/cambio_clave', 'Cambio Clave').'</li>';
			//$opciones = $opciones.'<li>'.anchor('inicio/salir', 'Salir').'</li>';
		} else {
			//$opciones = $opciones.'<li>'.anchor('products/qp', 'Tienda en Línea').'</li>';
			//$opciones = $opciones.'<li>'.anchor('inicio/inicio_sesion', 'Iniciar Sesión').'</li>';
		}

		return $opciones;
	}

}

if (!function_exists('my_menu_ppalx')) {

	function my_menu_ppalx() {
		
		$opciones = null;
		
		if (get_instance()->session->userdata('usuario_id')) {
			$opciones = $opciones.anchor('usuario/edit_imgx/'.get_instance()->session->userdata('usuario_id'), '<img src="'.base_url('').'assets/images/usuario_image/'.get_instance()->session->userdata('usuario_image').'" width="40" height="29" class="img-rounded">');
			$opciones = $opciones.'<li>'.anchor('admin/cambio_clave', 'Cambio Clave').'</li>';
			$opciones = $opciones.'<li>'.anchor('admin/salir', 'Salir').'</li>';
		} else {
			$opciones = $opciones.'<li>'.anchor('admin/inicio_sesion', 'Iniciar Sesión').'</li>';
		}

		return $opciones;
	}

}

if (!function_exists('my_menu_app')) {

	function my_menu_app() {

		$opciones = null;

		if (get_instance()->session->userdata('usuario_id')) {
			$opciones = '';
			get_instance()->load->model('Model_Menu');
			$opciones = $opciones.'<hr>';
			$opciones = $opciones.'<li class="nav-header"><i class="icon-wrench"></i>Menú Administrador</li>';
			$query = get_instance()->Model_Menu->allForMenu();

			foreach ($query as $opcion) {
				if ($opcion->url != '') {
					$irA = $opcion->url;
					$param = array('target'=>'_blank');
				} else {
					$irA = $opcion->controlador.'/'.$opcion->accion;
					$param = array();
				}
				$opciones = $opciones.'<li>'.anchor($irA, $opcion->name, $param).'</li>';
			}
		}
		return $opciones;
	}

}

if (!function_exists('my_menu_public')) {

	function my_menu_public() {

		$opciones = null;

			$opciones = '';
			get_instance()->load->model('Model_Menu_Public');
			$query = get_instance()->Model_Menu_Public->allForMenu_Public();

			foreach ($query as $opcion) {
				if ($opcion->url != '') {
					$irA = $opcion->url;
					$param = array('target'=>"_blank");
				} else {
					$irA = $opcion->controlador.'/'.$opcion->accion;
					$param = array('target'=>'_blank');
				}
				$opciones = $opciones.'<li>'.anchor($irA, $opcion->name, $param).'</li>';
			}

		return $opciones;
	}

}


if (!function_exists('my_menu_site_system')) {

	function my_menu_site_system() {

		$opciones = null;

		if (get_instance()->session->userdata('usuario_id')) {
			$opciones = '';
			get_instance()->load->model('Model_Menu');
			$opciones = $opciones.'<hr>';
			$opciones = $opciones.'<li class="nav-header"><i class="icon-globe"></i>Menú del Sitio</li>';
			$query = get_instance()->Model_Menu->all_site();

			foreach ($query as $opcion) {
				if ($opcion->url != '') {
					$irA = $opcion->url;
					$param = array('target'=>'_blank');
				} else {
					$irA = $opcion->controlador.'/'.$opcion->accion;
					$param = array('target'=>'_blank');
				}
				$opciones = $opciones.'<li>'.anchor($irA, $opcion->name, $param).'</li>';
			}
		}
		return $opciones;
	}

}

if (!function_exists('my_menu_site')) {

	function my_menu_site() {

		$opciones = null;

		if (get_instance()->session->userdata('usuario_id')>=0) {
			$opciones = '';
			get_instance()->load->model('Model_Menu');
			$query = get_instance()->Model_Menu->all_site();

			foreach ($query as $opcion) {
				if ($opcion->url != '') {
					$irA = $opcion->url;
					$param = array();
					$param = array('target'=>'_blank');
				} else {
					$irA = $opcion->controlador.'/'.$opcion->accion;
					$param = array();
				}
				$opciones = $opciones.'<li>'.anchor($irA, $opcion->name, $param).'</li>';
			}//<li class="wow fadeIn"><h3 class="areas-admin-title"><h3></li>
		}
		return $opciones;
	}

}
