﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Contans Helper
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
//Definición de constantes personalizadas.
//Constantes para conexión a la base de datos principal.
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'vertrigo');
define('DB_NAME', 'boutique');
define('DB_CHAR', 'utf8');
define('DB_PORT', '3306');
define('DB_DRIVER', 'pdo');
define('DB_ENGINE', 'mysql');

//Constante para conexión personalizada a base de datos secundaria.
define('LOAD_CUSTOM_DB', TRUE);

/*define('CUSTOM_PDO', TRUE);
define('CUSTOM_MySQLNative', FALSE);
define('CUSTOM_MySQLi', FALSE);
define('CUSTOM_mySQLDBTest', FALSE);
define('CUSTOM_odbcDB', FALSE);*/

//Identificación de la conexión personalizada.
if (LOAD_CUSTOM_DB == TRUE){
	return librarypath('libraries/MyDBConnect');
} else {
	echo css('bootstrap.min');
	echo '<div class="alert">Alerta! Necesitas cargar las conexiones presonalizadas</div>';
}



/////////////////////////////////////////////////////////////////////////////////////////////////////
//Test para conexiones personalizadas a bases de datos y para su posterior uso e instanciarlas
/////////////////////////////////////////////////////////////////////////////////////////////////////
/*if (CUSTOM_PDO == TRUE){$pdo = DataBaseX::pdoDB();}
if (CUSTOM_MySQLNative == TRUE){$mysqlnative = DataBaseX::mySQLNativeDB();}
if (CUSTOM_MySQLi == TRUE){$mysqli = DataBaseX::mySQLiDB();}
if (CUSTOM_mySQLDBTest == TRUE){$mysqlitest = DataBaseX::mySQLiDBTest();}
if (CUSTOM_odbcDB == TRUE){$odbc = DataBaseX::odbcDB();}

//Intentamos ejecutar el siguiente código
try{
	$pdo = $pdo;
	#$stmt sería un objeto de tipo PDOStatement (consulta preparada)
	$stmt = $pdo->prepare('SELECT * FROM usuario');
	$stmt->execute();
	#Devuelve la siguiente fila como un objeto anónimo con nombres de columna como propiedades
	$rt = $stmt->fetchALL(PDO::FETCH_OBJ);
	//return $rt;
	//return $stmt->fetchAll(PDO::FETCH_OBJ);
	var_dump($rt);
}
//Obtenemos una lista de los mensajes de error.
catch (Exception $e){
	die($e->getMessage());
}*/
/////////////////////////////////////////////////////////////////////////////////////////////////////

/*
Here are the correspondences:

mysql_fetch_array = fetch(PDO::FETCH_BOTH) - The rows are arrays with both numeric and named indexes.
mysql_fetch_assoc = fetch(PDO::FETCH_ASSOC) - The rows are arrays with named indexes.
mysql_fetch_row = fetch(PDO::FETCH_NUM) - The rows are arrays with numeric indexes.
mysql_fetch_object = fetch(PDO::FETCH_OBJ) or fetch(PDO::FETCH_CLASS) depending on whether you specify the optional className argument to mysql_fetch_object. The rows are objects, either of the specified class or stdClass.
The while loop is equivalent to:

$data = $query->fetchAll(PDO::FETCH_BOTH);
*/


//$dsn = 'mysql:host=localhost; dbname=regsysdb; charset=utf8;';
/*$dsn = 'mysql:host=localhost; dbname=regsysdb; charset=utf8; port=3306;', 'root','vertrigo';
$this->load->database($dsn);
*/

//$db1 = $this->load->database('default', TRUE);
//$db2 = $this->load->database('db2', TRUE);



/*$key = $this->config->item('encryption_key');
$data = array('login' => 'adminsystem');
$query = $this->db->get_where('usuario', $data);
if (($query->num_rows() == 1)) {
	$user = $query->row();
	$plain_password = $this->encrypt->decode($user->password, $key);
}
echo $plain_password;*/