﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2016, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Components Helper
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
$css_folder = 'assets';
$js_folder = 'assets';
//SELF deveulve: basename($_SERVER['PHP_SELF']), el nombre del archivo actual 'abierto'.
//SELF deveulve: basename($_SERVER['SCRIPT_NAME']), el nombre del archivo actual 'abierto'.
//parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH), devuelve la ruta completa el archivo actual 'abierto'.

//Ruta de la carpeta "css"
if (is_dir($css_folder)){
	define('CSSPATH', $css_folder.'/');
} else {
	if (!is_dir(BASEPATH.$css_folder.'/')){
		exit("La ruta de la carpeta CSS no parece estar configurada correctamente. Por favor, abra el archivo 'my_tag2_helper.php' y corrígalo".' || RUTA - '.APPPATH.'helpers');
	}
	define('CSSPATH', BASEPATH.$css_folder.'/');
}

//Ruta de la carpeta "js"
if (is_dir($js_folder)){
	define('JSPATH', $js_folder.'/');
} else {
	if (!is_dir(BASEPATH.$js_folder.'/')){
		exit("La ruta de la carpeta JS no parece estar configurada correctamente. Por favor, abra el archivo 'my_tag2_helper.php' y corrígalo".' || RUTA - '.APPPATH.'helpers');
	}
	define('JSPATH', BASEPATH.$js_folder.'/');
}

//Especificación de headers.
if (!function_exists('headers')){
	function headers(){
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             	// Expira en fecha pasada
		//header("Expires", 0);
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");	// Siempre página modificada
		header("Cache-Control: no-cache, must-revalidate");           	// Evitar guardado en cache del cliente HTTP/1.1
		header("Cache-Control: no-store");
		header("Pragma: no-cache");                               		// Evitar guardado en cache del cliente HTTP/1.0
	}
}

//Especificación de headers nativos de CodeIgniter.
if (!function_exists('headers_ci')){
	function headers_ci(){
		//$get_instance()->output->set_header("HTTP/1.0 200 OK");
		//$get_instance()->output->set_header("HTTP/1.1 200 OK");
		get_instance()->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		//$get_instance()->output->set_header("Expires", 0);
		get_instance()->output->set_header('Last-Modified: '.gmdate('D, d M Y H:i:s'/*, $last_update*/).' GMT');
		get_instance()->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
		get_instance()->output->set_header("Cache-Control: post-check=0, pre-check=0");
		get_instance()->output->set_header("Pragma: no-cache");
	}
}

//Espeficicación o validacion de hojas de estilo.
if (!function_exists('css')){
    function css($css){
		$pathCSS = 'assets/'.('css/'.$css.'.css');
        if(file_exists($pathCSS)){//Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			echo '<link rel="stylesheet" href="'.base_url('').$pathCSS.'"/>';
		} else {//Error 404
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo '<div class="alert">
				  	<strong>Alerta! </strong>'.'Error, no se puede encontrar la hoja de estilo - '.$css.'.css'.' || Ruta - (assets/css)'.'
				  </div>';
			exit(3); //EXIT_CONFIG
        }
    }
}

//Espeficicación o validacion de archivos javascript.
if (!function_exists('js')){
    function js($js){
		$pathJS = JSPATH.('js/'.$js.'.js');
        if(file_exists($pathJS)){//Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			echo '<script src="'.base_url('').$pathJS.'"></script>';
		} else {//Error 404
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo '<div class="alert">
				  	<strong>Alerta! </strong>'.'Error, no se puede encontrar el archivo javascript - '.$js.'.js'.' || Ruta - (assets/js)'.'
				  </div>';
			exit(3); //EXIT_CONFIG
        }
    }
}

//Espeficicación o validacion de hojas de estilo.
if ( ! function_exists('packstylecss')){
    function packstylecss($packstylecss){
		$pathJS_CSS = CSSPATH.($packstylecss.'.css');
        if(file_exists($pathJS_CSS)){//Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			echo '<link rel="stylesheet" href="'.base_url('').$pathJS_CSS.'"/>';
		} else {//Error 404
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo '<div class="alert">
				  	<strong>Alerta! </strong>'.'Error, no se puede cargar la hoja de estilo - '.$packstylecss.'.css'.' || Ruta - (assets/)'.'
				  </div>';
			exit(3); //EXIT_CONFIG
        }
    }
}

//Espeficicación o validacion de archivos javascript.
if (!function_exists('packstylejs')){
    function packstylejs($packstylejs){
		$pathJS_CSS = JSPATH.($packstylejs.'.js');
        if(file_exists($pathJS_CSS)){//Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			echo '<script src="'.base_url('').$pathJS_CSS.'"></script>';
		} else {//Error 404
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo '<div class="alert">
				  	<strong>Alerta! </strong>'.'Error, no se puede cargar el archivo javascript - '.$packstylejs.'.js'.' || Ruta - (assets/)'.'
				  </div>';
			exit(3); //EXIT_CONFIG
        }
    }
}

//Espeficicación o validacion de librerias de terceros.
if (!function_exists('librarypath')){
    function librarypath($libraryClass){
		$customPath = APPPATH.($libraryClass.'.php');
        if(file_exists($customPath)){//Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			include_once ($customPath);
		} else {//Error 404
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo '<div class="alert">
				  	<strong>Alerta! </strong>'.'Error, no se puede encontrar labreria de clases - '.$libraryClass.'.php'.' || Ruta - ('.APPPATH.$libraryClass.'.php'.'
				  </div>';
			exit(3); //EXIT_CONFIG
        }
    }
}

if (!function_exists('boolval')) {

    function boolval($in, $strict = false) {
        $out = null;
        $in = (is_string($in) ? strtolower($in) : $in);
        // if not strict, we only have to check if something is false
        if (in_array($in, array('false', 'no', 'n', '0', 'off', false, 0), true) || !$in) {
            $out = false;
        } else if ($strict) {
            // if strict, check the equivalent true values
            if (in_array($in, array('true', 'yes', 'y', '1', 'on', true, 1), true)) {
                $out = true;
            }
        } else {
            // not strict? let the regular php bool check figure it out (will
            //     largely default to true)
            $out = ($in ? true : false);
        }
        return $out;
    }

}

/*if (!function_exists('set_css')){
    function set_css(array $css){
        $css = array();
		$pathCSS = CSSPATH.('css/'.$css.'.css');
        if(is_array($css) && count($css)){
            for($i=0; $i < count($css); $i++){
                return $css[] = '<link rel="stylesheet" href="'.base_url('').CSSPATH.('assets/css/'.$css[$i++].'.css').'"/>';
            }
        } else {
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo 'Error, no se puede cargar la hoja de estilo - '.$css.'.css'.' || Ruta - (assets/css)';
			exit(3); //EXIT_CONFIG
        }
    }
}

if (!function_exists('set_css')){
    function set_css(array $css){
        $css = array();
		$pathCSS = CSSPATH.('css/'.$css.'.css');
		foreach($pathCSS as $folder){
			if (file_exists($folder)){
				echo '<link rel="stylesheet" href="'.base_url('').$folder.'"/>';
			}
		}
    }
}*/

/*
****************
Componente de la version 2.2.0
****************
*/
//Espeficicación o validacion de componete personalizado "Select o Dropdown".
if (!function_exists('my_dropdown')){
    function my_dropdown($name, $id ,$array_data, $option_data, $extra){
		echo '<select name="'.$name.'" id="'.$id.'" '.$extra.'>
				<option selected="selected" value="">Elija l@s '.ucfirst($name).'</option>';
				foreach (explode(',', $array_data) as $option_data){
				echo '<option value="'.$option_data.'">'.$option_data.'</option>';
				}
		echo '</select> ';
    }
}