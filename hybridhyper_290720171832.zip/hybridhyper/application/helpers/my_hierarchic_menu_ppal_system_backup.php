﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Hierarchic Menu Helper
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
if (!function_exists('my_hierarchic_menu_ppal_system')){
	function my_hierarchic_menu_ppal_system(){
		//Cargamos el super objeto.
		$ABRKOF = & get_instance();
		if ($ABRKOF->session->get_userdata('usuario_id')>=1){
			//Obtenemos el perfil_id del usuario logeado.
			$perfil_id = $ABRKOF->session->get_userdata('perfil_id');
			//Preparamos la primera consulta de acceso y cargamos los permisos de visualización para los Menús.
			$stmtp = $ABRKOF->db->prepare('SELECT menu.* FROM menu WHERE EXISTS (SELECT * FROM menu_perfil_vistas 
									WHERE menu_perfil_vistas.menu_id = menu.id AND perfil_id= :perfil_id) 
									AND tipo = :system ORDER BY orden ASC');
			$stmtp->execute(array(':system'=>'system', ':perfil_id'=>$perfil_id));
			$stmtpx = $stmtp->fetchAll();
			//Imprimimos el encabezado.
			//echo '<h3><i class="fa fa-dashboard" style="color:#ffffff;"> </i>Menú Administrador</span></h3>';
			foreach($stmtpx as $menux){
				//Preparamos la segunda consulta de acceso y sus permisos de visualización.
				$stmt1 = $ABRKOF->db->prepare('SELECT menu_perfil_vistas.*, menu.name AS name 
										from menu_perfil_vistas 
										LEFT JOIN menu ON (menu_perfil_vistas.menu_id = menu.id)
										WHERE menu_id = :menu_id AND perfil_id = :perfil_id');
				$stmt1->execute(array(':menu_id'=>$menux['id'], ':perfil_id'=>$perfil_id));
				//Devolvemos un arreglo con la siguiente fila.
				$stmtx = $stmt1->fetchAll();
				$menu_url = host_url().$menux['controlador'].'/'.$menux['accion'];
				$menu_external_url = $menux['url'];
				//Creamos un salto o nueva linea.
				$menu = '';
				//Evaluamos si el arreglo trae algo.
				if(count($stmtx) > 0);
				foreach($stmtx as $row1){
					//Preparamos la tercera consulta de accesoo y cargamos los permisos de visualización para los Sub Menús.
					$stmt2 = $ABRKOF->db->prepare('SELECT * FROM submenu 
											WHERE menu_id = :menu_id 
											AND EXISTS (SELECT * FROM submenu_perfil_vistas WHERE 
											submenu_perfil_vistas.submenu_id = submenu.id AND perfil_id = :perfil_id)
											ORDER BY orden ASC');
					$stmt2->execute(array(':menu_id'=>$row1['menu_id'], ':perfil_id'=>$perfil_id));
					//Contamos el número de filas que trae.
					$submenu_ppal = $stmt2->rowCount();
					//Llenamos variable con el controlador y su acción.
					if ($menu_external_url != '') {
						$menu_ppal = $menu_external_url;
					} else {
						$menu_ppal = $menu_url;
					}
					//Evaluamos si el arreglo viene vacío.
					if($submenu_ppal == 0){//Si no se relaciona con un sub menú, imprime un link normal.
						echo $menu .='<li><a href="'.$menu_ppal.'"><i class="'.$menux['icon'].'"></i> <span>'.$row1['name'].'</span></a></li>';
					} else {//Si hay un sub menú relacionado, imprime un menú en cascada.
						$menu .= '<li><a><i class="'.$menux['icon'].'"></i> '.$menux['name'].' <span class="fa fa-chevron-down"></span></a>
									<ul class="nav child_menu">';
						foreach($stmt2 as $row2){
							$submenu_url = host_url().$row2['controlador'].'/'.$row2['accion'];
							$submenu_external_url = $row2['url'];
							if ($submenu_external_url != '') {
								$menu .= '<li><a href="'.$submenu_external_url.'">'.$row2['name'].'</a></li>';
							} else {
								$menu .= '<li><a href="'.$submenu_url.'">'.$row2['name'].'</a></li>';
							}
						}
					$menu .= '</ul></li>';
					echo $menu;
					}
				}
			}
		} else {
			echo '<hr><li class="header"><i class="fa fa-dashboard"></i> Menú Restringido</li><hr>';
		}
	}
}

if (!function_exists('my_hierarchic_menu_ppal_site')){
	function my_hierarchic_menu_ppal_site(){
		//Cargamos el super objeto.
		$ABRKOF = & get_instance();
		if ($ABRKOF->session->get_userdata('usuario_id')>=0){
			//Obtenemos el perfil_id del usuario logeado.
			$perfil_id = $ABRKOF->session->get_userdata('perfil_id');
			//Preparamos la primera consulta de acceso y cargamos los permisos de visualización para los Menús.
			$stmtp = $ABRKOF->db->prepare('SELECT menu.* FROM menu WHERE EXISTS (SELECT * FROM menu_perfil_vistas 
									WHERE menu_perfil_vistas.menu_id = menu.id AND perfil_id= :perfil_id) 
									AND tipo = :tipo ORDER BY orden ASC');
			$stmtp->execute(array(':tipo'=>'site', ':perfil_id'=>'8'));
			$stmtpx = $stmtp->fetchAll();
			//Imprimimos el encabezado.
			//echo '<h3><i class="fa fa-dashboard" style="color:#ffffff;"> </i>Menú Administrador</span></h3>';
			foreach($stmtpx as $menux){
				//Preparamos la segunda consulta de acceso y sus permisos de visualización.
				$stmt1 = $ABRKOF->db->prepare('SELECT menu_perfil_vistas.*, menu.name AS name 
										from menu_perfil_vistas 
										LEFT JOIN menu ON (menu_perfil_vistas.menu_id = menu.id)
										WHERE menu_id = :menu_id AND perfil_id = :perfil_id');
				$stmt1->execute(array(':menu_id'=>$menux['id'], ':perfil_id'=>'8'));
				//Devolvemos un arreglo con la siguiente fila.
				$stmtx = $stmt1->fetchAll();
				$menu_url = host_url('').$menux['controlador'].'/'.$menux['accion'];
				$menu_external_url = $menux['url'];
				//Creamos un salto o nueva linea.
				$menu = '';
				//Evaluamos si el arreglo trae algo.
				if(count($stmtx) > 0);
				foreach($stmtx as $row1){
					//Preparamos la tercera consulta de accesoo y cargamos los permisos de visualización para los Sub Menús.
					$stmt2 = $ABRKOF->db->prepare('SELECT * FROM submenu 
											WHERE menu_id = :menu_id 
											AND EXISTS (SELECT * FROM submenu_perfil_vistas WHERE 
											submenu_perfil_vistas.submenu_id = submenu.id AND perfil_id = :perfil_id)
											ORDER BY orden ASC');
					$stmt2->execute(array(':menu_id'=>$row1['menu_id'], ':perfil_id'=>'8'));
					//Contamos el número de filas que trae.
					$submenu_ppal = $stmt2->rowCount();
					//Llenamos variable con el controlador y su acción.
					if ($menu_external_url != '') {
						$menu_ppal = $menu_external_url;
					} else {
						$menu_ppal = $menu_url;
					}
					//Evaluamos si el arreglo viene vacío.
					if($submenu_ppal == 0){//Si no se relaciona con un sub menú, imprime un link normal.
						echo $menu .='<li class="dropdown">
										<a href="'.$menu_ppal.'">
											<div class="text-center">
												<i class="'.$menux['icon'].'" data-original-title="" title=""></i><br>
												'.$row1['name'].'
											</div>
										</a>
									</li>';
					} else {
						$menu .= '<li class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#">
										<div class="text-center">
											<i class="'.$menux['icon'].'" data-original-title="" title=""></i><br>
											'.$menux['name'].' <span class="caret"></span>
										</div>
									</a>
									<ul class="dropdown-menu" role="menu">';
						foreach($stmt2 as $row2){
							$submenu_url = host_url().$row2['controlador'].'/'.$row2['accion'];
							$submenu_external_url = $row2['url'];
							if ($submenu_external_url != '') {
								$menu .= '<li><a href="'.$submenu_external_url.'">'.$row2['name'].'</a></li>';
							} else {
								$menu .= '<li><a href="'.$submenu_url.'">'.$row2['name'].'</a></li>';
							}
						}
					$menu .= '</ul></li>';
					echo $menu;
					}
				}
			}
		} else {
			echo '<hr><li class="header"><i class="fa fa-dashboard"></i> Menú Restringido</li><hr>';
		}
	}
}