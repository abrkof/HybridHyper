<?php
?>
<br><br>
<h1 class="page-header">
    <?php echo 'Creando Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><?php echo open_link('datos_estudiante', 'Datos Estudiante'); ?></li>
  <li class="active">/ <?php echo 'Creando Nuevo Registro'; ?></li>
</ol>

<?php echo form_open("datos_estudiante/insert", array('id'=>'frm-datos_estudiante', 'class'=>'form-horizontal')); ?>    
    <div class="control-group">
        <?php echo form_label('Nombre : ', 'name', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'nombres', 'id'=>'nombres', 'value'=>set_value('nombres'), 'class'=>'form-control', 'placeholder'=>'Ingrese su nombre', 'data-validation-type'=>'requerido|min:3'));?>
    </div>
    
    <div class="control-group">
		 <?php echo form_label('Apellido : ', 'ape', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'apellidos', 'id'=>'apellidos', 'value'=>set_value('apellidos'), 'class'=>'form-control', 'placeholder'=>'Ingrese su apellido', 'data-validation-type'=>'requerido|min:3'));?>
    </div>
    
    <div class="control-group">
        <?php echo form_label('Genero : ', 'genero', array('class'=>'control-label')); ?>
		<?php $option = array('1' => 'Masculino', '2' => 'Femenino');?>
		<?php $style = 'class="form-control"' ;?>
		<?php echo form_dropdown('genero', $option, 0, $style); ?>
    </div>
    
    <div class="control-group">
		<?php echo form_label('Fecha de nacimiento : ', 'fecha_nac', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'date', 'name'=>'fecha_nacimiento', 'id'=>'fecha_nacimiento', 'value'=>set_value('fecha_nacimiento'), 'class'=>'form-control datepicker', 'placeholder'=>'Ingrese su fecha de nacimiento', 'data-validation-type'=>'requerido'));?>
	</div>
    
    <hr>
    
    <div class="control-group">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Guardar', 'class'=>'btn btn-success')); ?>
		<?php echo anchor('datos_estudiante', 'Cancelar', 'class="btn btn-warning"'); ?>
    </div>
<?php echo form_close();?>

<script>
    $(document).ready(function(){
        $("#frm-datos_estudiante").submit(function(){
            return $(this).validate();
        });
    })
</script>