<br><br>
<div class="hero-unit">
	<h1> Acceso Denegado !! </h1>
	<hr>
	<p> No tiene acceso a esta opción </p>
	<p> <img src="<?php echo base_url('')?>assets/img/174.png"> </p>
    <p> Comuníquese con el administrador. </p>
</div>
