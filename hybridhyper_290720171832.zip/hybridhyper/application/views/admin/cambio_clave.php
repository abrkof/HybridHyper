﻿<?php $this->load->view('admin/headers_check_login');?>
<div ng-app="myApp" id="container">
<div class="u-wrapper u-paddingHm u-paddingTl" ng-controller="MainController as mainCtrl">
    <div class="u-textCenter u-marginBl">
      <!--<button class="Button Button--default Button--lg u-marginAs" ng-click="mainCtrl.openInfoModal()">Cambiar Contraseña</button>-->
	  <input type="submit" ng-click="mainCtrl.openInfoModal()" value="Cambiar Contraseña" style="background-color:#FF9966; border-color:#FF9933;">
    </div>

	<script>
	function validar(f){
		if(f.clave_new.value != "" && (f.clave_new.value == f.clave_rep.value)){
			return true;
		} else {
			var alert = alertify.alert("Error de Validación","La contraseña nueva y su confirmación no coinciden!", function(){     	 
			alert.set({transition:'flipx'}); //slide, zoom, flipx, flipy, fade, pulse (default)
			alert.set('modal', false);  //al pulsar fuera del dialog se cierra o no	
			alertify.warning('Intenta de Nuevo');
			}).set('label', 'Aceptar');
			return false;
		}
	}
	</script>

  <script type="text/ng-template" id="info-modal-template.html">

    <v-modal class="vModal--default">
      <v-dialog heading="vModal" middle>
        <h4 class="u-marginBs" style="color:#000000;">Cambiando Contraseña de Usuario</h4>

        <p>
<?php echo form_open('admin/cambiar_clave', array('name'=>'frm-cambiar_clave', 'id'=>'frm-cambiar_clave', 'class'=>'form-horizontal', 'onSubmit'=>"return validar(this)")); ?>

	<div class="control-group" style="color:#000000;">
		<?php echo form_label('Contraseña Actual :', 'clave_act', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'password', 'name'=>'clave_act', 'id'=>'clave_act', 'autofocus'=>'clave_act')); ?>
	</div>

	<div class="control-group" style="color:#000000;">
		<?php echo form_label('Contraseña Nueva :', 'clave_new', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'password', 'name'=>'clave_new', 'id'=>'clave_new')); ?>
	</div>

	<div class="control-group" style="color:#000000;">
		<?php echo form_label('Confirmar Contraseña Nueva :', 'clave_rep', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'password', 'name'=>'clave_rep', 'id'=>'clave_rep')); ?>
	</div>

	<div class="form-actions">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Confirmar', 'class'=>'btn btn-success')); ?>
	</div>
<?php echo form_close(); ?>

		  <br>
        </p>
        <div class="u-marginTm">
          <!--<button class="Button" ng-click="infoModal.close()">Cancelar</button>-->
		  <input type="submit" ng-click="infoModal.close()" value="Cancelar">
        </div>
      </v-dialog>
    </v-modal>

  </script>
</div>
</div>