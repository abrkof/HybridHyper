﻿<?php $this->load->view('admin/headers_check_login');?>
<br><br>
<script src="<?php echo base_url('') ;?>assets/js/jquery_ordenar.js"></script>
<script src="<?php echo base_url('') ;?>assets/js/jquery-ui-1.8.12.custom.min.js"></script>
<h1 class="page-header">Ordenando Sub Menús</h1>

<div class="well well-sm text-right">
    <a class="btn btn-primary" href="submenu/procesos" style="color:#FFF;">CONSULTAR Sub Menús</a>
</div>

<style type="text/css">
.contentx{
	padding-top:20px;
	width:320px;
	margin:0 auto;
}
.ui-state-highlight{ background:#FFF0A5; border:1px solid #FED22F}
.msg{
	color:#0C0;
	font:normal 11px Tahoma
}
</style>
<script type="text/javascript">
$(document).ready(function(){
	$("#submenus").sortable({ placeholder: "ui-state-highlight",opacity: 0.6, cursor: 'move', update: function() {
		var order = $(this).sortable("serialize");
		$.post("<?php echo base_url('');?>submenu/update_orden", order, function(respuesta){
			$(".msg").html(respuesta).fadeIn("fast").fadeOut(4500);
		});
	}
	});
});
</script>
<div class="contentx">
	<ul id="submenus" style="/*list-style:none;*/margin:0;padding:0;">
		<?php foreach($query as $registro): ?>
			<li id="submenu-<?php echo $registro->id; ?>" style="display:block;background:#F6F6F6;border:1px solid #CCC;color:#3594C4;margin-top:3px;height:30px;padding:3px;">
			<img src="<?php echo base_url('') ;?>assets/img/arrastrar.png"><?php echo $registro->submenu; ?></li>
		<?php endforeach; ?>
	</ul>
	<div class="msg"></div>
</div>
</article>