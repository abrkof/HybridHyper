﻿<?php $this->load->view('admin/headers_check_login');?>
<br><br>
<div class="page-header">
	<h1> Opciones de Sub Menús <small>|| mantenimiento de registros </small> </h1>
</div>

<div class="well well-sm text-right">
    <a class="btn btn-primary" href="<?php echo base_url('');?>submenu/create" style="color:#FFF;">Nuevo Sub Menú</a>
</div>


<table class="table table-striped">
    <thead>
        <tr>
            <th style="width:10px;">Id</th>
			<th style="width:220px;">Nombre del Sub Menú</th>
			 <th style="width:220px;">Nombrel del Menú</th>
			 <th style="width:180px;">Controlador</th>
			<th style="width:180px;">Acción</th>
            <th style="width:180px;">Url</th>
			<th style="width:120px;">Orden</th>
			<th style="width:120px;">Icon</th>
			<th style="width:120px;">Descripción</th>
            <th style="width:60px;">Creado</th>
            <th style="width:60px;">Modificado</th>	
			<th style="width:60px;">Accesos</th>	
        </tr>
    </thead>
    <tbody>
    <?php foreach($query as $registro): ?>
        <tr>
			<td><?php echo $registro->id; ?></td>
            <td><?php echo $registro->submenu; ?></td>
			<td><?php echo $registro->menu_name; ?></td>
			<td><?php echo $registro->controlador; ?></td>
			<?php $slice = substr($registro->accion,0,strripos($registro->accion,'/')); ?>
			<td><?php echo $slice; ?></td>
            <td><?php echo $registro->url; ?></td>
			<td><?php echo $registro->orden; ?></td>
			<td><?php echo $registro->icon; ?></td>
			<td><?php echo $registro->descripcion; ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->created)); ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->updated)); ?></td>
            <td><a href="submenu/submenu_perfiles/<?php echo $registro->id; ?>"><img src="<?php echo base_url('') ;?>assets/img/acceso.png"><img src="<?php echo base_url('') ;?>assets/img/visualizar.png"></a></td><!---->
            <td><a href="submenu/edit/<?php echo $registro->id; ?>">Editar</a></td>
            <td><a onclick="alertify.confirm('Estas Eliminado El ID de Registro Nº<?php echo $registro->id; ?>','¿Estas seguro de eliminar este registro?',
			  function(ok){
				window.location='submenu/delete/<?php echo $registro->id; ?>';
				alertify.success('Eliminación Exitosa');
			  },
			  function(cancel){
				alertify.message('Cancelado');
			  }); return false" href="#">Eliminar</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>