﻿<?php $this->load->view('admin/headers_check_login');?>
<br><br>
<h1 class="page-header">
    <?php echo 'Creando Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><?php echo open_link('menu', 'Menú'); ?></li>
  <li class="active">/ <?php echo 'Creando Nuevo Registro'; ?></li>
</ol>


<script>
function index(){
	if(document.frm_menu.accion.value == "index"){
		var alert = alertify.alert("Error de Validación","La Acción “index” es reservada por el sistema! <br> Escribe una Acción valida o deja el espacio en blanco.", function(){     	 
			alert.set({transition:'flipx'}); //slide, zoom, flipx, flipy, fade, pulse (default)
			alert.set('modal', false);  //al pulsar fuera del dialog se cierra o no.
			alertify.error('Intenta de Nuevo');
		}).set('label', 'Aceptar');
		return false;
	}
}
</script>

<script>
function char_set(e) { // 1
    tecla = (document.all) ? e.keyCode : e.which; // 2
    if (tecla==8) return true; // 3
    patron =/[A-Za-z_0-9/ _\s]/; // 4
    te = String.fromCharCode(tecla); // 5
    return patron.test(te); // 6
}
</script>

<?php echo form_open("menu/insert", array('name'=>'frm_menu', 'id'=>'frm_menu', 'class'=>'form-horizontal', 'onSubmit'=>'return index();')); ?>
    <div class="control-group">
		<?php echo form_label('Nombre : ', 'menu', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'menu', 'id'=>'menu', 'value'=>set_value('menu'), 'class'=>'form-control', 'placeholder'=>'Ingrese el Nombre del Menú'));?>
    </div>
    
    <div class="control-group">
		<?php echo form_label('Módulo o Controlador : ', 'modulo', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'controlador', 'id'=>'controlador', 'value'=>set_value('controlador'), 'class'=>'form-control', 'placeholder'=>'Ingrese el Controlador', 'onkeypress'=>'return char_set(event);', 'pattern'=>'[a-z_A-Z0-9/]*', 'title'=>'a-z _ A-Z 0-9 /'));?>
    </div>

    <div class="control-group">
		<?php echo form_label('Acción : ', 'accon', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'accion', 'id'=>'accion', 'value'=>set_value('accion'), 'class'=>'form-control', 'placeholder'=>'Ingrese la Acción', 'onkeypress'=>'return slash(event);', 'pattern'=>'[a-z_A-Z0-9]*', 'title'=>'a-z _ A-Z 0-9'));?>
    </div>

    <div class="control-group">
		<?php echo form_label('Url : ', 'url', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'url', 'id'=>'url', 'value'=>set_value('url'), 'class'=>'form-control', 'placeholder'=>'Ingrese la Url'));?>
    </div>

    <div class="control-group">
		<?php echo form_label('Orden : ', 'orden', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'number', 'name'=>'orden', 'id'=>'orden', 'value'=>set_value('orden'), 'class'=>'form-control', 'placeholder'=>'Ingrese el orden'));?>
    </div>
	
    <div class="control-group">
		<?php echo form_label('Icono : ', 'icon', array('class'=>'control-label')); ?>
		<?php echo form_input(array('type'=>'text', 'name'=>'icon', 'id'=>'icon', 'value'=>set_value('icon'), 'class'=>'form-control', 'placeholder'=>'Ingrese el orden'));?>
    </div>

    <div class="control-group">
		<?php echo form_label('Descripción : ', 'descripcion', array('class'=>'control-label')); ?>
		<?php echo form_textarea(array('type'=>'text', 'name'=>'descripcion', 'id'=>'descripcion', 'value'=>set_value('descripcion'), 'class'=>'form-control', 'placeholder'=>'Ingrese una Descripción')); ?>
    </div>
    
    <hr>
    
    <div class="control-group">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Guardar', 'class'=>'btn btn-success')); ?>
		<?php echo anchor('menu', 'Cancelar', 'class="btn btn-warning"'); ?>
    </div>
</article>
<?php echo form_close();?>

<script>
    $(document).ready(function(){
        $("#frm_menu").submit(function(){
            return $(this).validate();
        });
    })
</script>