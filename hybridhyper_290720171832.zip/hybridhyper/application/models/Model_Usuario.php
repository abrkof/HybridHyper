<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase del modelo
class Model_Usuario extends Model{
	//Creamos el constructor
	public function __construct(){ 
		parent::__construct();
	}
	
	//Generamos un m�todo para una vista de los datos a obtener
	public function all(){
		$query = $this->db->query('SELECT usuario.*, perfil.perfil as perfil_name
									 FROM usuario
									 left join perfil ON (usuario.perfil_id = perfil.id)');
		return $query;
	}

	//Generamos un m�todo y cargamos los registros de la tabla requerida seg�n su id
	public function allFiltered($id){
		$query = $this->db->by_id('SELECT usuario.*, perfil.perfil as perfil_name
									 FROM usuario
									 left join perfil ON (usuario.perfil_id = perfil.id)
									 WHERE usuario.id = :id', array(':id'=>$id));
		return $query;
	}
	
	//Generamos el m�todo de registro de datos a la tabla
	public function insert($registro){
		$query = $this->db->insert('usuario', $registro);
		return $query;
	}
	
	//Generamos un m�todo para sentencia de actualizacion de datos mediante SQL
	public function update($registro){
        $query = $this->db->update('usuario', $registro, 'id = '.$registro['id'].'');
		return $query;
	}
	
	//Generamos el m�todo de eleminaci�n de registros
	public function delete($id){
		$query = $this->db->delete('usuario', 'id = '.$id.'');
		return $query;
	}

    function get_login($user, $pass){
		$query = $this->db->by_id('SELECT login, password FROM usuario WHERE login = :login AND password = :pwd', 
									array(':login'=>$user['login'], ':pwd'=>$pass['password']));
		return $query;
    }

    function get_perfiles(){
        $lista = array();
        $this->Model_Perfil = $this->load->model('Model_Perfil');
        $registros = $this->Model_Perfil->all();
        foreach ($registros as $registro){
            $lista[$registro->id] = $registro->perfil;
        }
        return $lista;
    }

	//Generamos un m�todo para sentencia de actualizaci�n de datos mediante SQL
	public function find($id){
		$query = $this->db->next_row('SELECT * FROM usuario WHERE id = :id', 
											array(':id'=>$id));
		return $query;
	}

	//Generamos un m�todo para sentencia de actualizaci�n de datos mediante SQL
	public function update_pass($registro){
        $query = $this->db->update('usuario', $registro, 'id = '.$registro['id'].'');
		return $query;
	}

}