<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase del modelo
class Model_Datos_Estudiante extends Model{
	//Creamos el constructor
	public function __construct(){ 
		parent::__construct();
	}
	
	//Generamos un m�todo para una vista de los datos a obtener
	public function all($start, $pagination){
		$query = $this->db->query('SELECT * FROM datos_estudiante');
		return $query;
	}
	
	//Generamos un m�todo para una vista de los datos a obtener
	public function all_paginate($start, $pagination){
		$query = $this->db->query('SELECT * FROM datos_estudiante LIMIT '.$start.','.$pagination);
		return $query;
	}
	
	//Generamos un m�todo y cargamos los registros de la tabla requerida seg�n su id
	public function allFiltered($id){
		$query = $this->db->by_id('SELECT * FROM datos_estudiante WHERE id_dat_est = :id', array(':id'=>$id));
		return $query;
	}
	
	//Generamos el m�todo de registro de datos a la tabla
	public function insert($registro){
		$query = $this->db->insert('datos_estudiante', $registro);
		return $query;
	}
	
	//Generamos un m�todo para sentencia de actualizacion de datos mediante SQL
	public function update($registro){
        $query = $this->db->update('datos_estudiante', $registro, 'id_dat_est = '.$registro['id_dat_est'].'');
		return $query;
	}
	
	//Generamos el m�todo de eleminaci�n de registros
	public function delete($id){
		$query = $this->db->delete('datos_estudiante', 'id_dat_est = '.$id.'');
		return $query;
	}

}