<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Controlador para autentificación de usuarios.
echo 'NOZE';
class CorrectAccess{
	function __construct(){
		//Realizamos la conexion a la base de datos
		try{
			$this->ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librería
			$this->menulib = $this->ABRKOF->load->library('MenuLib');
			$this->menu_perfillib = $this->ABRKOF->load->library('Menu_PerfilLib');
		}
		catch(Exception $e){
			die($e->getMessage());
		}
    }

	public function pathAccess(){
		/*$url = explode('/', $_REQUEST['url']);
		print_r ($url);
		$controlador = $url[0];
		$accion = $url[1];*/
		$controlador = $this->ABRKOF->uri->segment(0);
		$accion = $this->ABRKOF->uri->segment(1);
		$url = $controlador.'/'.$accion;
		echo $url;
		//echo 'You\'ll be redirected in about 5 secs. If not, click <a href="wherever.php">here</a>.';

		$$freeCtrlAcc  = array(
			'/',
			'inicio/index',
			'inicio/acceso_denegado',
			'inicio/acerca_de',
			'inicio/inicio_sesion',
			'inicio/ingresar',
			'inicio/cambio_clave',
			'inicio/cambiar_clave',
			'inicio/salir'
		);

		if(in_array($url, $freeCtrlAcc )){
			//redirect('inicio/acceso_denegado');
			return $url;
		}
		else {
			if(get_instance()->session->get_userdata('usuario')){
				if($this->authorize_menu_submenu()){
					//redirect('inicio/acceso_denegado');
					return $url;
				}
				else {
					redirect('admin/acceso_denegado');
				}
			}
			else {
				redirect('admin/acceso_denegado');
			}
		}

	}

	public function authorize_menu_submenu(){
		$controlador = $this->ABRKOF->uri->segment(0);
		$accion = $this->ABRKOF->uri->segment(1);
		$url = $controlador.'/'.$accion;
		//echo $url;
	
		//$this->ABRKOF = & get_instance();
	
		//El perfil del usuario logueado
		$perfil_id = $this->ABRKOF->session->get_userdata('perfil_id');
	
		//Con el controlador, buscar la opción de menú
		$controlador = $this->ABRKOF->uri->segment(0);
		$menu_id = $this->ABRKOF->menulib->findByControlador($controlador)->id;
	
		if(!$menu_id){
			return FALSE;
		}
	
		//Recuperar de la tabla de permisos, la combinación Menu - Perfil
		$acceso = $this->ABRKOF->menu_perfillib->findByMenuAndPerfil($menu_id, $perfil_id);
		if(!$acceso){
			return FALSE;
		}
		return TRUE;
	}
}