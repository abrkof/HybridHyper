<?php defined('BASEPATH') OR exit('No direct script access allowed');

$tables_names = array(
	'tbl0', 'datos_estudiante',
	'tbl2', 'grupo',
	'tbl3', 'grupo_usuario',
	'tbl4', 'menu',
	'tbl5', 'menu_perfil',
	'tbl7', 'perfil',
	'tbl8', 'submenu',
	'tbl9', 'submenu_perfil',
	'tbl11', 'usuario'
);