<?php defined('BASEPATH') OR exit('No direct script access allowed');

$route = array(
	'default_controller' => 'admin' //Identificaci�n del controlador principal a iniciar.
);
