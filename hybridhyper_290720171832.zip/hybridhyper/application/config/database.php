﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Configuración de constantes para la configuración de la conexión de la base de datos.

$db = array(
	'db_host' => 'localhost', //Servidor local o remoto.
	'db_port' => '3306', //Puerto del servidor local o remoto.
	'db_user' => 'root', //Usuario de conexión a la base de datos.
	'db_pass' => 'vertrigo', //Contraseña de conexión a la base de datos.
	'db_name' => 'hybridhyper', //Nombre de la base de datos.
	'db_char' => 'utf8', //Tipo de codificación de la base de datos.
	'db_driver' => 'pdoDB', //Para su uso: pdoDB, legacyMySQLDB, mysqliDB, odbcDB, pgsql.
	'db_engine' => 'mysql' //Utlizar "mysql" para conexiones con PDO o usar "SQL Server" para el caso de ODBC en conexiones MS-SQLSERVER.
);
