<?php defined('BASEPATH') OR exit('No direct script access allowed');

//Identificaci�n de lo m�dulos a iniciar.
$modules_array = array(
	'testmodule',
	'webservice4android'
);

/*$modules = '';
for($i=0;$i<count($modules_array);$i++){
	$array[$modules_array[$i]] = $modules_array[$i];
}

foreach ($array as $clave=>$valor) { 
	$modules .= $valor.",";
}*/

//Identificaci�n del controlador del m�dulo principal a iniciar.
$default_module_controller = array(
	'controller' => 'app1'
); 