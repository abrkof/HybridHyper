<?php defined('BASEPATH') OR exit('No direct script access allowed');
//construimos la clase de conexi�n a los hooks de seguridad.
class Hooks{
	function __construct(){
		try{
			$this->ABRKOF = Singleton::getInstance(); //Esto para acceder a la instancia que carga la librer�a
			$this->load = $this->ABRKOF->load; //Instanciamos.
		}
		catch(Exception $e){
			die($e->getMessage());
		}
		//$this->ABRKOF->correctAccess = $this->ABRKOF->load->hook('MySecurityAccess');
    }   
	
	public function loadHook(){
		//return $this->correctAccess->pathAccess();
	}

}


/*
| -------------------------------------------------------------------------
| Hooks
| -------------------------------------------------------------------------
| This file lets you define "hooks" to extend the framework without hacking the core
| files.  Please see the user guide for info:
|
|	http://codeigniter.com/user_guide/general/hooks.html
|
*/
