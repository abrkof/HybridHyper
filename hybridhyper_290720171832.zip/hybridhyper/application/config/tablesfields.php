<?php defined('BASEPATH') OR exit('No direct script access allowed');

$tables_fields = array(
	'tbl0flds' => 'id_dat_est,nombres,apellidos,genero,fecha_nacimiento,created,updated', //datos_personales
	'tbl2flds' => 'id,name,descripcion,created,updated', //grupo
	'tbl3flds' => 'id,name,grupo_id,usuario_id,descripcion,created,updated', //grupo_usuario
	'tbl4flds' => 'id,name,controlador,accion,url,orden,descripcion,created,updated', //menu
	'tbl5flds' => 'id,menu_id,perfil_id,created,updated', //menu_perfil
	'tbl7flds' => 'id,name,descripcion,created,updated', //perfil
	'tbl8flds' => 'id,name,menu_id,controlador,accion,url,orden,descripcion,created,updated', //submenu
	'tbl9flds' => 'id,submenu_id,perfil_id,created,updated', //submenu_perfil
	'tbl11flds' => 'id,name,login,password,email,perfil_id,created,updated' //usuario
);