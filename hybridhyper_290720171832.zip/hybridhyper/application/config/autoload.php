<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(
	'app_helpers_folder' => TRUE,
	//'app_libraries_folder' => FALSE, //
	
	//'base_helpers_folder' => TRUE, //
	//'base_libraries_folder' => TRUE //
);