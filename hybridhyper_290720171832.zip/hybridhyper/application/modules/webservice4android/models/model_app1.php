<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase del modelo
class Model_App1 extends Model{
	//Creamos el constructor
	public function __construct(){ 
		parent::__construct();
	//Realizamos la conexi�n a la base de datos
	}
	//Generamos un m�todo para una vista de los datos a obtener
	public function all(){
		try{
			//Generamos la sentencia SQL de la tabla requerida
			#$stmt ser�a un objeto de tipo PDOStatement (consulta preparada)
			$stmt = $this->dbx->prepare('SELECT * FROM usuario');
			$stmt->execute();
			//Devuelve la siguiente fila como un objeto an�nimo con nombres de columna como propiedades
			return $stmt->fetchAll(PDO::FETCH_OBJ);
		}
		catch(Exception $e){
			die($e->getMessage());
		}
	}
	//Generamos un m�todo para una vista de los datos a obtener
	public function allx(){
		try{
			//Generamos la sentencia SQL de la tabla requerida
			#$stmt ser�a un objeto de tipo PDOStatement (consulta preparada)
			$stmt = $this->dbx->prepare('SELECT * FROM usuario');
			$stmt->execute();
			//Devuelve la siguiente fila como un objeto an�nimo con nombres de columna como propiedades
			return $stmt->fetchAll(PDO::FETCH_OBJ);
		}
		catch(Exception $e){
			die($e->getMessage());
		}
	}
	//Generamos un m�todo y cargamos los registros de la tabla requerida seg�n su id
	public function allFiltered($id){
		try{
			$stmt = $this->dbx->prepare('SELECT * FROM usuario WHERE id=?');
			$stmt->execute(array($id));
			return $stmt->fetch(PDO::FETCH_OBJ);
		} 
		catch (Exception $e){
			die($e->getMessage());
		}
	}
	//Generamos el m�todo de registro de datos a la tabla
	public function insert($registro){
		try{
			$stmt = 'INSERT INTO '.tbl12.' ('.tbl12flds.') 
					VALUES (?, ?, ?, ?, ?)';
			$this->dbx->prepare($stmt)->execute(
					array(
						$registro['id'],
						$registro['nombres'],
						$registro['apellidos'],
						$registro['perfil_id'],
						$registro['created'],
						$registro['updated']
					)
			);
		}
		catch (Exception $e){
			die($e->getMessage());
		}
	}
	//Generamos un m�todo para sentencia de actualizaci�n de datos mediate SQL
	public function update($registro){
		try{
			$stmt = 'UPDATE usuario SET nombres=?, apeliidos=?, perfil_id=?, created=?, updated=?  WHERE id=?';
			$this->dbx->prepare($stmt)->execute(
				    array(
						$registro['nombres'],
						$registro['apellidos'],
						$registro['perfil_id'],
						$registro['created'],
						$registro['updated'],
						$registro['id']
					)
			);
		}
		catch (Exception $e){
			die($e->getMessage());
		}
	}
	//Generamos el metodo de eleminaci�n de registros
	public function delete($id){
		try{
			$stmt = $this->dbx->prepare('DELETE FROM usuario WHERE id=?');			          
			$stmt->execute(array($id));
		}
		catch (Exception $e){
			die($e->getMessage());
		}
	}

}