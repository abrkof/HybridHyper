<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Menu_PerfilLib{
private $pdo;
	function __construct(){
		//Realizamos la conexion a la base de datos.
		try{
			$this->ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librer�a
		}
		catch(Exception $e){
			die($e->getMessage());
		}
		$this->ABRKOF->Model_Menu_Perfil = $this->ABRKOF->load->model('Model_Menu_Perfil');
    }

    public function my_validation($registro){
        $registro['id'] = $this->ABRKOF->input->request('id');
		$registro['menu_id'] = $this->ABRKOF->input->request('menu_id');
        $registro['perfil_id'] = $this->ABRKOF->input->request('perfil_id');
		
		$query = $this->ABRKOF->db->row_array('SELECT * FROM menu_perfil WHERE menu_id = :menu_id AND perfil_id = :perfil_id',
											array(':menu_id'=>$registro->menu_id, ':perfil_id'=>$registro->perfil_id));
		
		$rt = redirect('menu_perfil');
			
        if (count($query) > 0 AND (!isset($registro['id']) OR ($registro['id'] != $query->fetchAll('id')))) {
            return FALSE;
        } else {
            return $rt;
        }
    }

    public function dar_acceso($perfil_id, $menu_id){
		$registro['menu_id'] = $this->ABRKOF->input->request('menu_id');
        $registro['perfil_id'] = $this->ABRKOF->input->request('perfil_id');
        $this->ABRKOF->Model_Menu_Perfil->insert($registro);
    }

    public function quitar_acceso($perfil_id, $menu_id){
		$query = $this->ABRKOF->db->delete('menu_perfil', 'perfil_id = '.$perfil_id.' AND menu_id = '.$menu_id.'');			          
		return $query;
    }

    public function findByMenuAndPerfil($menu_id, $perfil_id){
		$stmt = $this->ABRKOF->db->row_count('SELECT * FROM menu_perfil WHERE menu_id = :menu_id AND perfil_id = :perfil_id',
											array(':menu_id'=>$registro->menu_id, ':perfil_id'=>$registro->perfil_id));
		return $query;
    }

}