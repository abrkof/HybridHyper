<?php defined('BASEPATH') OR exit('No direct script access allowed');
// Creamos la clase
class Inicio extends Controller{
    public function __construct(){
		parent::__construct();
    }
    // Creamos una accion principal y cargamos las vistas
    public function index(){
        /*$data['titulo'] = 'Bienvenido';//array_push with key value pair.
		$datos = array('dato1' => 'hola1', 'dato2' => 'hola2', 'dato3' => 'hola3');//Ejemplo de arreglo asociativo.
		$this->load->view('header',$data);
        $this->load->view('home');
        $this->load->view('footer');*/
        $data['titulo'] = 'Bienvenido';
		$data['contenido'] = 'home';
		$data['query'] = $this->db->query('SELECT * FROM datos_estudiante WHERE id_dat_est = :id', array(':id'=>'1'));
		//print_r($query);
		$data['data'] = $data;
		$this->load->view('template/template',$data);/**/
    }

}