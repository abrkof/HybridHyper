﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase.
class Admin extends Controller{ 
	//Constructor de la Clase
	function __construct(){
		parent::__construct();
		$this->usuariolib = $this->load->library('UsuarioLib');
	}

	public function index() {
		$data['titulo'] = 'Inicio';
		$data['contenido'] = 'admin/index';
		$this->load->view('template/template',$data);
	}

	public function inicio_sesion(){
		$data['titulo'] = 'Inicio de Sesión';
		$this->load->view('admin/inicio_sesion',$data);
	}

	public function acerca_de(){
		$data['titulo'] = 'Acerca De';
		$data['contenido'] = 'admin/acerca_de';
		$this->load->view('template/template',$data);
	}

	public function acceso_denegado(){
		$data['titulo'] = 'Acceso Denegado';
		$data['contenido'] = 'admin/acceso_denegado';
		$this->load->view('template/template',$data);
	}

	public function ingresar(){
		if (call_user_func(array($this->usuariolib, 'login'))){
			redirect('admin/index');
		} else {
			$data['error_login'] = ERROR_LOGIN;
			$this->load->view('admin/inicio_sesion', $data);
		}
	}

	public function salir(){
		$this->session->sess_destroy();
		redirect('admin/inicio_sesion');
	}

	public function cambiar_clave(){
		if ($this->cambiook()){
			return FALSE;
		} else {
			redirect('admin/index');
		}
	}

	public function cambiook(){
		$act = $this->input->post('clave_act');
		$new = $this->input->post('clave_new');
		return $this->usuariolib->cambiarPWD(md5($act), md5($new));
	}

	public function error_pwdusr(){
		echo packstylecss('alertifyjs/css/alertify.min');
		echo packstylecss('alertifyjs/css/themes/default.min');
		echo packstylejs('alertifyjs/alertify.min');
		
		echo js('val_pass');
	}

}