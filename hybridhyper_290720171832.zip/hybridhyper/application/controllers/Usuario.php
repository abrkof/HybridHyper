﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Usuario extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Usuario = $this->load->model('Model_Usuario');
		$this->usuariolib = $this->load->library('UsuarioLib');
    }

    public function index(){
		$data['titulo'] = 'Usuarios';
		$data['query'] = $this->Model_Usuario->all();
		$data['contenido'] = 'usuario/index';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

    public function create(){
		$data['titulo'] = 'Usuarios';
		$data['perfiles'] = $this->Model_Usuario->get_perfiles(); /* Lista de los Perfiles */
		$data['contenido'] = 'usuario/create';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$count = $this->db->get('usuario');
		$n_e = $count + 1;
		$registro['id'] = $n_e;
		$registro['nombres'] = $this->input->post('nombres');
		$registro['apellidos'] = $this->input->post('apellidos');
		$registro['login'] = $this->input->post('login');
		$registro['password'] = $this->input->post('password');
		$registro['email'] = $this->input->post('email');
		$registro['perfil_id'] = $this->input->post('perfil_id');
		$registro['image'] = $this->input->post('image');
		$registro['created'] = TODAY;
		$registro['updated'] = TODAY;

		//Llamada al método de un objeto
		//if (call_user_func(array($this->usuariolib, 'my_validation')));

		$this->Model_Usuario->insert($registro);
			
		redirect('usuario');
    }

    public function edit($id){
		$data['titulo'] = 'Usuarios';
		$data['perfiles'] = $this->Model_Usuario->get_perfiles(); /* Lista de los Perfiles */
		$data['registro'] = $this->Model_Usuario->allFiltered($id);
		$data['contenido'] = 'usuario/edit';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }
    
    public function update(){
		$registro['id'] = $this->input->post('id');
		$registro['nombres'] = $this->input->post('nombres');
		$registro['apellidos'] = $this->input->post('apellidos');
		$registro['login'] = $this->input->post('login');
		$registro['email'] = $this->input->post('email');
		$registro['perfil_id'] = $this->input->post('perfil_id');
		$registro['image'] = $this->input->post('image');
		$registro['updated'] = TODAY;

		//Llamada al método de un objeto
		//if (call_user_func(array($this->usuariolib, 'my_validation')));

		$this->Model_Usuario->update($registro);
			
		redirect('usuario');
    }
    
    public function delete($id){
		$this->Model_Usuario->delete($id);
		redirect('usuario');
    }

	public function comprobar(){
		//Llamada al método de un objeto
		call_user_func(array($this->usuariolib, 'my_validation'));
	}

}