﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Perfil extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Perfil = $this->load->model('Model_Perfil');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
		$data['titulo'] = 'Perfiles';
		$data['query'] = $this->Model_Perfil->all();
		$data['contenido'] = 'perfil/index';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

    public function create(){
		$data['titulo'] = 'Perfiles';
		$data['contenido'] = 'perfil/create';
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$registro['perfil'] = $this->input->post('perfil');
		$registro['descripcion'] = $this->input->post('descripcion');
		$registro['created'] = TODAY;
		$registro['updated'] = TODAY;

		$$this->Model_Perfil->insert($registro);
		
		redirect('perfil');
    }

    public function edit($id){
		$data['titulo'] = 'Perfiles';
		$data['registro'] = $this->Model_Perfil->allFiltered($id);
		$data['contenido'] = 'perfil/edit';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }
    
    public function update(){
		$registro['id'] = $this->input->post('id');
		$registro['perfil'] = $this->input->post('perfil');
		$registro['descripcion'] = $this->input->post('descripcion');
		$registro['updated'] = TODAY;

		$this->Model_Perfil->update($registro);
		
		redirect('perfil');
    }
    
    public function delete($id){
		$this->Model_Perfil->delete($id);
		redirect('perfil');
    }

}