﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class Menu_Perfil extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Menu_Perfil = $this->load->model('Model_Menu_Perfil');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
		$data['titulo'] = 'Seguridad (Menús)';
		$data['query'] = $this->Model_Menu_Perfil->all();
		$data['contenido'] = 'menu_perfil/index';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

    public function create(){
		$data['titulo'] = 'Seguridad (Menús)';
		$data['menus'] = $this->Model_Menu_Perfil->get_menus(); /* Lista de los Menús */
		$data['perfiles'] = $this->Model_Menu_Perfil->get_perfiles(); /* Lista de los Perfiles */
		$data['contenido'] = 'menu_perfil/create';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$registro['menu_id'] = $this->input->post('menu_id');
		$registro['perfil_id'] = $this->input->post('perfil_id');
		$registro['created'] = TODAY;
		$registro['updated'] = TODAY;
		
		//$myCallback = new Menu_PerfilLib();
		//Llamada al método de un objeto
		//if (call_user_func(array($myCallback, 'my_validation')));

		$this->Model_Menu_Perfil->insert($registro);
		
		redirect('menu_perfil');
    }

    public function edit($id){
		$data['titulo'] = 'Seguridad (Menús)';
		$data['menus'] = $this->Model_Menu_Perfil->get_menus(); /* Lista de los Menús */
		$data['perfiles'] = $this->Model_Menu_Perfil->get_perfiles(); /* Lista de los Perfiles */
		$data['registro'] = $this->Model_Menu_Perfil->allFiltered($id);
		$data['contenido'] = 'menu_perfil/edit';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

    public function update(){
		$registro['id'] = $this->input->post('id');
		$registro['menu_id'] = $this->input->post('menu_id');
		$registro['perfil_id'] = $this->input->post('perfil_id');
		$registro['updated'] = TODAY;
		
		//$myCallback = new Menu_PerfilLib();
		//Llamada al método de un objeto
		//if (call_user_func(array($myCallback, 'my_validation')));

		$this->Model_Menu_Perfil->update($registro);
		
		redirect('menu_perfil');
    }
    
    public function delete($id){
		$this->Model_Menu_Perfil->delete($id);
		$this->redirect('menu_perfil');
    }

}