<?php
// Format time output

$str = "It is %a on %b %d, %Y, %X - Time zone: %Z";

// Echo results

echo(gmstrftime($str,time()));

?>