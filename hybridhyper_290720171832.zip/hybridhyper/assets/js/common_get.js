function selectMunicipio(depto_id){
	if(depto_id!="-1"){
		loadData('munpo',depto_id);
		$("#canton_id").html("<option value='-1'>::.Canton.::</option>");	
	}else{
		$("#munpo_id").html("<option value='-1'>::.Municipio.::</option>");
		$("#canton_id").html("<option value='-1'>::.Canton.::</option>");
		$("#caserio_id").html("<option value='-1'>::.Caserio.::</option>");
	}
}

function selectCanton(munpo_id){
	if(munpo_id!="-1"){
		loadData('canton',munpo_id);
	}else{
		$("#canton_id").html("<option value='-1'>::.Canton.::</option>");
	}
}

function selectCaserio(canton_id){
	if(canton_id!="-1"){
		loadData('caserio',canton_id);
	}else{
		$("#caserio_id").html("<option value='-1'>::.Caserio.::</option>");		
	}
}

function loadData(loadType,loadId){
	var dataString = 'loadType='+ loadType +'&loadId='+ loadId;
	$("#"+loadType+"_loader").show();
    $("#"+loadType+"_loader").fadeIn(400).html('Cargando... <img src="../img/loading.gif" />');
	$.ajax({
		type: "POST",
		url: "loadData",
		data: dataString,
		cache: false,
		success: function(result){
			$("#"+loadType+"_loader").hide();
			$("#"+loadType+"_id").html("<option value='-1'>::.SELECCIONE.::</option>");  
			$("#"+loadType+"_id").append(result);  
		}
	});
}