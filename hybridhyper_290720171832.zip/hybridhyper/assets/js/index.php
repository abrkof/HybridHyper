<script src="ajax.js"></script>
<strong>This is the current date and time (updates every 5 seconds):</strong>.
<script type="text/javascript"><!--
refreshdiv();
// --></script>
<div id="timediv"></div>