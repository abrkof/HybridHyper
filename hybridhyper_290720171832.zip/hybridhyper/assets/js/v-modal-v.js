(function (angular) {
    'use strict';
    angular.module('myApp', [
        'ngAnimate',
        'vModal'

    ]).config(function ($compileProvider, modalConfig) {
        $compileProvider.debugInfoEnabled(false);
        modalConfig.containerSelector = '#container';
    }).factory('infoModal', function (vModal) {
        return vModal({
            controller: 'InfoController',
            controllerAs: 'infoModal',
            templateUrl: 'info-modal-template.html'
        });
    }).controller('InfoController', function ($scope, infoModal) {
        var ctrl = this;
        ctrl.close = infoModal.deactivate;
    }).controller('MainController', function (infoModal) {
        var ctrl = this;
        ctrl.openInfoModal = infoModal.activate;
    });
}(angular));