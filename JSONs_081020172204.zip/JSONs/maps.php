﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head>
		<title>Example Map - mrMarcus</title>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
		<script src='https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false'></script>
		<script type="text/javascript">
		var map;
		var mapCenter = new google.maps.LatLng(47.6145, -122.3418);//13.7253, -89.7232 change initial centering if necessary
		var gmarkers = [];
		function initialize() {
			var myOptions = {
				zoom: 13,
				center: mapCenter,
				mapTypeId: 'roadmap'//google.maps.MapTypeId.TERRAIN
			};
			map = new google.maps.Map(document.getElementById('map_canvas'), myOptions);
			current_zoom = map.getZoom();
		}

		google.maps.event.addDomListener(window, 'load', initialize);

		var infowindow = new google.maps.InfoWindow();
		var bounds = new google.maps.LatLngBounds();
		var marker, i;
		var myLatLng;

		function CreateMarker(obj, i){
			myLatLng = new google.maps.LatLng(obj['lat'], obj['lng']);
			marker = new google.maps.Marker({
				position: myLatLng,
				map: map
			});
			google.maps.event.addListener(marker, 'click', (function(marker, i) {
				return function() {
					infowindow.setContent('Name: ' + obj['name'] + '; Address: ' + obj['address']); // obj[] will contain elements from your postback array, ie. obj['name'] && obj['address'] && obj['lat'], etc.
					infowindow.open(map, marker);
				}
			})(marker, i));
			bounds.extend(myLatLng);
			gmarkers.push(marker);
		}
		
		/*function bindInfoWindow(marker, map, infoWindow, html) {
		  google.maps.event.addListener(marker, 'click', function() {
			infoWindow.setContent(html);
			infoWindow.open(map, marker);
		  });
		}
	
		function downloadUrl(url, callback) {
		  var request = window.ActiveXObject ?
			  new ActiveXObject('Microsoft.XMLHTTP') :
			  new XMLHttpRequest;
	
		  request.onreadystatechange = function() {
			if (request.readyState == 4) {
			  request.onreadystatechange = doNothing;
			  callback(request, request.status);
			}
		  };
	
		  request.open('GET', url, true);
		  request.send(null);
		}*/
		</script>
	</head>
  <body onload="initialize()">
		<div id="map_canvas" style="width: 500px; height: 300px"></div>
		<script type="text/javascript">
		$.ajax({
			beforeSend: function() {
				// can have something happen before request is made (ie. "Loading..." message)
			},
			cache: false,
			// data: params, // if you are sending parameters to the 'url' below, ie. if search capabilities are included on the map; 'params' would be GET style URL
			dataType: 'json',
			timeout: 0,
			type: 'POST',
			url: 'get_markers.php', // create additional file and call it get_markers.php; see code for this file below
			success: function(data) {
				if (data) {
					if (data['count'] > 0) {
						var obj;
						var results = data['results'];

						for (r in data['results']) {
							if (r < (data['count'])) {
								CreateMarker(results[r]);
							}
						}
						map.fitBounds(bounds);
					}
					else {
						alert('No results from the database.');
					}
				}
				else {
					alert('No data received.');
				}
			},
			complete: function(data) {
				// when AJAX call has completed, additional stuff can happen here, but is not necessary
			}
		});
		</script>
	</body>
</html>