﻿<?php
class DataBaseX extends PDO{
	//Conexión para conexiones mysql usando PDO.
    public static function pdoDB(){
		//Realizamos la conexión mediante PDO la cual es de clase universal.
        $db = new PDO(
		'mysql:
		host=localhost;
		port=3306;
		dbname=enterprise;
		charset=utf-8;', 
		'root', 
		'vertrigo');
		//Le asignamos los atributos correspondientes para realizar la conexión.
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		//Retornamos la conexión.
        return $db;
    }
}
$pdo = DataBaseX::pdoDB();//Instanciamos a la clase conectora con PDO.
$stmt = $pdo->prepare('SELECT * FROM markers');
$stmt->execute();
//Devuelve la siguiente fila como un objeto anónimo con nombres de columna como propiedades.
$query = $stmt->fetchAll(PDO::FETCH_OBJ);
if ($query){
	$count = $stmt->rowCount();
	if (count($count) > 0){
		foreach ($query as $registro){
			$lat = (int)$registro->lat;
			$lng = (int)$registro->lng;
			if (!empty($lat) && !empty($lng)){//si Latitude y Longitud vienen vacias, no se mostraran en el mapa.
				$listings_results[] = array(
					'name' => $registro->name,
					'lat' => $registro->lat,
					'lng' => $registro->lng,
					'address' => $registro->address
				);
			}
		}

		//Crear las variables del arreglo;
		$results['count'] = $count;
		$results['results'] = $listings_results;

		//Envio de resultados encodeados;
		$json = @json_encode($results);
		echo $json;
		exit(0);
	}
}
?>