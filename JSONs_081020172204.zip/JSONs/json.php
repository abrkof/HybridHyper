﻿<?php
class DataBaseX extends PDO{
	//Conexión para conexiones mysql usando PDO.
    public static function pdoDB(){
		//Realizamos la conexión mediante PDO la cual es de clase universal.
        $db = new PDO(
		'mysql:
		host=localhost;
		port=3306;
		dbname=test;
		charset=utf8;', 
		'root',
		'abrkof');
		//Le asignamos los atributos correspondientes para realizar la conexión.
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		//Retornamos la conexión.
        return $db;
    }
}

$pdo = DataBaseX::pdoDB();//Instanciamos a la clase conectora con PDO.
#$stmt sería un objeto de tipo PDOStatement (consulta preparada).
$stmt = $pdo->prepare('SELECT * FROM user');
$stmt->execute();
//Devuelve la siguiente fila como un objeto anónimo con nombres de columna como propiedades.
$query = $stmt->fetchAll(PDO::FETCH_OBJ);

$users = array();

foreach($query as $registro){
	/*$users[] = array(
		'id'=> $registro->id,
		'name'=> $registro->name
	);*/
	//$users["data"]["users"][] = $registro;
	$users["users"][] = $registro;
}		
header('Content-type: application/json; charset=utf-8');
echo json_encode($users/*, JSON_FORCE_OBJECT*/);

?>