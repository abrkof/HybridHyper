<?php
class Marcador extends ActiveRecord\Model
{
	public static $table_name = 'marcador';
	public static $primary_key = 'id';
}
?>