<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<title>JSON PHP MYSQL</title>
		<script src="http://code.jquery.com/jquery-1.11.1.js"></script>
		<style>
		.grilla{
			background-color: #fff; 
			margin: 5px 0 10px 0; 
			border: solid 1px black; 
			border-collapse:collapse; 
		}
		.grilla td{ 
			padding: 2px; 
			border: solid 1px black; 
			color: #717171; 
			text-align:center;
		}
		.grilla th{ 
			padding: 4px 2px;
			background: gray repeat-x;
			border-left: solid 1px #525252; 
			font-size: 1 em; 
		}
		
		tr:nth-child(odd){
			background-color:#eee;
		}
		tr:nth-child(even){
			background-color:#fff;
		}
		</style>
	</head>
	<body>
		<header>
			<h1>Consultando Registros</h1>
		</header>
		<table class="grilla" id="tablajson">
			<thead>
				<th>Id</th>
				<th>Name</th>
			</thead>
			<tbody></tbody>
		</table>

		<script type="text/javascript">
		$(document).ready(function(){
		var data = "json.php";//open('GET', data, true)
		$("#tablajson tbody").html("");
		$.getJSON(data, function(users){
			$.each(users, function(i,users){
				var newRow =
				"<tr>"
					+"<td>"+users.id+"</td>"
					+"<td>"+users.name+"</td>"
				+"</tr>";
				$(newRow).appendTo("#tablajson tbody");
				});
			});
		});
		</script>

	</body>
</html>