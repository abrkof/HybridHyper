﻿<?php
$username="root";
$password="vertrigo";
$database="enterprise";
?>