﻿/*SELECT municipios.*, departamentos.depto as 'depto_name', paises.pais as 'pais_name'
FROM municipios
LEFT JOIN departamentos ON (municipios.depto_id = departamentos.id)
LEFT JOIN paises ON (departamentos.pais_id = paises.id)
GROUP BY paises.`created_at` ASC, paises.id ASC, departamentos.id ASC, municipios.id ASC*/

create database test;
use test;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamentos`
--

CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL,
  `depto` char(20) NOT NULL,
  `pais_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `departamentos`
--

INSERT INTO `departamentos` (`id`, `depto`, `pais_id`, `created_at`, `updated_at`) VALUES
(1, 'Ahuachapan', 1, '2017-10-09 01:30:45', '0000-00-00 00:00:00'),
(2, 'La Libertad', 1, '2017-10-09 01:30:47', '0000-00-00 00:00:00'),
(3, 'San Salvador', 1, '2017-10-09 01:30:49', '0000-00-00 00:00:00'),
(4, 'Sonsonate', 1, '2017-10-09 01:30:51', '0000-00-00 00:00:00'),
(5, 'Cortes', 4, '2017-10-09 03:40:35', '0000-00-00 00:00:00'),
(6, 'El Paraiso', 4, '2017-10-09 03:40:53', '0000-00-00 00:00:00'),
(7, 'Yoro', 4, '2017-10-09 03:41:13', '0000-00-00 00:00:00'),
(8, 'Colon', 4, '2017-10-09 03:41:20', '0000-00-00 00:00:00'),
(9, 'Francisco Morazan', 4, '2017-10-09 03:41:35', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipios`
--

CREATE TABLE `municipios` (
  `id` int(11) NOT NULL,
  `munpo` char(20) NOT NULL,
  `depto_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `municipios`
--

INSERT INTO `municipios` (`id`, `munpo`, `depto_id`, `created_at`, `updated_at`) VALUES
(1, 'Acajulta', 4, '2017-10-09 01:31:07', '0000-00-00 00:00:00'),
(2, 'Sonsonate', 4, '2017-10-09 01:31:08', '0000-00-00 00:00:00'),
(3, 'Izalco', 4, '2017-10-09 01:31:10', '0000-00-00 00:00:00'),
(4, 'Nahuizalco', 4, '2017-10-09 01:31:12', '0000-00-00 00:00:00'),
(5, 'Nahulingo', 4, '2017-10-09 01:31:17', '0000-00-00 00:00:00'),
(6, 'Lourdes', 2, '2017-10-09 01:31:28', '0000-00-00 00:00:00'),
(7, 'Santa Tecla', 2, '2017-10-09 01:31:29', '0000-00-00 00:00:00'),
(8, 'Antiguo Cuscatlan', 2, '2017-10-09 01:31:33', '0000-00-00 00:00:00'),
(9, 'Soyapango', 3, '2017-10-09 01:31:42', '0000-00-00 00:00:00'),
(10, 'Apopa', 3, '2017-10-09 01:31:45', '0000-00-00 00:00:00'),
(11, 'San Salvador', 3, '2017-10-09 01:31:47', '0000-00-00 00:00:00'),
(12, 'San Marcos', 3, '2017-10-09 01:31:49', '0000-00-00 00:00:00'),
(13, 'Ahuachapan', 1, '2017-10-09 01:32:41', '0000-00-00 00:00:00'),
(14, 'Atiquizaya', 1, '2017-10-09 01:32:50', '0000-00-00 00:00:00'),
(15, 'San Pedro Sula', 5, '2017-10-09 03:43:46', '0000-00-00 00:00:00'),
(16, 'Villanueva', 5, '2017-10-09 03:43:48', '0000-00-00 00:00:00'),
(17, 'Choloma', 5, '2017-10-09 03:43:52', '0000-00-00 00:00:00'),
(18, 'Danli', 6, '2017-10-09 03:43:41', '0000-00-00 00:00:00'),
(19, 'Trojes', 6, '2017-10-09 03:44:02', '0000-00-00 00:00:00'),
(20, 'El Paraiso', 6, '2017-10-09 03:44:11', '0000-00-00 00:00:00'),
(21, 'El Progreso', 7, '2017-10-09 03:44:40', '0000-00-00 00:00:00'),
(22, 'Olanchito', 7, '2017-10-09 03:44:50', '0000-00-00 00:00:00'),
(23, 'Yoro', 7, '2017-10-09 03:44:59', '0000-00-00 00:00:00'),
(24, 'Sonaguera', 8, '2017-10-09 03:45:12', '0000-00-00 00:00:00'),
(25, 'Tocoa', 8, '2017-10-09 03:45:23', '0000-00-00 00:00:00'),
(26, 'Saba', 8, '2017-10-09 03:45:29', '0000-00-00 00:00:00'),
(27, 'Distrito Central', 9, '2017-10-09 03:46:06', '0000-00-00 00:00:00'),
(28, 'Valle de Angeles', 9, '2017-10-09 03:46:20', '0000-00-00 00:00:00'),
(29, 'Talanga', 9, '2017-10-09 03:46:30', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paises`
--

CREATE TABLE `paises` (
  `id` int(11) NOT NULL,
  `pais` char(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `paises`
--

INSERT INTO `paises` (`id`, `pais`, `created_at`, `updated_at`) VALUES
(1, 'El Salvador', '2017-10-09 00:28:42', '0000-00-00 00:00:00'),
(2, 'Guatemala', '2017-10-09 00:28:53', '0000-00-00 00:00:00'),
(3, 'Nicaragua', '2017-10-09 00:28:58', '0000-00-00 00:00:00'),
(4, 'Honduras', '2017-10-09 00:29:05', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'A', '2017-10-08 01:19:35', '0000-00-00 00:00:00'),
(2, 'B', '2017-10-08 01:19:41', '0000-00-00 00:00:00'),
(3, 'C', '2017-10-08 01:19:44', '0000-00-00 00:00:00'),
(4, 'D', '2017-10-08 01:19:47', '0000-00-00 00:00:00'),
(5, 'E', '2017-10-08 01:19:51', '0000-00-00 00:00:00'),
(6, 'F', '2017-10-08 01:40:19', '0000-00-00 00:00:00'),
(7, 'G1', '2017-10-08 03:14:38', '2017-10-08 09:14:38');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `departamentos`
--
ALTER TABLE `departamentos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `municipios`
--
ALTER TABLE `municipios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `paises`
--
ALTER TABLE `paises`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `departamentos`
--
ALTER TABLE `departamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de la tabla `municipios`
--
ALTER TABLE `municipios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT de la tabla `paises`
--
ALTER TABLE `paises`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;