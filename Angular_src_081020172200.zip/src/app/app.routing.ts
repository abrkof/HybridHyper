import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { UsersComponent } from "./users/users.component";
import { NewUserComponent } from "./new-user/new-user.component";

const APP_ROUTES: Routes = [
    { path: '', component: UsersComponent },
	{ path: 'new-user', component: NewUserComponent }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(APP_ROUTES);