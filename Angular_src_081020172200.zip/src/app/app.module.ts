import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { NewUserComponent } from './new-user/new-user.component';
import { UsersComponent } from './users/users.component';
import { routing } from "./app.routing";

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    UsersComponent,
    NewUserComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    routing,
    NewUserComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
