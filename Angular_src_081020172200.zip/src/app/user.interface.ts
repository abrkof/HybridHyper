export interface User {
    id: number;
    name: String;
}