<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Municipios extends Model{
    public $table = 'municipios';
}
