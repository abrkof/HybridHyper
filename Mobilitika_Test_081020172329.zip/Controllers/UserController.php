<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Paises;
use App\Models\Departamentos;
use App\Models\Municipios;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class UserController extends Controller{

    public function index(Request $request){
        $user = User::orderBy('id','DESC')->paginate(5);
        return view('users.index',compact('user'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    public function create(){
        return view('users.create');
    }

    public function store(Request $request){
        $this->validate($request, [
            'title' => 'required',
            'description' => 'required',
        ]);

        User::create($request->all());
        return redirect()->route('users.index')
                        ->with('success','Creado!!!');
    }

    public function show($id){
        $user = User::find($id);
        return view('users.show',compact('user'));
    }

    public function edit($id){
        $user = User::find($id);
        return view('users.edit',compact('user'));
    }

    public function update(Request $request, $id){
        $this->validate($request, [
            'name' => 'required',
        ]);

        User::find($id)->update($request->all());
        return redirect()->route('users.index')
                        ->with('success','Actualizado!!!');
    }

    public function destroy($id){
        User::find($id)->delete();
        return redirect()->route('users.index')
                        ->with('success','Eliminado!!!');
    }
	
	/*
		API
	*/

    public function postUser(Request $request){
        $user = new User();

        //for($i=0;$i<10; $i++){}

        //$user->id = $request->input('id');
        $user->name = $request->input('name');

        $user->save(); 
        
        return response()->json(['users'=>$user], 201);

    }/**/

    public function getUsers(){
        $users = User::all();
        $response = [
            'users'=>$users
        ];

        return response()->json($response, 200);
    }
	
    public function getLugar(Request $request, $id){
        //$user = User::find($id);
		$lugar = DB::select( DB::raw("SELECT municipios.*, departamentos.depto as 'depto_name', paises.pais as 'pais_name'
										FROM municipios
										LEFT JOIN departamentos ON (municipios.depto_id = departamentos.id)
										LEFT JOIN paises ON (departamentos.pais_id = paises.id)
										WHERE departamentos.id = '$id'"));
        $response = [
            'lugar'=>$lugar
        ];
		
		return response()->json($response, 200);
    }

    public function putUser(Request $request, $id){
        $user = User::find($id);
        if (!$user){
            return response()->json(['message'=>'Document not found'], 404);
        }

        $user->name = $request->input('name');

        $user->save();

        return response()->json(['user'=>$user], 200);
    }

    public function deleteUser($id){
        $user = User::find($id);
        $user->delete();
        
        return response()->json(['message'=>'User Delete'], 200);
    }

}
