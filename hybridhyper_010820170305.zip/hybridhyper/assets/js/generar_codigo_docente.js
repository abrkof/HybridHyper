	function generar_codigo_docente(frm) {
		
    var rt1 = frm.apellidos.value;
    var rt2 = rt1.split(" ");
    codigo = rt1.substr(0,1) + rt2[1].substr(0,1);
	
  frm.id_doc_enc.value = frm.apellidos.value.substr(0,1).toUpperCase() + rt2[1].substr(0,1).toUpperCase() + frm.nusr.value + frm.d.value + frm.year.value;
}