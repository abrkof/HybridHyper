﻿create database hybridhyper;
use hybridhyper;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_estudiante`
--

CREATE TABLE `datos_estudiante` (
  `id` int(11) NOT NULL,
  `nombres` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `apellidos` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `genero` char(15) COLLATE utf8_spanish2_ci NOT NULL,
  `fecha_nacimiento` char(10) COLLATE utf8_spanish2_ci NOT NULL,
  `created` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` varchar(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `datos_estudiante`
--

INSERT INTO `datos_estudiante` (`id`, `nombres`, `apellidos`, `genero`, `fecha_nacimiento`, `created`, `updated`) VALUES
(1, 'Carlos Abraham', 'Ayala Herrera', '1', '2015-10-11', '2015-10-14 22:54:31', '2017-07-28 20:58:40'),
(2, 'Einspringt Hellsengberm', 'Root Fraunlensky', '1', '2015-10-11', '2015-10-12 00:43:00', '2015-10-12 00:43:00'),
(3, 'Glenda Yamileth', 'Garcia Linares', '2', '2015-10-11', '2015-10-12 00:43:00', '2015-10-12 00:43:00'),
(4, 'Charles Ansengbernhem', 'Ayla Hero', '1', '2015-10-11', '2015-10-12 00:43:00', '2017-07-28 12:22:18'),
(5, 'Irma', 'Rivas', '2', '2015-10-11', '2015-10-12 00:44:00', '2017-07-28 12:20:55'),
(6, 'Stephanie Yamileth', 'Alvarado Gonzales', '2', '2015-10-12', '2015-10-12 20:33:47', '2017-07-29 15:33:09'),
(7, 'asd1', '', '', '', '', ''),
(8, 'asd2', '', '', '', '', ''),
(9, 'asd3', '', '', '', '', ''),
(10, 'asd4', '', '', '', '', ''),
(12, 'asd5', '', '', '', '', ''),
(13, 'asd6', '', '', '', '', ''),
(14, 'asd7', '', '', '', '', ''),
(15, 'asd8', '', '', '', '', ''),
(16, 'asd9', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupo`
--

CREATE TABLE `grupo` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` varchar(25) COLLATE utf8_spanish2_ci NOT NULL,
  `created` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` varchar(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `grupo`
--

INSERT INTO `grupo` (`id`, `name`, `descripcion`, `created`, `updated`) VALUES
(1, 'Sonsonate', 'Gerencia', '2015-10-29 21:47:15', '2016-05-22 09:06:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupo_usuario`
--

CREATE TABLE `grupo_usuario` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `grupo_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `descripcion` varchar(25) COLLATE utf8_spanish2_ci NOT NULL,
  `created` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` varchar(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `grupo_usuario`
--

INSERT INTO `grupo_usuario` (`id`, `name`, `grupo_id`, `usuario_id`, `descripcion`, `created`, `updated`) VALUES
(1, 'Gerencia', 1, 1, 'CRUD del Sistema', '2015-10-29 21:47', '2015-11-25 14:30:21'),
(2, 'Gerencia', 1, 12, 'Gerencia', '2016-04-24 21:55', '2016-04-24 21:55');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `menu` char(100) COLLATE utf8_spanish2_ci NOT NULL,
  `controlador` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `accion` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `url` tinytext COLLATE utf8_spanish2_ci NOT NULL,
  `orden` char(5) COLLATE utf8_spanish2_ci NOT NULL,
  `icon` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish2_ci NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `menu`
--

INSERT INTO `menu` (`id`, `menu`, `controlador`, `accion`, `url`, `orden`, `icon`, `descripcion`, `created`, `updated`) VALUES
(1, 'Perfiles (Administrar)', 'perfil', '', '', '1', '#', 'Principal', '2015-11-23 22:12:31', '2017-07-31 22:08:50'),
(2, 'Usuarios (Administraar)', 'usuario', '', '', '2', '#', 'Registro de Estudiantes', '2015-11-23 22:13:24', '2017-07-31 22:08:16'),
(3, 'Modulos', 'module', '', '', '3', '#', 'Registro de Menús', '2015-11-23 22:15:06', '2017-07-31 22:09:32'),
(4, 'Menús (Administrar)', 'menu', '', '', '4', '', 'Registro de Perfiles', '2015-11-23 22:17:27', '2017-07-28 12:32:32'),
(5, 'Sub Menús (Administrar)', 'submenu', '', '', '5', '', 'Registro de Sub Menús', '2015-11-23 22:18:44', '2017-07-28 12:32:32'),
(6, 'Registro de Accesos (Sistema)', '', '', '#', '6', '', 'Registro de Usuarios', '2015-11-23 22:19:31', '2017-07-28 12:32:32'),
(7, 'Base de Datos (Administrar)', '', '', '#', '7', '#', 'Acerca De', '2015-11-23 22:20:30', '2017-07-31 22:09:01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu_perfil`
--

CREATE TABLE `menu_perfil` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `menu_perfil`
--

INSERT INTO `menu_perfil` (`id`, `menu_id`, `perfil_id`, `created`, `updated`) VALUES
(1, 1, 1, '2015-11-24 12:29:47', '2015-11-24 12:29:47'),
(2, 2, 1, '2015-11-24 12:29:59', '2015-11-24 12:29:59'),
(3, 3, 1, '2015-11-24 12:30:18', '2015-11-24 12:30:18'),
(4, 4, 1, '2015-11-24 12:30:18', '2015-11-24 12:30:18'),
(5, 5, 1, '2017-07-29 18:04:16', '2017-07-29 18:04:16'),
(6, 6, 1, '2017-07-31 21:45:03', '2017-07-31 21:45:03'),
(7, 7, 1, '2017-08-01 00:40:46', '2017-08-01 00:40:46');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu_perfil_vistas`
--

CREATE TABLE `menu_perfil_vistas` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `created` char(19) NOT NULL,
  `updated` char(19) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `module`
--

CREATE TABLE `module` (
  `id` int(11) NOT NULL,
  `module` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` tinytext COLLATE utf8_spanish2_ci NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil`
--

CREATE TABLE `perfil` (
  `id` int(11) NOT NULL,
  `perfil` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish2_ci NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `perfil`
--

INSERT INTO `perfil` (`id`, `perfil`, `descripcion`, `created`, `updated`) VALUES
(1, 'Administrador', 'Perfil Principal', '2015-10-13 19:26:22', '2015-10-16 14:01:56'),
(2, 'Reportes', 'Generación de Reportes', '2015-10-13 19:26:22', '2015-11-22 21:42:35'),
(3, 'Restricción', 'Perfil Restringido', '2015-10-13 19:26:22', '2017-07-29 18:08:37');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones`
--

CREATE TABLE `sesiones` (
  `id` float NOT NULL,
  `usuario_id` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `ip` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `Date` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `Latitude` float NOT NULL DEFAULT '0',
  `Longitude` float NOT NULL DEFAULT '0',
  `ZoneTime` varchar(100) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '',
  `user_agent` tinytext COLLATE utf8_spanish2_ci NOT NULL,
  `entrada` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `salida` char(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones_temp`
--

CREATE TABLE `sesiones_temp` (
  `id` float NOT NULL,
  `usuario_id` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `estado` char(1) COLLATE utf8_spanish2_ci NOT NULL,
  `ip` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `Date` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `Latitude` float NOT NULL DEFAULT '0',
  `Longitude` float NOT NULL DEFAULT '0',
  `ZoneTime` varchar(100) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '',
  `user_agent` tinytext COLLATE utf8_spanish2_ci NOT NULL,
  `entrada` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `salida` char(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `submenu`
--

CREATE TABLE `submenu` (
  `id` int(11) NOT NULL,
  `submenu` char(100) COLLATE utf8_spanish2_ci NOT NULL,
  `menu_id` int(11) NOT NULL,
  `controlador` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `accion` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `url` tinytext COLLATE utf8_spanish2_ci NOT NULL,
  `orden` char(5) COLLATE utf8_spanish2_ci NOT NULL,
  `icon` char(20) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish2_ci NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `submenu`
--

INSERT INTO `submenu` (`id`, `submenu`, `menu_id`, `controlador`, `accion`, `url`, `orden`, `icon`, `descripcion`, `created`, `updated`) VALUES
(1, 'Consultar Menús', 4, 'menu', '', '#', '2', '#', 'Consultar Menús', '2015-11-26 00:07:08', '2017-07-29 18:04:48'),
(2, 'Seguridad (Menús)', 4, 'menu_perfil', '', '#', '3', '', 'Seguridad (Menús)', '2015-11-26 00:09:46', '2015-12-12 00:07:39'),
(3, 'Ordenar Menús', 4, 'menu', 'menu_ordenar/', '#', '4', '', 'Ordenar Menús', '2015-11-26 00:11:24', '2015-12-20 18:59:33'),
(4, 'Consultar Sub Menús', 5, 'submenu', '', '#', '5', '', 'Consultar Sub Menús', '2015-11-26 19:23:08', '2015-11-26 19:23:08'),
(5, 'Seguridad (SubMenús)', 5, 'submenu_perfil', '', '#', '6', '', 'Ordenar Sub Menús', '2015-11-26 19:24:06', '2017-07-28 10:55:56'),
(6, 'Ordenar Sub Menús', 5, 'submenu', 'submenu_ordenar/', '#', '1', '', 'Seguridad (Sub Menús)', '2015-11-26 19:24:06', '2015-12-20 18:59:58');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `submenu_perfil`
--

CREATE TABLE `submenu_perfil` (
  `id` int(11) NOT NULL,
  `submenu_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `submenu_perfil`
--

INSERT INTO `submenu_perfil` (`id`, `submenu_id`, `perfil_id`, `created`, `updated`) VALUES
(1, 2, 1, '2017-08-01 01:53:06', '2017-08-01 01:53:06'),
(2, 7, 1, '2017-08-01 01:53:19', '2017-08-01 01:53:19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `submenu_perfil_vistas`
--

CREATE TABLE `submenu_perfil_vistas` (
  `id` int(11) NOT NULL,
  `submenu_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `created` char(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` char(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombres` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `apellidos` char(50) COLLATE utf8_spanish2_ci NOT NULL,
  `login` varchar(11) COLLATE utf8_spanish2_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `image` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `created` varchar(19) COLLATE utf8_spanish2_ci NOT NULL,
  `updated` varchar(19) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombres`, `apellidos`, `login`, `password`, `email`, `perfil_id`, `image`, `created`, `updated`) VALUES
(1, 'Charles Ansengberhem', 'Ayla Hero', 'abrkof', '0cc175b9c0f1b6a831c399e269772661', 'abraham_kof@hotmail.com', 1, '', '2015-10-16 00:44', '2017-08-01 00:38:28'),
(2, 'Einspringt Hellsengberm', 'Root Frauhlensky', 'fantomghost', '0cc175b9c0f1b6a831c399e269772661', 'abrkof@gmail.com', 2, '', '2015-11-23 23:28:43', '2017-07-29 02:57:28');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `datos_estudiante`
--
ALTER TABLE `datos_estudiante`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `grupo`
--
ALTER TABLE `grupo`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `grupo_usuario`
--
ALTER TABLE `grupo_usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `grupo_id` (`grupo_id`);

--
-- Indices de la tabla `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `menu_perfil`
--
ALTER TABLE `menu_perfil`
  ADD PRIMARY KEY (`id`),
  ADD KEY `perfil_id` (`perfil_id`),
  ADD KEY `menu_id` (`menu_id`),
  ADD KEY `menu_id_2` (`menu_id`),
  ADD KEY `perfil_id_2` (`perfil_id`);

--
-- Indices de la tabla `menu_perfil_vistas`
--
ALTER TABLE `menu_perfil_vistas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_id` (`menu_id`),
  ADD KEY `perfil_id` (`perfil_id`);

--
-- Indices de la tabla `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `perfil`
--
ALTER TABLE `perfil`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `sesiones`
--
ALTER TABLE `sesiones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `sesiones_temp`
--
ALTER TABLE `sesiones_temp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `submenu`
--
ALTER TABLE `submenu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_id` (`menu_id`);

--
-- Indices de la tabla `submenu_perfil`
--
ALTER TABLE `submenu_perfil`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `submenu_perfil_vistas`
--
ALTER TABLE `submenu_perfil_vistas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `perfil_id` (`perfil_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `datos_estudiante`
--
ALTER TABLE `datos_estudiante`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT de la tabla `grupo`
--
ALTER TABLE `grupo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `grupo_usuario`
--
ALTER TABLE `grupo_usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `menu_perfil`
--
ALTER TABLE `menu_perfil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `menu_perfil_vistas`
--
ALTER TABLE `menu_perfil_vistas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `module`
--
ALTER TABLE `module`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `perfil`
--
ALTER TABLE `perfil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `sesiones`
--
ALTER TABLE `sesiones`
  MODIFY `id` float NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `sesiones_temp`
--
ALTER TABLE `sesiones_temp`
  MODIFY `id` float NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `submenu`
--
ALTER TABLE `submenu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `submenu_perfil`
--
ALTER TABLE `submenu_perfil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `submenu_perfil_vistas`
--
ALTER TABLE `submenu_perfil_vistas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
