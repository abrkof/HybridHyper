﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Common Class
 *
 * Carga las clases base y ejecuta la solicitud.
 *
 * @package		HybridHyper
 * @subpackage	HybridHyper
 * @category	Common Functions
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

//Creamos la clase que cargara todas las librerias del sistema.
class Common{
    private $controller; //Creamos una variable de tipo privada.
	private $load = array(); //Creamos una variable de tipo pública. 
	protected $module; //Creamos una variable de tipo privada.
	protected $session; //Creamos un variable u objeto de tipo pública.
	protected $cached_vars = array();
	protected $css;
	private $ABRKOF;
	private $uri;
    
    public function __construct(Loader $request){ //Inicializamos el constructor, cargamos la clase Loader.
		$this->ABRKOF = Singleton::getInstance();
		$this->module = $request->getModule(); //Instanciamos.
		$this->controller = $request->getController(); //Seteamos los valores que se obtienen del controlador.
		$this->session = $this->ABRKOF->session; //Instanciamos.
		$this->uri = $this->ABRKOF->uri; //Instanciamos.
    }
	
    public function view($view, $vars = array(), $val = ''/*array $vars = NULL*/){ //$vars Es el contenedor de nuestras variables, es un arreglo(Vector) del tipo llave => valor, opcional.
		if($this->module){
            $pathView = APPPATH.('modules/'.$this->module.'/views/'.$view.'.php'); //Establecemos la ruta de las vistas de los modulos.
        } else {
			$pathView = APPPATH.('views/'.$view.'.php'); //De no existir, se carga la ruta de las vistas por defecto.
		}

		//echo '<br><br><br>'.print_r($pathView);
        $this->load = new Common (new Loader); //Instanciamos.
		if(is_readable($pathView)){ //Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			if (is_array($vars)){
				$this->cached_vars = array_merge($this->cached_vars, $vars); //Almacenamos las variables en un objeto.
			}
			
			extract($this->cached_vars); //Las extraemos para su posterior utilización.
			include ($pathView); // include() vs include_once() permite múltiples vista con el mismo nombre.
			return true;
		} else {//Error 404
            echo css('bootstrap.min');
			throw new Exception('Error, no se puede cargar la vista - '.$view.'.php'); //Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }

    public function template($template, $vars = array() /*array $vars = NULL*/){ //$vars Es el contenedor de nuestras variables, es un arreglo(Vector) del tipo llave => valor, opcional.
		if($this->module){
            $pathTemplate = APPPATH.('modules/'.$this->module.'/views/template/'.$template.'.php'); //Establecemos la ruta de las vistas de los modulos.
        } else {
			$pathTemplate = APPPATH.('views/template/'.$template.'.php'); //De no existir, se carga la ruta de las vistas por defecto.
		}
		
        $this->load = new Common (new Loader); //Instanciamos.
        if(is_readable($pathTemplate)){ //Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			//Si existen variables para asignar, las pasamos una a una.
			if (is_array($vars)){
				$this->cached_vars = array_merge($vars); //Almacenamos las variables en un objeto.
			}
			extract($this->cached_vars); //Las extraemos para su posterior utilización.
			include_once $pathTemplate;
		} else {//Error 404
            echo css('bootstrap.min');
			throw new Exception('Error, no se puede cargar la plantilla - '.$template.'.php'); //Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
		
    }

    public function model($model){
		if($this->module){
            $pathModel = APPPATH.('modules/'.$this->module.'/models/'.$model.'.php'); //Establecemos la ruta de las vistas de los modulos.
        } else {
			$pathModel = APPPATH.('models/'.$model.'.php'); //De no existir, se carga la ruta de las vistas por defecto.
		}        
        if(is_readable($pathModel)){ //Verificamos si existe.
            require_once $pathModel; //Lo incluimos.
            $model = new $model; //Lo instanciamos.
            return $model; //Lo cargamos.
        } else {
            echo css('bootstrap.min');
			throw new Exception('Error al cargar el modelo - '.$model.'.php'); //Si no existe, cargamos un mesaje de error.
        }
    }

    public function library($library){
		if($this->module){
            $pathLibrary = APPPATH.('modules/'.$this->module.'/libraries/'.$library.'.php'); //Establecemos la ruta de las vistas de los modulos.
        } else {
			$pathLibrary = APPPATH.'libraries/'.$library.'.php'; //Seteamos el origen del la clase.
		}  

        //$this->model = new Model (); //Instanciamos a la clase Model.
        if(is_readable($pathLibrary)){ //Verificamos si existe.
            require_once $pathLibrary; //La incluimos o cargamos.
			$library = new $library; //La instanciamos.
			return $library; //La cargamos.
        } else {
            echo css('bootstrap.min');
			throw new Exception('Error al cargar la libreria - '.$library.'.php'); //Si no existe, cargamos un mesaje de error.
        }
    }

    public function baseLibrary($baseLibrary){
        $baseLibrary = $baseLibrary;
		$pathBaseLibrary = BASEPATH.'libraries/'.$baseLibrary.'.php'; //Seteamos el origen del la clase.
        //$this->model = new Model (); //Instanciamos a la clase Model.
        if(is_readable($pathBaseLibrary)){ //Verificamos si existe.
            require_once $pathBaseLibrary; //La incluimos o cargamos.
			$baseLibrary = new $baseLibrary; //La instanciamos.
			return $baseLibrary; //La cargamos.
        } else {
            echo css('bootstrap.min');
			throw new Exception('Error al cargar la libreria del sistema - '.$baseLibrary.'.php'); //Si no existe, cargamos un mesaje de error.
        }
    }
	
    public function thirdparty($thirdParty){
		if($this->module){
            $pathThirdParty = APPPATH.('modules/'.$this->module.'/third_party/'.$thirdParty.'.php'); //Establecemos la ruta de las vistas de los modulos.
        } else {
			$pathThirdParty = APPPATH.('third_party/'.$thirdParty.'.php'); //Seteamos el origen del la clase.
		}        
		
        if(is_readable($pathThirdParty)){ //Verificamos si existe.
            require_once $pathThirdParty; //Lo incluimos.
            $thirdParty = new $thirdParty; //Lo instanciamos.
            return $thirdParty; //Lo cargamos.
        } else {
            echo css('bootstrap.min');
			throw new Exception('Error al cargar la clase de origen de terceros - '.$thirdParty.'.php'); //Si no existe, cargamos un mesaje de error.
        }
    }

}

/* End of file Common.php */
/* Location: ./system/core/Common.php */