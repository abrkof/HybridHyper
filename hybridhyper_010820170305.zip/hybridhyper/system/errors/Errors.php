﻿<?php if ( ! defined('BASEPATH')) exit('Acceso no permitido al nucleo del sistema, ABRKOF');
//Clase Errors.
class Errors extends Controller{

	public function __construct(){ //Inicializamos el constructor.
	
	}

	public function index(){
	
	}
	
	public function error($message = 'El sistema no encontro información sobre el error, ponganse en contacto con el desarrrollador.'){
		echo '<pre>'.print_r($message,1).'</pre>';	
	}
}