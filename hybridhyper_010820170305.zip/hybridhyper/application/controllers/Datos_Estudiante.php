﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Datos_Estudiante Controller Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
 
//Creamos la clase
class Datos_Estudiante extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Datos_Estudiante = $this->load->model('Model_Datos_Estudiante'); 
		$this->pdf = $this->load->library('Pdf');
		echo librarypath('third_party/Zebra_Pagination-master/Zebra_Pagination');
		$this->pagination = new Zebra_Pagination;
    }
	
    //Creamos una acción principal cargamos las vistas
    public function index(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin/inicio_sesion');
            exit;
        } else {
			//$this->input->server('HTTP_USER_AGENT');
			$pagination = 20;
			$data['navigation_position'] = $this->pagination->navigation_position(isset($_GET['navigation_position']) && in_array($_GET['navigation_position'], array('left', 'right')) ? $_GET['navigation_position'] : 'outside');
			$per_page = (($this->pagination->get_page() - 1) * $pagination);
			$data['total_rows'] = $this->pagination->records($this->db->get('datos_estudiante'));
			$data['total_per_page'] = $this->pagination->records_per_page($pagination);
			$data['link_labels'] = $this->pagination->labels('Anterior', 'Siguiente');
			
			$data['titulo'] = 'Bienvenido';
			$data['query'] = $this->Model_Datos_Estudiante->all_paginate($per_page, $pagination);
			$data['contenido'] = 'datos_estudiante/index';
			$data['paginate'] = $this->pagination->render();
			$data['data'] = $data;
			$this->load->view('template/template',$data);
		}
    }
	
    //Con esta función validamos y protegemos el buscador
    public function validar(){
		$buscador = $this->input->post('buscar');
		$query = $this->Model_Datos_Estudiante->got_result($buscador);
		if($query > 0) {
			$this->session->set_userdata('buscar', $buscador);
            redirect('datos_estudiante/consultar');
        } else {
			$data['titulo'] = 'Datos Estudiante';
			$data['contenido'] = 'datos_estudiante/result';
			$this->load->view('template/template', $data);
        }
    }

	//Mostramos los datos de busqueda.
	public function consultar(){
		$buscador = $this->session->get_userdata('buscar');
		
		$pagination = 20;
		$data['navigation_position'] = $this->pagination->navigation_position(isset($_GET['navigation_position']) && in_array($_GET['navigation_position'], array('left', 'right')) ? $_GET['navigation_position'] : 'outside');
		$per_pages = (($this->pagination->get_page() - 1) * $pagination);
		$data['total_rows'] = $this->pagination->records(count($this->Model_Datos_Estudiante->got_result($buscador)));
		$data['total_per_page'] = $this->pagination->records_per_page($pagination);
		$data['link_labels'] = $this->pagination->labels('Anterior', 'Siguiente');
	
		$data['titulo'] = 'Datos Estudiante';
		$data['query'] = $this->Model_Datos_Estudiante->total_posts_paginated($buscador, $per_pages, $pagination);
		$data['contenido'] = 'datos_estudiante/result';
		$data['paginate'] = $this->pagination->render();
		$data['data'] = $data;
		$this->load->view('template/template', $data);
	}
	
	public function prototypePagintator(){
		//Limito la busqueda 
		$pagination = 5; 
		//examino la página a mostrar y el inicio del registro a mostrar 
		$page = 1;
		$start = 0;
		
		if(isset($_GET["page"])){
			$page = $_GET["page"];
			$start = ($page - 1) * $pagination;
		}
			
		//veo el número total de campos que hay en la tabla con esa búsqueda 
		$total_rows = count($this->Model_Datos_Estudiante->all());
		//echo count($total_rows);
		
		//calculo el total de páginas 
		$total_pages = ceil($total_rows / $pagination); 
		/*//pongo el número de registros total, el tamaño de página y la página que se muestra 
		echo "Número de registros encontrados: " . $total_rows . "<br>"; 
		echo "Se muestran páginas de " . $pagination . " registros cada una<br>"; 
		echo "Mostrando la página " . $page . " de " . $total_pages . "<p>";*/
			
		//construyo la sentencia SQL 
		$query = $this->Model_Datos_Estudiante->all_paginate($start, $pagination);
		foreach($query as $registro){
			echo $registro->nombres."<br>";
		}
		
		
		//muestro los distintos índices de las páginas, si es que hay varias páginas 
		if ($total_pages > 1){ 
			for ($i = 1;$i <= $total_pages; $i++){ 
			   if ($page.'?' == $i){
				  //si muestro el índice de la página actual, no coloco enlace 
				  $current .=$page.' '; 
				} else {
				  //si el índice no corresponde con la página mostrada actualmente, coloco el enlace para ir a esa página 
				  $next .= '<a href="'.base_url('').'datos_estudiante/asd/?page='.$i.'">'.$i.'</a> '; 
				}
			} 
		}
		echo $current.$next;
	}
	
	function generarCodigo($longitud) {
		
		$key = '';
		$pattern = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ12345noze67890abcdefghijklmnopqrstuvwxyz';
		$max = strlen($pattern)-1;
		for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)};
		return $key;
	}

	public function codeHAA(){
		$string= $registro['apellidos'];
		$position=1;
		
		for ($i=0; $i<strlen($string); $i++){
			if($string[$i]!=" " && $position==1){
				$result .= $string[$i];
				$position=0;
			}
			if($string[$i]==" "){ 
				$position=1;
			}
		}
	}
	
	public function otherFunction(){
		for($i = 1; $i <= 5; $i += 1) echo $i . "\n";
		$coockies = 1;
		while ($coockies < 5 + 1){
			$coockies;
			$array = array($coockies++); 
			$string = "?"; 
			echo strtr($string,$array);
		}
	}

    public function create(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin/inicio_sesion');
            exit;
        } else {
			$data['titulo'] = 'Datos Estudiante';
			$data['contenido'] = 'datos_estudiante/create';
			$this->load->view('template/template',$data);
		}
    }
    
    public function insert(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin/inicio_sesion');
            exit;
        } else {
			$registro['nombres'] = $this->input->post('nombres');
			$registro['apellidos'] = $this->input->post('apellidos');
			$registro['genero'] = $this->input->post('genero');
			$registro['fecha_nacimiento'] = $this->input->post('fecha_nacimiento');
			
			$registro['created'] = TODAY;
			$registro['updated'] = TODAY;
	
			$this->Model_Datos_Estudiante->insert($registro);
			
			redirect('datos_estudiante');
		}
    }	
	
    public function edit($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin/inicio_sesion');
            exit;
        } else {
			$data['titulo'] = 'Datos Estudiante';
			$data['registro'] = $this->Model_Datos_Estudiante->allFiltered($id);
			$data['contenido'] = 'datos_estudiante/edit';
			$data['data'] = $data;
			$this->load->view('template/template',$data);
		}
    }


    public function update(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin/inicio_sesion');
            exit;
        } else {
			$registro['id'] = $this->input->post('id');
			$registro['nombres'] = $this->input->post('nombres');
			$registro['apellidos'] = $this->input->post('apellidos');
			$registro['genero'] = $this->input->post('genero');
			$registro['fecha_nacimiento'] = $this->input->post('fecha_nacimiento');
			
			$registro['updated'] = TODAY;
	
			$this->Model_Datos_Estudiante->update($registro);
			
			redirect('datos_estudiante');
		}
    }
    
    public function delete($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin/inicio_sesion');
            exit;
        } else {
			$this->Model_Datos_Estudiante->delete($id);
			redirect('datos_estudiante');
		}
    }

	public function pdf($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('inicio');
            exit;
        } else {
            $registro = $this->Model_Datos_Estudiante->allFiltered($id);
        //Creacion del PDF
 
        /*
         * Se crea un objeto de la clase Pdf, recuerda que la clase Pdf
         * heredó todos las variables y métodos de fpdf
         */
        //$this->pdf = new Pdf();
		$this->pdf->SetDatosHeader($datosHeader);
        // Agregamos una página
        $this->pdf->AddPage();
        // Define el alias para el número de página que se imprimirá en el pie
        $this->pdf->AliasNbPages();
 
        /* Se define el titulo, márgenes izquierdo, derecho y
         * el color de relleno predeterminado
         */
        $this->pdf->SetTitle("Ficha de Matricula");
        $this->pdf->SetLeftMargin(15);
        $this->pdf->SetRightMargin(15);
        $this->pdf->SetFillColor(200,200,200);
 
        //Se define el formato de fuente: Arial, negritas, tamaño 9
        $this->pdf->SetFont('Arial', 'B', 9);
        /*
         * TITULOS DE COLUMNAS
         *
         * $this->pdf->Cell(Ancho, Alto,texto,borde,posición,alineación,relleno);
         */

        /*$this->pdf->Cell(15,7,'NUM','TBL',0,'C','1');
        $this->pdf->Cell(25,7,'Nombres','TB',0,'L','1');
        $this->pdf->Cell(25,7,'Apellidos','TB',0,'L','1');
        $this->pdf->Cell(25,7,'Genero','TB',0,'L','1');
        $this->pdf->Cell(40,7,'Fecha Nacimiento','TB',0,'C','1');
        $this->pdf->Cell(25,7,'Grado','TB',0,'L','1');
        $this->pdf->Cell(25,7,'Sección','TBR',0,'C','1');
        $this->pdf->Ln(7);*/
		
        //La variable $x se utiliza para mostrar un número consecutivo
        $x = 1;
        //foreach($query as $registro){
            // se imprime el numero actual y despues se incrementa el valor de $x en uno
            //$this->pdf->Cell(15,5,$x++,'BL',0,'C',0);
            // Se imprimen los datos de cada estudiante
			$this->pdf->Ln(9);
			$this->pdf->Cell(37,5,'Nombre del Estudiante: ',0,0,'L').
            $this->pdf->Cell(40,5,utf8_decode($registro->nombres),'B',0,'L',0).
            $this->pdf->Cell(40,5,utf8_decode($registro->apellidos),'B',0,'L',0);
			$this->pdf->Cell(14,5,utf8_decode('Género: '),0,0,'L').
            $this->pdf->Cell(20,5,utf8_decode($registro->genero == 1 ? 'Masculino' : 'Femenino'),'B',0,'L',0);
			$this->pdf->Cell(12,5,'Fecha:',0,0,'L').
            $this->pdf->Cell(30,5,utf8_decode($registro->fecha_nacimiento),'B',0,'L',0);
			$this->pdf->Ln(9);
		//}
			
        //}
		
        /*
         * Se manda el pdf al navegador
         *
         * $this->pdf->Output(nombredelarchivo, destino);
         *
         * I = Muestra el pdf en el navegador
         * D = Envia el pdf para descarga
         *
         */
		 ob_end_clean();
		 //$this->pdf->Cell(25,5,html_entity_decode($estudiante->turno_name));
		 //$this->pdf->Cell(25,5,html_entity_decode("&aacute;").$estudiante->turno_name);
		 //utf8_encode();
        $this->pdf->Output($registro->apellidos.', '.$registro->nombres.' - '."Ficha Matricula.pdf", 'I');
		}
	}

	/*public function pdfx($nombres, $apellidos){
		$this->pdf->AddPage();
		$this->pdf->SetFont('Arial', 'B', 16);
		$this->pdf->Cell(40,10,utf8_decode($nombres.' '.$apellidos));
		$this->pdf->Output();
	}*/

}