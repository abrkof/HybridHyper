﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * SubMenu Controller Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
 
//Creamos la clase
class SubMenu extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_SubMenu = $this->load->model('Model_SubMenu');
		$this->submenulib = $this->load->library('SubMenuLib');
		$this->submenu_perfillib = $this->load->library('SubMenu_PerfilLib');
    }

    public function index(){
		$data['titulo'] = 'Sub Menús';
		$data['query'] = $this->Model_SubMenu->all();
		$data['contenido'] = 'submenu/index';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

    public function create(){
		$data['titulo'] = 'Sub Menús';
		$data['menus'] = $this->Model_SubMenu->get_menus(); /* Lista de los Menús */
		$data['contenido'] = 'submenu/create';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$registro['submenu'] = $this->input->post('submenu');
		$registro['menu_id'] = $this->input->post('menu_id');
		$registro['controlador'] = $this->input->post('controlador');
		$registro['accion'] = $this->input->post('accion');
		$registro['url'] = $this->input->post('url');
		$registro['orden'] = $this->input->post('orden');
		$registro['icon'] = $this->input->post('icon');
		$registro['descripcion'] = $this->input->post('descripcion');
		$registro['created'] = TODAY;
		$registro['updated'] = TODAY;

		$this->Model_SubMenu->insert($registro);
		
		redirect('submenu');
    }

    public function edit($id){
		$data['titulo'] = 'Sub Menús';
		$data['menus'] = $this->Model_SubMenu->get_menus(); /* Lista de los Menús */
		$data['registro'] = $this->Model_SubMenu->allFiltered($id);
		$data['contenido'] = 'submenu/edit';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }
    
    public function update(){
		$registro['id'] = $this->input->post('id');
		$registro['submenu'] = $this->input->post('submenu');
		$registro['menu_id'] = $this->input->post('menu_id');
		$registro['controlador'] = $this->input->post('controlador');
		$registro['accion'] = $this->input->post('accion');
		$registro['url'] = $this->input->post('url');
		$registro['orden'] = $this->input->post('orden');
		$registro['icon'] = $this->input->post('icon');
		$registro['descripcion'] = $this->input->post('descripcion');
		$registro['updated'] = TODAY;

		$this->Model_SubMenu->update($registro);
		
		redirect('submenu');
    }
    
    public function delete($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin');
            exit;
        } else {
			$this->Model_SubMenu->delete($id);
			redirect('submenu');
		}
    }

    //Creamos el metodo de asiganción de permisos
    public function submenu_perfiles($submenu_id){
		$data['titulo'] = 'Sub Menús';
		//Cargar arreglos Izquierda y Derecha
		$perfiles = $this->submenulib->get_perfiles_asig_noasig($submenu_id);
		$data['query_izq'] = $perfiles[0];
		$data['query_der'] = $perfiles[1];
		$data['contenido'] = 'submenu/submenu_perfiles';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

	public function smp_noasig(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin');
            exit;
        } else {
			$perfil_id = $this->input->request('perfil_id');
			$submenu_id = $this->input->request('submenu_id');
			$this->submenu_perfillib->quitar_acceso($perfil_id, $submenu_id);
			redirect('submenu/submenu_perfiles/'.$submenu_id);
		}
	}

	public function smp_asig(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin');
            exit;
        } else {
			$perfil_id = $this->input->request('perfil_id');
			$submenu_id = $this->input->request('submenu_id');
			$this->submenu_perfillib->dar_acceso($perfil_id, $submenu_id);
			redirect('submenu/submenu_perfiles/'.$submenu_id);
		}
	}
    //Creamos una acción para cargar el ordenar los menús
    public function submenu_ordenar(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin');
            exit;
        } else {
			$data['titulo'] = 'Odenando Sub Menús';
			$data['query'] = $this->Model_SubMenu->allx();
			$data['contenido'] = 'submenu/submenu_ordenar';
			$data['data'] = $data;
			$this->load->view('template/template',$data);
		}
    }
    //Creamos una acción para actualizar el orden de los sub menús
    public function update_orden(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin');
            exit;
        } else {
			//aquí ordenaremos los articulos con ajax
			//array con el nuevo orden de nuestros registros
			$submenus_ordenados = $this->input->request('submenu');
			$pos = 1;
			foreach ($submenus_ordenados as $key) {
			//actualizamos el campo orden_articulo
			$stmt = $this->dbx->prepare('UPDATE submenu SET orden = ? WHERE id = ?');			          
			$stmt->execute(array($pos, $key));
				$pos++;
			}
			echo "El Sub Menú se ha actualizado con Exito";
		}
	}

}