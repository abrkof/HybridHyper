﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Perfil Controller Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
 
//Creamos la clase
class Perfil extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Perfil = $this->load->model('Model_Perfil');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
		$data['titulo'] = 'Perfiles';
		$data['query'] = $this->Model_Perfil->all();
		$data['contenido'] = 'perfil/index';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

    public function create(){
		$data['titulo'] = 'Perfiles';
		$data['contenido'] = 'perfil/create';
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$registro['perfil'] = $this->input->post('perfil');
		$registro['descripcion'] = $this->input->post('descripcion');
		$registro['created'] = TODAY;
		$registro['updated'] = TODAY;

		$$this->Model_Perfil->insert($registro);
		
		redirect('perfil');
    }

    public function edit($id){
		$data['titulo'] = 'Perfiles';
		$data['registro'] = $this->Model_Perfil->allFiltered($id);
		$data['contenido'] = 'perfil/edit';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }
    
    public function update(){
		$registro['id'] = $this->input->post('id');
		$registro['perfil'] = $this->input->post('perfil');
		$registro['descripcion'] = $this->input->post('descripcion');
		$registro['updated'] = TODAY;

		$this->Model_Perfil->update($registro);
		
		redirect('perfil');
    }
    
    public function delete($id){
		$this->Model_Perfil->delete($id);
		redirect('perfil');
    }

}