﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Usuario Controller Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
 
//Creamos la clase
class Usuario extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Usuario = $this->load->model('Model_Usuario');
		$this->usuariolib = $this->load->library('UsuarioLib');
    }

    public function index(){
		$data['titulo'] = 'Usuarios';
		$data['query'] = $this->Model_Usuario->all();
		$data['contenido'] = 'usuario/index';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

    public function create(){
		$data['titulo'] = 'Usuarios';
		$data['perfiles'] = $this->Model_Usuario->get_perfiles(); /* Lista de los Perfiles */
		$data['contenido'] = 'usuario/create';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$count = $this->db->get('usuario');
		$n_e = $count + 1;
		$registro['id'] = $n_e;
		$registro['nombres'] = $this->input->post('nombres');
		$registro['apellidos'] = $this->input->post('apellidos');
		$registro['login'] = $this->input->post('login');
		$registro['password'] = $this->input->post('password');
		$registro['email'] = $this->input->post('email');
		$registro['perfil_id'] = $this->input->post('perfil_id');
		$registro['image'] = $this->input->post('image');
		$registro['created'] = TODAY;
		$registro['updated'] = TODAY;

		//Llamada al método de un objeto
		//if (call_user_func(array($this->usuariolib, 'my_validation')));

		$this->Model_Usuario->insert($registro);
			
		redirect('usuario');
    }

    public function edit($id){
		$data['titulo'] = 'Usuarios';
		$data['perfiles'] = $this->Model_Usuario->get_perfiles(); /* Lista de los Perfiles */
		$data['registro'] = $this->Model_Usuario->allFiltered($id);
		$data['contenido'] = 'usuario/edit';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }
    
    public function update(){
		$registro['id'] = $this->input->post('id');
		$registro['nombres'] = $this->input->post('nombres');
		$registro['apellidos'] = $this->input->post('apellidos');
		$registro['login'] = $this->input->post('login');
		$registro['email'] = $this->input->post('email');
		$registro['perfil_id'] = $this->input->post('perfil_id');
		$registro['image'] = $this->input->post('image');
		$registro['updated'] = TODAY;

		//Llamada al método de un objeto
		//if (call_user_func(array($this->usuariolib, 'my_validation')));

		$this->Model_Usuario->update($registro);
			
		redirect('usuario');
    }
    
    public function delete($id){
		$this->Model_Usuario->delete($id);
		redirect('usuario');
    }

	public function comprobar(){
		//Llamada al método de un objeto
		call_user_func(array($this->usuariolib, 'my_validation'));
	}

}