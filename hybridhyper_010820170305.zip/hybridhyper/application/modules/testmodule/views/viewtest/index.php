﻿<br><br>
<h1 class="page-header">Bienvenidos</h1>
<div class="well well-sm text-center">
<h1>NOZE!!!</h1>
<?php echo form_open('Datos_Estudiante', array('class'=>'form-horizontal', 'method'=>'post')); ?>
	<div class="form-actions">
		<?php echo form_button(array('type'=>'submit', 'content'=>'Entrar', 'class'=>'btn btn-primary')); ?>
		<?php echo anchor('Datos_Estudiante', 'Ingresar', 'class="btn btn-default"'); ?>
	</div>
<?php echo form_close(); ?>
</div>

<article id="post-105" class="post-105 post type-post status-publish format-quote hentry category-php-poo-2 tag-php tag-php-oop tag-php-poo">
	<header class="entry-header">
		<h1 class="entry-title">Bla Bla Bla</h1>

		<div class="entry-meta">
			<span class="posted-on">Bla Bla Bla</span></div><!-- .entry-meta -->
	</header><!-- .entry-header -->
	
	<div class="entry-content">
		<h2>Bla Bla Bla</h2>
<p>Bla Bla Bla<em>Bla Bla Bla</em> Bla Bla Bla</p>
<p>Bla Bla Bla</p>
<div>
<div id="highlighter_191950" class="syntaxhighlighter  php">
<table border="0" cellpadding="0" cellspacing="0"><tbody><tr><td class="gutter">
<div class="line number1 index0 alt2">1</div><div class="line number2 index1 alt1">2</div>
<div class="line number3 index2 alt2">3</div><div class="line number4 index3 alt1">4</div>
<div class="line number5 index4 alt2">5</div><div class="line number6 index5 alt1">6</div>
</td><td class="code"><div class="container"><div class="line number1 index0 alt2"><code class="php comments">// Heredamos de la clase</code></div><div class="line number2 index1 alt1"><code class="php variable">$Jum</code> <code class="php plain">= </code><code class="php keyword">new</code> <code class="php plain">Ti;</code></div><div class="line number3 index2 alt2"><code class="php comments">// Jum</code></div>
<div class="line number4 index3 alt1"><code class="php variable">$Hola</code><code class="php plain">-&gt;PrintName(); </code></div><div class="line number5 index4 alt2"><code class="php variable">$Noze</code><code class="php plain">-&gt;PrintContent(); </code></div><div class="line number6 index5 alt1"><code class="php variable">$Jum</code><code class="php plain">-&gt;PrintAll(); </code></div></div></td></tr></tbody></table></div></div>
<p>Bla Bla Bla</p>
<p>Bla Bla Bla</p>
<p>Bla Bla Bla</p>
</div>			
</div>
</article>
<!-- .entry-content -->
