﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Hierarchic Menu Helper
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
if (!function_exists('my_menu_ppal')){
	function my_menu_ppal(){
		//Instanciamos a la clase de conexion de la base de datos
		$ABRKOF = & get_instance();
				
		$stmtp = $ABRKOF->dbx->prepare('SELECT id, menu, controlador, accion, url, orden FROM menu ORDER BY orden ASC');
		$stmtp->execute();
		$stmtpx = $stmtp->fetchAll();

		foreach($stmtpx as $menux){
			//Preparamos la primera consulta de acceso
			$stmt1 = $ABRKOF->dbx->prepare('SELECT menu_perfil.*, menu.menu AS menu 
							from menu_perfil 
							LEFT JOIN menu ON (menu_perfil.menu_id = menu.id)
							WHERE menu_id = "'.$menux['id'].'" AND perfil_id = "'.$ABRKOF->session->get_userdata('perfil_id').'"');
			$stmt1->execute();
			//Delvemos un arreglo con la siguiente fila
			$stmtx = $stmt1->fetchAll();
			//if ($stmtp != 0){
			$menu_urlx = $menux['controlador'].'/'.$menux['accion'];
			$menu_url = substr($menu_urlx,0,strripos($menu_urlx,"/"));
			//}
			$menu = "\n";
	
			//Evaluamos si el arreglo trae algo
			if(count($stmtx) > 0);
			foreach($stmtx as $row1){
				//Preparamos la segunda consulta de acceso
				$stmt2 = $ABRKOF->dbx->prepare('SELECT id, submenu, controlador, accion, url, menu_id, icon, orden FROM submenu 
										WHERE menu_id = "'.$row1['menu_id'].'" ORDER BY orden ASC');
				$stmt2->execute();
				//Contamos el número de filas que trae.
				$rows = $stmt2->rowCount();
				
				$m = $menu_url;
				//Evaluamos si el arreglo viene vacío
				if($rows == 0){//Si no se relaciona con un sub menú, imprime un link normal.
					echo $menu .= "<li><a href=".base_url('')."$m>".$row1['menu']."</a></li>\n";
				} else {//Si hay un sub menú relacionado, imprime un menú en cascada.
					$menu .= "<li class='dropdown'>\n <a href='#' class='dropdown-toggle' data-toggle='dropdown'>".$row1['menu']."<b class='caret'></b></a>\n
							 <ul class='dropdown-menu'>\n";
					foreach($stmt2 as $row2){
						$submenu_urlx = $row2['controlador'].'/'.$row2['accion'];
						$submenu_url = substr($submenu_urlx,0,strripos($submenu_urlx,'/'));
						
						$menu .= "<li><a href=".base_url('')."$submenu_url>".$row2['submenu']."</a></li>\n";
					}
				$menu .= "</ul></li>\n";
				echo $menu;
				}
			}
		}
		//$menu .="";
		//return $menu;
	}
}