﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Pdf Library Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
 
//Incluimos el archivo fpdf
echo librarypath('third_party/fpdf/fpdf');
//Extendemos la clase Pdf de la clase fpdf para que herede todas sus variables, metodos y funciones
class Pdf extends FPDF {
	public function __construct(){
		parent::__construct();
	}

	function SetDatosHeader( $datos ){
		$this->datosHeader = $datos;
	}
	
	function GetDatosHeader(){
		return $this->datosHeader;
	}

	// El encabezado del PDF
	public function Header(){

		$datosHeader = $this->GetDatosHeader();
		$this->Image('assets/img/coed2.png',165,1,40);
		$this->Image('assets/img/mined.png',5,8,36);
		$this->SetFont('Arial','B',8);
		$this->Cell(30);
		$this->Cell(120,10,utf8_decode('MINISTERIO DE EDUCACIÓN'),0,0,'C');
		$this->Ln('5');

		$this->Cell(30);
		$this->Cell(120,10,utf8_decode('COMPLEJO EDUCATIVO "EUGENIO AGUILAR TRIGUEROS"'),0,0,'C');
		$this->Ln('5');

		$this->Cell(30);
		$this->Cell(120,10,utf8_decode('CANTON LOS LAGARTOS, SAN JULIÁN, SONSONATE.'),0,0,'C');
		$this->Ln('10');

		$this->SetFont('Arial','B',13);
		$this->Cell(30);
		$this->Cell(120,10,utf8_decode('FICHA DE INSCRIPCIÖN DE ESTUDIANTES, ').'       ',0,0,'C');
		
		$this->Ln(20);

		/*$this->SetFont('Arial','I',10);
		$this->Cell(30);
		$this->Cell(120,10,'CANTON LOS LAGARTOS, SAN JULIAN, SONSONATE.',0,0,'C');
		$this->Ln('10');*/
   }
   // El pie del pdf
   public function Footer(){
	   $this->SetY(-15);
	   $this->SetFont('Arial','B',13);
	   $this->Cell(0,-200,'COMPROMISO',0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(164.5,-180,'Yo:__________________________________________________________________, como padre o madre responsable',0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','B',10);
	   $this->Cell(8,-170,'ME COMPROMETO',0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(200,-170,'a que mi hijo/a cumpla con el reglamento interno y de las disposiciones del Complejo Educativo,',0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(164,-160,utf8_decode('asumiendo la resposabilidad sobre la conducta de el (ella) y la participación de toda actividad que la insitución convoque'),0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(61,-150,utf8_decode('durante todo el año lectivo, también me comprometo a'),0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','B',10);
	   $this->Cell(164,-150,'VIGILAR',0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(265,-150,utf8_decode('el comportamiento de mi hijo/a con relación a: Corte '),0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(165,-140,utf8_decode('de Cabello, llegadas tardías, Noviazgo, ruedo de pantalón, falda normal y uso de celular. También informar al maestro (a)'),0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(150,-130,utf8_decode('las causas de asusencia de mi hijo/a y a retirar la documentación en caso de que el (ella) ya no asista a clases.'),0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(156,-100,'F.______________________________',0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(156,-85,'Nombre del Responsable:________________________________________________',0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(146,-70,utf8_decode('DUI Nº:______________________________'),0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(156,-40,utf8_decode('Fecha de Matrícula:     ').'        '.'      , Maestro/a:_______________________________________________________ ',0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(163,-20,utf8_decode('Se le devolvió partida de nacimiento:______ En que fecha:___________________ F.__________________________'),0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','B',10);
	   $this->Cell(295,-10,utf8_decode('Recibí partida, conforme'),0,0,'C');

	   $this->SetY(-15);
	   $this->SetFont('Arial','I',10);
	   $this->Cell(163,10,'Otros documentos que deja:________________________________________________________________________',0,0,'C');
    }
}