﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * MenuLib Library Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
 
class MenuLib {
	function __construct(){
		try{
			$this->ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librería
		}
		catch(Exception $e){
			die($e->getMessage());
		}
		$this->ABRKOF->Model_Perfil = $this->ABRKOF->load->model('Model_Perfil');
    }

    public function get_perfiles_asig_noasig($menu_id){
        $lista_asig = array();
        $lista_noasig = array();
		
		$perfiles = $this->ABRKOF->Model_Perfil->all();
		
		foreach($perfiles as $perfil){
			$query = $this->ABRKOF->db->row_array('SELECT * FROM menu_perfil WHERE menu_id = :menu_id AND perfil_id = :perfil_id', 
												array(':menu_id'=>$menu_id, ':perfil_id'=>$perfil->id));
			$existe = (count($query) > 0);
			
            if($existe){
                $lista_asig[] = array($perfil->id, $perfil->perfil, $menu_id);
            } else {
                $lista_noasig[] = array($perfil->id, $perfil->perfil, $menu_id);
            }
        }
		return array($lista_noasig, $lista_asig);
    }

    public function findByControlador($controlador){
		$query = $this->ABRKOF->db->by_id('SELECT * FROM menu WHERE controlador = :controlador', 
											array(':controlador'=>$controlador));
		return $query;
    }

}