﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * UsuarioLib Library Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
 
class UsuarioLib{
	function __construct(){
		try{
			$this->ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librería
		}
		catch(Exception $e){
			die($e->getMessage());
		}
		$this->ABRKOF->Model_Usuario = $this->ABRKOF->load->model('Model_Usuario');
		$this->ABRKOF->Model_Perfil = $this->ABRKOF->load->model('Model_Perfil');
    }

	public function login(){
        define('ERROR_LOGIN','Error, Usuario o Contraseña Incorrectos!!!.');
		
		$login = $this->ABRKOF->input->request('login');
        $password = md5($this->ABRKOF->input->request('password'));
		
		$stmt = $this->ABRKOF->db->next_row('SELECT * FROM usuario WHERE login = :login AND password = :password', 
											array(':login'=>$login, ':password'=>$password));
		
		if(count($stmt) == 1){
			$this->ABRKOF->session->sess_destroy();
			return FALSE;
		} else {
    		$usuario = $stmt;
			
			$stmtp = $this->ABRKOF->db->next_row('SELECT * FROM perfil WHERE id = :id', 
												array(':id'=>$usuario['perfil_id']));
			
			$perfil = $stmtp;
			
			//////////////////////////////////////////////////////////////////////////////////////////////
			$stmtm = $this->ABRKOF->db->next_row('SELECT * FROM menu');
			
			$menu = $stmtm;
			
			$stmtr = $this->ABRKOF->db->next_row('SELECT * FROM menu_perfil WHERE perfil_id = :perfil_id', 
												array(':perfil_id'=>$perfil['id']));
			
			$menu_perfil = $stmtr;
			//////////////////////////////////////////////////////////////////////////////////////////////

			$this->ABRKOF->session->set_userdata('usuario_login', $usuario['login']);
			$this->ABRKOF->session->set_userdata('usuario_name', $usuario['nombres']);
			$this->ABRKOF->session->set_userdata('usuario_ape', $usuario['apellidos']);
			$this->ABRKOF->session->set_userdata('usuario_id', $usuario['id']);
			$this->ABRKOF->session->set_userdata('perfil_id', $usuario['perfil_id']);
			$this->ABRKOF->session->set_userdata('perfil_name', $perfil['perfil']);
			$this->ABRKOF->session->set_userdata('usuario_image', $perfil['image']);
			
			//////////////////////////////////////////////////////////////////////////////////////////////
			
		return TRUE;
		}
	}

    public function cambiarPWD($act, $new){
    	if($this->ABRKOF->session->get_userdata('usuario_id') == NULL){
    		throw new Exception('No existe el usuario o los datos de sesión vienen vacios');//return FALSE;
    	}
		
		$id = $this->ABRKOF->session->get_userdata('usuario_id');

		$usuario = $this->ABRKOF->Model_Usuario->find($id);

		if($usuario['password'] == $act){
    		$registro = array('id' => $id,
               			  'password' => $new,
						  'updated' => TODAY);
			$this->ABRKOF->Model_Usuario->update_pass($registro);
		} else {
			redirect('admin/error_pwdusr');
			//throw new Exception('La Nueva Contraseña No Coincide Con La Contraseña Actual');//return FALSE;
		}
    }

    public function my_validation($registro){
		$registro->login = $this->ABRKOF->input->request('login');
		
		$stmt = $this->ABRKOF->dbx->prepare('SELECT * FROM usuario WHERE login = :login');
		$stmt->execute(array($registro->login));
		$stmtx = $stmt->fetchAll();

		$rt = redirect('usuario/create');
			
        if (count($stmtx) > 0 AND (!isset($registro['id']) OR ($registro['id'] != $stmt->fetchAll('id')))){
            return FALSE;
        }
        else{
            return $rt;
        }
    }

}