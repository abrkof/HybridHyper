<?php

?>
<br><br>
<div class="page-header">
	<h1> Datos Estudiante <small>|| Mantenimiento de registros </small> </h1>
</div>

<div class="well well-sm text-right">
    <a class="btn btn-primary" href="<?php echo base_url('');?>datos_estudiante/create" style="color:#FFF;">Nuevo Estudiante</a>
</div>

<?php echo form_open('datos_estudiante/validar', array('class'=>'sidebar-form')); ?>
<div class="title_right">
	<div class="col-md-3 col-sm-8 col-xs-12 form-group pull-left top_search">
		<div class="input-group">
			<?php echo form_input(array('type'=>'text', 'name'=>'buscar', 'id'=>'buscar', 'placeholder'=>'Buscar Estudiante...', 'class'=>'form-control', 'required'=>'true')); ?>
			<span class="input-group-btn">
				<?php echo form_button(array('type'=>'submit', 'content'=>'Buscar', 'class'=>'btn btn-default', 'type'=>'submit')); ?>
			</span>
		</div>
	</div>
</div>
<?php echo form_close(); ?>

<table class="table table-striped">
    <thead>
        <tr>
            <th style="width:10px;">Id</th>
			<th style="width:100px;">Nombres</th>
            <th style="width:100px;">Apellidos</th>
            <th style="width:120px;">Género</th>
            <th style="width:120px;">Fecha de Nacimiento</th>
            <th style="width:60px;">Creado</th>
            <th style="width:60px;">Modificado</th>			
            <th style="width:60px;"></th>
            <th style="width:60px;"></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($query as $registro): ?>
        <tr>
			<td><?php echo $registro->id; ?></td>
            <td><?php echo $registro->nombres; ?></td>
            <td><?php echo $registro->apellidos; ?></td>
            <td><?php echo $registro->genero; ?></td>
            <td><?php echo date("d/m/Y", strtotime($registro->fecha_nacimiento)); ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->created)); ?></td>
			<td><?php echo date("d/m/Y - H:i", strtotime($registro->updated)); ?></td>
			<td><?php echo open_link('datos_estudiante/edit/'.$registro->id_dat_est, 'Editar') ;?></td>
            <td><a onclick="alertify.confirm('Estas Eliminado El ID de Registro Nº<?php echo $registro->id_dat_est; ?>','¿Estas seguro de eliminar este registro?',
			  function(ok){
				window.location='datos_estudiante/delete/<?php echo $registro->id_dat_est; ?>';
				alertify.success('Eliminación Exitosa');
			  },
			  function(cancel){
				alertify.message('Cancelado');
			  }); return false" href="#">Eliminar</a></td>
			<td><?php echo anchor('datos_estudiante/pdf/'.$registro->id_dat_est,'Reporte', 'target=_blank') ;?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<div class="pagination"><ul><li><?php echo $paginate; ?></li></ul></div>

<div class="backtotop">
<span id="top" class="dashicons dashicons-arrow-up-alt2"></span>
</div>