﻿<?php
#Declaración de variables con valores absolutos
#$system_path='/home/user/public_html/system/';
#$application_folder='/home/user/public_html/application/';
ob_start();

include_once('index.php');

ob_end_clean();

$ABRKOF = & get_instance();

//var_dump($ABKOF);

?>

<?php
if($ABRKOF->session->get_userdata('usuario_id')!=0){
	echo "Logueado";
} else {
	echo "No logueado";
}
?>