﻿<?php //if(isset($this->pagination)): ?>

<div class="pagination" style="text-align: center;">
    <ul>
        <?php if($this->pagination['first']): ?>

            <li><a class="page" pagina="<?php echo $this->pagination['first']; ?>" href="javascript:void(0);">&Lt;</a></li>

        <?php else: ?>

            <li class="disabled"><span>&Lt;</span></li>

        <?php endif; ?>

        <?php if($this->pagination['previous']): ?>

            <li><a class="page" pagina="<?php echo $this->pagination['previous']; ?>" href="javascript:void(0);">&lt;</a></li>

        <?php else: ?>

            <li class="disabled"><span>&lt;</span></li>

        <?php endif; ?>

        <?php for($i = 0; $i < count($this->pagination['range']); $i++): ?>

            <?php if($this->pagination['current'] == $this->pagination['rango'][$i]): ?>

                <li class="active"><span><?php echo $this->pagination['rango'][$i]; ?></span></li>

            <?php else: ?>

                <li>
                    <a class="page" pagina="<?php echo $this->pagination['range'][$i]; ?>" href="javascript:void(0);">
                        <?php echo $this->pagination['range'][$i]; ?>
                    </a>
                </li>

            <?php endif; ?>

        <?php endfor; ?>

        <?php if($this->pagination['next']): ?>

            <li><a class="page" pagina="<?php echo $this->pagination['next']; ?>" href="javascript:void(0);">&gt;</a></li>

        <?php else: ?>

            <li class="disabled"><span>&gt;</span></li>

        <?php endif; ?>

        <?php if($this->pagination['last']): ?>

            <li><a class="page" pagina="<?php echo $this->pagination['last']; ?>" href="javascript:void(0);">&Gt;</a></li>

        <?php else: ?>

            <li class="disabled"><span>&Gt;</span></li>

        <?php endif; ?>
    </ul>
</div>

<div style="text-align: center">
    <p>
        <small>
            Pagina <?php echo $this->pagination['current']; ?> de <?php echo $this->pagination['total']; ?>
            
            <br>
            
            Registros por pagina: 
            <select id="records" class="span1">
                <?php for($i = 10; $i <= 100; $i += 10): ?>
                    <option value="<?php echo $i; ?>" <?php if($i == $this->pagination['limit']){ echo 'selected="selected"'; } ?>  ><?php echo $i; ?></option>
                <?php endfor;?>
            </select>
        </small>
    </p>
</div>