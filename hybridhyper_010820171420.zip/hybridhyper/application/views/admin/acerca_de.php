<?php //$this->load->view('inicio/headers_check_login');?>
<style type="text/css">
<!--
.Estilo1x {
	color: #21759B;
	font-weight: bold;
}
-->
</style>
<div class="hero-unit">
	<h1> <?php echo VERSION ;?> </h1><p>
	<hr>
	<p> Sistema de Administración de Usuarios - ADUS </p>
	<p> <img src="<?php echo base_url('');?>assets/images/abrkof_logo_x.png" height="300" width="300"> </p>
    <p> Información del Sistema: </p>
	<p> Configuración de Perfiles. </p>
	<p> Administración de Usuarios. </p>
	<p> Registro de Menús "Opciones" (Links, Controladores y sus acciones). </p>
	<p> Configuración de Menús "Seguridad". </p>
	<p> Administración de Contenido. </p>
	<p> Administración de Menú Público. </p>
	<p> Administración de Gráficas Estadísticas y Reportes.</p>
	<?php

	?>
</div>
