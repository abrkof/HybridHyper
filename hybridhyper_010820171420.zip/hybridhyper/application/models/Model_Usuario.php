<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una funci�n.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Model_Usuario Model Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
 
//Creamos la clase del modelo
class Model_Usuario extends Model{
	//Creamos el constructor
	public function __construct(){ 
		parent::__construct();
	}
	
	//Generamos un m�todo para una vista de los datos a obtener
	public function all(){
		$query = $this->db->query('SELECT usuario.*, perfil.perfil as perfil_name
									 FROM usuario
									 left join perfil ON (usuario.perfil_id = perfil.id)');
		return $query;
	}

	//Generamos un m�todo y cargamos los registros de la tabla requerida seg�n su id
	public function allFiltered($id){
		$query = $this->db->by_id('SELECT usuario.*, perfil.perfil as perfil_name
									 FROM usuario
									 left join perfil ON (usuario.perfil_id = perfil.id)
									 WHERE usuario.id = :id', array(':id'=>$id));
		return $query;
	}
	
	//Generamos el m�todo de registro de datos a la tabla
	public function insert($registro){
		$query = $this->db->insert('usuario', $registro);
		return $query;
	}
	
	//Generamos un m�todo para sentencia de actualizacion de datos mediante SQL
	public function update($registro){
        $query = $this->db->update('usuario', $registro, 'id = '.$registro['id'].'');
		return $query;
	}
	
	//Generamos el m�todo de eleminaci�n de registros
	public function delete($id){
		$query = $this->db->delete('usuario', 'id = '.$id.'');
		return $query;
	}

    function get_login($user, $pass){
		$query = $this->db->by_id('SELECT login, password FROM usuario WHERE login = :login AND password = :pwd', 
									array(':login'=>$user['login'], ':pwd'=>$pass['password']));
		return $query;
    }

    function get_perfiles(){
        $lista = array();
        $this->Model_Perfil = $this->load->model('Model_Perfil');
        $registros = $this->Model_Perfil->all();
        foreach ($registros as $registro){
            $lista[$registro->id] = $registro->perfil;
        }
        return $lista;
    }

	//Generamos un m�todo para sentencia de actualizaci�n de datos mediante SQL
	public function find($id){
		$query = $this->db->next_row('SELECT * FROM usuario WHERE id = :id', 
											array(':id'=>$id));
		return $query;
	}

	//Generamos un m�todo para sentencia de actualizaci�n de datos mediante SQL
	public function update_pass($registro){
        $query = $this->db->update('usuario', $registro, 'id = '.$registro['id'].'');
		return $query;
	}

}