<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Controlador para autentificación de usuarios.
if (!function_exists('pathAccess')){
	function pathAccess(){
		$ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librería.
		
		$controlador = $ABRKOF->uri->segment(0);
		$accion = $ABRKOF->uri->segment(1);
		$url = $controlador.'/'.$accion;

		$freeCtrlAcc = array(
			'/',
			'admin/index',
			'admin/acceso_denegado',
			'admin/acerca_de',
			'admin/inicio_sesion',
			'admin/ingresar',
			'admin/cambio_clave',
			'admin/cambiar_clave',
			'admin/salir'
		);

		if(in_array($url, $freeCtrlAcc)){
			return TRUE;
		} else {
			if($ABRKOF->session->get_userdata('usuario_id')){
				if(authorize_menu_submenu()){
					return TRUE;
				} else {
					redirect('admin/acceso_denegado');
				}
			} else {
				redirect('admin/acceso_denegado');
			}
		}
	}
}

function authorize_menu_submenu(){
	$ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librería.

	//El perfil del usuario logueado
	$perfil_id = $ABRKOF->session->get_userdata('perfil_id');

	//Con el controlador, buscar la opción de menú
	$menulib = $ABRKOF->load->library('MenuLib');
	$controlador = $ABRKOF->uri->segment(0);
	$menu_id = $ABRKOF->menulib->findByControlador($controlador)->id;

	if(!$menu_id){
		return FALSE;
	}

	//Recuperar de la tabla de permisos, la combinación Menu - Perfil
	$menu_perfillib = $ABRKOF->load->library('Menu_PerfilLib');
	$acceso = $ABRKOF->menu_perfillib->findByMenuAndPerfil($menu_id, $perfil_id);
		
	
	if(!$acceso){
		return FALSE;
	}
	return TRUE;
}