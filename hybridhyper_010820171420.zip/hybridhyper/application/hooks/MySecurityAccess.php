<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * My Security Access Library Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
//Acceso por autentificación de usuarios.
class CorrectAccess extends Controller{
	function __construct(){
		parent::__construct();
		try{
			$this->ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librería
		}
		catch(Exception $e){
			die($e->getMessage());
		}
    }
	
	public function index(){
	
	}

	public function pathAccess(){

		$controlador = $this->ABRKOF->uri->segment(0);
		$accion = $this->ABRKOF->uri->segment(1);
		$url = $controlador.'/'.$accion;

		$freeCtrlAcc  = array(
			'/',
			'admin/index',
			'admin/acceso_denegado',
			'admin/acerca_de',
			'admin/inicio_sesion',
			'admin/ingresar',
			'admin/cambio_clave',
			'admin/cambiar_clave',
			'admin/salir',
			'datos_estudiante/',
			'datos_estudiante/index',
			'datos_estudiante/validar',
			'datos_estudiante/consultar',
			'webservice4android/',
			'webservice4android/app1'
		);

		if(in_array($url, $freeCtrlAcc)){
			return TRUE;
		} else {
			if($this->ABRKOF->session->get_userdata('usuario_id')){
				if($this->authorize_menu_submenu()){
					return TRUE;
				} else {
					redirect('admin/acceso_denegado');
				}
			} else {
				redirect('admin/acceso_denegado');
			}
		}

	}

	public function authorize_menu_submenu(){
		//El perfil del usuario logueado
		$perfil_id = $this->ABRKOF->session->get_userdata('perfil_id');
	
		//Con el controlador, buscar la opción de menú, Sub Menú.
		$controlador = $this->ABRKOF->uri->segment(0);
		
		$this->menulib = $this->ABRKOF->load->library('MenuLib');
		$this->submenulib = $this->ABRKOF->load->library('SubMenuLib');
		
		$menu_id = $this->menulib->findByControlador($controlador)->id;
		$submenu_id = $this->submenulib->findByControlador($controlador)->id;
	
		if(!$menu_id AND !$submenu_id){
			return FALSE;
		}
	
		//Recuperar de la tabla de permisos, la combinación Menú, Sub Menú - Perfil.
		$this->menu_perfillib = $this->ABRKOF->load->library('Menu_PerfilLib');
		$this->submenu_perfillib = $this->ABRKOF->load->library('SubMenu_PerfilLib');
		$menus = $this->menu_perfillib->findByMenuAndPerfil($menu_id, $perfil_id);
		$submenus = $this->submenu_perfillib->findBySubMenuAndPerfil($submenu_id, $perfil_id);
		
		if(!$menus AND !$submenus){
			return FALSE;
		}
		return TRUE;
	}
}