﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una función.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Menu Controller Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */
 
//Creamos la clase
class Menu extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_Menu = $this->load->model('Model_Menu');
		$this->menulib = $this->load->library('MenuLib');
		$this->menu_perfillib = $this->load->library('Menu_PerfilLib');
    }
    //Creamos una acción principal cargamos las vistas
    public function index(){
		$data['titulo'] = 'Menús';
		$data['query'] = $this->Model_Menu->all();
		$data['contenido'] = 'menu/index';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

    public function create(){
		$data['titulo'] = 'Menús';
		$data['contenido'] = 'menu/create';
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$registro['menu'] = $this->input->post('menu');
		$registro['controlador'] = $this->input->post('controlador');
		$registro['accion'] = $this->input->post('accion');
		$registro['url'] = $this->input->post('url');
		$registro['orden'] = $this->input->post('orden');
		$registro['icon'] = $this->input->post('icon');
		$registro['descripcion'] = $this->input->post('descripcion');
		$registro['created'] = TODAY;
		$registro['updated'] = TODAY;

		$this->Model_Menu->insert($registro);
		
		redirect('menu');
    }

    public function edit($id){
		$data['titulo'] = 'Menús';
		$data['registro'] = $this->Model_Menu->allFiltered($id);
		$data['contenido'] = 'menu/edit';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

    public function update(){
		$registro['id'] = $this->input->post('id');
		$registro['menu'] = $this->input->post('menu');
		$registro['controlador'] = $this->input->post('controlador');
		$registro['accion'] = $this->input->post('accion');
		$registro['url'] = $this->input->post('url');
		$registro['orden'] = $this->input->post('orden');
		$registro['icon'] = $this->input->post('icon');
		$registro['descripcion'] = $this->input->post('descripcion');
		$registro['updated'] = TODAY;

		$this->Model_Menu->update($registro);
		
		redirect('menu');
    }
    
    public function delete($id){
		$this->Model_Menu->delete($id);
		redirect('menu');
    }
#**********************************************************************************#
    //Creamos el metodo de asiganción de permisos
    public function menu_perfiles($menu_id){
		$data['titulo'] = 'Menú Perfiles';
		//Cargar arreglos Izquierda y Derecha
		$perfiles = $this->menulib->get_perfiles_asig_noasig($menu_id);
		$data['query_izq'] = $perfiles[0];
		$data['query_der'] = $perfiles[1];
		$data['contenido'] = 'menu/menu_perfiles';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }

	public function mp_noasig(){
		$perfil_id = $this->input->request('perfil_id');
		$menu_id = $this->input->request('menu_id');
		$this->menu_perfillib->quitar_acceso($perfil_id, $menu_id);
		redirect('menu/menu_perfiles/'.$menu_id);
	}

	public function mp_asig(){
		$perfil_id = $this->input->request('perfil_id');//$this->uri->segment(3);
		$menu_id = $this->input->request('menu_id');//$this->uri->segment(4);
		$this->menu_perfillib->dar_acceso($perfil_id, $menu_id);
		redirect('menu/menu_perfiles/'.$menu_id);
	}
    //Creamos una acción para cargar el ordenar los menús
    public function menu_ordenar(){
		$data['titulo'] = 'Odenando Menús';
		$data['query'] = $this->Model_Menu->allx();
		$data['contenido'] = 'menu/menu_ordenar';
		$data['data'] = $data;
		$this->load->view('template/template',$data);
    }
    //Creamos una acción para actualizar el orden de los menús
    public function update_orden(){
		//aquí ordenaremos los articulos con ajax
		//array con el nuevo orden de nuestros registros
		$menus_ordenados = $this->input->request('menu');
		$pos = 1;
		foreach ($menus_ordenados as $key){
		//actualizamos el campo orden_articulo
		$stmt = $this->dbx->prepare('UPDATE menu SET orden = ? WHERE id = ?');
		$stmt->execute(array($pos, $key));
		$pos++;
		}
		echo "El Menú se ha actualizado con Exito";
	}

}