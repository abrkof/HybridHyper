<?php defined('BASEPATH') OR exit('No direct script access allowed'); //Evita que se ejecute como una funci�n.
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * SubMenu_PerfilLib Library Class
 *
 * @package		HybridHyper
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

class SubMenu_PerfilLib{
private $pdo;
	function __construct(){
		//Realizamos la conexion a la base de datos
		try{
			$this->ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librer�a
		}
		catch(Exception $e){
			die($e->getMessage());
		}
		$this->ABRKOF->Model_SubMenu_perfil = $this->ABRKOF->load->model('Model_SubMenu_Perfil');
    }

    public function my_validation($registro){
        $registro['id'] = $this->input->request('id');
		$registro['submenu_id'] = $this->ABRKOF->input->request('submenu_id');
        $registro['perfil_id'] = $this->ABRKOF->input->request('perfil_id');
		
		$query = $this->ABRKOF->db->get_array('SELECT * FROM submenu_perfil WHERE submenu_id = :submenu_id AND perfil_id = :perfil_id', 
										array(':submenu_id'=>$registro->submenu_id, ':perfil_id'=>$registro->perfil_id));
		
		$rt = redirect('submenu_perfil');
			
        if (count($query) > 0 AND (!isset($registro['id']) OR ($registro['id'] != $stmt->fetchAll('id')))){
            return FALSE;
        } else {
            return $rt;
        }
    }

    public function dar_acceso($perfil_id, $submenu_id){
        $registro['submenu_id'] = $this->ABRKOF->input->request('submenu_id');
        $registro['perfil_id'] = $this->ABRKOF->input->request('perfil_id');
		$registro['created'] = TODAY;
		$registro['updated'] = TODAY;
        $this->ABRKOF->Model_SubMenu_perfil->insert($registro);
    }

    public function quitar_acceso($perfil_id, $submenu_id){
		$query = $this->ABRKOF->db->delete('submenu_perfil', 'perfil_id = '.$perfil_id.' AND submenu_id = '.$submenu_id.'');
		return $query;
    }

    public function findBySubMenuAndPerfil($submenu_id, $perfil_id){
		$query = $this->ABRKOF->db->by_id('SELECT * FROM submenu_perfil WHERE submenu_id = :submenu_id AND perfil_id = :perfil_id',
											array(':submenu_id'=>$submenu_id, ':perfil_id'=>$perfil_id));
		return $query;
    }

}