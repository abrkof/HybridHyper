	function generar_codigo(frm) {
		
    var rt1 = frm.apellidos.value;
    var rt2 = rt1.split(" ");
    codigo = rt1.substr(0,1) + rt2[1].substr(0,1);
	
  frm.id_dat_est.value = frm.apellidos.value.substr(0,1).toUpperCase() + rt2[1].substr(0,1).toUpperCase() + frm.nusr.value + frm.e.value + frm.year.value;
  frm.id_dat_edu.value = frm.apellidos.value.substr(0,1).toUpperCase() + rt2[1].substr(0,1).toUpperCase() + frm.nusr.value + frm.e.value + frm.year.value;
  frm.id_dat_pak.value = frm.apellidos.value.substr(0,1).toUpperCase() + rt2[1].substr(0,1).toUpperCase() + frm.nusr.value + frm.e.value + frm.year.value;
  frm.id_dat_fam.value = frm.apellidos.value.substr(0,1).toUpperCase() + rt2[1].substr(0,1).toUpperCase() + frm.nusr.value + frm.e.value + frm.year.value;
  frm.id_enc_est.value = frm.apellidos.value.substr(0,1).toUpperCase() + rt2[1].substr(0,1).toUpperCase() + frm.nusr.value + frm.e.value + frm.year.value;

}