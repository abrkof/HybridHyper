<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * HybridHyper Base Helpers
 *
 * @package		HybridHyper
 * @subpackage	Helpers
 * @category	Helpers
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

// ------------------------------------------------------------------------

/**
 * Base Helper
 *
 * Creates the opening portion of the form.
 *
 * @access	public
 * @param	string	the URI segments of the form destination
 * @param	array	a key/value pair of attributes
 * @param	array	a key/value pair hidden data
 * @return	string
 */

//Espeficicaci�n o validacion de librerias de terceros.
if (!function_exists('librarypath')){
    function librarypath($libraryClass){
		$customPath = APPPATH.($libraryClass.'.php');
        if(file_exists($customPath)){//Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			include_once ($customPath);
		} else {//Error 404
			throw new Exception('<div class="alert">
				  					<strong>Alerta! </strong>'.'Error, no se puede encontrar labreria de clases - '.$libraryClass.'.php'.' || Ruta - ('.APPPATH.$libraryClass.'.php'.'
				  				</div>');//Tambien se puede usar: trigger_error('Mensaje de error', E_USER_NOTICE); return false;
        }
    }
}

/*if (!function_exists('txt_freeCtrlAcc')){
	function txt_freeCtrlAcc(){
		$HH = & get_instance(); //Instanciamos al super objeto.
		$HH->load->model('Model_Menu_Public');
		
		$filename = "./assets/freeCtrlAcc.txt";
		$text = "";
		
		$lista = array();
		$registros = $HH->Model_Menu_Public->all();
		foreach ($registros as $registro){
			$lista[$registro->id] = $registro->controlador.'/'.$registro->accion.',';
			foreach (explode(',', $lista[$registro->id]) as $option_data){
			$text .= "'".$option_data."',";
			}
		}
		
		$fh = fopen($filename, "w") or die("Imposible abir el archivo.");
		fwrite($fh, $text."'/'") or die("Imposible escribir el archivo!");
		fclose($fh);
	}
}*/


/* End of file base_helper.php */
/* Location: ./system/helpers/base_helper.php */
