<?php defined('BASEPATH') OR exit('Acceso no permitido al n�cleo del sistema, ABRKOF');
/**
 * HybridHyper
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	HybridHyper
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * HybridHyper HTML Helpers
 *
 * @package		HybridHyper
 * @subpackage	Helpers
 * @category	Helpers
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

// ------------------------------------------------------------------------

/**
 * Heading
 *
 * Generates an HTML heading tag.  First param is the data.
 * Second param is the size of the heading tag.
 *
 * @access	public
 * @param	string
 * @param	integer
 * @return	string
 */
if ( ! function_exists('heading')){
	function heading($data = '', $h = '1', $attributes = ''){
		$attributes = ($attributes != '') ? ' '.$attributes : $attributes;
		return "<h".$h.$attributes.">".$data."</h".$h.">";
	}
}

// ------------------------------------------------------------------------

/**
 * Unordered List
 *
 * Generates an HTML unordered list from an single or multi-dimensional array.
 *
 * @access	public
 * @param	array
 * @param	mixed
 * @return	string
 */
if ( ! function_exists('ul')){
	function ul($list, $attributes = ''){
		return _list('ul', $list, $attributes);
	}
}

// ------------------------------------------------------------------------

/**
 * Ordered List
 *
 * Generates an HTML ordered list from an single or multi-dimensional array.
 *
 * @access	public
 * @param	array
 * @param	mixed
 * @return	string
 */
if ( ! function_exists('ol')){
	function ol($list, $attributes = ''){
		return _list('ol', $list, $attributes);
	}
}

// ------------------------------------------------------------------------

/**
 * Generates the list
 *
 * Generates an HTML ordered list from an single or multi-dimensional array.
 *
 * @access	private
 * @param	string
 * @param	mixed
 * @param	mixed
 * @param	integer
 * @return	string
 */
if ( ! function_exists('_list')){
	function _list($type = 'ul', $list, $attributes = '', $depth = 0){
		// If an array wasn't submitted there's nothing to do...
		if ( ! is_array($list)){
			return $list;
		}

		// Set the indentation based on the depth
		$out = str_repeat(" ", $depth);

		// Were any attributes submitted?  If so generate a string
		if (is_array($attributes)){
			$atts = '';
			foreach ($attributes as $key => $val){
				$atts .= ' ' . $key . '="' . $val . '"';
			}
			$attributes = $atts;
		}
		elseif (is_string($attributes) AND strlen($attributes) > 0){
			$attributes = ' '. $attributes;
		}

		// Write the opening list tag
		$out .= "<".$type.$attributes.">\n";

		// Cycle through the list elements.  If an array is
		// encountered we will recursively call _list()

		static $_last_list_item = '';
		foreach ($list as $key => $val){
			$_last_list_item = $key;

			$out .= str_repeat(" ", $depth + 2);
			$out .= "<li>";

			if ( ! is_array($val)){
				$out .= $val;
			}
			else{
				$out .= $_last_list_item."\n";
				$out .= _list($type, $val, '', $depth + 4);
				$out .= str_repeat(" ", $depth + 2);
			}

			$out .= "</li>\n";
		}

		// Set the indentation for the closing tag
		$out .= str_repeat(" ", $depth);

		// Write the closing list tag
		$out .= "</".$type.">\n";

		return $out;
	}
}

// ------------------------------------------------------------------------

/**
 * Generates HTML BR tags based on number supplied
 *
 * @access	public
 * @param	integer
 * @return	string
 */
if ( ! function_exists('br')){
	function br($num = 1){
		return str_repeat("<br />", $num);
	}
}

// ------------------------------------------------------------------------

/**
 * Image
 *
 * Generates an <img /> element
 *
 * @access	public
 * @param	mixed
 * @return	string
 */
if ( ! function_exists('img')){
	function img($src = '', $index_page = FALSE){
		if ( ! is_array($src) ){
			$src = array('src' => $src);
		}

		// If there is no alt attribute defined, set it to an empty string
		if ( ! isset($src['alt'])){
			$src['alt'] = '';
		}

		$img = '<img';

		foreach ($src as $k=>$v){

			if ($k == 'src' AND strpos($v, '://') === FALSE){
				$CI =& get_instance();

				if ($index_page === TRUE){
					$img .= ' src="'.base_url($v)/*$CI->config->site_url($v)*/.'"';
				}
				else{
					$img .= ' src="'.base_url('')/*$CI->config->slash_item('base_url')*/.$v.'"';
				}
			}
			else{
				$img .= " $k=\"$v\"";
			}
		}

		$img .= '/>';

		return $img;
	}
}

// ------------------------------------------------------------------------

/**
 * Doctype
 *
 * Generates a page document type declaration
 *
 * Valid options are xhtml-11, xhtml-strict, xhtml-trans, xhtml-frame,
 * html4-strict, html4-trans, and html4-frame.  Values are saved in the
 * doctypes config file.
 *
 * @access	public
 * @param	string	type	The doctype to be generated
 * @return	string
 */
if ( ! function_exists('doctype')){
	function doctype($type = 'xhtml1-strict'){
		global $_doctypes;

		if ( ! is_array($_doctypes)){
			if (defined('ENVIRONMENT') AND is_file(APPPATH.'config/'.ENVIRONMENT.'/doctypes.php')){
				include(APPPATH.'config/'.ENVIRONMENT.'/doctypes.php');
			}
			elseif (is_file(APPPATH.'config/doctypes.php')){
				include(APPPATH.'config/doctypes.php');
			}

			if ( ! is_array($_doctypes)){
				return FALSE;
			}
		}

		if (isset($_doctypes[$type])){
			return $_doctypes[$type];
		}
		else{
			return FALSE;
		}
	}
}

// ------------------------------------------------------------------------

/**
 * Link
 *
 * Generates link to a CSS file
 *
 * @access	public
 * @param	mixed	stylesheet hrefs or an array
 * @param	string	rel
 * @param	string	type
 * @param	string	title
 * @param	string	media
 * @param	boolean	should index_page be added to the css path
 * @return	string
 */
if ( ! function_exists('link_tag')){
	function link_tag($href = '', $rel = 'stylesheet', $type = 'text/css', $title = '', $media = '', $index_page = FALSE){
		$CI =& get_instance();

		$link = '<link ';

		if (is_array($href)){
			foreach ($href as $k=>$v){
				if ($k == 'href' AND strpos($v, '://') === FALSE){
					if ($index_page === TRUE){
						$link .= 'href="'.base_url($v).'" ';
					}
					else{
						$link .= 'href="'.base_url('').$v.'" ';
					}
				}
				else{
					$link .= "$k=\"$v\" ";
				}
			}

			$link .= "/>";
		}
		else{
			if ( strpos($href, '://') !== FALSE){
				$link .= 'href="'.$href.'" ';
			}
			elseif ($index_page === TRUE){
				$link .= 'href="'.base_url($href).'" ';
			}
			else{
				$link .= 'href="'.base_url('').$href.'" ';
			}

			$link .= 'rel="'.$rel.'" type="'.$type.'" ';

			if ($media	!= ''){
				$link .= 'media="'.$media.'" ';
			}

			if ($title	!= ''){
				$link .= 'title="'.$title.'" ';
			}

			$link .= '/>';
		}


		return $link;
	}
}

//Especificaci�n de headers.
if (!function_exists('headers')){
	function headers(){
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             	// Expira en fecha pasada
		//header("Expires", 0);
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");	// Siempre p�gina modificada
		header("Cache-Control: no-cache, must-revalidate");           	// Evitar guardado en cache del cliente HTTP/1.1
		header("Cache-Control: no-store");
		header("Pragma: no-cache");                               		// Evitar guardado en cache del cliente HTTP/1.0
	}
}

$css_folder = 'assets';
$js_folder = 'assets';
//SELF deveulve: basename($_SERVER['PHP_SELF']), el nombre del archivo actual 'abierto'.
//SELF deveulve: basename($_SERVER['SCRIPT_NAME']), el nombre del archivo actual 'abierto'.
//parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH), devuelve la ruta completa el archivo actual 'abierto'.

//Ruta de la carpeta "css"
if (is_dir($css_folder)){
	define('CSSPATH', $css_folder.'/');
} else {
	if (!is_dir(BASEPATH.$css_folder.'/')){
		exit('La ruta de la carpeta CSS no parece estar configurada correctamente. Por favor, abra el archivo "'.pathinfo(__FILE__, PATHINFO_BASENAME).'" y corr�galo'.' || RUTA - '.APPPATH.'helpers');
	}
	define('CSSPATH', BASEPATH.$css_folder.'/');
}

//Ruta de la carpeta "js"
if (is_dir($js_folder)){
	define('JSPATH', $js_folder.'/');
} else {
	if (!is_dir(BASEPATH.$js_folder.'/')){
		exit('La ruta de la carpeta JS no parece estar configurada correctamente. Por favor, abra el archivo "'.pathinfo(__FILE__, PATHINFO_BASENAME).'" y corr�galo'.' || RUTA - '.APPPATH.'helpers');
	}
	define('JSPATH', BASEPATH.$js_folder.'/');
}


//Espeficicaci�n o validacion de hojas de estilo.
if (!function_exists('css')){
    function css($css){
		$pathCSS = CSSPATH.('css/'.$css.'.css');
        if(file_exists($pathCSS)){//Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			echo '<link rel="stylesheet" href="'.base_url('').$pathCSS.'"/>';
		} else {//Error 404
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo '<div class="alert">
				  	<strong>Alerta! </strong>'.'Error, no se puede encontrar la hoja de estilo - '.$css.'.css'.' || Ruta - (assets/css)'.'
				  </div>';
			exit(3); //EXIT_CONFIG
        }
    }
}

//Espeficicaci�n o validacion de archivos javascript.
if (!function_exists('js')){
    function js($js){
		$pathJS = JSPATH.('js/'.$js.'.js');
        if(file_exists($pathJS)){//Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			echo '<script src="'.base_url('').$pathJS.'"></script>';
		} else {//Error 404
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo '<div class="col-xs-3">
					<div class="alert alert-warning">
				  		<strong>Alerta! </strong>'.'Error, no se puede encontrar el archivo javascript - '.$js.'.js'.' || Ruta - (assets/js)'.'
				  	</div>
				  </div>';
			exit(3); //EXIT_CONFIG
        }
    }
}

//Espeficicaci�n o validacion de hojas de estilo.
if (!function_exists('packstylecss')){
    function packstylecss($packstylecss){
		$pathJS_CSS = CSSPATH.($packstylecss.'.css');
        if(file_exists($pathJS_CSS)){//Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			echo '<link rel="stylesheet" href="'.base_url('').$pathJS_CSS.'"/>';
		} else {//Error 404
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo '<div class="col-xs-3">
					<div class="alert alert-warning">
				  		<strong>Alerta! </strong>'.'Error, no se puede cargar la hoja de estilo - '.$packstylecss.'.css'.' || Ruta - (assets/)'.'
				  	</div>
				  </div>';
			exit(3); //EXIT_CONFIG
        }
    }
}

//Espeficicaci�n o validacion de archivos javascript.
if (!function_exists('packstylejs')){
    function packstylejs($packstylejs){
		$pathJS_CSS = JSPATH.($packstylejs.'.js');
        if(file_exists($pathJS_CSS)){//Se puede usar file_exists o is_readable para verificar la existencia o lectura del archivo requerido.
			echo '<script src="'.base_url('').$pathJS_CSS.'"></script>';
		} else {//Error 404
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo '<div class="col-xs-3">
					<div class="alert alert-warning">
				  		<strong>Alerta! </strong>'.'Error, no se puede cargar el archivo javascript - '.$packstylejs.'.js'.' || Ruta - (assets/)'.'
				  	</div>
				  </div>';
			exit(3); //EXIT_CONFIG
        }
    }
}

//Espeficicaci�n o validacion de componete personalizado "Select o Dropdown".
if (!function_exists('my_dropdown')){
    function my_dropdown($name, $id ,$array_data, $option_data, $extra){
		echo '<select name="'.$name.'" id="'.$id.'" '.$extra.'>
				<option selected="selected">Elija l@s '.ucfirst($name).'</option>';
				foreach (explode(',', $array_data) as $option_data){
				echo '<option value="'.$option_data.'">'.$option_data.'</option>';
				}
		echo '</select> ';
    }
}

//Carga componentes de una carpeta.
if (!function_exists('imagepath')){
	function imagepath($folder){
		if(is_dir($folder)){
			if($dir = opendir($folder)){
				while(($file = readdir($dir)) !== false){
					if($file != '.' && $file != '..' && $file != '.htaccess'){
						echo '<img src="'.$folder.'/'.$file.'"  style="height:400px; width:600px"> ';
					}
				}
				closedir($dir);
			}
		}
	}
	//echo csspath('assets/image/');
}


/*if (!function_exists('set_css')){
    function set_css(array $css){
        $css = array();
		$pathCSS = CSSPATH.('css/'.$css.'.css');
        if(is_array($css) && count($css)){
            for($i=0; $i < count($css); $i++){
                return $css[] = '<link rel="stylesheet" href="'.base_url('').CSSPATH.('assets/css/'.$css[$i++].'.css').'"/>';
            }
        } else {
			header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
			echo 'Error, no se puede cargar la hoja de estilo - '.$css.'.css'.' || Ruta - (assets/css)';
			exit(3); //EXIT_CONFIG
        }
    }
}

if (!function_exists('set_css')){
    function set_css(array $css){
        $css = array();
		$pathCSS = CSSPATH.('css/'.$css.'.css');
		foreach($pathCSS as $folder){
			if (file_exists($folder)){
				echo '<link rel="stylesheet" href="'.base_url('').$folder.'"/>';
			}
		}
    }
}*/


// ------------------------------------------------------------------------

/**
 * Generates meta tags from an array of key/values
 *
 * @access	public
 * @param	array
 * @return	string
 */
if ( ! function_exists('meta')){
	function meta($name = '', $content = '', $type = 'name', $newline = "\n"){
		// Since we allow the data to be passes as a string, a simple array
		// or a multidimensional one, we need to do a little prepping.
		if ( ! is_array($name)){
			$name = array(array('name' => $name, 'content' => $content, 'type' => $type, 'newline' => $newline));
		}
		else{
			// Turn single array into multidimensional
			if (isset($name['name'])){
				$name = array($name);
			}
		}

		$str = '';
		foreach ($name as $meta){
			$type		= ( ! isset($meta['type']) OR $meta['type'] == 'name') ? 'name' : 'http-equiv';
			$name		= ( ! isset($meta['name']))		? ''	: $meta['name'];
			$content	= ( ! isset($meta['content']))	? ''	: $meta['content'];
			$newline	= ( ! isset($meta['newline']))	? "\n"	: $meta['newline'];

			$str .= '<meta '.$type.'="'.$name.'" content="'.$content.'" />'.$newline;
		}

		return $str;
	}
}

// ------------------------------------------------------------------------

/**
 * Generates non-breaking space entities based on number supplied
 *
 * @access	public
 * @param	integer
 * @return	string
 */
if ( ! function_exists('nbs')){
	function nbs($num = 1){
		return str_repeat("&nbsp;", $num);
	}
}


/* End of file html_helper.php */
/* Location: ./system/helpers/html_helper.php */