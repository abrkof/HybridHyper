﻿<?php defined('BASEPATH') OR exit('Acceso no permitido al núcleo del sistema, ABRKOF');

/**
 * CodeIgniter
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2014 - 2016, British Columbia Institute of Technology
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	CodeIgniter
 * @author	EllisLab Dev Team
 * @copyright	Copyright (c) 2008 - 2014, EllisLab, Inc. (https://ellislab.com/)
 * @copyright	Copyright (c) 2014 - 2016, British Columbia Institute of Technology (http://bcit.ca/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	https://codeigniter.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * Pagination Class
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Pagination
 * @author		EllisLab Dev Team
 * @link		https://codeigniter.com/user_guide/libraries/pagination.html
 */

class Pagination{
    private $dates;
    private $pagination;
    
    public function __construct(){
        $this->dates = array();
        $this->pagination = array();
    }
    
    public function paginate($query, $page = false, $limit = false, $pagination = false){
        if($limit && is_numeric($limit)){
            $limit = $limit;
        } else {
            $limit = 10;
        }
        
        if($page && is_numeric($page)){
            $page = $page;
            $start = ($page - 1) * $limit;
        } else {
            $page = 1;
            $start = 0;
        }
        
        $records = count($query);
        $total = ceil($records / $limit);
        $this->dates = array_slice($query, $start, $limit);
               
        $pagination = array();
        $pagination['current'] = $page;
        $pagination['total'] = $total;
        $pagination['limit'] = $limit;
        
        if($page > 1){
            $pagination['first'] = 1;
            $pagination['previous'] = $page - 1;
        } else {
            $pagination['first'] = '';
            $pagination['previous'] = '';
        }
        
        if($page < $total){
            $pagination['last'] = $total;
            $pagination['next'] = $page + 1;
        } else {
            $paginacion['last'] = '';
            $paginacion['nex'] = '';
        }
        
        $this->pagination = $pagination;
		$this->rangePagination($pagination);
        
        return $this->dates;
    }
    
    private function rangePagination($limit = false){
        if($limit && is_numeric($limit)){
            $limit = $limit;
        } else {
            $limit = 10;
        }
        
        $total_pages = $this->pagination['total'];
        $page_selected = $this->pagination['current'];
        $range = ceil($limit / 2);
        $pages = array();
        
        $range_right = $total_pages - $page_selected;
        
        if($range_right < $range){
            $remainder = $range - $range_right;
        } else {
            $remainder = 0;
        }
        
        $range_left = $page_selected - ($range + $remainder);
        
        for($i = $page_selected; $i > $range_left; $i--){
            if($i == 0){
                break;
            }
            
            $pages[] = $i;
        }
        
        sort($pages);
        
        if($page_selected < $rango){
            $range_right = $limit;
        } else {
            $range_right = $page_selected + $range;
        }
        
        for($i = $page_selected + 1; $i <= $range_right; $i++){
            if($i > $total_pages){
                break;
            }
            
            $pages[] = $i;
        }
        
        $this->pagination['range'] = $pages;
        
        return $this->pagination;
        
    }

	public function view($view, $link = false){
		$pathView = APPPATH.('views/'.$view.'.php');
		
		if($link)
		$link = base_url('').$link.'/';
		
		if(is_readable($pathView)){
			ob_start();
			
			include $pathView;
			
			$content = ob_get_contents();
			
			ob_end_clean();
			
			return $content;
		}
		
		throw new Exception('Error de paginación');		
	}
	
}
