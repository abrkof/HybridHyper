<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * ADUS CI
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	ADUS CI
 * @author	ABRKOF
 * @copyright	Copyright (c) 2015 - 2017, Carlos Abraham Ayala Herrera (http://www.abrkof.com/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://www.abrkof.com
 * @since	Version 1.0.0
 * @filesource
 */

/**
 * DB_Backup Controller Class
 *
 * @package		ADUS CI
 * @subpackage	Libraries
 * @category	Libraries
 * @author		Carlos Abraham Ayala Herrera
 * @link		http://www.abrkof.com/
 */

class DB_Backup extends Controller {

	//Constructor de Clase
	function __construct() {
		parent::__construct();
		echo librarypath('third_party/db_backup/db.backup.class');
		$this->db_backup = new dbBackup;
	}

    // Creamos una accion principal y cargamos las vistas
    public function index(){
        $data['titulo'] = 'Bienvenido';
		$data['contenido'] = 'home';
		$this->load->view('template/template',$data);
    }

	public function backup (){
		 //$this->accessregistrylib->my_access_registry();
		 
		 $logued = $this->session->get_userdata('usuario_id');
		 //$session = $this->session->userdata('session_id');
		
		if($logued == FALSE /*|| $session === FALSE */){ /* por seguridad hacemos doble verificaci�n; aunque estas 
													   * 2 variables siempre van a tener el mismo estado */
			redirect('admin/acceso_denegado'); 
			exit();
		 } else {

			$this->db_backup->backup();

			echo packstylecss('alertifyjs/css/themes/default.min');
			echo packstylecss('alertifyjs/css/alertify.min');
			echo packstylejs('alertifyjs/alertify.min');
	
			echo "<script>
				function error_pwdusr(){
					var alert = alertify.alert('Generando script sql en archivo zip!','El respaldo de la base de datos se ha generado con exito!', function (e){     	 
					alert.set({transition:'flipx'}); //slide, zoom, flipx, flipy, fade, pulse (default)
					alert.set('modal', false);  //al pulsar fuera del dialog se cierra o no
						if (e){
							//window.location='".host_url('')."inicio/acerca_de';
							alertify.success('Proceso realizado con Exito!');
							//alertify.error('Puedes regresar a la pagina anterior.');
							//alertify.warning('Puedes regresar a la pagina anterior.');
							//alertify.message('Puedes regresar a la pagina anterior.');
						} else {
							return false;
						}
					}).set('label', 'Aceptar');
					return true;
				}
			
				error_pwdusr();
				</script>";
		}
	
	 }

}