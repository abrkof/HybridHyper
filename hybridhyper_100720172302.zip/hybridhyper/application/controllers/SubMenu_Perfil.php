﻿<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Creamos la clase
class SubMenu_Perfil extends Controller{
    //Creamos el constructor que cargara los metodos del modelo requerido
    public function __construct(){
		parent::__construct();
		//Instanciamos a la clase
		$this->Model_SubMenu_perfil = $this->load->model('Model_SubMenu_Perfil');
    }

    public function index(){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin');
            exit;
        } else {
			$data['titulo'] = 'Seguridad (Sub Menús)';
			$data['query'] = $this->Model_SubMenu_perfil->all();
			$data['contenido'] = 'submenu_perfil/index';
			$this->load->view('template/template',$data);
		}
    }

    public function create(){
		$data['titulo'] = 'Seguridad (Sub Menús)';
		$data['submenus'] = $this->Model_SubMenu_perfil->get_submenus(); /* Lista de los Sub Menús */
		$data['perfiles'] = $this->Model_SubMenu_perfil->get_perfiles(); /* Lista de los Perfiles */
		$data['contenido'] = 'submenu_perfil/create';
		$this->load->view('template/template',$data);
    }
    
    public function insert(){
		$registro['submenu_id'] = $_REQUEST['submenu_id'];
		$registro['perfil_id'] = $_REQUEST['perfil_id'];
		$registro['created'] = date('Y/m/d H:i:s');
		$registro['updated'] = date('Y/m/d H:i:s');

		//$myCallback = new SubMenu_PerfilLib();
		//Llamada al método de un objeto
		//if (call_user_func(array($myCallback, 'my_validation')));

		$this->Model_SubMenu_perfil->insert($registro);
		
		redirect('submenu_perfil');
    }

    public function edit($id){
		$data['titulo'] = 'Seguridad (Sub Menús)';
		$data['submenus'] = $this->Model_SubMenu_perfil->get_submenus(); /* Lista de los Sub Menús */
		$data['perfiles'] = $this->Model_SubMenu_perfil->get_perfiles(); /* Lista de los Perfiles */
		$data['registro'] = $this->Model_SubMenu_perfil->allFiltered($id);
		$data['contenido'] = 'submenu_perfil/edit';
		$this->load->view('template/template',$data);
    }
    
    public function update(){
		$registro['id'] = $_REQUEST['id'];
		$registro['submenu_id'] = $_REQUEST['submenu_id'];
		$registro['perfil_id'] = $_REQUEST['perfil_id'];
		$registro['updated'] = date('Y/m/d H:i:s');

		//$myCallback = new SubMenu_PerfilLib();
		//Llamada al método de un objeto
		//if (call_user_func(array($myCallback, 'my_validation')));

		$this->Model_SubMenu_perfil->update($registro);
		
		redirect('submenu_perfil');
    }
    
    public function delete($id){
        if(!$this->session->get_userdata('usuario_id')){
            redirect('admin');
            exit;
        } else {
			$this->Model_SubMenu_perfil->delete($id);
			redirect('submenu_perfil');
		}
    }
}