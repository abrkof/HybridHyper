<?php $this->load->view('admin/headers_check_login');?>

<body onload="find_location();return false;">

<div class="hero-unit">
<img src="<?php echo base_url('');?>assets/images/abrkof_logo_x.png" height="300" width="300">
	<h1> Sistema de Administración de Usuarios </h1>
	<hr>
	<p> Sistema de Administracion de Usuarios - ADUS </p>
    <p> Para acceder a las opciones del sistema debe autenticarse como usuario del mismo. </p>
</div>
</body>