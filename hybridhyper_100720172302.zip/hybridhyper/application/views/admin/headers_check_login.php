<?php
echo headers();
$loguedx = ($this->session->get_userdata('usuario_id'));
if(!$loguedx){
	$this->session->sess_destroy();
	redirect('admin/acceso_denegado');
	exit();
}	
?>