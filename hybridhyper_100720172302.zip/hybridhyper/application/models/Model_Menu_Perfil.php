<?php defined('BASEPATH') OR exit('No direct script access allowed');
//error_reporting(0);
//Creamos la clase del modelo
class Model_Menu_Perfil extends Model{
	//Creamos el constructor
	public function __construct(){ 
		parent::__construct();
	}
	
	//Generamos un m�todo para una vista de los datos a obtener
	public function all(){
		$query = $this->db->query('SELECT menu_perfil.*, perfil.perfil as perfil_name, menu.menu as menu_name
									 FROM menu_perfil
									 left join perfil ON (menu_perfil.perfil_id = perfil.id)
									 left join menu ON (menu_perfil.menu_id = menu.id)');
		return $query;

	}

	//Generamos un m�todo y cargamos los registros de la tabla requerida seg�n su id
	public function allFiltered($id){
		$query = $this->dbx->query('SELECT menu_perfil.*, perfil.perfil as perfil_name, menu.menu as menu_name
									 FROM menu_perfil
									 left join perfil ON (menu_perfil.perfil_id = perfil.id)
									 left join menu ON (menu_perfil.menu_id = menu.id)
									 WHERE menu_perfil.id = ?');
		return $query;
	}
	
	//Generamos el m�todo de registro de datos a la tabla
	public function insert($registro){
		$query = $this->db->insert('menu_perfil', $registro);
		return $query;
	}
	
	//Generamos un m�todo para sentencia de actualizacion de datos mediante SQL
	public function update($registro){
        $query = $this->db->update('menu_perfil', $registro, 'id = '.$registro['id'].'');
		return $query;
	}
	
	//Generamos el m�todo de eleminaci�n de registros
	public function delete($id){
		$query = $this->db->delete('menu_perfil', 'id = '.$id.'');
		return $query;
	}

    function get_menus(){
        $lista = array();
        $this->Model_Menu = $this->load->model('Model_Menu');
        $registros = $this->Model_Menu->all();
        foreach ($registros as $registro) {
            $lista[$registro->id] = $registro->name;
        }
        return $lista;
    }

    function get_perfiles(){
        $lista = array();
        $this->Model_Perfil = $this->load->model('Model_Perfil');
        $registros = $this->Model_Perfil->all();
        foreach ($registros as $registro) {
            $lista[$registro->id] = $registro->name;
        }
        return $lista;
    }

}