<?php if (!defined('BASEPATH')) exit('No permitir el acceso directo al script');
class SubMenu_PerfilLib{
private $pdo;
	function __construct(){
		//Realizamos la conexion a la base de datos
		try{
			$this->ABRKOF = & get_instance(); //Esto para acceder a la instancia que carga la librer�a
		}
		catch(Exception $e){
			die($e->getMessage());
		}
		$this->ABRKOF->Model_SubMenu_perfil = $this->ABRKOF->load->model('Model_SubMenu_Perfil');
    }

    public function my_validation($registro){
        $registro['id'] = $_REQUEST['id'];
		$registro['submenu_id'] = $_REQUEST['submenu_id'];
        $registro['perfil_id'] = $_REQUEST['perfil_id'];
		
		$query = $this->ABRKOF->db->get_array('SELECT * FROM submenu_perfil WHERE submenu_id = :submenu_id AND perfil_id = :perfil_id', 
										array(':submenu_id'=>$registro->submenu_id, ':perfil_id'=>$registro->perfil_id));
		
		$rt = redirect('submenu_perfil');
			
        if (count($query) > 0 AND (!isset($registro['id']) OR ($registro['id'] != $stmt->fetchAll('id')))){
            return FALSE;
        }
        else{
            return $rt;
        }
    }

    public function dar_acceso($perfil_id, $submenu_id){
        if(isset($_REQUEST['id'])){
            $submenu_id = $_REQUEST['submenu_id'];
			$perfil_id = $_REQUEST['perfil_id'];
        }
        $registro['id'] = $_REQUEST['id'];
        $registro['submenu_id'] = $_REQUEST['submenu_id'];
        $registro['perfil_id'] = $_REQUEST['perfil_id'];
        $this->ABRKOF->Model_SubMenu_perfil->insert($registro);
    }

    public function quitar_acceso($perfil_id, $submenu_id){
        if(isset($_REQUEST['id'])){
            $submenu_id = $_REQUEST['submenu_id'];
			$perfil_id = $_REQUEST['perfil_id'];
        }
		$query = $this->ABRKOF->db->delete('submenu_perfil', 'perfil_id = '.$perfil_id.' AND submenu_id = '.$submenu_id.'');
		return $query;
    }

    public function findBySubMenuAndPerfil($menu_id, $perfil_id){
		$stmt = $this->ABRKOF->db->row_count('SELECT * FROM submenu_perfil WHERE menu_id = :menu_id AND perfil_id = :perfil_id',
											array(':menu_id'=>$registro->menu_id, ':perfil_id'=>$registro->perfil_id));
		return $query;
    }

}