﻿<?php
#Declaración de variables con valores absolutos
#$system_path='/home/user/public_html/system/';
#$application_folder='/home/user/public_html/application/';
ob_start();

include_once('index.php');

ob_end_clean();

$abrkof = & get_instance();

var_dump($abrkof);

?>

<?php
//$abrkof->load->library('session');
if($abrkof->session->get_userdata('usuario')!=0){
echo "Logueado";
}
else{
echo "No logueado";
}
?>