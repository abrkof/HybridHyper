﻿function error_pwdusr(){
	var alert = alertify.alert('Error de Validación','La Nueva Contraseña No Coincide Con La Contraseña Actual', function (e){     	 
	alert.set({transition:'flipx'}); //slide, zoom, flipx, flipy, fade, pulse (default)
	alert.set('modal', false);  //al pulsar fuera del dialog se cierra o no
		if (e){
			window.location='inicio/home';
		} else {
			return false;
		}
	}).set('label', 'Aceptar');
	return true;
}

error_pwdusr();